########################################################################################
# File    : findScore.py
#
# Creator : <Instructor/teacher of a course>
#
# Purpose : This file is to evaluate a student's answer(s) to the question(s) given through Jupyter Notebook, and
#           to assign a score to each answer.
#
# Details : 1) It defines a main() function which takes as input the answer(s) given by students, and returns
#              the score against each answer, along with overall accuracy.
#
#           2) The input parameter to the main function is a Python list "ans".
#
#           3) Each element of "ans" is expected to have the student's answer to the corresponding question
#              as per the Jupyter Notebook of the exercise.
#              For example, the "ans[0]" is expected to have the answer to "Question 1", the "ans[1]" to "Question 2",
#              and so on.
#
#           4) The element of "ans" is restricted to be of simple data-type such as integer, float, string, or list of
#              any of these types. It is possible to have heterogeneous elements - e.g. ans[0] is an integer, ans[1] is
#              a string, ans[2] is a list of real numbers.
#
#           5) Each element of the answer must be evaluated individually, and their score to be populated in a return variable.
#
#           6) The return variable is to be in JSON format. The format of its fields is given below:
#
#              {
#                 "status"   : "Success",
#                 "response" :
#                  [
#                     { "question":1, "obtained_marks":1, "total_marks":1 },
#                     { "question":2, "obtained_marks":0, "total_marks":4 },
#                     { "question":3, "obtained_marks":3, "total_marks":5 }
#                  ],
#                 "accuracy" : 0.4,
#              }
#
#              - In the above example, the Jupyter Notebook asked 3 questions - Question 1, Question 2 and Question 3.
#
#              - Assign "status" as "Failure", in case the evaluation function encounters a programmatic error
#                (memory outage, number of elements of "ans" does not match number of asked questions etc.).
#                Else, assign "status" as "Success".
#
#              - "response" is a list of elements. The number of elements should be equal to the number of questions
#                asked in the Jupyter Notebook.
#                Each element of "response" must have following 3 fields:
#                      i) "questions"      : to denote the question number as in the Jupyter Notebook.
#                     ii) "obtained_marks" : marks obtained by the student for this question.
#                    iii) "total_marks"    : total marks for this question
#
#              - "accuracy", whose value is between 0 and 1, is to be computed is an aggregate of obtained marks
#                over all questions.
#                In this example, accuracy = (1+0+3)/(1+4+5) = 0.4.
#
########################################################################################


import ast


def main(ans):
    res = {}
    res["status"] = 'Success'
    res["response"] = []
    try:
        score = 1 if ans[0] == "                                                 App  Rating   Reviews  Size  \\\n0     Photo Editor & Candy Camera & Grid & ScrapBook     4.1     159.0  19.0   \n1                                Coloring book moana     3.9     967.0  14.0   \n2  U Launcher Lite \u00e2\u0080\u0093 FREE Live Cool Themes, Hid...     4.7   87510.0   8.7   \n3                              Sketch - Draw & Paint     4.5  215644.0  25.0   \n4              Pixel Draw - Number Art Coloring Book     4.3     967.0   2.8   \n\n     Installs  Price  \n0     10000.0    0.0  \n1    500000.0    0.0  \n2   5000000.0    0.0  \n3  50000000.0    0.0  \n4    100000.0    0.0  " else 0
        res["response"].append(
            {"question": 1, "obtained_marks": score, "total_marks": 1})

        score = 1 if ans[1] == "            Rating       Reviews         Size      Installs        Price\ncount  7729.000000  7.729000e+03  7729.000000  7.729000e+03  7729.000000\nmean      4.173852  2.946726e+05    37.284513  8.417734e+06     1.127614\nstd       0.544563  1.863227e+06    93.509493  5.013846e+07    17.401297\nmin       1.000000  1.000000e+00     1.000000  1.000000e+00     0.000000\n25%       4.000000  1.080000e+02     6.100000  1.000000e+04     0.000000\n50%       4.300000  2.328000e+03    16.000000  1.000000e+05     0.000000\n75%       4.500000  3.896100e+04    37.000000  1.000000e+06     0.000000\nmax       5.000000  4.489389e+07   994.000000  1.000000e+09   400.000000" else 0
        res["response"].append(
            {"question": 2, "obtained_marks": score, "total_marks": 1})

        score = 1 if int(ans[2]) == 16 else 0
        res["response"].append(
            {"question": 3, "obtained_marks": score, "total_marks": 1})

        if (ast.literal_eval(ans[3]) == (0.42,0.53)):
            score = 2
        elif (ast.literal_eval(ans[3])[0] == 0.42):
            score = 1
        elif (ast.literal_eval(ans[3])[1] == 0.53):
            score = 1
        else:
            score = 0
        res["response"].append(
            {"question": 4, "obtained_marks": score, "total_marks": 2})

        score = 1 if ans[4] == 'n' else 0
        res["response"].append(
            {"question": 5, "obtained_marks": score, "total_marks": 1})

        score = 1 if int(ans[5]) == 100000 else 0
        res["response"].append(
            {"question": 6, "obtained_marks": score, "total_marks": 1})

        if (ast.literal_eval(ans[6]) == (0.40,0.42)):
            score = 2
        elif (ast.literal_eval(ans[6])[0] == 0.40):
            score = 1
        elif (ast.literal_eval(ans[6])[1] == 0.42):
            score = 1
        else:
            score = 0
        res["response"].append(
            {"question": 7, "obtained_marks": score, "total_marks": 2})

        score = 1 if ans[7] == 'n' else 0
        res["response"].append(
            {"question": 8, "obtained_marks": score, "total_marks": 1})
        
        res["accuracy"] = sum(list(item['obtained_marks'] for item in res["response"])) / sum(
            list(item['total_marks'] for item in res["response"]))
        return res

    except:
        return {'status': 'Failure'}
