# it will call the moodle_course_upload
# import moodle_course_upload

import mongodb_local

print ("Thanks")