from pymongo import MongoClient
import pymongo
import pprint
import gridfs
import sys 
import csv_to_json as csj

print("\n", "******************************* Upload Course in MongoDB *******************************")

course = csj.course
host = input("Enter the MongoDB server hostname : ")
port = input("Enter the MongoDB server port no. : ")

myclient = MongoClient("mongodb://" + host + ":" + port + "/") # "mongodb://localhost:27017/" 
# print(myclient.MongoClient)
# sys.exit()

db_name = input("Enter the database name in which you wish to upload the course : ")
col_name = input("Enter the collection name in which you wish to upload the course : ")
dblist = myclient.list_database_names()
# print(dblist)
if db_name in dblist:
    print('\n', "The database exists", '\n')
    mydb = myclient[db_name]
    mycol = mydb[col_name]
    # docs = mycol.count_documents({}) 
    # print ("doc count:", docs, "for", mycol.name)
    # dblist = myclient.list_database_names()
    # collist = mydb.list_collection_names()
    # print(dblist,collist)
    for i in range(len(course)):
        try:
            mydict = course[str(i)]
            xy = mycol.insert_one(mydict)
        except:
            print("There is already a course with this name, so please change it!")
            sys.exit()
    
    for i in range(len(course)):
        for x in mycol.find({ "course_title": course[str(i)]['course_title']}):
            if x['course_title'] == course[str(i)]['course_title'] and x['course_short_name'] == course[str(i)]['course_short_name']:
                print("The course also uploaded in the database successfully.")
            else:
                print("The course is not uploaded successfully, please try again later")
                sys.exit()
else:
    print("\nThe database doesn't exist", '\n')
    print("We can create the database for you if you want then write 'yes' or press 'no'", '\n')
    c = str(input("Enter your choice : "))
    if c == 'yes':
        my_db = myclient[db_name]
        my_col_1 = my_db[col_name]
        for i in range(len(course)):
            my_dict_1 = course[str(i)]
            xy = my_col_1.insert_one(my_dict_1)
            # print(xy)
        my_col_2 = my_db['users']
        my_dict_2 = { "name": "Demo subham", "address": "demo Highway 37" }
        x = my_col_2.insert_one(my_dict_2)
        dblist = myclient.list_database_names()
        collist = my_db.list_collection_names()
        # print(dblist, collist)
        if db_name in dblist and col_name in collist:
            print("Database and collection created successfully.", '\n')
            for i in range(len(course)):
                for x in my_col_1.find({ "course_title": course[str(i)]['course_title']}):
                    if x['course_title'] == course[str(i)]['course_title'] and x['course_short_name'] == course[str(i)]['course_short_name']:
                        print("The course also uploaded in the database successfully.")
                    else:
                        print("The course is not uploaded successfully, please try again later")
                        sys.exit()
        else:
            print("Something wrong happened while creating database and collection, please check the MongoDB connection and try again later")
            sys.exit()
    else:
        sys.exit("Script stopped")
