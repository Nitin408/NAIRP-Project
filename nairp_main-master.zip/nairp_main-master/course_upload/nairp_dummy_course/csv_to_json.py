import csv, sys
import json
import time
import pandas as pd
import pprint
# from pymongo import MongoClient
# import pymongo

###########################

# Mongodb Connection

# myclient = MongoClient("mongodb://localhost:27017/")
# mydb = myclient["nairp-database"]

######################################################

#################### All Global variable are declared here

error = []
mou_id = []
lec_id = []
exe_id = []
pro_work_id = []
que_id = []
ans_id = []
ins_id = []
ref_id = []
con_id = []

######################################################

######## Define all the function below ##########

def miss_value_fun(course):
    global error, mou_id, lec_id, exe_id, pro_work_id, que_id, ans_id, ins_id, ref_id, con_id
    # check wether all the mandatory feilds have values or not
    ############################################# Course sheet #############################################
    
    l = json.loads(course[0].to_json(orient ='index'))
    for i in range(len(l)):
        cour_error = []
        for v in l[str(i)]:
            if v != 'course_intro_video' or v != 'prerequisite_preexisting_course_title_list' or v != 'reference_materials_ref' or v != 'copyright_message':    
                if l[str(i)][v] == None or l[str(i)][v] == 'None' or l[str(i)][v] == 'none':
                    cour_error.append(v)
                else:
                    continue
            else:
                continue
        if len(cour_error) > 0:
            if len(cour_error) == len(v)-1:
                error.append(l[str(i)]['course_title'] + " course doesn't have any record, so please provide it!")
            else:
                for k in range(len(cour_error)):
                    error.append(l[str(i)]['course_title'] + " course doesn't have any value in " + cour_error[k] +" column, so please provide it!")
    
    ############################################# Module sheet #############################################
   
    module_details = json.loads(course[1].to_json(orient ='index'))
    for k,v in module_details.items():
        mod_error = []
        for g in v:
            if g == 'module_id':
                mou_id.append(v[g])
            if g != 'exercise_ref':
                if v[g] == None or v[g] == 'None' or v[g] == 'none':
                    mod_error.append(g)
                else:
                    continue
        if len(mod_error) > 0:
            if len(mod_error) == len(v)-1:
                error.append(str(v['module_id']) + " no. module id doesn't have any record, so please provied it!")
            else:
                for k in range(len(mod_error)):
                    error.append(str(v['module_id']) + " no. module id doesn't have any value in " + mod_error[k] +" column, so please provide it!")
    
     ############################################ Lecture sheet ##############################################
    
    lecture_details = json.loads(course[2].to_json(orient ='index'))
    for k,v in lecture_details.items():
        lec_error = []
        for g in v:
            if g == 'lecture_id':
                lec_id.append(v[g])
            if g != 'lecture_note' or g != 'worked_out_worksheet':
                if v[g] == None or v[g] == 'None' or v[g] == 'none':
                    lec_error.append(g)
                else:
                    continue
        if len(lec_error) > 0:
            if len(lec_error) == len(v)-1:
                error.append(str(lecture_details[k]['lecture_title'])+ " no. lecture id doesn't have any record, so please provide it!")
            else:
                for p in range(len(lec_error)):
                    error.append(str(lecture_details[k]['lecture_id']) + " no. lecture id doesn't have any value in " + lec_error[p] + " column, so please provide it!. It's a mandatory feild.")
                    
    ############################################# exercise sheet #############################################

    exercise_details = json.loads(course[3].to_json(orient ='index'))
    for k,v in exercise_details.items():
        exe_error = []
        for g in v:
            if g == 'exercise_id':
                exe_id.append(v[g])
            if v[g] == None or v[g] == 'None' or v[g] == 'none':
                exe_error.append(g)
            else:
                continue
        if len(exe_error) > 0:
            if len(exe_error) == len(v)-1:
                error.append(str(exercise_details[k]['exercise_id'])+ " no. exercise id doesn't have any record, so please provide it!")
            else:
                for p in range(len(exe_error)):
                    error.append(str(exercise_details[k]['exercise_id']) + " no. exercise id doesn't have any value in " + exe_error[p] + " column, so please provide it!. It's a mandatory feild.")
                    
    ############################################# program worksheet sheet #############################################
    
    program_details = json.loads(course[4].to_json(orient ='index'))
    for k,v in program_details.items():
        pro_work_error = []
        for g in v:
            if g == 'id':
                pro_work_id.append(v[g])
            if v[g] == None or v[g] == 'None' or v[g] == 'none':
                pro_work_error.append(g)
            else:
                continue
        if len(pro_work_error) > 0:
            if len(pro_work_error) == len(v)-1:
                error.append(str(program_details[k]['id'])+ " no. program worksheet id doesn't have any record, so please provide it!")
            else:
                for p in range(len(pro_work_error)):
                    error.append(str(program_details[k]['id']) + " no. program worksheet id doesn't have any value in " + pro_work_error[p] + " column, so please provide it!. It's a mandatory feild.")
    
    ############################################# question sheet #############################################
    
    question_details = json.loads(course[5].to_json(orient ='index'))
    for k,v in question_details.items():
        question_error = []
        for g in v:
            if g == 'question_id':
                que_id.append(v[g])
            if v[g] == None or v[g] == 'None' or v[g] == 'none':
                question_error.append(g)
            else:
                continue
        if len(question_error) > 0:
            if len(question_error) == len(v)-1:
                error.append(str(question_details[k]['question_id'])+ " no. question id doesn't have any record, so please provide it!")
            else:
                for p in range(len(question_error)):
                    error.append(str(question_details[k]['question_id']) + " no. question id doesn't have any value in " + question_error[p] + " column, so please provide it!. It's a mandatory feild.")
    
    
    ############################################# answer choice sheet #############################################
    
    choice_details = json.loads(course[6].to_json(orient ='index'))
    for k,v in choice_details.items():
        answer_error = []
        for g in v:
            if g == 'answer_id':
                ans_id.append(v[g])
            if v[g] == None or v[g] == 'None' or v[g] == 'none':
                answer_error.append(g)
            else:
                continue
        if len(answer_error) > 0:
            if len(answer_error) == len(v)-1:
                error.append(str(choice_details[k]['answer_id'])+ " no. answer id doesn't have any record, so please provide it!")
            else:
                for p in range(len(answer_error)):
                    error.append(str(choice_details[k]['answer_id']) + " no. answer id doesn't have any value in " + answer_error[p] + " column, so please provide it!. It's a mandatory feild.")
    
    
    ############################################# concept sheet #############################################
    
    concept_details = json.loads(course[11].to_json(orient ='index'))
    for k,v in concept_details.items():
        concept_error = []
        for g in v:
            if g == 'id':
                con_id.append(v[g])
            if v[g] == None or v[g] == 'None' or v[g] == 'none':
                concept_error.append(g)
            else:
                continue
        if len(concept_error) > 0:
            if len(concept_error) == len(v)-1:
                error.append(str(concept_details[k]['id'])+ " no. concept id doesn't have any record, so please provide it!")
            else:
                for p in range(len(concept_error)):
                    error.append(str(concept_details[k]['id']) + " no. concept id doesn't have any value in " + concept_error[p] + " column, so please provide it!. It's a mandatory feild.")
    
    ############################################# instructor sheet #############################################
    
    instructor_details = json.loads(course[9].to_json(orient ='index'))
    for k,v in instructor_details.items():
        ins_error = []
        for g in v:
            if g == 'id':
                ins_id.append(v[g])
            if v[g] == None or v[g] == 'None' or v[g] == 'none':
                ins_error.append(g)
            else:
                continue
        if len(ins_error) > 0:
            if len(ins_error) == len(v)-1:
                error.append(str(v['id']) + " no. instructor id doesn't have any record, so please provide it!")
            else:
                for k in range(len(ins_error)):
                    error.append(str(v['id']) + " no. instructor id doesn't have any value in " + ins_error[k] +" column, so please provide it!")
                    
    ############################################# reference materials sheet #############################################
    
    reference_details = json.loads(course[10].to_json(orient ='index'))
    for k,v in reference_details.items():
        ref_error = []
        for g in v:
            if g == 'ref_id':
                ref_id.append(v[g])
            if v[g] == None or v[g] == 'None' or v[g] == 'none':
                ref_error.append(g)
            else:
                continue
            if len(ref_error) > 0:
                if len(ref_error) == len(v)-1:
                    error.append(str(v['ref_id']) + " no. reference id doesn't have any record, so please provide it!")
                # else:
                #     for p in range(len(ref_error)):
                #         error.append(str(reference_details[k]['ref_id']) + " no. reference id doesn't have any value in " + ref_error[p] + " column, so please provide it!. It's a mandatory feild.")
    

def condition_fun(value):
    l = []
    if type(value) == int or type(value) == float:
        l.append(value)
        return l
    else:
        return value.split('|') # return list 
    

def concept_fun(concept, course):
    global con_id
    concept_id = condition_fun(concept)
    concept_details = json.loads(course[11].to_json(orient ='index'))
    lecture_concept = []
    for p in range(len(concept_id)):
        for j,l in concept_details.items():
            if int(concept_id[p]) in con_id:
                if concept_details[j]['id'] == int(concept_id[p]):
                    lecture_concept.append(l)
            else:
                sys.exit("This Concept id " + str(concept_id[p]) + " isn't exist")
    return lecture_concept

def question_fun(question, course):
    global ans_id
    question[0]['concept_ref'] = concept_fun(question[0]['concept_ref'], course)
    choice = condition_fun(question[0]['choice_of_answer_ref'])
    correct = condition_fun(question[0]['correct_answer_id_list'])
    choice_details = json.loads(course[6].to_json(orient ='index'))
    option = []
    answer = []
    for i in range(len(choice)):
        for k,v in choice_details.items():
            if int(choice[i]) in ans_id:
                if v['answer_id'] == int(choice[i]):
                    option.append(v)
                    if v['answer_id'] in correct:
                        answer.append(v)
            else:
                sys.exit("This answer id " + str(choice[i]) + " isn't exist")
    question[0]['choice_of_answer_ref'] = option
    question[0]['correct_answer_id_list'] = answer
    return question[0]
            

def exercise_fun(exercise, course):
    global que_id, pro_work_id
    #Concept              
    exercise[0]['concept_ref'] = concept_fun(exercise[0]['concept_ref'], course)
    
    # Question
       
    question = condition_fun(exercise[0]['question_ref'])
    question_details = json.loads(course[5].to_json(orient ='index'))
    exercise_question = []
    for i in range(len(question)):
        for k,v in question_details.items():
            if int(question[i]) in que_id:
                if int(question[i]) == v['question_id']:
                    question_parameter = []
                    question_parameter.append(v)
                    question_details[k] = question_fun(question_parameter, course)
                    exercise_question.append(question_details[k])
            else:
                sys.exit("This Question id " + str(question[i]) + " isn't exist")
    exercise[0]['question_ref'] = exercise_question
    
    # program_worksheet
    
    program = condition_fun(exercise[0]['program_worksheet_ref'])
    program_details = json.loads(course[4].to_json(orient ='index'))
    exercise_program = []
    for i in range(len(program)):
        for k,v in program_details.items():
            if int(program[i]) in pro_work_id:
                if int(program[i]) == v['id']:
                    program_parameter = []
                    program_parameter.append(v)
                    # program_details[k] = program_fun(program_parameter, course)
                    exercise_program.append(program_details[k])
            else:
                sys.exit("This program worksheet id " + str(program[i]) + " isn't exist")
    exercise[0]['program_worksheet'] = exercise_program
    # else:
        # print (name +' module does not have any Program Worksheet')
    
    # # other_question

    # ot = 0
    # if exercise[0]['other_question_ref'] == None : # for checking weather l_id is single value
    #     ot += 1
    # else:
    #     # return a list
    #     other = condition_fun(exercise[0]['other_question_ref'])
    
    # if pr != 1:
    #     other_details = json.loads(course[8].to_json(orient ='index'))
    #     exercise_other = []
    #     for i in range(len(other)):
    #         for k,v in other_details.items():
    #             if int(other[i]) == v['id']:
    #                 other_parameter = []
    #                 other_parameter.append(v)
    #                 exercise_other.append(other_details[k])
    #     exercise[0]['other_question'] = exercise_other
    # else:
    #     print ('Module does not have any other Question')
    return exercise[0]


def module_fun(module, course):
    global lec_id, exe_id
    # Lecture

    l_id = condition_fun(module[0]['lecture_ref'])
    
    lecture_details = json.loads(course[2].to_json(orient ='index'))
    module_lecture = []
    for i in range(len(l_id)):
        for k,v in lecture_details.items():
            if int(l_id[i]) in lec_id: 
                if int(l_id[i]) == int(v['lecture_id']): # lecture_details[str(0)]['lecture_id'] give int value
                    v['concept_ref'] = concept_fun(v['concept_ref'], course)                    
                    module_lecture.append(v)
            else:
                sys.exit("This lecture id " + str(l_id[i]) + " isn't exist")
    module[0]['lecture_ref'] = module_lecture
    
    #Exercise 

    e_id = condition_fun(module[0]['exercise_ref']) 
    exercise_details = json.loads(course[3].to_json(orient ='index'))
    module_exercise = []
    for i in range(len(e_id)):
        for k,v in exercise_details.items():
            if int(e_id[i]) in exe_id: 
                if int(e_id[i]) == int(v['exercise_id']): # lecture_details[str(0)]['lecture_id'] give int value
                    exercise_parameter = []
                    exercise_parameter.append(v)
                    # if int(e_id[i]) == v['exercise_id']:
                    exercise_details[k] = exercise_fun(exercise_parameter, course)
                    module_exercise.append(exercise_details[k])
            else:
                sys.exit("This exercise id " + str(e_id[i]) + " isn't exist")
    module[0]['exercise_ref'] = module_exercise
    return module[0]


def course_fun(course):
    
    global mou_id, ref_id, ins_id
    
    l = json.loads(course[0].to_json(orient ='index'))
    for i in range(len(l)):
    ############################################# reference materials #############################################
        
        references = condition_fun(l[str(i)]['reference_materials_ref'])
        reference_details = json.loads(course[10].to_json(orient ='index'))
        courses_reference = []
        for j in range(len(references)):
            for k,v in reference_details.items():
                if int(references[j]) in ref_id:
                    if int(references[j]) == v['ref_id']:
                        courses_reference.append(reference_details[k])
                else:
                    sys.exit("This reference id " + references[j] + " isn't exist")
        l[str(i)]['reference_materials_ref'] = courses_reference
        
        
        ############################################# Module #############################################
        
        module = condition_fun(l[str(i)]['module_ref'])
        module_details = json.loads(course[1].to_json(orient ='index'))
        courses_module = []
        for j in range(len(module)):
            for k,v in module_details.items():
                module_parameter = []
                module_parameter.append(v)
                if int(module[j]) in mou_id: 
                    if int(module[j]) == v['module_id']:
                        module_details[k]  = module_fun(module_parameter, course)
                        courses_module.append(module_details[k])
                else:
                    sys.exit("This module id " + module[j] + " isn't exist")
        l[str(i)]['module_ref'] = courses_module
    
        ############################################# instructor #############################################
        
        instructor = condition_fun(l[str(i)]['instructor_ref'])
        instructor_details = json.loads(course[9].to_json(orient ='index'))
        course_instructor = []
        for j in range(len(instructor)):
            for k,v in instructor_details.items():
                if int(instructor[j]) in ins_id: 
                    if int(instructor[j]) == v['id']:
                        course_instructor.append(instructor_details[k])
                else:
                    sys.exit("This instructor id " + instructor[j] + " isn't exist")
            l[str(i)]['instructor_ref'] = course_instructor
    return l
        
 

def main_fun(excel_name):
    global error
    start = time.time()
    excel_file = excel_name + '.xlsx'
    try:
        xlsx = pd.ExcelFile(excel_file)
    except:
        print("\n" + excel_file + " name doesn't exists, please provide correct excel file name.")
        sys.exit()
    course = []
    for sheet in xlsx.sheet_names:
        course.append(xlsx.parse(sheet))
    
    ################ It'll check whether there are any missing values in the excel file 
        
    miss_value_fun(course)    
    
    ################ Program terminating point
    
    if  len(error) > 0: 
        print('\n')
        for i in range(len(error)):
            print(error[i])
        print('\n')
        sys.exit("Please provide information that is mentioned above")

    ###################################
    course_1 = course_fun(course)
    print('\n', 'csv_to_json program run successfully', '\n')
    # pprint.pprint(course_1)
    with open('json_file.json', 'w') as data:
        json.dump(course_1, data)
    # print(course_1)
    print ("Total Time : "), time.time() - start
    return course_1

excel_name = input("Enter the excel file name which contains the course details : ")
course = main_fun(excel_name)


