import csv_to_json as csj
import boto3, pprint
from botocore.exceptions import NoCredentialsError
import sys

course = csj.course
print("\n To upload videos in AWS, you have to provide Following keys: \n")

ACCESS_KEY  = input("Enter your Access key : ")
SECRET_KEY  = input("Enter your Secret key : ")

######################### Here we connect with AWS S3 service #########################

# s3 = boto3.resource('s3',aws_access_key_id=ACCESS_KEY,aws_secret_access_key= SECRET_KEY)

s3 = boto3.client('s3', aws_access_key_id=ACCESS_KEY,aws_secret_access_key=SECRET_KEY)
Buckets = s3.list_buckets()
bucket_name = Buckets['Buckets'][1]['Name']
Objects = s3.list_objects(Bucket=bucket_name) # here we get the all object name for duplicate name
# pprint.pprint(Objects)
# obj_name = []
# for i in range(len(Objects['Contents'])):
#     obj_name.append(Objects['Contents'][i]['Key'])
# # print(obj_name)


########################## Define all our functions #############################

def upload_to_aws(local_file, bucket_name, file_name):
    try:
        Objects = s3.list_objects(Bucket=bucket_name) # here we get the all object name for duplicate name
        obj_name = []
        for i in range(len(Objects['Contents'])):
            obj_name.append(Objects['Contents'][i]['Key'])
        if file_name in obj_name:
            print(file_name + " name is already in use, please use another name!")
            return False
        else:
            p = s3.upload_file(local_file, bucket_name, file_name)
            print(file_name + " Upload Successfully\n")
            return True
        # p = s3.meta.client.upload_file(local_file, bucket_name, file_name)
        # print(p)
        # bucket = s3.Bucket('nairpcoursevideos-source-11yip8w7pm5e8') 
        # for bucket in bucket.objects.all():
        #    print(bucket) # bucket_name, owner, size, key
    except FileNotFoundError:
        print(file_name + " file was not found, please check it!\n")
        return False
    except NoCredentialsError:
        print("Credentials are not correct, Kindly provide correct Credentials\n!")
        return False


    
###################################################################################


# local_file = 'file/11804158814.pdf'
# file_name = 'Aaaa.pdf'

print('*************** Video file is now uploading to AWS ****************\n')



for i in range(len(course)):
    print("*************** " + course[str(i)]['course_title'] + " course Introduction video is now uploading *********\n")
    file_path = course[str(i)]['course_intro_video']
    value = course[str(i)]['course_intro_video'].split('/')
    aws_file_name = value[1]
    uploaded =  upload_to_aws(file_path, bucket_name, aws_file_name)
    if uploaded == False:
        sys.exit()
    print('******************** Lecture videos and Notes are now uploading ********************\n')
    for j in range(len(course[str(i)]['module_ref'])):
        # error = 0
        for l in range(len(course[str(i)]['module_ref'][j]['lecture_ref'])):
            
            ################################# video #######################################
            file_path = course[str(i)]['module_ref'][j]['lecture_ref'][l]['lecture_video']
            # print(file_path)
            value = course[str(i)]['module_ref'][j]['lecture_ref'][l]['lecture_video'].split('/')
            aws_video_file_name = value[1]
            uploaded_video = upload_to_aws(file_path, bucket_name, aws_video_file_name)
            if uploaded_video == False:
                sys.exit()
                # error = 1
                # break
            
            ################### Notes ##############
            
            note_file_path = course[str(i)]['module_ref'][j]['lecture_ref'][l]['lecture_note']
            note_value = course[str(i)]['module_ref'][j]['lecture_ref'][l]['lecture_note'].split('/')
            aws_note_file_name = note_value[1]
            uploaded_note = upload_to_aws(file_path, bucket_name, aws_note_file_name)
            if uploaded_note == False:
                sys.exit()
                # error = 1
                # break
            
        # for l in range(len(course[str(i)]['module_ref'][j]['lecture_ref'])):
        #      ################### dataset ##############
            
        #     dataset_file_path = course[str(i)]['module_ref'][j]['lecture_ref'][l]['lecture_note']
        #     print(dataset_file_path)
        #     note_value = course[str(i)]['module_ref'][j]['lecture_ref'][l]['lecture_note'].split('/')
        #     aws_note_file_name = note_value[1]
        #     # uploaded_note = upload_to_aws(file_path, bucket_name, aws_note_file_name)
        #     # if uploaded_note == False:
        #         # error = 1
        #         # break
            
        #     # ######################################################################
            ######################################################################
            course[str(i)]['module_ref'][j]['lecture_ref'][l]['lecture_video'] = 'http://nairpcoursevideos-source-11yip8w7pm5e8.s3.amazonaws.com/' + aws_video_file_name
            course[str(i)]['module_ref'][j]['lecture_ref'][l]['lecture_note'] = 'http://nairpcoursevideos-source-11yip8w7pm5e8.s3.amazonaws.com/' + aws_note_file_name
            print('we successfully store the URL to Json file')
            print(course[str(i)]['module_ref'][j]['lecture_ref'][l]['lecture_video'])
        # if error == 1:
        #     break

course = course



# uploaded = upload_to_aws(local_file, bucket_name, file_name)
# print(course)
# bucket_name = 'nairpcoursevideos-source-11yip8w7pm5e8'
# local_file = '/home/developer/Desktop/Subham_Python/'
# file_name = 'AWS_apigateway-dg.pdf'

# # print(local_file + file_name)
# # https://subham-bucket.s3.ap-south-1.amazonaws.com/NEW_1/1-s2.0-S1097276504003284-main.pdf
# # Key
# # NEW_1/1-s2.0-S1097276504003284-main.pdf

# # 'http://nairpcoursevideos-source-11yip8w7pm5e8.s3.amazonaws.com/AWS_apigateway-dg.pdf'  https://d3u083tmwdy2gl.cloudfront.net/9ef63225-dc28-41c9-9806-efcc5a2ee58a/dash/ml_introduction.mpd


# #########################################################################################
# # s3 = boto3.client('s3', aws_access_key_id=ACCESS_KEY,
# #                       aws_secret_access_key=SECRET_KEY)
# # # response = s3.list_buckets()
# # # response_1 = s3.list_objects(Bucket='nairpcoursevideos-source-11yip8w7pm5e8')
# # # pprint.pprint(response_1)
# ##########################################################################################




# # bucket = s3.Bucket('nairpcoursevideos-source-11yip8w7pm5e8')

# # 


# for bucket in bucket.objects.all():
    # print(bucket.key) # bucket_name, owner, size, key


