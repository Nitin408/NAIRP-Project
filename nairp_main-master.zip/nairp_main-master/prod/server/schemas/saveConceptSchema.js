const mongoose = require ("mongoose")
const saveConceptSchema= new mongoose.Schema(
    {   
        concept_id:{
            type:Number,
            required:true
        },
        concept_text:{
            type:String,
            required:true
        }
           
    }
)

const SaveConceptSchema = mongoose.model('saveConcepts', saveConceptSchema)

module.exports = SaveConceptSchema;