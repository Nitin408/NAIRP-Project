const mongoose = require ("mongoose")
const progExerciseSchema= new mongoose.Schema(
    {   
        exercise_id:{
            type:Number,
            required:true,
            trim:true,
        },
        marks:{
            type:Number,
            required:true,
        },
        concepts:[{             
            //array of integers which are referred to concepts database       
            type:Number,
            required:true,
        }],
        worksheet:{
            // database will keep S3 paths to worksheet (.ipynb) file
            type:String,
            required:true,
            trim:true,
        },
        evaluation_fn:{
            // database will keep S3 paths to evaluation_fn file (.py)
            type:String,
            required:true,
            trim:true,
        },
        datasets:[{
            // database will keep S3 paths to each dataset files
            type:String,
            required:true,
            trim:true,
        }],
        sub_exercises:[{
            marks:{
                type:Number,
                required:true,
            },
            concepts:[{       
                //array of integers which are referred to concepts database       
                type:Number,
                required:true,
            }]
        }]
           
    }
)

const ProgExercise = mongoose.model('ProgExercise', progExerciseSchema)

module.exports = ProgExercise;
