const mongoose = require("mongoose")
const userScoreSchema = new mongoose.Schema(
    {
        uid: {
            type: String,
            required: true,
            unique: true
        },
        user_id: {
            type: String,
            required: true,
        },
        course_id: {
            type: Number,
            required: true,
        },
        module_id: {
            type: Number,
            required: true,
        },
        question_type: {
            type: String,
            required: true,
            trim: true,
        },
        accuracy:{
            type: Number,
            required: true,
            default: 0
        },
        best_score:{
            type: Number,
            required: true,
            default: 0
        },
        response_data: [{
            question_id: {
                type: String,
                required: true
            },
            last_score: {
                type: Number,
                required: true,
                default: 0
            },
            best_score: {
                type: Number,
                required: true,
                default: 0
            },
            sub_exercises: [{
                last_score: {
                    type: Number,
                },
                best_score: {
                    type: Number,
                    default: 0,
                },
                timestamp: {
                    type: String,
                },
            }],
        }],
        no_of_successful_attempts: {
            type: Number,
            required: true,
            default: 0,
        },
        no_of_failed_attempts: {
            type: Number,
            required: true,
            default: 0,
        },
    },
    {
        timestamps: true
    }
)

const UserScore = mongoose.model('UserScore', userScoreSchema)

module.exports = UserScore;