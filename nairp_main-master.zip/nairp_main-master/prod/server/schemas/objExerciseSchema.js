const mongoose = require ("mongoose")
const objExerciseSchema= new mongoose.Schema(
    {   
        
        exercise_id:{
            type:String,
            required:true,
            trim:true,
        },                       
        question_type:{  
            // Possible Values: 
            // 1)mcq
            // 2)fillUp
            type:String,
            required:true,
            trim:true,
        },
        question_has_pdf:{ 
            type:Boolean,
            required:true,
        },
        mcq_type:{                          
            //Possible Values: 
            // 1)multichoice (if question_type is mcq)
            // 2)singlechoice (if question_type is mcq)
            // 3)none   (if question_type is fillUp)
            type:String,
            trim:true,
        },
        question:{                          
            //Possible way of question if question_type is fillUp: question should contain $$ or $# if answer is to be put there
            type:String,
            required:true,
        },
        choice_has_pdf:{ 
            type:Boolean,
            required:true,
        },
        list_of_choices:{
            //(if question_type is mcq) it can can four strings as the possible choices
            //(if question_type is fillUp) it will have only one choice which matches listOfAnswers
           type:[String],
            required:true,
        },
        list_of_answers:{
            //(if mcqType is singlechoice or question_type is fillUp) it can have only one string in array Ex: ["machine Learning"]
            //(if mcqType is multichoice) it can have any number of strings in array <=4
            type:[String],
            required:true,
        },
        marks:{
            // int values only 
            type:Number,
            required:true,
        },
        concepts:[{       
            //array of integers which are referred to concepts database       
            type:Number,
            required:true,
        }]
    }
)

const Objexercise = mongoose.model('objExercise', objExerciseSchema)

module.exports = Objexercise;