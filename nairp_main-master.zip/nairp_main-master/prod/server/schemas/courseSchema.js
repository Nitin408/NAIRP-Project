const mongoose = require ("mongoose")
const courseSchema= new mongoose.Schema(
    {   
        _id:{
            type:mongoose.Schema.ObjectId,
            required:true
        },
        add_to_carousal:{
            type: Boolean,
            default: false   
        },
        
        course_id:{
            type: Number,
            required:true,
        },
        card_image_file:{
            type:String,
            required:true,
            trim:true,
        },
        advertisement_image_file:{
            type:String,
            required:true,
            trim:true,
        },
        course_title: {
            type: String,
            required: true,
            unique: true,
            trim: true,
        },
        course_short_name:{
            type: String,
            required:true,
        },
        course_description:{
            type: String,
            required:true,
            
        },
        course_intro_video:{
            type:String,
            required:true,
            trim:true,
        },
        prerequisite_preexisting_course_title_list:[{
            type:String,
            required:true,
            trim:true,
        }],
        prerequisite_knowledge_file:{
            type:String,
        },
        created_on:{
            type: String,
            required:true,
            trim:true,
        },
        communication_language:{
            type:String,
            trim:true,
            required:true
        },
        reference_material_file:           {
            type:String,
        },
        credit:{
            type: Number,
            trim:true,
            required:true,
        },
        duration_in_min:{                  
            type: Number,
            trim:true,
            required:true,
        },
        offering_period_from_to:[{           
            ///////Possible Value: "12-25-2020 12:00 AM|12-22-2021 12:00 AM" 
            type:String,
            required:true,
            trim:true,
        }],
        copyright_message:{
            type:String,
            required:true,
            trim:true,
        },
        module:[
            {
                module_title:{
                    type:String,
                    required:true,
                    trim:true,
                },
                module_id:{
                    type:Number,
                    required:true,
                    trim:true,
                },
                lecture:[               
                    {
                        lecture_title:{
                            type:String,
                            required:true,
                            trim:true,
                        },
                        lecture_id:{
                            type:Number,
                            required:true,
                            trim:true,
                        },
                        topic:{
                            type:String,
                            required:true,
                            trim:true,
                        },
                        concept:[{               
                            type:Number,        
                            required:true,
                            trim:true,
                        }],
                        lecture_video:{
                            type:String,
                            required:true,
                            trim:true,
                        },
                        lecture_note:{
                            type:String,
                            required:true,
                            trim:true,
                        },
                        worksheets:[{
                            worksheet:{
                                type:String,
                                required:true,
                            },
                            worksheet_id:{
                                type:String,
                                required:true,
                                trim:true,
                            },
                            datasets:                   
                            {
                                type:[String],
                                unique:false,
                                trim:true,
                                default:[],
                            },
                        }],
                    }
                ],
                exercise:[
                    {
                    exercise_type:{
                        //////Possible Values: objectiveExecise (for local exercise ) /progExercise (for AWS exercise)
                        type:String,    
                        required:true,

                    },
                    exercise_id:{      
                        type:Number,
                        required:true
                    },  
                    }
                ]
            }
        ],
        instructor:[
            {
                id:{
                    type:Number,
                    required:true,
                    trim:true,
                },
                name:{
                    type:String,
                    required:true,
                    trim:true,
                },
                designation:{
                    type:String,
                    required:true,
                    trim:true,
                },
                profile:{
                    type:String,
                    required:true,
                    trim:true,
                },
            }
        ]
    }
)

const Course = mongoose.model('Courses', courseSchema)

module.exports = Course;
