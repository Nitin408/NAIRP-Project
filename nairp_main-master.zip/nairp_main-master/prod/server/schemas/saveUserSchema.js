const mongoose = require ("mongoose")
const saveUserSchema= new mongoose.Schema(
    {   
        user_object_id:{
            type:Object,
            required:true
        },
		course_object_id:{
            type:Object,
            required:true
        }
           
    }
)

const SaveUserSchema = mongoose.model('userForSaveCourse', saveUserSchema)

module.exports = SaveUserSchema;