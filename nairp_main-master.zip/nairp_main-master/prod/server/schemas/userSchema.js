const mongoose = require ("mongoose")
const Course = require("./courseSchema")

const UserAccessType = {
    ADMIN     : "admin",
    ENDUSER   : "enduser",
    INSTRUCTOR: "instructor"
}

const UserEducationalLevel = {
    SCHOOL    : "School",
    COLLEGE   : "College",
    RESEARCHER: "Researcher",
    PROFESSOR : "Professor",
    LAYMAN    : "Layman"
}
const userSchema = new mongoose.Schema(
    {
        email: {
            type: String,
            required: true,
            unique: true,
            trim: true,
        },
        password: {
            type: String,
            required: true,
            unique: false,
            trim: false,
        },
        subscribedCourses:                   
            {
                type:[String],
                unique:false,
                trim:true,
                default:[],
            }
        ,
        firstName: {
            type: String,
            required: true,
            unique: false,
            trim: true,
        },
        middleName: {
            type: String,
            required: false,
            unique: false,
            trim: true,
        },
        lastName: {
            type: String,
            required: true,
            unique: false,
            trim: true,
        },
        accessType: {   // UserAccessType: admin, enduser, instructor
            type: String,
            required: true,
            unique: false,
            trim: true,
        },
        educationalLevel: {
            type: String // UserEducationalLevel: School, College, Researcher, Professor, Layman
        },
        dob: {
            type: Date,
            min: '1900-01-01',
            max: Date(Date.now())
        },
        country: {
            type: String, // Should come from a controlled vocabulary
            required: false,
            unique: false,
            trim: true,
        },
        state: {
            type: String, // Should come from a controlled vocabulary
            required: false,
            unique: false,
            trim: true,
        },
        gender: {
            type: String,
            required: false,
            unique: false,
            trim: true,
        },
        profession: {
            type: String // Should come from a controlled vocabulary
        },
        moodleSignup:{
            type: Boolean,
            default: false
        },
        accessHistory: {
            loginCreatedAt: {
                type: Date
            },
            lastLoggedInAt: {
                type: Date
            },
            lastLoggedOutAt: {
                type: Date
            },
            loginCount: {
                type: Number
            },
            ipAddressesLoggedInFrom: [{
                type: Number  // Revise this later
            }],
            totalLoginDuration: {
                type: Number  // In seconds
            }
        },
        isEmailVerified: {              //for checking if user has verified email
            type: Boolean,       
            default: false
        },
        emailVerificationToken: {        //saving the token to match from email verification url  
            type: String,
            unique: false,
            default: null
        },
        passResetToken: {                // saving the token to match from password reset url  
            type: String,
            default: ""
        },
        passResetInitiated: {      //for checking if password reset was initiated.
            type: Boolean,
            default: false
        },
        passResetCount: {          //anti-spam measure
            type: Number,
            default: 0
        },
        missingFields: {        //if the user logged in via google the first time, some fields will be missing and
            type: Boolean,      //user will be redirected to another form
            default: true
        },
        googleId: {             //id from the info obtained via google oauth2.0
            type: String,
            default: null
        }
    },
    {
        timestamps: true
    }
)

const User = mongoose.model('User', userSchema)

module.exports = User;
