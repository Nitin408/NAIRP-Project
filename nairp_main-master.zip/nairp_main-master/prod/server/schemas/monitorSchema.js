const mongoose = require("mongoose")

const monitorSchema = new mongoose.Schema(
    {
        user_id: {
            type: String,
            required: true,
            unique: true
        },
        is_seen: {
            type: Boolean,
            required: true,
            default: false
        },
        data: [
            {
                course_id:{
                    type: Number,
                    required: true,
                },
                course_name: {
                    type: String,
                    required: true,
                },
                exercise_id: {
                    type: Number,
                    required: false,
                },               
                message_id: {
                    type: Number,
                    required: true,
                },
                time : { type : Date, default: Date.now }
            }
        ]
    },
    {
        timestamps: true
    }
)

const monitor = mongoose.model('Monitorings', monitorSchema)
module.exports = monitor