const mongoose = require ("mongoose")
const saveCourseSchema= new mongoose.Schema(
    {   
        add_to_carousal:{
            type: Boolean,   
        },
        
        course_id:{
            type: Number,
        },
        card_image_file:{
            type:String,
            trim:true,
        },
        advertisement_image_file:{
            type:String,
            trim:true,
        },
        course_title: {
            type: String,
            unique: true,
            trim: true,
        },
        course_short_name:{
            type: String,
        },
        course_description:{
            type: String,
            
        },
        course_intro_video:{
            type:String,
            trim:true,
        },
        prerequisite_preexisting_course_title_list:[{
            type:String,
            trim:true,
        }],
        prerequisite_knowledge_file:{
            type:String,
        },
        created_on:{
            type: String,
            trim:true,
        },
        communication_language:{
            type:String,
            trim:true,
        },
        reference_material_file:           {
            type:String,
        },
        credit:{
            type: Number,
            trim:true,
        },
        duration_in_min:{                  
            type: Number,
            trim:true,
        },
        offering_period_from_to:[{           
            ///////Possible Value: "12-25-2020 12:00 AM|12-22-2021 12:00 AM" 
            type:String,
            trim:true,
        }],
        copyright_message:{
            type:String,
            trim:true,
        },
        module:[
            {
                module_title:{
                    type:String,
                    trim:true,
                },
                module_id:{
                    type:Number,
                    trim:true,
                },
                lecture:[               
                    {
                        lecture_title:{
                            type:String,
                            trim:true,
                        },
                        lecture_id:{
                            type:Number,
                            trim:true,
                        },
                        topic:{
                            type:String,
                            required:true,
                            trim:true,
                        },
                        concept:[{               
                            type:Number,        
                            trim:true,
                        }],
                        lecture_video:{
                            type:String,
                            trim:true,
                        },
                        lecture_note:{
                            type:String,
                            trim:true,
                        },
                        worksheets:[{
                            worksheet:{
                                type:String,
                                required:true,
                            },
                            worksheet_id:{
                                type:String,
                                required:true,
                                trim:true,
                            }
                        }],
                    }
                ],
                exercise:[
                    {
                    exercise_type:{
                        //////Possible Values: objectiveExecise (for local exercise ) /progExercise (for AWS exercise)
                        type:String,    

                    },
                    exercise_id:{      
                        type:Number,
                    },  
                    }
                ]
            }
        ],
        instructor:[
            {
                id:{
                    type:Number,
                    trim:true,
                },
                name:{
                    type:String,
                    trim:true,
                },
                designation:{
                    type:String,
                    trim:true,
                },
                profile:{
                    type:String,
                    trim:true,
                },
            }
        ]
    }
)

const SaveCourseSchema = mongoose.model('saveCourses', saveCourseSchema)

module.exports = SaveCourseSchema;
