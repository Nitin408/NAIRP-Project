const mongoose = require ("mongoose")
const conceptSchema= new mongoose.Schema(
    {   
        concept_id:{
            type:Number,
            required:true
        },
        concept_text:{
            type:String,
            required:true
        }
           
    }
)

const Concept = mongoose.model('Concept', conceptSchema)

module.exports = Concept;