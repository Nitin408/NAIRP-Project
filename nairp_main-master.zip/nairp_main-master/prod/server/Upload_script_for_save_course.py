try:
    import pip
    import csv, sys
    import json, os
    import time, datetime
    import pandas as pd
    import pprint, requests
    from PIL import Image
    import boto3
    import tempfile
    import shutil
    from botocore.exceptions import ClientError, ParamValidationError, EndpointConnectionError
    from pymongo import MongoClient
    from pymongo.errors import ServerSelectionTimeoutError, OperationFailure
except:
    if hasattr(pip, 'main'):
        pip.main(['install', 'pandas'])
        pip.main(['install', 'xlrd'])
        pip.main(['install', 'openpyxl'])
        pip.main(['install', 'requests'])
        pip.main(['install', 'PIL'])
        pip.main(['install', 'boto3'])
        pip.main(['install', 'tempfile'])
        pip.main(['install', 'shutil'])
        pip.main(['install', 'botocore'])
        pip.main(['install', 'pymongo'])
    else:
        pip._internal.main(['install', 'pandas'])
        pip._internal.main(['install', 'xlrd'])
        pip._internal.main(['install', 'openpyxl'])
        pip._internal.main(['install', 'requests'])
        pip._internal.main(['install', 'PIL'])
        pip._internal.main(['install', 'boto3'])
        pip._internal.main(['install', 'tempfile'])
        pip._internal.main(['install', 'shutil'])
        pip._internal.main(['install', 'botocore'])
        pip._internal.main(['install', 'pymongo'])

os.environ['no_proxy']= '10.5.30.191'
os.environ['NO_PROXY']= '10.5.30.191'
os.environ['no_proxy']= '127.0.0.1'
os.environ['NO_PROXY']= '127.0.0.1'


######## Define all the function below ##########


def global_fun(sys_argv):
    global SYS_ERROR, ABS_PATH, ERROR_MESSAGE, DELETE_FILES_SYSTEM, AWS_REGION_NAME, COMPLETE_UPLOAD, FOLDER_TUPLE
    global DEFAULT_TXT_FILE_SIZE, DEFAULT_VIDEO_FILE_SIZE, DEFAULT_IMAGE_FILE_SIZE, DEFAULT_WORKSHEET_FILE_SIZE
    global DEFAULT_DATASET_FILE_SIZE, DEFAULT_EVALUATION_FN_FILE_SIZE, DEFAULT_NOTE_FILE_SIZE
    global DATE_FORMAT, MIN_WORD_LENGTH, MAX_WORD_LENGTH, ERROR_DATE, COMMUNICATION_LANGUAGE
    global DEFAULT_IMAGE_FILE_HEIGHT, DEFAULT_IMAGE_FILE_WIDTH, QUESTION_TYPE, MCQ_TYPE, EXERCISE, MONGODB_COLLECTION
    global COURSE_SHEET_FIELD, MODULE_SHEET_FIELD, LECTURE_SHEET_FIELD, EXERCISE_SHEET_FIELD, PROG_EXERCISE_SHEET_FIELD
    global INSTRUCTOR_SHEET_FIELD, CONCEPT_SHEET_FIELD, OBJ_EXERCISE_SHEET_FIELD, OBJ_EXERCISE_PDF_SHEET_FIELD, SUB_EXERCISE_SHEET_FIELD
    global UPLOAD_LIST, EXERCISE_DATA_DICTIONARY_LIST, INSTANCE_TYPE, STROAGE_CAPACITY, COURSE_HEADERS, EXERCISE_HEADERS
    global COMPUTE_COURSE_URL, COMPUTE_EXERCISE_URL, COURSE_DATA_DICTIONARY
    global COURSE_DETAILS, MODULE_DETAILS, LECTURE_DETAILS, EXERCISE_DETAILS, PROG_EXERCISE_DETAILS, OBJ_EXERCISE_DETAILS, SUB_EXERCISE_DETAILS, CONCEPT_DETAILS, INSTRUCTOR_DETAILS, OBJ_EXERCISE_PDF_DETAILS, WORKED_OUT_WORKSHEET_DETAILS

    
    ERROR_MESSAGE = []
    SYS_ERROR = []
    DELETE_FILES_SYSTEM = [] # When a user wants to delete a course from our system then it will contain all the files path details which already uploaded to AWS S3
    COMPLETE_UPLOAD = [] # contain all the files path which successfully uploaded to AWS S3
    UPLOAD_LIST = [] # It'll contains all the information or data  about a program exercise
    EXERCISE_DATA_DICTIONARY_LIST = [] # It contains course id, program exercise id, storage capacity and instance type of an AWS compute service
    AWS_REGION_NAME = 'ap-south-1'
    DEFAULT_TXT_FILE_SIZE = 1024 # 1KB
    DEFAULT_VIDEO_FILE_SIZE = 10240 # 10KB
    DEFAULT_IMAGE_FILE_HEIGHT = 1080
    DEFAULT_IMAGE_FILE_WIDTH = 1400
    DEFAULT_IMAGE_FILE_SIZE = 51200 # 50KB
    DEFAULT_NOTE_FILE_SIZE = 10240 # 10KB
    DEFAULT_WORKSHEET_FILE_SIZE = 1024 # 1KB
    DEFAULT_DATASET_FILE_SIZE = 300 # 1KB
    DEFAULT_EVALUATION_FN_FILE_SIZE = 1024 # 1KB
    DATE_FORMAT = '%Y-%m-%d'
    MIN_WORD_LENGTH = 1
    MAX_WORD_LENGTH = 1000
    ERROR_DATE = datetime.datetime(2000, 1, 1)
    COMMUNICATION_LANGUAGE = ["English"]
    INSTANCE_TYPE = 'ml.t2.medium' # used in line no. 1695
    STROAGE_CAPACITY = 5 # used in line no. 1695
    COURSE_HEADERS = { 'api_key': 'NAIRPAdminKeyForTesting13423', 'Content-Type': 'application/json' }
    EXERCISE_HEADERS = { 'api_key': 'NAIRPAdminKeyForTesting13423'}
    COMPUTE_COURSE_URL = 'http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/course/'
    COMPUTE_EXERCISE_URL = 'http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/exercise/upload'
    
    QUESTION_TYPE = ['mcq', 'fillup']
    MCQ_TYPE = ["multichoice", "singlechoice", "none"]
    EXERCISE = ['objectiveExercise','progExercise']
    MONGODB_COLLECTION = ['savecourses','saveobjexercises', 'saveprogexercises', 'saveconcepts']
    
    COURSE_SHEET_FIELD = ['course_title', 'course_short_name', 'course_description', 'course_intro_video', 'advertisement_image_file', 'card_image_file', 'prerequisite_preexisting_course_title_list', 'prerequisite_knowledge_file', 'created_on', 'communication_language', 'reference_material_file', 'credit', 'duration_in_min', 'offering_period_from_to', 'copyright_message', 'module', 'instructor']
    MODULE_SHEET_FIELD = ['module_title', 'module_id', 'lecture', 'exercise']
    LECTURE_SHEET_FIELD = ['lecture_title', 'lecture_id', 'topic', 'concepts', 'lecture_video', 'lecture_note', 'worksheets']
    WORKED_OUT_WORKSHEET_SHEET_FIELD = ["worksheet_id", "worksheet"]
    EXERCISE_SHEET_FIELD = ['exercise_type', 'exercise_id']
    INSTRUCTOR_SHEET_FIELD = ['id', 'name', 'designation', 'profile']
    CONCEPT_SHEET_FIELD = ['concept_text', 'concept_id']
    PROG_EXERCISE_SHEET_FIELD = ['exercise_id', 'marks', 'concepts', 'worksheet', 'evaluation_fn', 'datasets', 'sub_exercises']
    OBJ_EXERCISE_SHEET_FIELD = ['exercise_id', 'question_type', 'mcq_type', 'question', 'concepts', 'list_of_choices', 'list_of_answers', 'marks']
    OBJ_EXERCISE_PDF_SHEET_FIELD = ['id', 'question_pdf', 'choices_pdf']
    SUB_EXERCISE_SHEET_FIELD = ['id', 'concepts', 'marks']
    
    
    global RED, GREEN, BLUE, YELLOW, NC , ENDC
    
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    BLUE = '\033[0;36m'
    YELLOW = '\033[0;33m'
    NC = '\033[0m'
    ENDC = '\033[m'
    
    ######################### For Finding the root path
    
    global CURRENT_WORKING_DIRECTORY
    
    #CURRENT_WORKING_DIRECTORY = os.getcwd()
    #os.chdir("..") # Go up one directory from working directory (It's like a 'cd ..' command in linux)
    # FOLDER_TUPLE store all directories path in it 
    # FOLDER_TUPLE = [os.path.join(CURRENT_WORKING_DIRECTORY,o) for o in os.listdir(CURRENT_WORKING_DIRECTORY) if os.path.isdir(os.path.join(CURRENT_WORKING_DIRECTORY,o))]
    # print(CURRENT_WORKING_DIRECTORY, FOLDER_TUPLE)
    
    global excel_file_path, course_id_overwrite, image_min_px_height, image_min_px_width
    global add_to_carousal, aws_access_key, aws_secret_key, aws_bucket_name, shadow_mode
    global mongodb_host_url_port, mongodb_database_name, course_id_delete, course_delete_confirm
    global PROG_ID, OBJ_ID, CONCEPT_ID, MONGO_CONCEPT_ID
    
    #################################################################################################################
    
    global COURSE_DETAILS, MODULE_DETAILS, LECTURE_DETAILS,EXERCISE_DETAIL, PROG_EXERCISE_DETAILS, OBJ_EXERCISE_DETAILS, INSTRUCTOR_DETAILS, CONCEPT_DETAILS
    #OBJ_EXERCISE_PDF_DETAILS = json.loads(course[0].to_json(orient ='index'))
    #SUB_EXERCISE_DETAILS = json.loads(course[0].to_json(orient ='index'))
    
    ##################################################################################################################
    
    course_id_overwrite = None
    shadow = 0
    if shadow == 0:
        shadow_mode = "off"
    ############################### Add new condition to read mongodb_host_url_port and mongodb_database_name from sys_argv ###############
    
    if sys_argv[10] == '-mongodb_host_url_port':
        mongodb_host_url_port = sys_argv[11]
    if sys_argv[12] == '-mongodb_database_name':
        mongodb_database_name = sys_argv[13]
    
    ###################################################################################
    #if len(sys_argv) == 1:
    #    print("\nNo result and nothing happend.")
    #    print("Maybe you wanted to say 'Upload_script.py -h'?")
    #    sys.exit()
    #elif sys_argv[1] == '-h' or sys_argv[1] == '-help':
    #    return sys_argv[1]
    #elif len(sys_argv) <= 10 and len(sys_argv) > 3:
    #    length = len(sys_argv)
    #    i = 1
    #    id_overwrite = 0
    #    carousal = 0
    #    height = 0
    #    width = 0
    #    while i < length:
    #        if sys_argv[i] == '-excel_file_path' :
    #            i = i+1
    #            excel_file_path = sys_argv[i]
    #            i = i+1
    #        elif sys_argv[i] == '-course_id_overwrite':
    #            i = i+1
    #            if sys_argv[i].isdigit():
    #                course_id_overwrite = sys_argv[i]
    #                id_overwrite = id_overwrite + 1
    #                i = i+1
    #            else:
    #                SYS_ERROR.append("In command-line argument '-course_id_overwrite' switch only takes an integer value.")
    #        elif sys_argv[i] == '-add_to_carousal':
    #            i = i+1
    #            add_to_carousal = True
    #            carousal = carousal + 1
    #        elif sys_argv[i] == '-image_min_px_height':
    #            i = i+1
    #            if sys_argv[i].isdigit():    
    #                image_min_px_height = sys_argv[i]
    #                height = height + 1
    #                i = i+1
    #            else:
    #                SYS_ERROR.append("In command-line argument '-image_min_px_height' switch only takes an integer value.")
    #        elif sys_argv[i] == '-image_min_px_width':
    #            i = i+1
    #            if sys_argv[i].isdigit():
    #                image_min_px_width = sys_argv[i]
    #                width = width + 1
    #                i = i+1
    #            else:
    #                SYS_ERROR.append("In command-line argument '-image_min_px_width' switch only takes an integer value.")                    
    #        
    #        elif sys_argv[i] == '-shadow_mode':
    #            i = i+1
    #            shadow_mode = "on"
    #            shadow = shadow + 1
    #           i = i+1
    #        else:
    #            SYS_ERROR.append("'" + sys_argv[i] + "' switch is invalid.")
    #            i = i + 2
    #    if id_overwrite == 0:
    #        course_id_overwrite = None
    #    if carousal == 0:
    #        add_to_carousal = False
    #    if height == 0:
    #        image_min_px_height = DEFAULT_IMAGE_FILE_HEIGHT
    #    if width == 0:
    #        image_min_px_width = DEFAULT_IMAGE_FILE_WIDTH
    #    if shadow == 0:
    #        shadow_mode = "off"
    #elif len(sys_argv) <= 21 and len(sys_argv) > 12:
    #    i = 1
    #    length = len(sys_argv)
    #    id_delete = 0
    #    delete_confirm = 0
    #    id_overwrite = 0
    #    carousal = 0
    #    height = 0
    #    width = 0
    #    while i < length:
    #        if sys_argv[i] == '-excel_file_path' :
    #            i = i+1
    #            excel_file_path = sys_argv[i]
    #            i = i+1
    #        elif sys_argv[i] == '-course_id_delete':
    #            i = i + 1
    #            if sys_argv[i].isdigit():
    #                course_id_delete = int(sys_argv[i])
    #                i = i + 1
    #                if sys_argv[i] == '-confirm':
    #                    course_delete_confirm = True
    ##                    id_delete = id_delete + 1
    #                   delete_confirm = delete_confirm + 1
    #                    i = i + 1
    #                else:
    #                    SYS_ERROR.append("To delete a course from NAIRP system script must take '-confirm' switch from command-line.")
    #            else:
    #                SYS_ERROR.append("In command-line argument '-course_id_delete' switch only takes an integer value.")
    #        elif sys_argv[i] == '-course_id_overwrite':
    #            i = i+1
    #            if sys_argv[i].isdigit():
    #                course_id_overwrite = sys_argv[i]
    #                id_overwrite = id_overwrite + 1
    #                i = i+1
    #            else:
    #                SYS_ERROR.append("In command-line argument '-course_id_overwrite' switch only takes an integer value.")
    #        elif sys_argv[i] == '-add_to_carousal':
    #            i = i+1
    #            add_to_carousal = True
    #            carousal = carousal + 1
    #        elif sys_argv[i] == '-image_min_px_height':
    #            i = i+1
    #            if sys_argv[i].isdigit():    
    #                image_min_px_height = sys_argv[i]
    #                height = height + 1
    #                i = i+1
    #            else:
    #                SYS_ERROR.append("In command-line argument '-image_min_px_height' switch only takes an integer value.")
    #        elif sys_argv[i] == '-image_min_px_width':
    #            i = i+1
    #            if sys_argv[i].isdigit():
    #                image_min_px_width = sys_argv[i]
    #                width = width + 1
    #                i = i+1
    #            else:
    #                SYS_ERROR.append("In command-line argument '-image_min_px_width' switch only takes an integer value.")                    
    #        elif sys_argv[i] == '-aws_access_key':
    #            i = i+1
    #            if len(sys_argv[i]) == 20:
    #                aws_access_key = sys_argv[i]
    #                i = i+1
    #            else:
    #                SYS_ERROR.append("In command-line argument '-aws_access_key' switch only takes a string(combination of alphabets and digits) value.")
    #        elif sys_argv[i] == '-aws_secret_key':
    #            i = i+1
    #            if len(sys_argv[i]) == 40:
    #                aws_secret_key = sys_argv[i]
    #                i = i+1
    #            else:
    #                SYS_ERROR.append("In command-line argument '-aws_secret_key' switch only takes a string(combination of alphabets, symbols and digits) value.")
    #        elif sys_argv[i] == '-aws_bucket_name':
    #            i = i+1
    #            aws_bucket_name = sys_argv[i]
    #            i = i+1
    #        elif sys_argv[i] == '-mongodb_host_url_port':
    #            i = i+1
    #            #if sys_argv[i].split(':')[2].isdigit():
    #            mongodb_host_url_port = sys_argv[i]
    #            i = i+1
    #            #else:
    #            #    SYS_ERROR.append("In command-line argument '-mongodb_host_url_port' switch only takes a string value but port must be an integer.")
    #        elif sys_argv[i] == '-mongodb_database_name':
    #            i = i+1
    #            mongodb_database_name = sys_argv[i]
    #            i = i+1
    #        else:
    #            SYS_ERROR.append("'" + sys_argv[i] + "' switch is invalid.")
    #            i = i + 2
    #    if id_overwrite == 0:
    #        course_id_overwrite = None
    #    if delete_confirm == 0 and id_delete == 0:
    #        course_delete_confirm = False
    #    if carousal == 0:
    #        add_to_carousal = False
    #    if height == 0:
    #        image_min_px_height = DEFAULT_IMAGE_FILE_HEIGHT
    #    if width == 0:
    #        image_min_px_width = DEFAULT_IMAGE_FILE_WIDTH
    #    if shadow == 0:
    #        shadow_mode = "off"
    #    
    #else:
    #    SYS_ERROR.append("The Command-line argument must take at least 6 switch to upload a course to NAIRP system.")
     #   SYS_ERROR.append("To Delete a course from NAIRP system the Command-line argument must take 7 switch.")        
            
    
    ############## print all the command line arguments ERROR_MESSAGEs
    if  len(SYS_ERROR) > 0: 
        print(RED + '\nErrors occur while reading the Command-line argument : \n', ENDC)
        for i in range(len(SYS_ERROR)):
            print(str(i+1) + "." + SYS_ERROR[i])
        print("\nGo and run <script_name.py> -h to see the script instruction.")
        sys.exit()
    #if shadow_mode == 'off':
    #    if delete_confirm == 1 and id_delete == 1:
    #        return '-course_id_delete'
    #    else:
    #        return None

    

def read_me():
   print("\n************************************************************************************\n")
   print("Useage : " + GREEN + "Upload_script.py [Options]\n", ENDC)
   print("Options : ")
   
   print(GREEN + "[ -h | -help]", ENDC)
   print("\tShows help message and exits.")
   
   print(GREEN + "[ -course_id_delete <course_id_delete>]", ENDC)
   print("\tDescription    : ")
   print("\t - Use this switch to delete a course.")
   print("\t - Course has to be exist in our system.")
   print("\tExample        : 3 ")
   print("\tSwitch type    : " + YELLOW + "Optional", ENDC)
   
   print(GREEN + "[ -confirm ]", ENDC)
   print("\tDescription    : ")
   print("\t - If course_id_delete switch is used then it's mandatory to use this switch.")
   print("\tSwitch type    : " + YELLOW + "Optional", ENDC)
   
   print(GREEN + "[ -excel_file_path <excel_file_path>]", ENDC)
   print("\tDescription    : This is the main excel file to provide all the course details.")
   print("\tExample        : course ")
   print("\tSwitch type    : " + YELLOW + "Mandatory", ENDC)
   
   print(GREEN + "[ -course_id_overwrite <course_id_overwrite>]", ENDC)
   print("\tDescription    : ")
   print("\t - Use this switch when an existing course with the given id should be overwrite.")
   print("\t - If no course exist in the system with the given id it'll use the given id for uploading.")
   print("\t - When this switch isn't given, script will automatically generate a new id for this course.")
   print("\tExample        : 5 ")
   print("\tDefault value  : Script generated")
   print("\tSwitch type    : " + YELLOW + "Optional", ENDC)
   
   print(GREEN + "[ -add_to_carousal]", ENDC)
   print("\tDescription    : If this's given then this course is shown in display carousal.")
   print("\tDefault value  : False")
   print("\tSwitch type    : " + YELLOW + "Optional", ENDC)
   
   print(GREEN + "[ -image_min_px_height <image_min_px_height>]", ENDC)
   print("\tDescription    : If this's given then the course image height should not less than this.")
   print("\tExample        : 1100")
   print("\tDefault value  : 1080")
   print("\tSwitch type    : " + YELLOW + "Optional", ENDC)
   
   print(GREEN + "[ -image_min_px_width <image_min_px_width>]", ENDC)
   print("\tDescription    : If this's given then the course image width should not less than this.")
   print("\tExample        : 2010")
   print("\tDefault value  : 1920")
   print("\tSwitch type    : " + YELLOW + "Optional", ENDC)
   
   print(GREEN + "[ -aws_access_key <aws_access_key>]", ENDC)
   print("\tDescription    : Must give a valid AWS access key here.")
   print("\tExample        : AKIA5htdo5RJISLWC6U6")
   print("\tSwitch type    : " + YELLOW + "Mandatory", ENDC)
   
   print(GREEN + "[ -aws_secret_key <aws_secret_key>]", ENDC)
   print("\tDescription    : Must give a valid AWS secret key here.")
   print("\tExample        : yYAldal9DYTNvwrPnGRat45erwi92DaIgGe+5po+")
   print("\tSwitch type    : " + YELLOW + "Mandatory", ENDC)
   
   print(GREEN + "[ -aws_bucket_name <aws_bucket_name>]", ENDC)
   print("\tDescription    : Give a valid AWS bucket name in which all the course data will be uploaded.")
   print("\tExample        : nairp")
   print("\tSwitch type    : " + YELLOW + "Mandatory", ENDC)
   
   print(GREEN + "[ -mongodb_host_url_port <mongodb_host_url_port>]", ENDC)
   print("\tDescription    : ")
   print("\t - Give a valid MongoDB host name and port number, where MongoDB server is running.")
   print("\tExample_1        : localhost:27017")
   print("\tExample_2        : mongodb://NAIRPAdmin:vgByJntyrtryrtga4@1.178.198.80:27017/nairp-test-local-0?authSource=nairp-test-local-0")
   print("\tSwitch type    : " + YELLOW + "Mandatory", ENDC)
   
   print(GREEN + "[ -mongodb_database_name <mongodb_database_name>]", ENDC)
   print("\tDescription    : ")
   print("\t - Give a valid MongoDB database name in which all the course data will be uploaded.")
   print("\t - That database must contain following collection in it :")
   print("\t   - courses")
   print("\t   - concept")
   print("\t   - objectiveExcercise")
   print("\t   - programExcercise")
   print("\tExample        : nairp-test-local-0")
   print("\tSwitch type    : " + YELLOW + "Mandatory", ENDC)
   
   print(GREEN + "[ -shadow_mode]", ENDC)
   print("\tDescription    : If this's given then it means you are a developer and you don't want to upload any thing")
   print("\t\t\t to any where mean it'll not check any third party connection.")
   print("\tDefault value  : off")
   print("\tSwitch type    : " + YELLOW + "Optional", ENDC)
   
   print("\nUse Cases : ")
   print(" 1. For developer : ")
   print("\tUpload_script.py -excel_file_path <excel_file_path> " + BLUE + "[-course_id_overwrite")
   print("\t<course_id_overwrite>] [-add_to_carousal] [-image_min_px_height <image_min_px_height>]")
   print("\t[-image_min_px_width <image_min_px_width>]", ENDC, "-shadow_mode")
   print(" 2. To upload course : ")
   print("\tUpload_script.py -excel_file_path <excel_file_path> " + BLUE + "[-course_id_overwrite")
   print("\t<course_id_overwrite>] [-add_to_carousal] [-image_min_px_height <image_min_px_height>]")
   print("\t[-image_min_px_width <image_min_px_width>]", ENDC, "-aws_access_key <aws_access_key> ")
   print("\t-aws_secret_key <aws_secret_key> -aws_bucket_name <aws_bucket_name>")
   print("\t-mongodb_host_url_port <mongodb_host_url_port> -mongodb_database_name <mongodb_database_name>")
   print(" 3. To delete course : ")
   print("\tUpload_script.py -course_id_delete <course_id_delete> -confirm -aws_access_key ")
   print("\t<aws_access_key> -aws_secret_key <aws_secret_key> -aws_bucket_name <aws_bucket_name> ")
   print("\t-mongodb_host_url_port <mongodb_host_url_port> -mongodb_database_name <mongodb_database_name>")
   


########################## Define course delete function

def delete_from_aws(key):
    try:
        for i in key:
            delete = s3.delete_object(Bucket= aws_bucket_name, Key=i)
    except EndpointConnectionError as end:
        print(str(end) + " while deleting files from AWS, Please Check internet connection.")
        return False

def delete_course_from_system():
    mydb = myclient[mongodb_database_name]
    mycol_course = mydb[MONGODB_COLLECTION[0]]
    mycol_obj = mydb[MONGODB_COLLECTION[1]]
    mycol_prog = mydb[MONGODB_COLLECTION[2]]
    prog_id = []
    obj_id = []
    docs = mycol_course.count_documents({'course_id' : course_id_delete})
    if docs == 1:
        aws_root_path = 'https://'+ aws_bucket_name + '.s3.' + AWS_REGION_NAME + '.amazonaws.com/'
        COURSE_DETAILS = mycol_course.find_one({'course_id' : course_id_delete})
        for i in COURSE_DETAILS:
            if i == 'course_description':
                DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i].replace(aws_root_path, ""))
            elif i == 'course_intro_video':
                DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i].replace(aws_root_path, ""))
            elif i == 'advertisement_image_file':
                DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i].replace(aws_root_path, ""))
            elif i == 'card_image_file':
                DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i].replace(aws_root_path, ""))
            elif i == 'prerequisite_knowledge_file':
                DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i].replace(aws_root_path, ""))
            elif i == 'reference_material_file':
                DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i].replace(aws_root_path, ""))
            elif i == 'copyright_message':
                DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i].replace(aws_root_path, ""))
            elif i == 'instructor':
                for j in range(len(COURSE_DETAILS[i])):
                    DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i][j]['designation'].replace(aws_root_path, ""))
                    if COURSE_DETAILS[i][j]['profile'] != None:
                        DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i][j]['profile'].replace(aws_root_path, ""))
            elif i == 'module':
                for j in range(len(COURSE_DETAILS[i])):
                    for k in range(len(COURSE_DETAILS[i][j]['lecture'])):
                        DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i][j]['lecture'][k]['lecture_video'].replace(aws_root_path, ""))
                        if COURSE_DETAILS[i][j]['lecture'][k]['lecture_note'] != None:
                            DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i][j]['lecture'][k]['lecture_note'].replace(aws_root_path, ""))
                        if COURSE_DETAILS[i][j]['lecture'][k]['worksheet'] != None:                        
                            DELETE_FILES_SYSTEM.append(COURSE_DETAILS[i][j]['lecture'][k]['worksheet'].replace(aws_root_path, ""))
                    for k in range(len(COURSE_DETAILS[i][j]['exercise'])):
                        if COURSE_DETAILS[i][j]['exercise'][k]['exercise_type'] == 'progExercise':
                            prog_id.append(COURSE_DETAILS[i][j]['exercise'][k]['exercise_id'])
                            mycol_prog = mydb[MONGODB_COLLECTION[2]]
                            mongo_prog_exercise = mycol_prog.find_one({'exercise_id' : COURSE_DETAILS[i][j]['exercise'][k]['exercise_id']})
                            for prog in mongo_prog_exercise:
                                if prog == 'worksheet':
                                    DELETE_FILES_SYSTEM.append(mongo_prog_exercise[prog].replace(aws_root_path, ""))
                                if prog == 'evaluation_fn':
                                    DELETE_FILES_SYSTEM.append(mongo_prog_exercise[prog].replace(aws_root_path, ""))
                                if prog == 'datasets' and mongo_prog_exercise[prog] != None:
                                    for data in mongo_prog_exercise[prog]:
                                        DELETE_FILES_SYSTEM.append(data.replace(aws_root_path, ""))
                        else:
                            obj_id.append(COURSE_DETAILS[i][j]['exercise'][k]['exercise_id'])
        delete = delete_from_aws(DELETE_FILES_SYSTEM)
        if delete == False:
            sys.exit()
        mongo_delete_course = mycol_course.delete_one({'course_id' : course_id_delete})
        mongo_delete_prog_count = 0
        for i in prog_id:
            mongo_delete_prog = mycol_prog.delete_one({'exercise_id' : i})
            mongo_delete_prog_count = mongo_delete_prog_count + mongo_delete_prog.deleted_count
        mongo_delete_obj_count = 0
        for i in obj_id:
            mongo_delete_obj = mycol_obj.delete_one({'exercise_id' : i})
            mongo_delete_obj_count = mongo_delete_obj_count + mongo_delete_obj.deleted_count
        if mongo_delete_course.deleted_count == 1 and mongo_delete_prog_count == len(prog_id) and mongo_delete_obj_count == len(obj_id):
            print(GREEN + "\nResult: ", ENDC)
            print(" - Script successfully deleted the course from NAIRP system.")
    
    else:
        print(RED + "\nAn error occur: ", ENDC)
        print(" - There is no course present in our system for this course id.")

def upload_exercise_to_compute_aws():
    error_count = 0
    for i in range(len(UPLOAD_LIST)):
        try:
            r = requests.request("POST", COMPUTE_EXERCISE_URL, headers=EXERCISE_HEADERS, files = UPLOAD_LIST[i], data = EXERCISE_DATA_DICTIONARY_LIST[i])
        except requests.exceptions.ConnectionError:
            error_count = error_count + 1
        if r.text != 'Upload Done' :
            error_count = error_count + 1
            return error_count
    return error_count
    
def create_course_to_compute_aws():
    error_count = 0
    try:
        r = requests.request("POST", COMPUTE_COURSE_URL, headers=COURSE_HEADERS, json = COURSE_DATA_DICTIONARY)
    except requests.exceptions.ConnectionError:
            error_count = error_count + 1
    message = r.text
    if message == '{"message":"Error occured"}' :
        error_count = error_count + 1
        return error_count
    else:
        return error_count
    
    

def delete_course_from_system_while_get_error():
    global PROG_ID, OBJ_ID, CONCEPT_ID

    mydb = myclient[mongodb_database_name]
    mycol_obj = mydb[MONGODB_COLLECTION[1]]
    mycol_prog = mydb[MONGODB_COLLECTION[2]]
    mycol_concept = mydb[MONGODB_COLLECTION[3]]
    mongo_delete_prog_count = 0
    for i in PROG_ID:
        mongo_delete_prog = mycol_prog.delete_one({'exercise_id' : i})
        mongo_delete_prog_count = mongo_delete_prog_count + mongo_delete_prog.deleted_count
    mongo_delete_obj_count = 0
    for i in OBJ_ID:
        mongo_delete_obj = mycol_obj.delete_one({'exercise_id' : i})
        mongo_delete_obj_count = mongo_delete_obj_count + mongo_delete_obj.deleted_count
    mongo_delete_concept_count = 0
    #for i in CONCEPT_ID:
    #    mongo_delete_concept = mycol_concept.delete_one({'concept_id' : i})
    #    mongo_delete_concept_count = mongo_delete_concept_count + mongo_delete_concept.deleted_count
    if mongo_delete_prog_count == len(PROG_ID) and mongo_delete_obj_count == len(OBJ_ID): #and mongo_delete_concept_count == len(CONCEPT_ID):
        return True
    else:
        return False
    


######################### Define function to upload course details to MongoDB ###########################

def mongodb_local(course, concept, question, program):
    #print("2. Upload Course details to MongoDB : ")
    mydb = myclient[mongodb_database_name]
    mycol_course = mydb[MONGODB_COLLECTION[0]]
    mycol_obj = mydb[MONGODB_COLLECTION[1]]
    mycol_prog = mydb[MONGODB_COLLECTION[2]]
    mycol_con = mydb[MONGODB_COLLECTION[3]]
    mongo_concepts = mycol_con.find({})
    ##################################### all changes have been made for front end #################
    for i in range(len(course)):
        mydict_course = course[str(i)]
        present = mycol_course.count_documents({"course_title": course[str(i)]['course_title'], "course_short_name" : course[str(i)]['course_short_name']})
        if present == 1:
           old_to_new_course = mycol_course.find_one({"course_title": course[str(i)]['course_title'], "course_short_name" : course[str(i)]['course_short_name']})
           if old_to_new_course['credit'] != course[str(i)]['credit']:
              old_to_new_course['credit'] = course[str(i)]['credit']
           if old_to_new_course['course_description'] != course[str(i)]['course_description']:
              old_to_new_course['course_description'] = course[str(i)]['course_description']
           if old_to_new_course['course_intro_video'] != course[str(i)]['course_intro_video']:
              old_to_new_course['course_intro_video'] = course[str(i)]['course_intro_video']
           if old_to_new_course['advertisement_image_file'] != course[str(i)]['advertisement_image_file']:
              old_to_new_course['advertisement_image_file'] = course[str(i)]['advertisement_image_file']
           if old_to_new_course['card_image_file'] != course[str(i)]['card_image_file']:
              old_to_new_course['card_image_file'] = course[str(i)]['card_image_file']
           if old_to_new_course['prerequisite_preexisting_course_title_list'] != course[str(i)]['prerequisite_preexisting_course_title_list']:
              old_to_new_course['prerequisite_preexisting_course_title_list'] = course[str(i)]['prerequisite_preexisting_course_title_list']
           if old_to_new_course['prerequisite_knowledge_file'] != course[str(i)]['prerequisite_knowledge_file']:
              old_to_new_course['prerequisite_knowledge_file'] = course[str(i)]['prerequisite_knowledge_file']
           if old_to_new_course['created_on'] != course[str(i)]['created_on']:
              old_to_new_course['created_on'] = course[str(i)]['created_on']
           if old_to_new_course['communication_language'] != course[str(i)]['communication_language']:
              old_to_new_course['communication_language'] = course[str(i)]['communication_language']
           #if old_to_new_course['reference_material_file'] != course[str(i)]['reference_material_file']:
           #   old_to_new_course['reference_material_file'] = course[str(i)]['reference_material_file']
           if old_to_new_course['duration_in_min'] != course[str(i)]['duration_in_min']:
              old_to_new_course['duration_in_min'] = course[str(i)]['duration_in_min']
           if old_to_new_course['offering_period_from_to'] != course[str(i)]['offering_period_from_to']:
              old_to_new_course['offering_period_from_to'] = course[str(i)]['offering_period_from_to']
           if old_to_new_course['copyright_message'] != course[str(i)]['copyright_message']:
              old_to_new_course['copyright_message'] = course[str(i)]['copyright_message']
           if old_to_new_course['module'] != course[str(i)]['module']:
              old_to_new_course['module'] = course[str(i)]['module']
           if old_to_new_course['instructor'] != course[str(i)]['instructor']:
              old_to_new_course['instructor'] = course[str(i)]['instructor']
           
           mycol_course.update_one({"course_title": course[str(i)]['course_title'], "course_short_name" : course[str(i)]['course_short_name']}, { "$set": old_to_new_course })
           
        else:
            mycol_course.insert_one(mydict_course)
    
    for i in range(len(question)):
        mydict_question = question[str(i)]
        present = mycol_obj.count_documents({"exercise_id": question[str(i)]['exercise_id'], "question_type" : question[str(i)]['question_type']})
        if present == 1:
           old_to_new_obj_exercise = mycol_obj.find_one({"exercise_id": question[str(i)]['exercise_id'], "question_type" : question[str(i)]['question_type']})
           if old_to_new_obj_exercise['mcq_type'] != question[str(i)]['mcq_type']:
              old_to_new_obj_exercise['mcq_type'] = question[str(i)]['mcq_type']
           if old_to_new_obj_exercise['question_text'] != question[str(i)]['question_text']:
              old_to_new_obj_exercise['question_text'] = question[str(i)]['question_text']
           if old_to_new_obj_exercise['concepts'] != question[str(i)]['concepts']:
              old_to_new_obj_exercise['concepts'] = question[str(i)]['concepts']
           if old_to_new_obj_exercise['list_of_choices'] != question[str(i)]['list_of_choices']:
              old_to_new_obj_exercise['list_of_choices'] = question[str(i)]['list_of_choices']
           if old_to_new_obj_exercise['list_of_answers'] != question[str(i)]['list_of_answers']:
              old_to_new_obj_exercise['list_of_answers'] = question[str(i)]['list_of_answers']
           if old_to_new_obj_exercise['marks'] != question[str(i)]['marks']:
              old_to_new_obj_exercise['marks'] = question[str(i)]['marks']
           
        else:
            mycol_obj.insert_one(mydict_question)
    for i in range(len(program)):
        mydict_program = program[str(i)]
        present = mycol_prog.count_documents({"exercise_id": program[str(i)]['exercise_id']})
        if present == 1:
           old_to_new_prog_exercise = mycol_prog.find_one({"exercise_id": program[str(i)]['exercise_id']})
           if old_to_new_prog_exercise['marks'] != program[str(i)]['marks']:
              old_to_new_prog_exercise['marks'] = program[str(i)]['marks']
           if old_to_new_prog_exercise['concepts'] != program[str(i)]['concepts']:
              old_to_new_prog_exercise['concepts'] = program[str(i)]['concepts']
           if old_to_new_prog_exercise['worksheet'] != program[str(i)]['worksheet']:
              old_to_new_prog_exercise['worksheet'] = program[str(i)]['worksheet']
           if old_to_new_prog_exercise['evaluation_fn'] != program[str(i)]['evaluation_fn']:
              old_to_new_prog_exercise['evaluation_fn'] = program[str(i)]['evaluation_fn']
           if old_to_new_prog_exercise['datasets'] != program[str(i)]['datasets']:
              old_to_new_prog_exercise['datasets'] = program[str(i)]['datasets']
           #if old_to_new_prog_exercise['sub_exercises'] != program[str(i)]['sub_exercises']:
           #   old_to_new_prog_exercise['sub_exercises'] = program[str(i)]['sub_exercises']
           
        else:
            mycol_prog.insert_one(mydict_program)
    #########################################################################################################################################
    return_id = []
    for i in mongo_concepts:
        return_id.append(i['concept_id'])
    for i in range(len(concept)):
        if concept[str(i)]['concept_id'] not in return_id:
            mydict_concept = concept[str(i)]
            mycol_con.insert_one(mydict_concept)
        
    for i in range(len(course)):
        present = mycol_course.count_documents({"course_title": course[str(i)]['course_title'], "course_short_name" : course[str(i)]['course_short_name']})
        if present == 1:
            new_course = mycol_course.find_one({"course_title": course[str(i)]['course_title'], "course_short_name" : course[str(i)]['course_short_name']})
            #print("\t - The course is uploaded in the database successfully " + "and Course obj_id : " + str(new_course["_id"]))
            print(str(new_course["_id"]))            
        else:
            delete_from_aws(COMPLETE_UPLOAD)
            value = delete_course_from_system_while_get_error()
            if value is True:    
                print(RED + "\nAn error occur :\n", ENDC, "\t - The course is not uploaded to MongoDB successfully.")
                sys.exit()
            else:
                print(RED + "\nAn error occur :\n", ENDC, "\t - No connection could be made with database because the target machine actively refused it.")
                sys.exit()



########################## Define function to Upload videos, images, notes, datasets to aws #################################

    
def upload_to_aws(local_file_path, bucket_name, file_name, name):
    try:
        Objects = s3.list_objects(Bucket=bucket_name) # here we get the all object name for duplicate name
        obj_name = []
        for i in range(len(Objects['Contents'])):
            obj_name.append(Objects['Contents'][i]['Key'])
        if file_name in obj_name:
            print(RED + "\nAn error occur : ", ENDC)
            print("\t" + "- " + name + " name is already in use in S3.")
            return False
        else:
            p = s3.upload_file(local_file_path, bucket_name, file_name)
            a2 = name + " Upload Successfully to AWS S3."
            print("\t" + "*." + a2)
            return True
    except FileNotFoundError:
        print(RED + "\nAn error occur : ", ENDC)
        print("\t" + "- " + name + " file was not found in this path" + local_file_path + ".\n")
        return False
    except ParamValidationError as e:
        print("Parameter validation error: " + e)
        return False
    except EndpointConnectionError as end:
        print(str(end) + "while uploading files to AWS, Please check internet connection.")
        return False

def mongo_check(v, name, sheet_name):
    mydb = myclient[mongodb_database_name]
    mycol_course = mydb[MONGODB_COLLECTION[0]]
    mycol_course_2 = mydb["courses"]
    mycol_obj = mydb[MONGODB_COLLECTION[1]]
    mycol_prog = mydb[MONGODB_COLLECTION[2]]
    mycol_con = mydb[MONGODB_COLLECTION[3]]
    
    if sheet_name == 'course':
        courses = mycol_course.find({})
        exist_courses = mycol_course_2.find({})
        c_id = []
        for i in courses:
            c_id.append(i['course_id'])
        for i in exist_courses:
            c_id.append(i['course_id'])
        
        if course_id_overwrite != None:
            if course_id_overwrite in c_id:    
                final_course_id = max(c_id) + 1
            else:
                final_course_id = course_id_overwrite
        else:
            final_course_id = max(c_id) + 1
        present = mycol_course.count_documents({v : name})
        if present >= 1:
            return "Exists a course called " + name + " in MongoDB database.", final_course_id
        else:
            return True, final_course_id
    elif sheet_name == 'concept':
        concepts = mycol_con.find({})
        con_id = []
        return_id = []
        for i in concepts:
            return_id.append(i['concept_id'])
        #for i in name:
        #    if i in con_id:
        #        return_id.append(i)
        if len(return_id) > 0:
            return False, return_id
        else:
            return True, return_id
    elif sheet_name == 'prog_exercise':
        prog_exercise = mycol_prog.find({})
        prog_id = []
        return_id = []
        for i in prog_exercise:
            prog_id.append(i['exercise_id'])
        for i in name:
            if i in prog_id:
                return_id.append(i)
        if len(return_id) > 0:
            return False, return_id
        else:
            return True, return_id
    elif sheet_name == 'obj_exercise':
        obj_exercise = mycol_obj.find({})
        obj_id = []
        return_id = []
        for i in obj_exercise:
            obj_id.append(i['exercise_id'])
        for i in name:
            if i in obj_id:
                return_id.append(i)
        if len(return_id) > 0:
            return False, return_id
        else:
            return True, return_id

################################# Convert CSV to Json #################################

def condition_fun(value):
    l = []
    if type(value) == int or type(value) == float:
        l.append(value)
        return l
    elif type(value) == str:
        return value.split('|||') 

def check_concept(concept, con_id, row, column_name, sheet_name):
    if isinstance(concept, list):
        for qa in concept:
            try:
                if int(qa) not in con_id:
                    ERROR_MESSAGE.append("The " + str(qa) + " id of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet isn't present in concept sheet.")
            except ValueError:
                ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet must be an integer or a string(like id_1|||id_2).")
                
    

def check_dataset_file_details(row, file_path, store, column_name, sheet_name):
    if file_path in store:
        ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '"+ sheet_name +"' sheet is already being used in this sheet.")
        return False
    else:
        extension = file_path[-4:]
        if extension == '.csv':
            try:
                size = os.path.getsize(file_path)
                if size < DEFAULT_DATASET_FILE_SIZE:
                    ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet must be at least 1 KB in size.")
            except FileNotFoundError:
                ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet isn't present.")
        else:
            ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet extension isn't csv.")
    return True
      
    
def check_evaluation_fn_file_details(row, file_path, store, column_name, sheet_name):
    if file_path in store:
        ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '"+ sheet_name +"' sheet is already being used in this sheet.")
        return False
    else:
        extension = file_path[-3:]
        if extension == '.py':
            try:
                size = os.path.getsize(file_path)
                if size < DEFAULT_EVALUATION_FN_FILE_SIZE:
                    ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet must be at least 1 KB in size.")
            except FileNotFoundError:
                ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet isn't present.")
        else:
            ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet extension isn't py.")
    return True
      

def check_worksheet_file_details(row, file_path, store, column_name, sheet_name):
    if file_path in store:
        ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '"+ sheet_name +"' sheet is already being used in this sheet.")
        return False
    else:
        extension = file_path[-6:]
        if extension == '.ipynb':
            try:
                size = os.path.getsize(file_path)
                if size < DEFAULT_WORKSHEET_FILE_SIZE:
                    ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet must be at least 1 KB in size.")
            except FileNotFoundError:
                ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet isn't present.")
        else:
            ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet extension isn't ipynb'.")
    return True
      


def check_video_details(row, file_path, store, column_name, sheet_name):
    if file_path in store:
        ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '"+ sheet_name +"' sheet is already being used in this sheet.")
        return False
    else:
        extension = file_path[-4:]
        if extension == '.mp4':
            try:
                size = os.path.getsize(file_path)
                if size < DEFAULT_VIDEO_FILE_SIZE:
                    ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet must be at least 10 KB in size.")
            except FileNotFoundError:
                ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet isn't present.")
        else:
            ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet extension isn't mp4.")
    return True
      
def check_PDF_file_details(row, file_path, store, column_name, sheet_name):
    if file_path in store:
        ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '"+ sheet_name +"' sheet is already being used in this sheet.")
        return False
    else:
        extension = file_path[-4:]
        if extension == '.pdf':
            try:
                size = os.path.getsize(file_path)
                if size < DEFAULT_NOTE_FILE_SIZE and sheet_name == 'lecture':
                    ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet must be at least 10 KB in size.")
            except FileNotFoundError:
                ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet isn't present.")
        else:
            ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet extension isn't pdf.")
    return True
      
def check_image_file_details(row, file_path, store, column_name, sheet_name):
    if file_path in store:
        ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '"+ sheet_name +"' sheet is already being used in this sheet.")
        return False
    else:
        extension = file_path[-4:]
        if extension == '.png' or extension == '.jpg':
            try:
                file = Image.open(file_path, "r")
                size = os.path.getsize(file_path)
                if size < DEFAULT_IMAGE_FILE_SIZE:
                    ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet must be at least 50 KB in size.")
                elif not file.size[0] >= int(image_min_px_width):
                    ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet width atleast " + str(image_min_px_width) + " pixels.")
                elif not file.size[1] >= int(image_min_px_height):
                    ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet height atleast " + str(image_min_px_height) + " pixels.")
            except FileNotFoundError:
                ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet isn't present.")
        else:
            ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet extension isn't jpg or png'.")
    return True
                            
def check_text_file_details(row, file_path, store, column_name, sheet_name):
    if file_path in store:
        ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '"+ sheet_name +"' sheet is already being used in this sheet.")
        return False
    else:
        extension = file_path[-4:]
        if extension == '.txt':
            try:
                file = open(file_path, "rt")
                size = os.path.getsize(file_path)
                data = file.read()
                words = data.split()
                if column_name == 'designation' or column_name == 'profile' or column_name == 'copyright_message':
                    if len(words)< MIN_WORD_LENGTH:
                        ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet is empty.")
                    elif len(words) > MAX_WORD_LENGTH:
                        ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet overshoot the word limit.")
                elif len(words )< MIN_WORD_LENGTH and size < DEFAULT_TXT_FILE_SIZE:
                    ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet is empty.")
                elif len(words) > MAX_WORD_LENGTH:
                    ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet overshoot the word limit.")
                elif column_name == 'reference_material_file':
                    file = open(file_path, "r")
                    lines = file.readlines()
                    if shadow_mode == 'off':
                        for i in lines:
                            if len(i) > 5 and i[:5] == 'https':
                                r = requests.get(url = i[:-1])
                                try:
                                    if r.status_code != 200:
                                        ERROR_MESSAGE.append("The "+ i[:-1] +" of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet isn't not a valid one.")
                                except requests.exceptions.ConnectionError:
                                    ERROR_MESSAGE.append("Failed to establish a new connection to this url: " + i[:-1])
                                except requests.MaxRetryError:
                                    ERROR_MESSAGE.append("Failed to establish a new connection to this url: " + i[:-1])
            except FileNotFoundError:
                ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet isn't present.")# in the " + folder_name + " folder.")
        else:
            ERROR_MESSAGE.append("The '" + file_path + "' file of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet extension isn't txt.")                     
    return True

def check_id_each_sheet(row, id_no, stored_id, column_name, sheet_name):
    if not id_no >= 1:
        ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet must be greater than 1.")
        return False
    elif  id_no in stored_id:
        ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name +"' sheet is already being used in this sheet.")
        return False
    else:
        return id_no
                
def check_date_format(row, date, vc, column_name, sheet_name):
    try:
        if vc == 0:
            try:
                datetime.datetime.strptime(date, DATE_FORMAT)
                year = date.split('-')
                d1 = datetime.datetime(int(year[0]), int(year[1]), int(year[2])) 
                if d1 < ERROR_DATE:
                    ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name + "' sheet created date must be greater than " + ERROR_DATE + ".")                                            
            except ValueError:
                ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name + "' sheet is the incorrect date string format. It should be YYYY-MM-DD")
        elif vc == 1:
            er = 0
            for i in date:
                try:
                    datetime.datetime.strptime(i, DATE_FORMAT)
                except ValueError:
                    er = er + 1
                    ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name + "' sheet is the incorrect date string format. It should be YYYY-MM-DD")
            if er != 0:
                year1 = date[0].split('-')
                year2 = date[1].split('-')
                d1 = datetime.datetime(int(year1[0]), int(year1[1]), int(year1[2])) 
                d2 = datetime.datetime(int(year2[0]), int(year2[1]), int(year2[2])) 
                d3 = datetime.datetime(2020, 1, 1)
                if d1 < d3 or d1 > d2:
                    ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name + "' sheet start date must be greater than 2020-01-01 and less than " + date[1] + ".")                                            
    except ValueError:
        ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '" + sheet_name + "' sheet is the incorrect date string format. It should be YYYY-MM-DD")
                    
def check_title(row, value, store, column_name, sheet_name):
    if not isinstance(value,str):
        ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '"+ sheet_name +"' sheet must be a string.")
        return False
    elif value in store:
        ERROR_MESSAGE.append("The value of the '" + column_name + "' column of the number " + str(row) + " row in the '"+ sheet_name +"' sheet is already being used in this sheet.")
        return False
    else:
        return True
    

def miss_fields_fun():
    course_fields = []
    module_fields = []
    lecture_fields = []
    exercise_fields = []
    prog_exercise_fields = []
    obj_exercise_fields = []
    obj_exercise_PDF_fields = []
    sub_exercise_fields = []
    concept_fields = []
    instructor_fields = []
    
    # Course
    
    for k,v in COURSE_DETAILS.items():
        for g in v:
            if g not in course_fields:
                course_fields.append(g)
    for i in COURSE_SHEET_FIELD:
        if i not in course_fields:
            ERROR_MESSAGE.append( i + " field isn't present in the 'course' sheet.")
 
    # Module
    
    for k,v in MODULE_DETAILS.items():
        for g in v:
            if g not in module_fields:
                module_fields.append(g)
    for i in MODULE_SHEET_FIELD:
        if i not in module_fields:
            ERROR_MESSAGE.append( i + " field isn't present in the 'module' sheet.")

    # Lecture
    
    for k,v in LECTURE_DETAILS.items():
        for g in v:
            if g not in lecture_fields:
                lecture_fields.append(g)
    for i in LECTURE_SHEET_FIELD:
        if i not in lecture_fields:
            ERROR_MESSAGE.append( i + " field isn't present in the 'lecture' sheet.")
    
    # Worked out worksheet
    
    for k,v in WORKED_OUT_WORKSHEET_DETAILS.items():
        for g in v:
            if g not in worked_out_worksheet_fields:
                worked_out_worksheet_fields.append(g)
    for i in WORKED_OUT_WORKSHEET_SHEET_FIELD:
        if i not in worked_out_worksheet_fields:
            ERROR_MESSAGE.append( i + " field isn't present in the 'worked out worksheet' sheet.")
    
    # Exercise
    
    for k,v in EXERCISE_DETAILS.items():
        for g in v:
            if g not in exercise_fields:
                exercise_fields.append(g)
    for i in EXERCISE_SHEET_FIELD:
        if i not in exercise_fields:
            ERROR_MESSAGE.append( i + " field isn't present in the 'exercise' sheet.")
     
    # Program Exercise
    
    for k,v in PROG_EXERCISE_DETAILS.items():
        for g in v:
            if g not in prog_exercise_fields:
                prog_exercise_fields.append(g)
    for i in PROG_EXERCISE_SHEET_FIELD:
        if i not in prog_exercise_fields:
            ERROR_MESSAGE.append( i + " field isn't present in the 'prog_exercise' sheet.")
    
    # Object Exercise
    
    for k,v in OBJ_EXERCISE_DETAILS.items():
        for g in v:
            if g not in obj_exercise_fields:
                obj_exercise_fields.append(g)
    for i in OBJ_EXERCISE_SHEET_FIELD:
        if i not in obj_exercise_fields:
            ERROR_MESSAGE.append( i + " field isn't present in the  'obj_exercise' sheet.")
    
    # Object Exercise PDF
    
    #for k,v in OBJ_EXERCISE_PDF_DETAILS.items():
    #    for g in v:
    #        if g not in obj_exercise_PDF_fields:
    #            obj_exercise_PDF_fields.append(g)
    #for i in OBJ_EXERCISE_PDF_SHEET_FIELD:
    #    if i not in obj_exercise_PDF_fields:
    #        ERROR_MESSAGE.append( i + " field isn't present in the  'obj_exercise_PDF' sheet.")
    
    # Sub Exercise
    
    #for k,v in SUB_EXERCISE_DETAILS.items():
    #    for g in v:
    #        if g not in sub_exercise_fields:
    #            sub_exercise_fields.append(g)
    #for i in SUB_EXERCISE_SHEET_FIELD:
    #    if i not in sub_exercise_fields:
     #       ERROR_MESSAGE.append( i + " field isn't present in the 'sub_exercise' sheet.")
    
    # Concept
    
    for k,v in CONCEPT_DETAILS.items():
        for g in v:
            if g not in concept_fields:
                concept_fields.append(g)
    for i in CONCEPT_SHEET_FIELD:
        if i not in concept_fields:
            ERROR_MESSAGE.append( i + " field isn't present in the 'concept' sheet.")
    
    # Instructor
    
    for k,v in INSTRUCTOR_DETAILS.items():
        for g in v:
            if g not in instructor_fields:
                instructor_fields.append(g)
    for i in INSTRUCTOR_SHEET_FIELD:
        if i not in instructor_fields:
            ERROR_MESSAGE.append( i + " field isn't present in the 'instructor' sheet.")
    
     
def miss_value_fun():
    global COURSE_DATA_DICTIONARY
    mou_id = []
    lec_id = []
    exe_id = []
    pro_work_id = []
    obj_ex_id = []
    obj_ex_PDF_id =[]
    sub_ex_id = []
    ins_id = []
    con_id = []
    ################### check wether all the mandatory feilds have values or not
    
    ############################################# instructor sheet #############################################
    row = 1
    designation = []
    profile = []
    for k,v in INSTRUCTOR_DETAILS.items():
        row = row + 1
        for g in v:
            if v['id'] == None or v['name'] == None or v['designation'] == None:
                ERROR_MESSAGE.append('The number ' + str(row) + " row of 'instructor' sheet has no value in the '" + g + "' column.")
            elif g == 'id':
                if isinstance(v[g], int):
                    id_no = check_id_each_sheet(row, v[g], ins_id, g, 'instructor')
                    if id_no != False:
                        ins_id.append(id_no)
                else:
                    ERROR_MESSAGE.append("The ''" + g + "'' column of the number " + str(row) + " row in the 'instructor' sheet only store the integer value.")
            elif g == 'name':
                if not isinstance(v[g],str):
                    ERROR_MESSAGE.append("The value of the ''" + g + "'' column of the number " + str(row) + " row in the 'instuctor' sheet must be a string.")
                else:
                    ins_name = v[g].split()
                    count = 0
                    for w in ins_name:
                        if not w[0].isupper():
                            count = count +1
                        elif not w.isalpha():
                            if '.' not in w:
                                count = count +1
                    if count != 0:
                        ERROR_MESSAGE.append("The name of the ''" + g + "'' column of the number " + str(row) + " row in the 'instuctor' sheet must contains only alphabets and the first letter of each word is a capital letter.")
            elif g == 'designation' or g == 'profile':
                if g == 'profile' and v[g] == None:
                    continue
                #else:
                #    if g == 'designation':
                #        return_value = check_text_file_details(row, v[g], designation, g, "instructor")
                #        if return_value is True:
                #            designation.append(v[g])
                #    else:
                #        return_value = check_text_file_details(row, v[g], profile, g, "instructor")
                #        if return_value is True:
                #            profile.append(v[g])
            
                
    ############################################# concept sheet #############################################
    
    row = 1
    concept_text = []
    for k,v in CONCEPT_DETAILS.items():
        row = row + 1
        for g in v:
            if v[g] == None:
                ERROR_MESSAGE.append('The number ' + str(row) + " row of 'concept' sheet has no value in the '" + g + "' column.")
            elif g == 'concept_id':
                if isinstance(v[g], int):
                    id_no = check_id_each_sheet(row, v[g], con_id, g, 'concept')
                    if id_no != False:
                        con_id.append(id_no)
                else:
                    ERROR_MESSAGE.append("The ''" + g + "'' column of the number " + str(row) + " row in the 'concept' sheet only store the integer value.")
            elif g == 'concept_text':
                if not isinstance(v[g],str):
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'concept' sheet must be a string.")
                else:
                    if v[g] in concept_text:
                        ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'concept' sheet is already being used.")
                    else:
                        concept_text.append(v[g])
    
    #if shadow_mode == 'off':
    #    value, id_list = mongo_check('concept_id', con_id, 'concept')
        #if value == False:
        #    for i in id_list:
        #        ERROR_MESSAGE.append(str(i) + " concept id is already being used in NAIRP system.")
    CONCEPT_ID = con_id
    ############################################# sub_exercises sheet #############################################
    #row = 1
    #for k,v in SUB_EXERCISE_DETAILS.items():
    #    row = row + 1
    #    for g in v:
    #        if v[g] == None:
    #            ERROR_MESSAGE.append('The number ' + str(row) + " row of 'sub_excercise' sheet has no value in the " + v + " column.")
    #        elif g == 'id':
    #            if isinstance(v[g], int):
    #                id_no = check_id_each_sheet(row, v[g], sub_ex_id, g, 'sub_exercises')
    #                if id_no != False:
    #                    sub_ex_id.append(id_no)
    #            else:
    #                ERROR_MESSAGE.append("The ''" + g + "'' column of the number " + str(row) + " row in the 'sub_exercises' sheet only store the integer value.")
    #        elif g == 'concepts':
    #            if isinstance(v[g], str) or isinstance(v[g], int):
    #                concept = condition_fun(v[g])
    #                check_concept(concept, con_id, row, g, "sub_exercises")
    #        elif g == 'marks':
    #            if not isinstance(v[g], int):
    #                ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'sub_exercises' sheet must be an integer.")
    #            elif not v[g] >= 1 and v[g] <= 100:
    #                ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'sub_exercises' sheet must be greater than 1.")
            
        
    ############################################# prog_exercise sheet #############################################
    row = 1
    evaluation_fn = []
    worksheet = []
    dataset = []
    sub_id = []
    for k,v in PROG_EXERCISE_DETAILS.items():
        row = row + 1
        read_data_for_compute_aws = []
        for g in v:
             if v['exercise_id'] == None or v['marks'] == None or v['concepts'] == None or v['evaluation_fn'] == None or v['worksheet'] == None or v['concepts'] == 'None':
                 continue # ERROR_MESSAGE.append('The number ' + str(row) + " row of 'prog_excercise' sheet has no value in the '" + g + "' column.")
             elif g == 'exercise_id':
                if isinstance(v[g], int):
                    id_no = check_id_each_sheet(row, v[g], pro_work_id, g, 'prog_exercise')
                    if id_no != False:
                        pro_work_id.append(id_no)
                else:
                    ERROR_MESSAGE.append("The ''" + g + "'' column of the number " + str(row) + " row in the 'prog_exercise' sheet only store the integer value.")
             elif g == 'marks':
                if not isinstance(v[g], int):
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'prog_exercise' sheet must be an integer.")
                elif not v[g] >= 1 and v[g] <= 100:
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'prog_exercise' sheet must be greater than 1.")
             elif g == 'concepts':
                if isinstance(v[g], str) or isinstance(v[g], int):
                    concept = condition_fun(v[g])
                    check_concept(concept, con_id, row, g, "prog_exercise")
             elif g == 'sub_exercises':
                if v[g] == None:
                    continue
                else:
                    sub_exercises = condition_fun(v[g])
                    if isinstance(sub_exercises, list):
                        for qa in sub_exercises:
                            try:
                                if int(qa) not in sub_ex_id:
                                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'prog_exercise' sheet isn't present in Sub_exercise sheet.")
                                elif qa in sub_id:
                                    ERROR_MESSAGE.append("The sub_exercises id " + qa + " of the '" + g + "' column of the number " + str(row) + " row in the 'prog_exercise' sheet is already being used in this sheet.")
                                else:
                                    sub_id.append(qa)
                            except ValueError:
                                ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'prog_exercise' sheet must be an integer or a string(like id_1|||id_2).")
                    else:
                        ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'prog_exercise' sheet must be an integer or a string(like id_1|||id_2).")
             #elif g == 'evaluation_fn':
             #    evu = condition_fun(v[g])
             #    for op in evu:
             #       return_value = check_evaluation_fn_file_details(row, op, evaluation_fn, g, "prog_exercise")
             #       if return_value is True:
             #           evaluation_fn.append(op)
             #elif g == 'worksheet':
             #    sheet = condition_fun(v[g])
             #    for op in sheet:
             #       return_value = check_worksheet_file_details(row, op, worksheet, g, "prog_exercise")
             #       if return_value is True:
             #           worksheet.append(op)
             #elif g == 'datasets':
             #    if v[g] == None:
             #       continue
             #    else:
             #        dataset_path = condition_fun(v[g])
             #        for op in dataset_path:
             #            return_value = check_dataset_file_details(row, op, dataset, g, "prog_exercise")
             #            if return_value is True:
             #                dataset.append(op)
    
    #if shadow_mode == 'off':
    #    value, id_list = mongo_check('exercise_id', pro_work_id, 'prog_exercise')
    #    if value == False:
    #        for i in id_list:
    #            ERROR_MESSAGE.append(str(i) + " prog_exercise id is already being used in NAIRP system.")
    PROG_ID = pro_work_id
    ############################################# obj_exercise_pdf ###############################################
    #question_PDF = []
    #choice_PDF = []
    #row = 1
    #for k,v in OBJ_EXERCISE_PDF_DETAILS.items():
    #    row = row + 1
    #    for g in v:
    #        if v[g] == None:
    #            ERROR_MESSAGE.append('The number ' + str(row) + " row of 'obj_excercise_PDF' sheet has no value in the '" + g + " column.")
    #        elif g == 'id':
    #            if isinstance(v[g], int):
    #                id_no = check_id_each_sheet(row, v[g], obj_ex_PDF_id, g, 'obj_exercise_PDF')
    #                if id_no != False:
    #                    obj_ex_PDF_id.append(id_no)
    #            else:
    #                ERROR_MESSAGE.append("The '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise_pdf' sheet only store the integer value.")
    #        elif g == 'question_pdf':
   #             if v[g] == None:
    #                continue
    #            else:
    #                return_value = check_PDF_file_details(row, v[g], question_PDF, g, "obj_exercise_PDF")
    #                if return_value is True:
    #                    question_PDF.append(v[g])
    #        elif g == 'choices_pdf':
    #            if v[g] == None:
    #                continue
    #            else:
    #                return_value = check_PDF_file_details(row, v[g], choice_PDF, g, "obj_exercise_PDF")
    #                if return_value is True:
    #                    choice_PDF.append(v[g])
    
    ############################################# obj_exercise sheet #############################################
    
    row = 1
    pdf = [True, False]
    for k,v in OBJ_EXERCISE_DETAILS.items():
        row = row + 1
        for g in v:
            if v[g] == None or v[g] == 'None':
               continue # ERROR_MESSAGE.append('The number ' + str(row) + " row of 'obj_excercise' sheet has no value in the '" + g + "' column.")
            elif g == 'exercise_id':
                if isinstance(v[g], int):
                    id_no = check_id_each_sheet(row, v[g], obj_ex_id, g, 'obj_exercise')
                    if id_no != False:
                        obj_ex_id.append(id_no)
                else:
                    ERROR_MESSAGE.append("The '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet only store the integer value.")
            elif g == 'choice_has_pdf':
                if v[g] in pdf:
                    choice_has_PDF = v[g]
                else:
                    ERROR_MESSAGE.append("The '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet only store a boolean value.")
            
            elif g == 'question_type':
                if not isinstance(v[g],str):
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must be a string.")
                elif v[g] not in QUESTION_TYPE:
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must be mcq or fillup.")
                else:
                    t1 = v[g]
            elif g == 'question_has_pdf':
                if v[g] in pdf:
                    question_has_PDF = v[g]
                else:
                    ERROR_MESSAGE.append("The '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet only store a boolean value.")
            
            elif g == 'mcq_type':
                if not isinstance(v[g],str):
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must be a string.")
                elif v[g] not in MCQ_TYPE:
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must be multichoice or singlechoice or none.")
                elif v[g] == 'multichoice' or v[g] == 'singlechoice':
                    if t1 != 'mcq':
                        ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet you provide " + v[g] + " but the question_type is not " + t1 +".")
                elif v[g] == 'none':
                    if t1 != 'fillup':
                        ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet you provide " + v[g] + " but the question_type is not fillup.")
            elif g == 'question':
                if not isinstance(v[g],str):
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must be a string.")
                elif v[g] == 'none' and question_has_PDF == True:
                    continue
                elif '$$' not in v[g].split(" ") and t1 == 'fillup':
                    if '$#' not in v[g].split(" "):
                        ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must have $$ or $# symbol because in it the question type is " + t1 +".")
                    else:
                        count = 0
                        for d in v[g].split():
                            if d == '$$' or d == '$#':
                                count = count + 1
                        if count > 1:
                            ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must have one $$ or one $# symbol because in it the question type is " + t1 +".")
            elif g == 'list_of_choices':
                if not isinstance(v[g],str):
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must be a string.")
                elif v[g] == 'none' and choice_has_PDF == True:
                    continue
                elif t1 == 'mcq':
                    if '|||' in v[g]:
                        value = v[g].split('|||')
                        if len(value)>1 and len(value) < 5:
                            continue
                        else:
                            ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must have more than 1 answer choice but less than 5.")
                    else:
                        ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must separated with '|||' because question_type is mcq.")
                elif t1 == 'fillup':
                    if '|||' in v[g]:
                        ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet only single value allowed because question_type is fillup.")
                    else:
                        value = v[g]
            elif g == 'list_of_answers':
                if not isinstance(v[g],str):
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must be a string.")
                elif t1 == 'mcq' and v['mcq_type'] == 'multichoice':
                    if '|||' in v[g]:
                        value1 = v[g].split('|||')
                        if len(value1)>1 and len(value1) < 5:
                            for t in value1:
                                if t not in value:
                                    ERROR_MESSAGE.append("The "+ t +" of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet isn't present in list_of_choices column.")
                        else:
                            ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must have more than 1 answer choice but less than 5.")
                    else:
                        ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must separated with '|||' because question_type is mcq and mcr_type is multichoice.")
                elif t1 == 'fillup'and v['mcq_type'] == 'none':
                    if '|||' in v[g]:
                        ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet only single value alowed because question_type is fillup.")
                    else:
                        if v[g] != value:
                            ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet isn't present in list_of_choices column.")
            elif g == 'marks':
                if not isinstance(v[g], int):
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must be an integer.")
                elif not v[g] >= 1 and v[g] <= 100:
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'obj_exercise' sheet must be greater than 1.")
            elif g == 'concepts':
                if isinstance(v[g], str) or isinstance(v[g], int):
                    concept = condition_fun(v[g])
                    check_concept(concept, con_id, row, g, "obj_exercise")
   
    #if shadow_mode == 'off':
    #    value, id_list = mongo_check('exercise_id', obj_ex_id, 'obj_exercise')
    #    if value == False:
    #        for i in id_list:
    #            ERROR_MESSAGE.append(str(i) + " obj_exercise id is already being used in NAIRP system.")
    OBJ_ID = obj_ex_id
    
   ############################################# exercise sheet #############################################
    row =1
    for k,v in EXERCISE_DETAILS.items():
        row = row + 1
        for g in v:
            if v[g] == None:
                ERROR_MESSAGE.append('The number ' + str(row) + " row of 'excercise' sheet has no value in the ''" + g + "'' column.")
            elif g == 'exercise_type':
                if not isinstance(v[g],str):
                    ERROR_MESSAGE.append("The value of the ''" + g + "'' column of the number " + str(row) + " row in the 'exercise' sheet must be a string.")
                elif v[g] not in EXERCISE:
                    ERROR_MESSAGE.append("The value of the ''" + g + "'' column of the number " + str(row) + " row in the 'exercise' sheet must be objectiveExercise or progExercise.")
                else:
                    ty = v[g]
            elif g == 'exercise_id':
                if isinstance(v[g], int):
                    id_no = check_id_each_sheet(row, v[g], exe_id, g, 'exercise')
                    if id_no != False:
                        exe_id.append(id_no)
                        if ty == EXERCISE[0]:
                            if v[g] in obj_ex_id and v[g] in pro_work_id:
                                ERROR_MESSAGE.append("The value of the ''" + g + "'' column of the number " + str(row) + " row in the 'exercise' sheet present in both obj_execercise and prog_exercise sheet.")
                            elif v[g] not in obj_ex_id and v[g] in pro_work_id:
                                ERROR_MESSAGE.append("The value of the ''" + g + "'' column of the number " + str(row) + " row in the 'exercise' sheet present in prog_exercise sheet not in obj_execercise sheet.")
                        elif ty == EXERCISE[1]:
                            if v[g] in obj_ex_id and v[g] in pro_work_id:
                                ERROR_MESSAGE.append("The value of the ''" + g + "'' column of the number " + str(row) + " row in the 'exercise' sheet present in both obj_execercise and prog_exercise sheet.")
                            elif v[g] not in pro_work_id and v[g] in obj_ex_id:
                                ERROR_MESSAGE.append("The value of the ''" + g + "'' column of the number " + str(row) + " row in the 'exercise' sheet present in obj_execercise sheet not in prog_exercise sheet.")
                else:
                    ERROR_MESSAGE.append("The value of the ''" + g + "'' column of the number " + str(row) + " row in the 'exercise' sheet only store the integer value.")
            
    ############################################ worked_out_worksheet sheet ##############################################
    row = 1
    worked_out_worksheet = []
    worksheet_id = []
    for k,v in WORKED_OUT_WORKSHEET_DETAILS.items():
        row = row + 1
        for g in v:
            if v[g] == None:
                ERROR_MESSAGE.append('The number ' + str(row) + " row of 'worked_out_worksheet' sheet has no value in the '" + g + "' column.")
            elif g == 'worksheet_id':
                if isinstance(v[g], int) or isinstance(v[g], float):
                    id_no = check_id_each_sheet(row, v[g], worksheet_id, g, 'worked_out_worksheet')
                    if id_no != False:
                        worksheet_id.append(id_no)
                else:
                    ERROR_MESSAGE.append("The '" + g + "' column of the number " + str(row) + " row in the 'worked_out_worksheet' sheet only store the integer value.")
            #elif g == 'worksheet':
            #    return_value = check_worksheet_file_details(row, v[g], worked_out_worksheet, g, "worked_out_worksheet")
            #    if return_value is True:
             #       worked_out_worksheet.append(v[g])
            
        
                   
    ############################################ Lecture sheet ##############################################
    row = 1
    lec_title = []
    lec_video = []
    lec_note = []
    lec_worksheet = []
    for k,v in LECTURE_DETAILS.items():
        row = row + 1
        for g in v:
            if v[g] == 'None': # v['lecture_id'] == None or v['lecture_title'] == None or v['topic'] == None or v['concepts'] == None or v['lecture_video'] == None :
                continue # ERROR_MESSAGE.append('The number ' + str(row) + " row of 'lecture' sheet has no value in the '" + g + "' column.")
            elif g == 'lecture_id':
                if isinstance(v[g], int):
                    id_no = check_id_each_sheet(row, v[g], lec_id, g, 'lecture')
                    if id_no != False:
                        lec_id.append(id_no)
                else:
                    ERROR_MESSAGE.append("The '" + g + "' column of the number " + str(row) + " row in the 'lecture' sheet only store the integer value.")
            elif g == 'lecture_title':
                return_value = check_title(row, v[g], lec_title, g, "lecture")
                if return_value is True:
                    lec_title.append(v[g])
            elif g == 'topic':
                if not isinstance(v[g],str):
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'lecture' sheet must be a string.")
            elif g == 'concepts':
                if isinstance(v[g], str) or isinstance(v[g], int):
                    concept = condition_fun(v[g])
                    check_concept(concept, con_id, row, g, "lecture")
            #elif g == 'lecture_video':
                #return_value = check_video_details(row, v[g], lec_video, g, "lecture")
                #if return_value is True:
                #    lec_video.append(v[g])
            elif g == 'lecture_note':
                if v[g] == None:
                    continue
                #else:
                #    return_value = check_PDF_file_details(row, v[g], lec_note, g, "lecture")
                #    if return_value is True:
                #        lec_note.append(v[g])
            elif g == 'worksheets':
                if v[g] == None:
                    continue
                else:
                    if isinstance(v[g], str) or isinstance(v[g], int):
                        worksheet = condition_fun(v[g])
                        check_concept(worksheet, worksheet_id, row, g, "lecture")
                    
            
    
    ############################################# Module sheet #############################################
   
    row = 1
    mou_lec_id = []
    mou_exe_id = []
    module_title = []
    for k,v in MODULE_DETAILS.items():
        row = row + 1
        for g in v:
            if v['module_title'] == None or v['lecture'] == None:
                ERROR_MESSAGE.append('The number ' + str(row) + " row of 'module' sheet has no value in the '" + g + "' column.")
            elif g == 'module_id':
                if v['module_id'] == None:
                    ERROR_MESSAGE.append('The number ' + str(row) + " row of 'module' sheet has no value in the '" + g + "' column.")
                elif isinstance(v[g],int):
                    id_no = check_id_each_sheet(row, v[g], mou_id, g, 'module')
                    if id_no != False:
                        mou_id.append(id_no)
                else:
                    ERROR_MESSAGE.append("The value of the ''" + g + "'' column of the number " + str(row) + " row in the 'module' sheet only store the integer value.")
            elif g == 'module_title':
                return_value = check_title(row, v[g], module_title, g, "module")
                if return_value is True:
                    module_title.append(v[g])
            elif g == 'lecture':
                if isinstance(v[g], str) or isinstance(v[g], int):
                    lecture = condition_fun(v[g])
                    for qa in lecture:
                        if int(qa) not in lec_id:
                            ERROR_MESSAGE.append("The lecture id of the '" + g + "' column of the number " + str(row) + " row in the 'module' sheet isn't present in 'lecture' sheet.")
                        elif qa in mou_lec_id:
                            ERROR_MESSAGE.append("The lecture id " + qa + " of the '" + g + "' column of the number " + str(row) + " row in the 'module' sheet is already being used in this sheet.")
                        else:
                            mou_lec_id.append(qa)
                else:
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'module' sheet must be an integer or string (like id_1|||id_2).")
            elif g == 'exercise':
                if v[g] == None or v[g] == "None":
                    continue
                elif isinstance(v[g], str) or isinstance(v[g], int) or isinstance(v[g], float):
                    exercise = condition_fun(v[g])
                    for qa in exercise:
                        if int(qa) not in exe_id:
                            ERROR_MESSAGE.append("The exercise id of the '" + g + "' column of the number " + str(row) + " row in the 'module' sheet isn't present in exercise sheet.")
                        elif qa in mou_exe_id:
                            ERROR_MESSAGE.append("The exercise id " + qa + " of the '" + g + "' column of the number " + str(row) + " row in the 'module' sheet is already being used in this sheet.")
                        else:
                            mou_exe_id.append(qa)
                else:
                    ERROR_MESSAGE.append("The value of the '" + g + "' column of the number " + str(row) + " row in the 'module' sheet must be an integer or string (like id_1|||id_2).")
                
    

        
    ############################################# Course sheet #############################################
    
    row = 1
    course_intro_video = []
    course_description = []
    prerequisite_knowledge_file =[]
    copyright_message = []
    advertisement_image = []
    card_image = []
    reference_material_file = []
    for i in range(len(COURSE_DETAILS)):
        row = row + 1
        for v in COURSE_DETAILS[str(i)]:
            if v == 'prerequisite_preexisting_course_title_list' or v == 'reference_material_file':
                if v == 'prerequisite_preexisting_course_title_list':
                    if COURSE_DETAILS[str(i)][v] == None:
                        continue
                    elif isinstance(COURSE_DETAILS[str(i)][v], str):
                        pre_course_name = condition_fun(COURSE_DETAILS[str(i)][v])
                        if shadow_mode == 'off':
                            for o in pre_course_name:
                                mydb = myclient[mongodb_database_name]
                                mycol_course = mydb['courses']
                                present = mycol_course.count_documents({'course_title' : o})
                                if present >= 1:
                                    continue
                                else:
                                    ERROR_MESSAGE.append("MongoDB database doesn't have any course details with this " + o + " course title.")
                    else:
                        ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet must be a string.")
                
                elif v == 'reference_material_file':
                    if COURSE_DETAILS[str(i)][v] == None:
                        continue
                    #else:
                        #return_value = check_text_file_details(row, COURSE_DETAILS[str(i)][v], reference_material_file, v, "course")
                        #if return_value is True:
                        #    reference_material_file.append(COURSE_DETAILS[str(i)][v])
                                             
            else:
                if COURSE_DETAILS[str(i)][v] == None or COURSE_DETAILS[str(i)][v] == 'None' or COURSE_DETAILS[str(i)][v] == 'none':
                    ERROR_MESSAGE.append('The number ' + str(row) + " row of 'course' sheet has no value in the " + v + " column.")
                else:
                    if v == 'course_title' or v == 'course_short_name':
                        if isinstance(COURSE_DETAILS[str(i)][v], str):#course_short_name
                            if len(COURSE_DETAILS[str(i)][v]) >= 2:
                                alpha = 0
                                for gg in COURSE_DETAILS[str(i)][v].split():
                                    if not gg.isalpha():
                                        alpha = alpha + 1
                                if alpha != 0:
                                    ERROR_MESSAGE.append("The value of the '" + v + "' column of the number " + str(row) + " row in the 'course' sheet must have at least 1 word(contain only alphabets) and more than 2 alphabets in it.")
                                else:
                                    if shadow_mode == 'off':
                                        vv, final_course_id = mongo_check(v, COURSE_DETAILS[str(i)][v], 'course')
                                        #if vv != True:
                                        #    ERROR_MESSAGE.append(vv)
                                        COURSE_DETAILS[str(i)]['course_id'] = final_course_id
                                        COURSE_DETAILS[str(i)]['aws_course_id'] = final_course_id
                            else:
                                ERROR_MESSAGE.append("The value of the '" + v + "' column of the number " + str(row) + " row in the 'course' sheet must have at least 1 word and more than 2 alphabets in it.")
                        else:
                            ERROR_MESSAGE.append("The value of the '" + v + "' column of the number " + str(row) + " row in the 'course' sheet must be a string.")
                    elif v == 'course_description' or v == 'prerequisite_knowledge_file' or v == 'copyright_message':
                         if COURSE_DETAILS[str(i)][v] == None:
                             continue
                         #else:
                         #    if  v == 'course_description':
                                 #return_value = check_text_file_details(row, COURSE_DETAILS[str(i)][v], course_description, v, "course")
                                 #if return_value is True:
                                 #    course_description.append(COURSE_DETAILS[str(i)][v])
                         #    elif  v == 'prerequisite_knowledge_file':
                                 #return_value = check_text_file_details(row, COURSE_DETAILS[str(i)][v], prerequisite_knowledge_file, v, "course")
                                 #if return_value is True:
                                 #    prerequisite_knowledge_file.append(COURSE_DETAILS[str(i)][v])
                         #    elif  v == 'copyright_message':
                                 #return_value = check_text_file_details(row, COURSE_DETAILS[str(i)][v], copyright_message, v, "course")
                                 #if return_value is True:
                                 #    copyright_message.append(COURSE_DETAILS[str(i)][v])
                    elif v == 'course_intro_video':
                         if COURSE_DETAILS[str(i)][v] == None:
                             continue
                         #else:
                             #return_value = check_video_details(row, COURSE_DETAILS[str(i)][v], course_intro_video, v, "course")
                             #if return_value is True:
                             #    course_intro_video.append(COURSE_DETAILS[str(i)][v])
                        
                    #elif v == 'created_on': #offering_period_from_to
                    #    if isinstance(COURSE_DETAILS[str(i)][v], str):
                    #        check_date_format(row, COURSE_DETAILS[str(i)][v], 0, v, 'course')
                    elif v == 'offering_period_from_to': #offering_period_from_to
                        if isinstance(COURSE_DETAILS[str(i)][v], str):
                            offer_date = condition_fun(COURSE_DETAILS[str(i)][v])
                    #        vc = 1
                    #        check_date_format(row, offer_date, vc, v, 'course')
                    elif v == 'communication_language':
                        if COURSE_DETAILS[str(i)][v] in COMMUNICATION_LANGUAGE:
                            continue
                        else:
                            ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet must be a string with letters and it must start with a capital letter.")
                    elif v == 'credit':
                        if isinstance(COURSE_DETAILS[str(i)][v], int):
                            if COURSE_DETAILS[str(i)][v] >= 0 and COURSE_DETAILS[str(i)][v] <= 10:
                                course_credit = COURSE_DETAILS[str(i)][v]
                                continue
                            else:
                                ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet must be an integer between 0 to 10.")
                        else:
                            ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet must be an integer.")
                            
                    elif v == 'duration_in_min':
                        if isinstance(COURSE_DETAILS[str(i)][v], int):
                            if COURSE_DETAILS[str(i)][v] >= 1:
                                continue
                            else:
                                ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet must be an integer >= 1.")
                        else:
                            ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet must be an integer.")
                            
                    #elif v == 'advertisement_image_file' or  v == 'card_image_file':
                    #    if v == 'card_image_file':
                    #        return_value = check_image_file_details(row, COURSE_DETAILS[str(i)][v], card_image, v, "course")
                    #        if return_value is True:
                    #            card_image.append(COURSE_DETAILS[str(i)][v])
                    #    else:
                    #        return_value = check_image_file_details(row, COURSE_DETAILS[str(i)][v], advertisement_image, v, "course")
                    #        if return_value is True:
                    #            advertisement_image.append(COURSE_DETAILS[str(i)][v])
                    elif v == 'module':
                        if isinstance(COURSE_DETAILS[str(i)][v], str) or isinstance(COURSE_DETAILS[str(i)][v], int):
                            module = condition_fun(COURSE_DETAILS[str(i)][v])
                            if isinstance(module, list):
                                for qa in module:
                                    try:
                                        if int(qa) not in mou_id:
                                            ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet isn't present in module sheet.")
                                    except ValueError:
                                        ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet must be an integer or a string(like id_1|||id_2).")
                            else:
                                ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet must be an integer or a string(like id_1|||id_2).")
                    elif v == 'instructor':
                        if isinstance(COURSE_DETAILS[str(i)][v], str) or isinstance(COURSE_DETAILS[str(i)][v], int):
                            instructor = condition_fun(COURSE_DETAILS[str(i)][v])
                            if isinstance(instructor, list):
                                for qa in instructor:
                                    try:
                                        if int(qa) not in ins_id:
                                            ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet isn't present in instructor sheet.")
                                    except ValueError:
                                        ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet must be an integer or a string(like id_1|||id_2).")
                            else:
                                ERROR_MESSAGE.append("The value of the " + v + " column of the number " + str(row) + " row in the 'course' sheet must be an integer or a string(like id_1|||id_2).")
    
    #if shadow_mode == 'off':
    #    no_of_ex = len(OBJ_ID) + len(PROG_ID)
    #    COURSE_DATA_DICTIONARY = { "id": str(4), "no_of_ex": no_of_ex, "credits": course_credit }
    


def prog_exercise_fun():
    for k,v in PROG_EXERCISE_DETAILS.items():
        marks = 0
        v['concepts'] = condition_fun(v['concepts'])
        v['datasets'] = condition_fun(v['datasets'])
        #if v['sub_exercises'] != None:
        #    sub_id = condition_fun(v['sub_exercises'])
        #    sub_details =[]
        #    for i in sub_id:
        #        for j,p in SUB_EXERCISE_DETAILS.items():
        #            if int(i) == p['id']:
        #                p['concepts'] = condition_fun(p['concepts'])
        #                for wq in p['concepts']:
        #                    if wq not in v['concepts']:
        #                        row = int(j) + 1
        #                        ERROR_MESSAGE.append("The concept id " + wq + " of the 'concepts' column of the number " + str(row) + " row in the 'Sub_exercise' sheet isn't present in the 'concepts' column of 'prog_exercise' id " + str(v['exercise_id']) + " of the'prog_exercise' sheet." )
        #                marks = marks + p['marks']
        #                sub_details.append(p)                    
        #    v['sub_exercises'] = sub_details
        if v['marks'] <= marks:
            ERROR_MESSAGE.append("The value of the 'marks' column of the number " + str(int(k)+1) + " row in the 'prog_exercise' sheet must be equal to or greater than the marks of it's  the'prog_exercise' sheet." )


def obj_exercise_fun():
    for k,v in OBJ_EXERCISE_DETAILS.items():
        v['concepts'] = condition_fun(v['concepts'])
        #if v['question_has_pdf'] == False and v['choice_has_pdf'] == False:
        v['list_of_choices'] = condition_fun(v['list_of_choices'])
        v['list_of_answers'] = condition_fun(v['list_of_answers'])
        #elif v['question_has_pdf'] == True and v['choice_has_pdf'] == True:
        #    for l,p in OBJ_EXERCISE_PDF_DETAILS.items():
        #        if int(v['pdf_exercise_id']) == int(p['id']):
        #            v['question'] = p['question_pdf']
        #            v['list_of_choices'] = p['choices_pdf']

def worked_out_worksheetfun(worksheet_id, course):
    global WORKED_OUT_WORKSHEET_DETAILS
    worksheet_id = condition_fun(worksheet_id)
    #WORKED_OUT_WORKSHEET_DETAILS = json.loads(course[3].to_json(orient ='index'))
    lecture_worked_out_worksheet = []
    for i in range(len(worksheet_id)):
        for k,v in WORKED_OUT_WORKSHEET_DETAILS.items():
            if int(worksheet_id[i]) == int(v['worksheet_id']): 
                lecture_worked_out_worksheet.append(WORKED_OUT_WORKSHEET_DETAILS[k])
    return lecture_worked_out_worksheet
          

def module_fun(module, course):
    global lec_id, exe_id, LECTURE_DETAILS, EXERCISE_DETAILS
    # Lecture

    l_id = condition_fun(module[0]['lecture'])
    
    #LECTURE_DETAILS = json.loads(course[2].to_json(orient ='index'))
    module_lecture = []
    for i in range(len(l_id)):
        for k,v in LECTURE_DETAILS.items():
            if int(l_id[i]) == int(v['lecture_id']): 
                v['concepts'] = condition_fun(v['concepts'])                   
                if v['worksheets'] != None:
                    v['worksheets'] = worked_out_worksheetfun(v['worksheets'], course)
                module_lecture.append(v)
    module[0]['lecture'] = module_lecture
    
    #Exercise 
    if module[0]['exercise'] != None or module[0]['exercise'] != "None":
        e_id = condition_fun(module[0]['exercise']) 
    #    EXERCISE_DETAILS = json.loads(course[3].to_json(orient ='index'))
        module_exercise = []
        for i in range(len(e_id)):
            for k,v in EXERCISE_DETAILS.items():
                if int(e_id[i]) == int(v['exercise_id']): 
                    exercise_parameter = []
                    exercise_parameter.append(v)
                    module_exercise.append(EXERCISE_DETAILS[k])
        module[0]['exercise'] = module_exercise
    return module[0]


def csv_to_json():
        
    for i in range(len(COURSE_DETAILS)):
        COURSE_DETAILS[str(i)]['prerequisite_preexisting_course_title_list'] = condition_fun(COURSE_DETAILS[str(i)]['prerequisite_preexisting_course_title_list'])        
        COURSE_DETAILS[str(i)]['offering_period_from_to'] = condition_fun(COURSE_DETAILS[str(i)]['offering_period_from_to'])        
        # COURSE_DETAILS[str(i)]['reference_material_pointer'] = condition_fun(COURSE_DETAILS[str(i)]['reference_material_pointer'])
        
        #COURSE_DETAILS[str(i)]['offering_period_from_to'] = condition_fun(COURSE_DETAILS[str(i)]['offering_period_from_to']) # it create an error, so subham please look into it
        
        
        ############################################# Module #############################################
        
        module = condition_fun(COURSE_DETAILS[str(i)]['module'])
        courses_module = []
        for j in range(len(module)):
            for k,v in MODULE_DETAILS.items():
                module_parameter = []
                module_parameter.append(v)
                if int(module[j]) == v['module_id']:
                    MODULE_DETAILS[k]  = module_fun(module_parameter, course)
                    courses_module.append(MODULE_DETAILS[k])
        COURSE_DETAILS[str(i)]['module'] = courses_module
    
        ############################################# instructor #############################################
        
        instructor = condition_fun(COURSE_DETAILS[str(i)]['instructor'])
        course_instructor = []
        for j in range(len(instructor)):
            for k,v in INSTRUCTOR_DETAILS.items():
                if int(instructor[j]) == v['id']:
                    course_instructor.append(INSTRUCTOR_DETAILS[k])
                COURSE_DETAILS[str(i)]['instructor'] = course_instructor
    
def main():    
    ################ It'll check whether there are any missing fields in the excel file 
    global MONGO_CONCEPT_ID
    #miss_fields_fun() # right now we don't need it
    
    if  len(ERROR_MESSAGE) > 0: 
        print(RED + '\nErrors occur while running the script : \n', ENDC)
        for i in range(len(ERROR_MESSAGE)):
            print(str(i+1) + "." +  ERROR_MESSAGE[i])
        sys.exit()
    
    #################################
    
    for i in range(len(COURSE_DETAILS)):
        COURSE_DETAILS[str(i)]['course_id'] = 0
        COURSE_DETAILS[str(i)]['aws_course_id'] = 0
        #if shadow_mode == 'off':
        #    COURSE_DETAILS[str(i)]['add_to_carousal'] = add_to_carousal

    ################ It'll check whether there are any missing values in the excel file                 
    miss_value_fun()
    ######################################################################################
    
    csv_to_json() # here we call csv to json function
    obj_exercise_fun() # here we deal with objective excercise
    prog_exercise_fun()  # here we deal with proram excercise

    ################ If ERROR_MESSAGEs occurs then it'll show those ERROR_MESSAGEs and stop the script 
    
    
    # error_message = [ele for ele in reversed(ERROR_MESSAGE)] # it will correct error message order

    if  len(ERROR_MESSAGE) > 0: 
        print(RED + '\nErrors occur while running the script : \n', ENDC)
        for i in range(len(ERROR_MESSAGE)):
            print(str(i+1) + "." +  ERROR_MESSAGE[i])
        sys.exit()    
    #else:
    #    print("\n1. Script successfully convert the excel file's to a JSON file.")
    
    ########## MongoDB upload
    if shadow_mode == 'off':
        course_mongo = COURSE_DETAILS 
        mongodb_local(course_mongo, CONCEPT_DETAILS, OBJ_EXERCISE_DETAILS, PROG_EXERCISE_DETAILS)
    #print(UPLOAD_LIST, len(UPLOAD_LIST))

if __name__ == '__main__':
    value = global_fun(sys.argv)
    ################################ For instruction 
    if value == '-h' or value == '-help':
        read_me()
        sys.exit()
    ######################### MongoDb and AWS S3's connection is being checked here

    if shadow_mode == 'off':
        try:
            myclient = MongoClient(host = [mongodb_host_url_port], ServerSelectionTimeoutMS = 5000) # "mongodb://localhost:27017/" 
            #myclient.test.authenticate( "NAIRPAdmin" , "vgByJnt9Ss1Ef9ga4" )
            dblist = myclient.list_database_names()
            if mongodb_database_name not in dblist:
                ERROR_MESSAGE.append("The "+ db_name + " database doesn't exist, So please provide valid database name!")
            else:
                collection = myclient[mongodb_database_name].list_collection_names()
                for i in MONGODB_COLLECTION:
                    if i not in collection:
                        ERROR_MESSAGE.append(i + " collection name isn't present in " + mongodb_database_name + "database.")
        except ServerSelectionTimeoutError:
            ERROR_MESSAGE.append("No connection could be made with database because the target machine actively refused it. Please check the MongoDB host URL that you provided.")
        except NameError:
            ERROR_MESSAGE.append("No connection could be made with database because the target machine actively refused it. Please check the MongoDB host URL that you provided.")
        except OperationFailure:
            ERROR_MESSAGE.append("Unauthorized access because of that no connection could be made with database. Please check the MongoDB host URL that you provided.")


    # ######################### Here we connect our script with  AWS S3 service and set region #########################
    
    #if shadow_mode == 'off':
    #    try:  
    #        s3 = boto3.client('s3', aws_access_key_id=aws_access_key, aws_secret_access_key=aws_secret_key)
    #        Buckets = s3.list_buckets()
    #        name = []
    #        for i in range(len(Buckets['Buckets'])):
    #            name.append(Buckets['Buckets'][i]['Name'])
    #        if aws_bucket_name not in  name:
    #            ERROR_MESSAGE.append("Some how " + aws_bucket_name + " bucket is deleted from S3.")
    #    except ClientError as e:
    #        if e.response['Error']['Code'] == 'InvalidAccessKeyId':
    #            ERROR_MESSAGE.append(e.response['Error']['Message'] +" So please check it!")
    #        elif e.response['Error']['Code'] == 'SignatureDoesNotMatch':
    #            ERROR_MESSAGE.append("The request signature we calculated does not match the signature or AWS Secret Key Id you provided. Check your AWS Secret key and signing method.")
    #    except EndpointConnectionError as end:
    #        ERROR_MESSAGE.append(str(end) + ".")

    
    ############################################ Delete a course from system
    
    #if shadow_mode == 'off':
    #    if value == '-course_id_delete':
    #        if  len(ERROR_MESSAGE) > 0: 
    #            print(RED + '\nErrors occur while running the script : \n', ENDC)
    #            for i in range(len(ERROR_MESSAGE)):
    #                print(f'  {i+1}. {ERROR_MESSAGE[i]}')
    #            sys.exit() 
    #        delete_course_from_system()
    #        sys.exit()
    #
    ############################################ Read the excel file # 
    #print(sys.argv)
    try:
        course_xlsx = pd.ExcelFile(sys.argv[1]) #pd.ExcelFile(excel_file_path)
        module_xlsx = pd.ExcelFile(sys.argv[2])
        lecture_xlsx = pd.ExcelFile(sys.argv[3])
        worked_out_worksheet_xlsx = pd.ExcelFile(sys.argv[4])
        exercise_xlsx = pd.ExcelFile(sys.argv[5])
        prog_exercise_xlsx = pd.ExcelFile(sys.argv[6])
        obj_exercise_xlsx = pd.ExcelFile(sys.argv[7])
        instructor_xlsx = pd.ExcelFile(sys.argv[8])
        concept_xlsx = pd.ExcelFile(sys.argv[9])
    except:
        print(RED + "\nAn error occur : \n", ENDC, "- Script can't able to open excel files.")#(RED + "\nAn error occur : \n", ENDC, "- " + excel_file_path + " path isn't valid.")
        sys.exit()
    course = []
    module = []
    lecture = []
    worked_out_worksheet = []
    exercise = []
    prog_exercise = []
    obj_exercise = []
    instructor = []
    concept = []
    for sheet in course_xlsx.sheet_names:
        course.append(course_xlsx.parse(sheet))
    for sheet in module_xlsx.sheet_names:
        module.append(module_xlsx.parse(sheet))
    for sheet in lecture_xlsx.sheet_names:
        lecture.append(lecture_xlsx.parse(sheet))
    for sheet in worked_out_worksheet_xlsx.sheet_names:
        worked_out_worksheet.append(worked_out_worksheet_xlsx.parse(sheet))
    for sheet in exercise_xlsx.sheet_names:
        exercise.append(exercise_xlsx.parse(sheet))
    for sheet in prog_exercise_xlsx.sheet_names:
        prog_exercise.append(prog_exercise_xlsx.parse(sheet))
    for sheet in obj_exercise_xlsx.sheet_names:
        obj_exercise.append(obj_exercise_xlsx.parse(sheet))
    for sheet in instructor_xlsx.sheet_names:
        instructor.append(instructor_xlsx.parse(sheet))
    for sheet in concept_xlsx.sheet_names:
        concept.append(concept_xlsx.parse(sheet))
    
    ##################################### Store each sheet details to a global variable
        
    COURSE_DETAILS = json.loads(course[0].to_json(orient ='index'))
    #{'0': {'course_title': 'Machine Learning', 'course_short_name': 'ML', 'course_description': 'nairp_course_template/texts/ML_course_description.txt', 'course_intro_video': 'nairp_course_template/videos/unit1.mp4', 'advertisement_image_file': 'nairp_course_template/images/adv_image.png', 'card_image_file': 'nairp_course_template/images/card_image.png', 'prerequisite_preexisting_course_title_list': 'Artificial Intelligence', 'prerequisite_knowledge_file': 'nairp_course_template/texts/ML_course_prerequisite_knowledge_file.txt', 'created_on': '2021-01-22', 'communication_language': 'English', 'reference_material_file': 'nairp_course_template/texts/ML_course_reference_material_file.txt', 'credit': 10, 'duration_in_min': 793, 'offering_period_from_to': '2021-02-01|||2021-12-22', 'copyright_message': 'nairp_course_template/texts/ML_course_copyright_msg.txt', 'module': '1|||2|||3|||4|||5|||6|||7|||8|||9|||10', 'instructor': '1|||2'}}
    #sys_argv[1] #json.loads(course[0].to_json(orient ='index'))
    MODULE_DETAILS = json.loads(module[0].to_json(orient ='index'))
    LECTURE_DETAILS = json.loads(lecture[0].to_json(orient ='index'))
    WORKED_OUT_WORKSHEET_DETAILS = json.loads(worked_out_worksheet[0].to_json(orient ='index'))
    EXERCISE_DETAILS = json.loads(exercise[0].to_json(orient ='index'))
    PROG_EXERCISE_DETAILS = json.loads(prog_exercise[0].to_json(orient ='index'))
    OBJ_EXERCISE_DETAILS = json.loads(obj_exercise[0].to_json(orient ='index'))
    #OBJ_EXERCISE_PDF_DETAILS = json.loads(course[0].to_json(orient ='index'))
    #SUB_EXERCISE_DETAILS = json.loads(course[0].to_json(orient ='index'))
    INSTRUCTOR_DETAILS = json.loads(instructor[0].to_json(orient ='index'))
    CONCEPT_DETAILS = json.loads(concept[0].to_json(orient ='index'))
    #print("Subham majumder", '\n', COURSE_DETAILS, '\n', MODULE_DETAILS, '\n', LECTURE_DETAILS,'\n', EXERCISE_DETAILS,'\n', OBJ_EXERCISE_DETAILS,'\n', PROG_EXERCISE_DETAILS,'\n', INSTRUCTOR_DETAILS,'\n', CONCEPT_DETAILS)#, COURSE_DETAILS)
    #pprint.pprint(COURSE_DETAILS)
    #sys.exit()
    main()    
    ########################################################################################3
