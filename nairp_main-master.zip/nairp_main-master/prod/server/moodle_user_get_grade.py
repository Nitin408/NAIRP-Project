import requests
import json
import pprint
import sys
import hashlib

import os
os.environ['no_proxy']= '10.5.30.191'
os.environ['NO_PROXY']= '10.5.30.191'


username = sys.argv[1]
password = sys.argv[2] 

# m = hashlib.sha224()
# m.update(password.encode('utf-8'))

# password = m.hexdigest()

service = "NAIRP_course_service"
argu = {'username' : username, 'password' : password, 'service' : service}
# # # if we don't use any service 

# # {'error': 'A required parameter (service) was missing', 'errorcode': 'missingparam', 
# # 'stacktrace': '* line 494 of /lib/setuplib.php: moodle_exception thrown\n* line 569 of /lib/moodlelib.php: call to print_error()\n* line 36 of /login/token.php: call to required_param()\n',
# #  'debuginfo': '\nError code: missingparam', 'reproductionlink': 'http://10.5.30.191:8888/moodle/'}
URL = "http://10.5.30.191:8888/moodle/login/token.php"    #?username="# + username + "&password=" + password + "&service=" + service
response = requests.post(url = URL, data= argu) 
# if response.status_code == 200:
#     print('Success!','\n')
# elif response.status_code == 404:
#     print('Not Found.')

data = response.json()
token = data ['token']
#print ("Got token of " + username + " for the service " + service +  " : " + token, '\n')

########################################################################################################################################################

# search for users matching the parameters, here we used username

user_function = "core_user_get_users"
user_argu = {'wstoken' : token, 'wsfunction' : user_function, 'moodlewsrestformat' : 'json', 'criteria[0][key]' : 'username', 'criteria[0][value]' : username}
user = "http://10.5.30.191:8888/moodle/webservice/rest/server.php"
user_response = requests.post(url = user, data=user_argu) 
user_data = user_response.json()
user_id = str(user_data['users'][0]['id'])
fullname = user_data['users'][0]['fullname']

########################################################################################################################################################

# # Get the list of courses where a user is enrolled in

course_function = "core_enrol_get_users_courses"
course_argu = {'wstoken' : token, 'wsfunction' : course_function, 'moodlewsrestformat' : 'json', 'userid' : user_id}
course = "http://10.5.30.191:8888/moodle/webservice/rest/server.php"    #?wstoken=" + token + "&wsfunction=" + course_function +"&moodlewsrestformat=json&userid=" + user_id
course_response = requests.post(url = course, data=course_argu) 
course_data = course_response.json()
# pprint.pprint(course_data)
for i in range(1):
    course_id = str(course_data[i]['id'])
    #####################################################################################################################
    # # contants
    # contants_function = "core_course_get_contents"
    # contants = "http://10.5.30.191:8888/moodle/webservice/rest/server.php?wstoken=" + token + "&wsfunction=" + contants_function +"&moodlewsrestformat=json&courseid=" + course_id
    # contants_response = requests.post(url = contants) 
    # contants_data = contants_response.json()
    # pprint.pprint(contants_data)
    # ########################################################################################################################################################

    # Returns a list of quizzes in a provided list of courses, if no list is provided all quizzes that the user can view will be returned.

    quizz_function = "mod_quiz_get_quizzes_by_courses"
    quizz_argu = {'wstoken' : token, 'wsfunction' : quizz_function, 'moodlewsrestformat' : 'json', 'courseids[0]' : course_id}
    quizz = "http://10.5.30.191:8888/moodle/webservice/rest/server.php"     #?wstoken=" + token + "&wsfunction=" + quizz_function +"&moodlewsrestformat=json&courseids[0]=" + course_id
    quizz_response = requests.post(url = quizz, data=quizz_argu) 
    quizz_data = quizz_response.json()
    # pprint.pprint(quizz_data)
    if (len(quizz_data['quizzes'])) > 0:
        quizz_id = []
        quizz_name = []
        for j in range(len(quizz_data['quizzes'])):
            quizz_id.append(str(quizz_data['quizzes'][j]['id']))
            quizz_name.append(quizz_data['quizzes'][j]['name'])
    
            # ########################################################################################################################################################
        finalGrade = 0
        for j in range(len(quizz_id)):
            # Get the best current grade for the given user on a quiz.

            user_grade_function = "mod_quiz_get_user_best_grade"
            user_grade_argu = {'wstoken' : token, 'wsfunction' : user_grade_function, 'moodlewsrestformat' : 'json', 'quizid' : quizz_id[j], 'userid' : user_id}
            grade = "http://10.5.30.191:8888/moodle/webservice/rest/server.php"    #?wstoken=" + token + "&wsfunction=" + user_grade_function +"&moodlewsrestformat=json&quizid=" + quizz_id[j] + "&userid=" + user_id
            grade_response = requests.post(url = grade, data=user_grade_argu) 
            grade_data = grade_response.json()
            if(grade_data['hasgrade']):
                
                finalGrade += int(grade_data['grade'])
        pprint.pprint(finalGrade)
            # if grade_data['hasgrade'] == True:
            #     #print (fullname + " with id " + user_id + " enrolled in " + course_data[i]['fullname'] + " course " + " short name " + course_data[i]['shortname'] + " in " + quizz_name[j] + " he get " + str(grade_data['grade']) + " grade", '\n')
            #     #finalGrade = 0
            #     #finalGrade += grade_data
            #     print (str(grade_data['grade']))
            # else:
            #     #print ('\n', fullname + " with id " + user_id + " enrolled in " + course_data[i]['fullname'] + " course " + " short name " + course_data[i]['shortname'] + " in " + quizz_name[j] +' no garde', '\n')
            #     print ('not attempted yet')

# we can print section name by section id from quizz