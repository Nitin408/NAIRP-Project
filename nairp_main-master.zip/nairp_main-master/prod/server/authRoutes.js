//const bodyParser = require("body-parser")
const jwt = require("jsonwebtoken")
const bcrypt = require("bcryptjs")
const moment = require("moment")
const User = require("./schemas/userSchema")
const axios = require('axios')
const mail = require('./utilities/mail.js')
const helpers = require('./utilities/helper.js')
const dotenv = require("dotenv");
dotenv.config()

const verifyCaptchaWithGoogle = require('./utilities/verifyCaptcha').verifyCaptchaWithGoogle
var env = process.env.NODE_ENV || "development";

verifyThatUserIsNotSignedUp = async (email) => {
    try {
        let user = await User.findOne({ 'email': email })
        if (user) {
            console.log("User with email-id '" + email + "' already exists ! Please login or signup with a different email-id.")
            return ({
                success: false,
                errcode: "already_signed_up",
                message: "User with email-id '" + email + "' already exists ! Please login or signup with a different email-id."
            });
        }
        else {
            return ({
                success: true
            })
        }
    }
    catch (error) {
        console.log("Failed at verifyThatUserIsNotSignedUp")
        return ({
            success: false,
            message: "Failed new user verification. User not signed up. Please try again after some time."
        });
    }
}

exports.googleOAuthCallback = async (req, res) => {
    var email = req.user.email
    if (req.user.missingFields) {
        //redirect to form to complete the profile info
        res.redirect(process.env.HOMEPAGE + '/complete_user_details/' + email)
    }
    else {
        //generate token and proceed to login
        var existingUser = {
            email: req.user.email,
            _id: req.user._id,
            password: req.user.password
        }
        jwt.sign({ user: existingUser },process.env.JWT_SECRET_KEY, { expiresIn: process.env.LOGIN_LIFE }, (err, token) => {
            console.log("User '" + existingUser.email + "' logged in successfully !" + " Token: " + token)

            if(env === "production"){
                res.redirect(process.env.HOMEPAGE + '/login/' + token)
            }else{
                res.redirect('http://localhost:3000/login/' + token)
            }
           
        });
    }
}

exports.signup = async (req, res) => {
    try {
        //////// Verify captcha with Google
        if(env === "production"){
            let captchaVerifyResponse = await verifyCaptchaWithGoogle(req.body.captchaVerifyResponse)
            if(captchaVerifyResponse.success === false){
                res.json(captchaVerifyResponse)
                return
            }
        }

        //null checks
        const email = req.body.email;
        const password = req.body.password
        const firstName = req.body.firstName
        const lastName = req.body.lastName
        const educationalLevel = req.body.educationalLevel
        const dob = req.body.dob
        const country = req.body.country
        const gender = req.body.gender
        const profession = req.body.profession

        if(!(email && password && firstName && lastName && educationalLevel && dob && country && gender && profession)){
            res.status(400)
            res.json({
                status: 400,
                errcode:"incomplete_data",
                success: false
            })
            return
        }

        //////// Check duplicate email ID, and create user in database
        let userVerifyResponse = await verifyThatUserIsNotSignedUp(req.body.email)
        if (userVerifyResponse.success === false) {
            res.json(userVerifyResponse)
            return
        }

        var emailVerificationToken = helpers.randomString()
        console.log(emailVerificationToken)

        //////// Create a new user
        const salt = await bcrypt.genSalt();
        const hashedPassword = await bcrypt.hash(password, salt)
        const user = new User({
            email: email,
            password: hashedPassword,
            firstName: firstName,
            middleName: req.body.middleName,
            lastName: lastName,
            accessType: "enduser", // Admin and instructor has to be manually changed into database
            educationalLevel: educationalLevel,
            dob: moment(dob, "YYYY-MM-DD").toDate(),
            country: country,
            state: req.body.state,
            gender: gender,
            profession: profession,
            //subscription: { courseId: [0] }, // courseId - 0 stands for default courseId for free access to AWS
            subscribedCourses: [], // courseId - 0 stands for default courseId for free access to AWS
            accessHistory: { loginCreatedAt: Date(Date.now()) },
            isEmailVerified: 0,                  //is email verified //boolean
            emailVerificationToken: emailVerificationToken,           //random string unique to each user
            missingFields: false,
            moodleSignup: false
        });

        //////// Save new user
        await user.save();
        console.log("Signed up new user :: ")
        console.log("    First Name      : ", user.firstName)
        console.log("    Middle Name     : ", user.middleName)
        console.log("    Last Name       : ", user.lastName)
        console.log("    Email           : ", user.email)
        console.log("    EducationalLevel: ", user.educationalLevel)
        console.log("    DOB             : ", user.dob)
        console.log("    Country         : ", user.country)
        console.log("    State           : ", user.state)
        console.log("    Gender          : ", user.gender)
        console.log("    Profession      : ", user.profession)
        console.log("    LoginCreatedAt  : ", user.accessHistory.loginCreatedAt)
        console.log("    isEmailVerified      : ", user.isEmailVerified)
        console.log("    emailVerificationToken : ", user.emailVerificationToken)
        console.log("    Moodle Signup         : ", user.moodleSignup)

        //change this url when hosted on domain
        var suffix = "/api/auth/verify-email?token=" + user.emailVerificationToken + "&to=" + user.email
        var uri = (env === "production") ? process.env.HOMEPAGE + suffix : "http://localhost:" + process.env.PORT + suffix
        console.log(uri)
        mail.sendVerificationMail(user, uri)

        //////// Send response
        res.json({
            success: true,
            message: "Successfully signed up ! Please verify your email address by clicking on the link provided in the mail we sent to your registered email address."
        });
    }
    catch (error) {
        console.log(error)
        console.log("Failed signing up new user (internal error)");
        res.json({
            success: false,
            message: "Failed to create new user. Please try again after some time."
        });
    }
}

exports.check_missing_details = async (req, res) => {
    try {
        var email = req.body.email
        var user = await User.findOne({ email: email })

        if (!user) {
            res.status(400)
            res.json({
                success: false,
                status: 400,
                errcode: "bad_user_id",
                message: "User does not exist."
            })
            return
        }

        if (user.missingFields == true) {
            res.status(200)
            res.json({
                success: true,
                message: "Proceed to provide details."
            })
        }
        else {
            res.status(401)
            res.json({
                status: 401,
                success: false,
                errcode: "unauthorized",
                message: "Unauthorized attempt at changing user info!"
            })
        }

    }
    catch (error) {
        console.log(error)
        console.log("Failed to  (internal error)");
        res.json({
            status: 500,
            success: false,
            message: "Internal Server Error. Please try again after some time.",
        });
    }
}

exports.complete_user_details = async (req, res) => {
    try {
        //////// Verify captcha with Google
        if(env === "production"){
            let captchaVerifyResponse = await verifyCaptchaWithGoogle(req.body.captchaVerifyResponse)
            if(captchaVerifyResponse.success === false){
                res.json(captchaVerifyResponse)
                return
            }
        }

        var user = await User.findOne({ email: req.body.email })

        if (!user) {
            console.log("Bad request. No such user.")
            res.status(400)
            res.json({
                status: 400,
                errcode:"bad_user_id",
                success: false,
                message: "Bad request. No such user.",
            })
            return
        }

        //////update the user info
        const salt = await bcrypt.genSalt();
        const hashedPassword = await bcrypt.hash(req.body.password, salt)

        user.password = hashedPassword
        user.educationalLevel = req.body.educationalLevel
        user.dob = moment(req.body.dob, "YYYY-MM-DD").toDate()
        user.country = req.body.country
        user.state = req.body.state
        user.gender = req.body.gender
        user.profession = req.body.profession
        user.missingFields = false

        //saving new user
        await user.save()

        const existingUser = {
            email: user.email,
            _id: user._id,
            password: user.password
        }

        console.log(existingUser)

        jwt.sign({ user: existingUser }, process.env.JWT_SECRET_KEY, { expiresIn: process.env.LOGIN_LIFE }, (err, token) => {
            console.log("User '" + existingUser.email + "' logged in successfully !" + " Token: " + token)
            res.json({
                status: 200,
                success: true,
                message: "Info updated successfully. Proceeding to login.",
                token: token
            })
        });
    }
    catch (error) {
        console.log(error)
        console.log("Failed to  (internal error)");
        res.json({
            status: 500,
            success: false,
            message: "Failed to update user information. Please try again after some time.",
            token: ""
        });
    }
}

async function signup_user_in_moodle(user){ 
    try {
    let moodle_details = await axios.get('http://localhost:5000/moodle_signup', {params:{username : user.email,
                          email : user.email,password : user.password, fname: user.firstName, lname: user.lastName}});
    
    console.log(moodle_details.data) //return data as 200
    if (moodle_details.data === 200){
        user.moodleSignup = true
        await user.save()
        console.log(user.moodleSignup)
        console.log("Successfully create an account in moodle!");
    }
    } catch(error) {
        console.log(error.message)
      }
  }

exports.verify_email = async (req, res) => {
    var to = req.query.to
    var token = req.query.token
    console.log(token)
    var user = await User.findOne({ email: to })
    if (user) {
        if (user.emailVerificationToken === token) {
            user.isEmailVerified = true
            user.emailVerificationToken = null;
            await user.save();
            signup_user_in_moodle(user); //.email, user.password, user.firstName, user.lastName);
            // res.send("Email verified. Please proceed to login")
            
            var redirect = (env === "production") ? process.env.HOMEPAGE + "/login" : "http://localhost:3000/login"
            res.redirect(redirect)  //change this url when hosted on domain
        }else{
            res.status(400)
            res.json({
                success: false,
                errcode: "invalid_token",
                message: "verification failed, please check if you got correct link"
            })
        }
    }
    else {
        res.status(400)
        res.json({
            success: false,
            errcode: "bad_user_id",
            message: "verification failed, please check if you got correct link"
        })
    }
}

//while initiating forgot password process (when user clicks on )
exports.forgot_password = async (req, res) => {
    var email = req.body.email

    var user = await User.findOne({ email: email })

    if (user) {
        if (user.passResetInitiated && user.passResetCount > process.env.MAX_FORGOT_PASSWORD_RESET_HIT_COUNT) {
            res.json({
                success: true,
                message: "An email has been already sent to you with password reset link. Please check your email."
            })
        }
        else {
            var token = helpers.randomString()
            user.passResetToken = token
            user.passResetInitiated = true
            user.passResetCount = user.passResetCount + 1
            await user.save()

            {
                setInterval(function () {
                    user.passResetCount = 0
                    user.save()
                    console.log("password reset count cleared")
                }
                    , process.env.FORGOT_PASSWORD_BLOCK_RESET_TIME) //12 hr
            }


            //resetting the link
            setInterval(function () {             //reset token after 10 mins
                user.passResetToken = ""
                user.save()
                console.log("password reset link cleared")
            }
                , process.env.FORGOT_PASSWORD_LINK_RESET_TIME) // 10 min
            
            var suffix = "/reset_password/" + user.email + "/" + user.passResetToken
            var uri = (env === "production") ? process.env.HOMEPAGE + suffix : "http://localhost:3000" + suffix

            console.log(uri)

            mail.forgotPassword(user, uri)
            res.status(200)
            res.json({
                status: 200,
                success: true,
                message: "An email has been sent to you with password reset link."
            })
        }

    }
    else {
        res.status(400)
        res.json({
            status: 400,
            success: false,
            errcode: "bad_user_id",
            message: "No such user found. Please check the email address again."
        })
    }

}

//when user clicks the password reset link from email
exports.check_pass_reset = async (req, res) => {
    var email = req.body.email
    var token = req.body.token

    var user = await User.findOne({ email: email })
    if (user) {
        if (token != "" && user.passResetToken === token) {
            console.log("Password reset token matched. Initiating password change.")
            res.status(200)
            res.json({
                status: 200,
                success: true,
                message: "Success!"
            })
        }else{
            console.log("bad request, token not matched")
            res.status(401)
            res.json({
                status: 401,
                success: false,
                errcode: "bad_token",
                message: "Link broken or expired. Please try again!"
            })
        }
    }
    else {
        res.status(400)
        res.json({
            status: 400,
            success: false,
            errcode: "bad_user_id",
            message: "Error! The link has expired or it is broken."
        })
    }
}


//from the reset password page
exports.reset_password = async (req, res) => {
    var email = req.body.email
    var password = req.body.password

    if(email == "" || password == ""){
        res.status(400)
        res.json({
            status:400,
            success: false,
            errcode: "bad_input",
            message: "Invalid input"
        })
        return
    }

    const salt = await bcrypt.genSalt();
    const hashedPassword = await bcrypt.hash(req.body.password, salt)

    try {
        var user = await User.findOne({ email: email })

        if(user){
            user.password = hashedPassword
            user.passResetInitiated = false
            user.passResetToken = ""
            await user.save()
            console.log("changed")
            res.status(200)
            res.json({
                status: 200,
                success: true,
                message: "Password changed successfully. Please proceed to login with new password."
            })
        }else{
            res.status(400)
            res.json({
                status:400,
                success: false,
                errcode: "bad_user_id",
                message: "User doesn't exist."
            })
        }
    }
    catch (e) {
        console.log(e)
        res.status(500)
        res.json({
            status: 500,
            success: false,
            message: "Internal Server Error! Password reset failed. Please try again"
        })
    }
}


exports.login = async (req, res) => {
    try {

        if(env === "production"){
            let captchaVerifyResponse = await verifyCaptchaWithGoogle(req.body.captchaVerifyResponse)
            if(captchaVerifyResponse.success === false){
                res.json(captchaVerifyResponse)
                return
            }
        }

        const requestedUser = {
            email: req.body.email,
            password: req.body.password
        };
        User.findOne({ 'email': requestedUser.email }, async (err, existingUser) => {
            if (existingUser == null) {
                console.log("Login failed (incorrect email) for requested email: " + requestedUser.email);
                res.status(401)
                res.json({
                    status: 401,
                    success: false,
                    errcode: "bad_user_id",
                    message: "Incorrect email-id !",
                    token: ""
                });
                return;
            }

            if (!existingUser.isEmailVerified) {
                console.log('Email not verified!')
                res.status(401)
                res.json({
                    status: 401,
                    success: false,
                    errcode: "not_verified",
                    message: "You have not verified your email address. Please verify your email address before logging in."
                })
                return
            }
            else
            {
                if(!existingUser.moodleSignup){
                    signup_user_in_moodle(existingUser);
                }
            }
            requestedUser._id = existingUser._id;




            if (await bcrypt.compare(requestedUser.password, existingUser.password)) {
                jwt.sign({ user: requestedUser },process.env.JWT_SECRET_KEY, { expiresIn: process.env.LOGIN_LIFE }, (err, token) => {
                    console.log("User '" + requestedUser.email + "' logged in successfully !" + " Token: " + token)
                    res.status(200)
                    res.json({
                        status: 200,
                        success: true,
                        message: "Logged in successfully !",
                        token: token,
                        email: requestedUser.email,
                    });
                });
            }
            else {
                console.log("Login failed (incorrect password) for requested email: " + requestedUser.email);
                res.status(401)
                res.json({
                    status: 401,
                    success: false,
                    errcode: "bad_credentials",
                    message: "Incorrect password !",
                    token: ""
                });
            }
        })
    }
    catch (e) {
        console.log("Login failed (internal error) for requested user: " + req.body.password)
        res.status(500)
        res.json({
            status: 500,
            success: false,
            message: "Failed to login. Please try again after some time.",
            token: ""
        });
    }
}


exports.authenticator = (req, res) => {
    jwt.verify(req.body.token, process.env.JWT_SECRET_KEY, (err, authData) => {
        console.log("Request to authenticator server");
        if (err) {
            res.json({
                status: 403,
                result: false,
                message: "Unauthorized access. Please login!"
            });
            return;
        }
        console.log("Authorized access");
        User.findOne({ 'email': authData.user.email }, async (err, existingUser) => {
            if (existingUser == null) {
                console.log("Fatal: /profile - authenticated user not found !")
            }
            console.log("Authorized user");
            res.json({
                status: 200,
                result: true,
                message: "Authorized access"
            });
        })
    })
}



