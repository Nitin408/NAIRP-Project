const policy = {
    'USAGE_CAP_1': .50,
    'USAGE_CAP_2': .70,
    'USAGE_CAP_3': .90
}

module.exports = policy