const email_template = require('./templates/email.js')
const User = require('../../schemas/userSchema')
const Course = require('../../schemas/courseSchema')

class Messages {
    constructor(params) {
        Object.assign(this, params)
    }

    async generate() {
        this.user_name = await this.getUserName()
        this.message = {}
        this.message.address = await this.getEmailAddress()
        this.message.subject = email_template(this.message_class, this.user_name, this.course_name)[0]
        this.message.body = email_template(this.message_class, this.user_name, this.course_name)[1]
        return this.message
    }

    async getEmailAddress() {
        const user = await User.findById(this.user_id)
        return user.email
    }

    async getUserName() {
        const user = await User.findById(this.user_id)
        try {
            if (user.middleName === null)
                return `${user.firstName} ${user.lastName}`
            else
                return `${user.firstName} ${user.middleName} ${user.lastName}`
        } catch (error) {
            console.log(error)
        }
            
    }
    
}

module.exports = Messages