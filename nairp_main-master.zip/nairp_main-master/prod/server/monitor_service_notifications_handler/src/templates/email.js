const {USAGE_CAP_1, USAGE_CAP_2, USAGE_CAP_3} = require('../../policy.js')

module.exports = (message_class, user_name, course_name) => {
    const temp = {
        subject: {
            0: `AISHIKSHA: Your Sagemaker instances have been stopped`,
            1: `AISHIKSHA: Sagemaker instance usage warning`,
            2: `AISHIKSHA: Sagemaker instance usage warning`,
            3: `AISHIKSHA: Sagemaker instance usage warning`,
            4: `AISHIKSHA: Your Sagemaker instances have been stopped`
        },
        body: {
            0: `Dear ${user_name}, <br> 
            <p>
            Unfortunately the AISHIKSHA.COM servers faced an outage due to which your AWS Jupyter Notebook instances that were running had to be stopped.<br> Not to worry, your instances are preserved. You just have to go back to the courses and re-start your instances. <br>
            Sorry for the inconvenience. We are working on it so that it does not happen again in future.
            </p> 
            Thankyou,<br>
            AISHIKSHA Team
            `,
            1: `Dear ${user_name}, <br> 
            <p>
            You have used up ${USAGE_CAP_1*100} of your allocated AWS credits for the Course ${course_name}.<br>
            On reaching 100% usage the system will stop your instances automatically. Once stopped by system, you will not be able to access the instance any longer.<br>
            We recommend to use the AWS credits judiciously.
            </p> 
            Thankyou,<br>
            AISHIKSHA Team
            `,
            2: `Dear ${user_name}, <br> 
            <p>
            You have used up ${USAGE_CAP_2*100} of your allocated AWS credits for the Course ${course_name}.<br>
            On reaching 100% usage the system will stop your instances automatically. Once stopped by system, you will not be able to access the instance any longer.<br>
            We recommend to use the AWS credits judiciously.
            </p> 
            Thankyou,<br>
            AISHIKSHA Team
            `,
            3: `Dear ${user_name}, <br>
            <p>
            You have used up ${USAGE_CAP_3*100} of your allocated AWS credits for the Course ${course_name}.<br>
            On reaching 100% usage the system will stop your instances automatically. Once stopped by system, you will not be able to access the instance any longer.<br>
            We recommend to use the AWS credits judiciously.
            </p> 
            Thankyou,<br>
            AISHIKSHA Team
            `,
            4: `Dear ${user_name}, <br> 
            <p>
            You have used up 100% of your allocated AWS credits for the Course ${course_name}. <br>
            The system has stopped your instance. You will no longer be able to access the instance.
            </p> 
            Thankyou,<br>
            AISHIKSHA Team
            `
        }
    }
    return [temp.subject[message_class], temp.body[message_class]]
}