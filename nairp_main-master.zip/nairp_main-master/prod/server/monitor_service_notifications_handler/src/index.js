const generateEmailContent = require('./generateEmailContent.js')
const monitor = require('../../schemas/monitorSchema')
const course = require("../../schemas/courseSchema")
const mail = require('../../utilities/mail.js')

const dotenv = require("dotenv");
dotenv.config()

const AWS = require('aws-sdk');

AWS.config.update({
  region: 'ap-south-1'
});
// var proxy = require('proxy-agent'); // Uncomment if running using Campus network
// const nodemailer = require('nodemailer')
// console.log("The email is ", process.env.EMAIL)

// var transport = nodemailer.createTransport({
//   service: "Gmail",
//   auth: {
//     user: process.env.EMAIL || "sauravjoshi123@gmail.com",
//     pass: process.env.PASSWORD || "qrbzgsewyuwmqwyt"
//   }
// });

// AWS.config.update({
// ,httpOptions: { agent: proxy('http://172.16.2.30:8080') } // Uncomment if running using Campus network 
// });

const sqs = new AWS.SQS({ apiVersion: '2012-11-05' });

const queueURL = process.env.MONITORING_SERVICE_SQS_URL || "https://sqs.ap-south-1.amazonaws.com/306511936602/monitoring-program-messages-to-nairp-dev.fifo";

const receiveMessages = async () => {
  var params = {
    AttributeNames: [
      "SentTimestamp"
    ],
    MaxNumberOfMessages: 10,
    MessageAttributeNames: [
      "All"
    ],
    QueueUrl: queueURL,
    VisibilityTimeout: 40,
    WaitTimeSeconds: 0
  };
  var data = await sqs.receiveMessage(params).promise()
  var Messages = data.Messages
  if (!Messages || Messages.length == 0) {
    return []
  }
  else {
    res = await receiveMessages()
    return Messages.concat(res)
  }
}

// const sendWarningMail = async ({ address, subject, body }) => {
//   const message = {
//     from: 'noreply.nairp@gmail.com', // Sender address
//     to: address,                 // recipient
//     subject: subject, // Subject line
//     html: body      // Plain html
//   };
//   return transport.sendMail(message)
// }

const delete_message_from_sqs = (ReceiptHandle) => {
  var deleteParams = {
    QueueUrl: queueURL,
    ReceiptHandle: ReceiptHandle
  };
  sqs.deleteMessage(deleteParams, function (err, data) {
    if (err) {
      console.log("Delete Error", err);
    } else {
      console.log("Message Deleted", data);
    }
  });
}

const getCourseName = async (course_id) => {

  course_name = await course.find({ course_id: course_id }, 'course_title').exec()
  if (course_name.length) {
    return (course_name[0].course_title)
  } else {
    return "NA"
  }

}


const insert_notification_db = async (Body) => {

  let c_id = 0
  let e_id = 0
  let course_name = ''
  let dataObj = {}

  if (Body.course_id != undefined) {
    c_id = Number(Body.course_id)
  }

  if (Body.exercise_id != undefined) {
    e_id = Number(Body.exercise_id)
    dataObj = {
      message_id: Number(Body.message_class),
      course_id: c_id,
      exercise_id: e_id,
      course_name: await getCourseName(c_id)
    }
  }
  else {
    dataObj = {
      message_id: Number(Body.message_class),
      course_id: c_id,
      course_name: await getCourseName(c_id)
    }
  }

  const message = new monitor({
    user_id: Body.user_id,
    data: dataObj
  })

  let count = await monitor.countDocuments({ user_id: Body.user_id })
  if (count === 0) {
    try {
      doc = await message.save()
      return (dataObj.course_name)
    } catch (error) {
      console.log("Race Fix!")
      console.log(error)
      if (error.code && error.code === 11000) {
        await monitor.findOneAndUpdate({ user_id: Body.user_id }, { $push: { data: dataObj } })
        return (dataObj.course_name)
      }
    }
  }
  else {
    try {
      await monitor.findOneAndUpdate({ user_id: Body.user_id }, { $push: { data: dataObj } })
      return (dataObj.course_name)
    } catch (error) {
      console.log(error)
    }
  }
}


const monitorProgram = async () => {
  const messages = await receiveMessages()
  messages.forEach(async ({ Body, ReceiptHandle }) => {
    // console.log(Body)
    course_name = await insert_notification_db(JSON.parse(Body))
    console.log("The course name is", course_name)
    let json_body = JSON.parse(Body)
    json_body['course_name'] = course_name

    if (json_body.exercise_id == undefined) {
      const email_content = await new generateEmailContent(json_body).generate()
      const { address, subject, body } = email_content
      await mail.sendWarningMail(address, subject, body)
      delete_message_from_sqs(ReceiptHandle)
    }
    else {
      delete_message_from_sqs(ReceiptHandle)
    }
  })
}

module.exports = monitorProgram