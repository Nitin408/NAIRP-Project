const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy
const User = require('../schemas/userSchema')
const bcrypt = require('bcryptjs')
const helper = require('../utilities/helper')
const dotenv = require("dotenv");
dotenv.config()

passport.use(
    new GoogleStrategy({
        // options for google strategy
        callbackURL: process.env.HOMEPAGE + '/auth/google/redirect',
        clientID: process.env.clientID,
        clientSecret: process.env.clientSecret
    },async (accessToken, refreshToken, profile, done) => {
        // passport callback function

        // console.log(profile);
        const user = await User.findOne({email: profile._json.email})
        
        if(user){
            //return to the redirect url with user data
            console.log("old user returned")
            return done(null, user);
        }
        
        else{
            //creating new user
            // console.log(profile)
            const randomPassword = helper.randomString()         //set random password until user creates his own
            const salt = await bcrypt.genSalt();
            const hashedPassword = await bcrypt.hash(randomPassword, salt)
            var newUser = new User({
                email: profile._json.email,
                firstName: profile._json.given_name,
                lastName: profile._json.family_name,
                password: hashedPassword,           
                accessType: "enduser", // Admin and instructor has to be manually changed into database
                //subscription: { courseId: [0] }, // courseId - 0 stands for default courseId for free access to AWS
                subscribedCourses: [], // courseId - 0 stands for default courseId for free access to AWS
                accessHistory: { loginCreatedAt: Date(Date.now()) },
                isEmailVerified: true,                  //is email verified 
                missingFields: true,
                googleId: profile.id            //google id
            })
        await newUser.save()
        console.log("new user created")
        //return to the redirect url with user data
        return done(null,newUser)
        }        
    })
);