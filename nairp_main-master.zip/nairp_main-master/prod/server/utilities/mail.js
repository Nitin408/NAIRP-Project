var nodemailer = require('nodemailer')
const User = require("../schemas/userSchema")
const dotenv = require("dotenv");
dotenv.config()

var env = process.env.NODE_ENV || 'development';


if(env == "production"){

  //actual account
  //use this account to actually send emails
  //you can access the inbox using the credentials
  //mentioned below
  var transport = nodemailer.createTransport({
    service: "Gmail",
    auth: {
      user: process.env.EMAIL,
      pass: process.env.PASSWORD
  }
});

} else {

  //for testing, will not actually send emails, 
  //you can monitor the mails sent from a 
  //dummy inbox provided by mailtrap 
  //to test: create your account on mailtrap and
  //paste the credentials at appropriate space in
  //the code below
  var transport = nodemailer.createTransport({
    host: "smtp.mailtrap.io",
    port: 2525,
    auth: {
      user: "93d2530278e8f1",
      pass: "9cb314db4dcb70"
    }
  });


}

module.exports.sendVerificationMail = async function sendVerificationMail(user, uri) {

  console.log("initiating")

  let message = {
    from: 'noreply.nairp@gmail.com', // Sender address
    to: user.email,                 // recipient
    subject: "NAIRP - Email Verification", // Subject line
    html: ` <h3>Click the below link to verify your email</h3>
                <br>
                <p><a href=`+ uri + `> Click Here </a></p>`      // Plain html
  };

  transport.sendMail(message, function (err, info) {
    if (err) {
      console.log(err)
    } else {
      console.log(info);
    }
  });

}


module.exports.forgotPassword = async function forgotPassword(user, uri) {

  let message = {
    from: 'noreply.nairp@gmail.com', // Sender address
    to: user.email,                 // recipient
    subject: "NAIRP - Reset Password", // Subject line
    html: ` <h3>Click the below link to reset your password</h3>
                <br>
                <p><a href=`+ uri + `> Click Here </a></p>`      // Plain html
  };

  transport.sendMail(message, function (err, info) {
    if (err) {
      console.log(err)
    } else {
      console.log(info);
    }
  });

  // User.findOne({email:user.email}, (err,existingUser)=>{
  //     existingUser.passResetInitiated = true,
  // })

}

module.exports.sendWarningMail = async function sendWarningMail(address, subject, body) {

  let message = {
    from: 'noreply.nairp@gmail.com', // Sender address
    to: address,                 // recipient
    subject: subject, // Subject line
    html: body      // Plain html
  }

  transport.sendMail(message, function (err, info) {
    if (err) {
      console.log(err)
    } else {
      console.log("Mail send success")
      console.log(info);
    }
  })

}