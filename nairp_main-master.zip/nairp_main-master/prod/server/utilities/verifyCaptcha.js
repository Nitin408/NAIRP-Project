const dotenv = require("dotenv");
const axios = require('axios')
dotenv.config()

var env = process.env.NODE_ENV || 'development';


exports.verifyCaptchaWithGoogle = async (captchaVerifyResponse) => {
    try {
        const url = "https://www.google.com/recaptcha/api/siteverify?secret=" + process.env.GOOGLE_RECAPTCHA_V2_SECRET_KEY + "&response=" + captchaVerifyResponse;
        let response = await axios.get(url, {
        })
        if (response.data.success === false) { // Success
            console.log("Signup captcha failure for hostname:", response.data.hostname, "with error code:", response.data.error);
            return ({
                success: false,
                message: "Entry from a robot is not acceptable !"
            });
        }
        else {
            status = true
            console.log("Signup captcha success for hostname:", response.data.hostname)
            return ({
                success: true,
            });
        }
    }
    catch (error) {
        console.log("Failed at verifyCaptchaWithGoogle")
        return ({
            success: false,
            message: "Failed captcha verification. User not signed up. Please try again after some time."
        });
    }
}