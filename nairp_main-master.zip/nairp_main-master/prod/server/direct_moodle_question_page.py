import requests
import json
import pprint
import urllib, webbrowser
import http.cookiejar as cookielib
from requests.utils import dict_from_cookiejar
from selenium import webdriver
import sys
import hashlib

import os
os.environ['no_proxy']= '10.5.30.191'
os.environ['NO_PROXY']= '10.5.30.191'

username = sys.argv[1]
password = sys.argv[2]
m = hashlib.sha224()
m.update(password.encode('utf-8'))

password = m.hexdigest()
service = "NAIRP_course_service"
URL = "http://10.5.30.191:8888/moodle/login/index.php"
driver = webdriver.Chrome("./chromedriver")
# driver = webdriver.Chrome()
driver.get(URL)
driver.find_element_by_id('username').send_keys(username)
driver.find_element_by_id('password').send_keys(password)
driver.find_element_by_id('loginbtn').click()
driver.get('http://10.5.30.191:8888/moodle/mod/quiz/view.php?id=52')
          # http://10.5.30.191:8888/moodle/mod/quiz/view.php?id=3
