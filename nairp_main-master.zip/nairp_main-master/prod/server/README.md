# OAuth2.0 Proxy work-around
To make OAuth service work behind proxy, replace the file node_modules/oauth/lib/oauth2.js with the one on this directory.
