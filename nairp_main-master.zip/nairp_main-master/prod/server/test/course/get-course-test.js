let chai = require('chai');
let should = chai.should();
let expect = chai.expect
const User = require('../../schemas/userSchema')
const Course = require('../../schemas/courseSchema')
var chaiHttp = require('chai-http');
chai.use(chaiHttp);
const app = require('../../server')

describe('Get Courses', () => {

    let courseId;

    describe("GET /api/course/learn", () => {

        it('Should return list of all available courses',(done)=>{

            chai.request(app)
                .get('/api/course/learn')
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.should.be.a("Array")
                        let results = res.body
                        let titles = []
                        results.forEach(element => {
                            titles.push(element.course_title)
                            if(element.course_title==='Artificial Intelligence'){
                                courseId = element._id
                            }
                        });
                        expect(titles).to.have.members([ 'Artificial Intelligence', 'Machine Learning Fundamentals' ])
                        done()
                    }
                })

        })
    })

    describe('POST /api/course/get_course', ()=>{


        it('Should verify bad course id',(done)=>{

            chai.request(app)
                .post('/api/course/get_course')
                .send({courseId: "5e5451bacc73635f2ced8322"}) //bad id
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal('bad_course_id')
                        done()
                    }
                })

        })

        it('Should return course with given id',(done)=>{

            chai.request(app)
                .post('/api/course/get_course')
                .send({courseId})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(true)
                        res.body.data._id.should.equal(courseId)
                        res.body.data.course_title.should.equal('Artificial Intelligence')
                        done()
                    }
                })

        })
    })

})
