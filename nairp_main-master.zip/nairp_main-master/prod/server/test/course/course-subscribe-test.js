let chai = require('chai');
let should = chai.should();
let expect = chai.expect
const User = require('../../schemas/userSchema')
const Course = require('../../schemas/courseSchema')
var chaiHttp = require('chai-http');
chai.use(chaiHttp);
const app = require('../../server')

describe('Subscribe to Courses', () => {

    let courseId = "5e5661bacc73943f2ced8329"
    let testEmail = "test1@gmail.com"
    let userId;

    describe("PUT /api/course/subscribe_user_to_course", () => {

        it('Should check bad user',(done)=>{

            chai.request(app)
                .put('/api/course/subscribe_user_to_course')
                .send({email: "dummy", courseId: "5e5451bacc73635f2ced8322"}) //bad user and course
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_request")
                        done()
                    }
                })

        })

        it('Should check course id',(done)=>{

            chai.request(app)
                .put('/api/course/subscribe_user_to_course')
                .send({email: "test1@gmail.com", courseId: "5e5451bacc73635f2ced8322"}) //bad course
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_request")
                        done()
                    }
                })

        })

        it('Should subscribe user to a course',(done)=>{

            chai.request(app)
                .put('/api/course/subscribe_user_to_course')
                .send({email: testEmail, courseId})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.email.should.equal(testEmail)
                        res.body.subscribedCourses.length.should.equal(1)
                        expect(res.body.subscribedCourses).to.include(courseId)
                        userId = res.body._id
                        done()
                    }
                })

        })

        
    })

    describe('POST /api/course/subscribed_courses', ()=>{


        it('Should verify bad user id',(done)=>{

            chai.request(app)
                .post('/api/course/subscribed_courses')
                .send({userId: "3d7898bacc73635f2ced8322"}) //bad id
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal('bad_user_id')
                        done()
                    }
                })

        })

        it('Should return subscribed courses',(done)=>{

            chai.request(app)
                .post('/api/course/subscribed_courses')
                .send({userId})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        expect(res.body).to.include(courseId)
                        done()
                    }
                })

        })
    })

})
