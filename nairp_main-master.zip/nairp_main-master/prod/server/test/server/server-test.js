let chai = require('chai');
const request = require('request')
let should = chai.should();
const app = require('../../server')
var chaiHttp = require('chai-http');
chai.use(chaiHttp);
const sinon = require('sinon')


describe('Server running', ()=> {

    it('/GET test', function(done) {
        request('http://localhost:5000/test' , function(error, res, body) {
            res.statusCode.should.be.equal(200)
            body.should.equal('I am alive')
            done();
        });
    });

})
