const User = require('../../schemas/userSchema')
const jwt = require("jsonwebtoken")

module.exports.createUser = async (email) => {

    const user = new User({
        email: email,
        password: "Test@123",
        firstName: "Testf",
        middleName: "testm",
        lastName: "testl",
        accessType: "enduser", // Admin and instructor has to be manually changed into database
        educationalLevel: "School",
        dob: '1999-04-05',
        country: "India",
        state: "Goa",
        gender: "male",
        profession: "Student",
        //subscription: { courseId: [0] }, // courseId - 0 stands for default courseId for free access to AWS
        subscribedCourses: [], // courseId - 0 stands for default courseId for free access to AWS
        accessHistory: { loginCreatedAt: Date(Date.now()) },
        isEmailVerified: 1,                  //is email verified //boolean
        emailVerificationToken: "",           //random string unique to each user
        missingFields: false,
        moodleSignup: false
    });

    await user.save()

    let requestedUser = {
        email,
        password: "Test@123",
        _id: user._id
    }
    
    
    var token = jwt.sign({ user: requestedUser },process.env.JWT_SECRET_KEY, { expiresIn: process.env.LOGIN_LIFE })
    
    let data = {
        email,
        token
    }

    return data
}

module.exports.clean = async () => {
    await User.deleteMany({})
    // let requestedUser = {
    //     email: "test1@gmail.com",
    //     password: "Test@123",
    //     _id: "5ede709e55e4d4accd8f2b78"
    // }
    // var token = jwt.sign({ user: requestedUser },process.env.JWT_SECRET_KEY, { expiresIn: process.env.LOGIN_LIFE })

    // console.log(token)
}
