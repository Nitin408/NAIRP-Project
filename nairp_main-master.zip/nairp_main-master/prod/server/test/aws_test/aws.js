let chai = require('chai');
let should = chai.should();
let expect = chai.expect()
const app = require('../../server')
const helper = require('./get-token.js')
const socket = require('socket.io-client');

describe("Testing AWS apis - default version (3 instances)", () => {
    let user1;
    let user2;

    before(async () => {
        console.log.restore()
        await helper.clean()
        user1 = await helper.createUser("user1@gmail.com")
        user2 = await helper.createUser("user2@gmail.com")
        console.log(user1)
        console.log(user2)
    })

    it("Checking User:1, Course:1, Exercise:1", function (done) {
        this.timeout(540000) // 9 min

        io = socket.connect(process.env.SAGEMAKER_URL, {
            'reconnection delay': 0
            , 'reopen delay': 0
            , 'force new connection': true
        })

        io.on("connect", () => {
            console.log("socket connected")
            io.emit("get_sage_status", {
                body: {
                    course_id: 1,
                    exercise_id: 1
                },
                token: user1.token
            })
            console.log("1. get status emitted")

            io.on("no_instance_exist", () => {
                console.log("2. Status: instance not yet exists")

                io.emit("create-instance")
                console.log("3. create-instance")

                io.on("sage_Failed", () => {
                    console.log("failed")
                    done(new Error("Creating instance failed"))
                })

                io.on("sage_Inservice", (url) => {
                    console.log("4. sage_Inservice")
                    console.log("Payload: " + url)

                    io.emit("stop-instance")
                    console.log("5. stop-instance")

                    io.on("sage_Failed", () => {
                        console.log("failed")
                        done(new Error("Stopping instance failed"))
                    })

                    io.on("sage_Stopping", () => {
                        console.log("6. sage_Stopping")

                        io.on("sage_Stopped", () => {
                            console.log("7. sage_Stopped")

                            io.emit("delete-instance")
                            console.log("8. delete-instance")

                            io.on("sage_Failed", () => {
                                console.log("failed")
                                done(new Error("deleting instance failed"))
                            })

                            io.on("sage_Deleting", () => {
                                console.log("9. sage_Deleting")

                                io.on("sage_Deleted", () => {
                                    console.log("10. sage_Deleted")
                                    io.close()
                                    done()
                                })
                            })

                        })
                    })

                })

            })

        })

    })

    it("Checking User:2, Course:1, Exercise:2", function (done) {
        this.timeout(540000) // 9 min

        io = socket.connect(process.env.SAGEMAKER_URL, {
            'reconnection delay': 0
            , 'reopen delay': 0
            , 'force new connection': true
        })

        io.on("connect", () => {
            console.log("socket connected")
            io.emit("get_sage_status", {
                body: {
                    course_id: 1,
                    exercise_id: 2
                },
                token: user2.token
            })
            console.log("1. get status emitted")

            io.on("no_instance_exist", () => {
                console.log("2. Status: instance not yet exists")

                io.emit("create-instance")
                console.log("3. create-instance")

                io.on("sage_Failed", () => {
                    console.log("failed")
                    done(new Error("Creating instance failed"))
                })

                io.on("sage_Inservice", (url) => {
                    console.log("4. sage_Inservice")
                    console.log("Payload: " + url)

                    io.emit("stop-instance")
                    console.log("5. stop-instance")

                    io.on("sage_Failed", () => {
                        console.log("failed")
                        done(new Error("Stopping instance failed"))
                    })

                    io.on("sage_Stopping", () => {
                        console.log("6. sage_Stopping")

                        io.on("sage_Stopped", () => {
                            console.log("7. sage_Stopped")

                            io.emit("delete-instance")
                            console.log("8. delete-instance")

                            io.on("sage_Failed", () => {
                                console.log("failed")
                                done(new Error("deleting instance failed"))
                            })

                            io.on("sage_Deleting", () => {
                                console.log("9. sage_Deleting")

                                io.on("sage_Deleted", () => {
                                    console.log("10. sage_Deleted")
                                    io.close()
                                    done()
                                })
                            })

                        })
                    })

                })

            })

        })

    })

    it("Checking User:1, Course:5, Exercise:1", function (done) {
        this.timeout(540000) // 9 min

        io = socket.connect(process.env.SAGEMAKER_URL, {
            'reconnection delay': 0
            , 'reopen delay': 0
            , 'force new connection': true
        })

        io.on("connect", () => {
            console.log("socket connected")
            io.emit("get_sage_status", {
                body: {
                    course_id: 5,
                    exercise_id: 2
                },
                token: user1.token
            })
            console.log("1. get status emitted")

            io.on("no_instance_exist", () => {
                console.log("2. Status: instance not yet exists")

                io.emit("create-instance")
                console.log("3. create-instance")

                io.on("sage_Failed", () => {
                    console.log("failed")
                    done(new Error("Creating instance failed"))
                })

                io.on("sage_Inservice", (url) => {
                    console.log("4. sage_Inservice")
                    console.log("Payload: " + url)

                    io.emit("stop-instance")
                    console.log("5. stop-instance")

                    io.on("sage_Failed", () => {
                        console.log("failed")
                        done(new Error("Stopping instance failed"))
                    })

                    io.on("sage_Stopping", () => {
                        console.log("6. sage_Stopping")

                        io.on("sage_Stopped", () => {
                            console.log("7. sage_Stopped")

                            io.emit("delete-instance")
                            console.log("8. delete-instance")

                            io.on("sage_Failed", () => {
                                console.log("failed")
                                done(new Error("deleting instance failed"))
                            })

                            io.on("sage_Deleting", () => {
                                console.log("9. sage_Deleting")

                                io.on("sage_Deleted", () => {
                                    console.log("10. sage_Deleted")
                                    io.close()
                                    done()
                                })
                            })

                        })
                    })

                })

            })

        })

    })
})
