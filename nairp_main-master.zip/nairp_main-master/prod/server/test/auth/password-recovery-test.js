const app = require('../../server')
let chai = require('chai');
let should = chai.should();
const User = require('../../schemas/userSchema')
var chaiHttp = require('chai-http');
chai.use(chaiHttp);

describe('Password Recovery service', ()=>{
    let token;
    let testEmail = "test@gmail.com"

    before(function(done){
        User.findOne({email:testEmail}, (err,user) => {
            if(err){
                done()
            }else{
                user.passResetCount = 0
                user.save();
                done()
            }
        })
    })

    describe('POST api/auth/forgot-password', ()=>{

        it('should detect non-existing email',(done)=>{

            chai.request(app)
                .post('/api/auth/forgot_password')
                .send({to: "dummy_email"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_user_id")
                        done()
                    }
                })
        })

        it('should generate token',(done)=>{

            chai.request(app)
                .post('/api/auth/forgot_password')
                .send({email: testEmail})
                .end(async (err,res,body)=>{
                    if(err){
                        done(err)
                     }else{
                        res.body.status.should.equal(200)
                        res.body.success.should.equal(true)
                        var tempUser = await User.findOne({email: testEmail});
                        tempUser.passResetCount.should.equal(1)
                        tempUser.passResetInitiated.should.equal(true)
                        tempUser.passResetToken.should.be.a("string")
                        token = tempUser.passResetToken
                        done()
                    }
               })
        })

    })

    describe('POST /api/auth/check_pass_reset', () => {

        it('should detect non-existing email',(done)=>{

            chai.request(app)
                .post('/api/auth/check_pass_reset')
                .send({email: "dummy_email", token:"dummy_token"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_user_id")
                        done()
                    }
                })
        })

        it('should detect bad token',(done)=>{

            chai.request(app)
                .post('/api/auth/check_pass_reset')
                .send({email: testEmail, token:"dummy_token"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(401)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_token")
                        done()
                    }
                })
        })

        it('should confirm token',(done)=>{

            chai.request(app)
                .post('/api/auth/check_pass_reset')
                .send({email: testEmail, token:token})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(true)
                        done()
                    }
                })
        })


    })


    describe("POST /api/auth/reset_password", () => {
        it('should detect non-existing email',(done)=>{

            chai.request(app)
                .post('/api/auth/reset_password')
                .send({email: "dummy_email", password:"dummy_token"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_user_id")
                        done()
                    }
                })
        })

        it('should detect bad input',(done)=>{

            chai.request(app)
                .post('/api/auth/reset_password')
                .send({email: "", password:"dummy_token"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_input")
                        done()
                    }
                })
        })
        

        it('should change password succesfully',(done)=>{

            chai.request(app)
                .post('/api/auth/reset_password')
                .send({email: testEmail, password:"TestPass@123"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(true)
                        done()
                    }
                })
        })


    })

    describe('POST /api/auth/login', ()=> {
        it("should login with new password", (done) => {
            chai.request(app)
                .post('/api/auth/login')
                .send({email: testEmail, password: "TestPass@123"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(true)
                        res.body.token.should.be.a("string")
                        done()
                    }
                })
        })
    })

})