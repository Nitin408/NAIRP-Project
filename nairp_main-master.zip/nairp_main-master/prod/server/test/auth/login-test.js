let chai = require('chai');
let should = chai.should();
let expect = chai.expect()
const User = require('../../schemas/userSchema')
var chaiHttp = require('chai-http');
chai.use(chaiHttp);
const sinon = require('sinon')
const app = require('../../server')

describe('Auth service', () => {

    describe("POST /api/auth/login", () => {
        let testEmail = "test1@gmail.com"

        it('should detect non-existing email',(done)=>{

            chai.request(app)
                .post('/api/auth/login')
                .send({email: "aasdf", password: "asdf"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(401)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_user_id")
                        done()
                    }
                })
        })

        it('should detect verification status and login with correct credentials',(done)=>{

            chai.request(app)
                .post('/api/auth/login')
                .send({email: testEmail, password: "asdf"})
                .end(async (err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(401)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("not_verified")

                        //manually verify for the next test here
                        let user = await User.findOne({email:testEmail})
                        user.isEmailVerified = true
                        await user.save()

                        chai.request(app)
                            .post('/api/auth/login')
                            .send({email: testEmail, password: "Test@123"})
                            .end((err,res,body)=>{
                                if(err){
                                    done(err)
                                }else{
                                    res.status.should.equal(200)
                                    res.body.success.should.equal(true)
                                    res.body.token.should.be.a("string")
                                    done()
                                }
                            })
                    }
                })
        })

        it('should not login with bad credentials',(done)=>{

            chai.request(app)
                .post('/api/auth/login')
                .send({email: testEmail, password: "asdf"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(401)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_credentials")
                        done()
                    }
                })
        })

        // it('should login successfully', (done) => {

        //     chai.request(app)
        //         .post('/login')
        //         .send({email: testEmail, password: "Test@123"})
        //         .end((err,res,body)=>{
        //             if(err){
        //                 done(err)
        //             }else{
        //                 res.status.should.equal(200)
        //                 res.body.success.should.equal(true)
        //                 res.body.token.should.be.a("string")
        //                 done()
        //             }
        //         })
        // })


    })
})

    // describe('GET /verify-email', ()=>{
    //     it('should check for valid token',()=>{

    //     })

    //     it('should successfully verify if token is correct'){

    //     }
    // })

    // describe('POST /login (after verification)', ()=>{
    //     it('should login if verified', ()=> {

    //     })
    // })
