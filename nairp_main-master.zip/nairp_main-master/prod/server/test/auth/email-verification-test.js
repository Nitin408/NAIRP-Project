const app = require('../../server')
let chai = require('chai');
let should = chai.should();
const User = require('../../schemas/userSchema')
var chaiHttp = require('chai-http');
chai.use(chaiHttp);
const sinon = require('sinon')

describe('Email verification service', () => {

    //already covered in previous test

    // before(function(done){
    //     sinon.stub(console, 'log')  // disable console.log
    //     sinon.stub(console, 'info')  // disable console.info
    //     sinon.stub(console, 'warn')  // disable console.warn
    //     sinon.stub(console, 'error')  // disable console.error
    //     done()
    // })

    let token;
    let testEmail = "test@gmail.com"

    before(function(done){
      User.findOne({email:testEmail}, (err,user)=>{
        if(err){
            done(err)
        }else{
            token = user.emailVerificationToken
            done()
        }
      })
    })

    describe("GET /api/auth/verify-email", () => {

        it('should detect non-existing email',(done)=>{

            chai.request(app)
                .get('/api/auth/verify-email')
                .query({to: "dummy_email", token: "dummy_token"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_user_id")
                        done()
                    }
                })
        })

        it('should detect invalid token',(done)=>{

            chai.request(app)
                .get('/api/auth/verify-email')
                .query({to: testEmail, token: "dummy_token"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("invalid_token")
                        done()
                    }
                })
        })

        it('should verify given email',async ()=>{

            // NOTE : This commented will fail the test because it need client side to be active

            // chai.request(app)
            //     .get('/verify-email')
            //     .query({to: testEmail, token: token})
            //     .end(async (err,res,body) => {
            //         if(err){
            //             done(err)
            //         }else{
            //             const check = await User.findOne({email:testEmail})
            //             check.isEmailVerified.should.equal(true)
            //             done()
            //         }
            //     })

            // Remove the below test and uncomment above when a running client is available
            let user = await User.findOne({email:testEmail})
            user.isEmailVerified = true
            user.emailVerificationToken = null;
            await user.save()
            
        })

    })
})