let chai = require('chai');
let should = chai.should();
let expect = chai.expect()
const User = require('../../schemas/userSchema')
var chaiHttp = require('chai-http');
chai.use(chaiHttp);
const app = require('../../server')

describe('Registration service', ()=> {

    before(function(done){

        User.deleteMany({},(err)=>{
            if(err){
                done(err)
            }else{
                done()
            }
        })

    })

    describe('POST /api/auth/signup', () => {

        let testInput = {
            firstName: 'testf',
            middleName: 'testm',
            lastName: 'testl',
            email: 'test@gmail.com',
            dob: '1999-04-05',
            gender: 'male',
            educationalLevel: 'School',
            profession: 'Student',
            country: "India",
            state: "Goa",
            password: "Test@123",
            captchaVerifyResponse: "" //not testing yet
        }

        let incompleteInput = {
            middleName: 'testm',
            email: 'test@gmail.com',
            dob: '1999-04-05',
            gender: 'male',
            profession: 'Student',
            password: "Test@123",
            captchaVerifyResponse: ""
        }

        it('should not create user if data is incomplete', (done)=>{

            chai.request('http://localhost:5000')
                .post('/api/auth/signup')
                .send(incompleteInput)
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("incomplete_data")
                        done()
                    }
                })
        })

        it('should create user successfully', (done)=>{

            chai.request('http://localhost:5000')
                .post('/api/auth/signup')
                .send(testInput)
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(true)
                        testInput.email = "test1@gmail.com" //change for further tests
                        done()
                    }
                })
        })



        it('should create another user successfully', (done)=>{

            chai.request('http://localhost:5000')
                .post('/api/auth/signup')
                .send(testInput)
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(true)
                        done()
                    }
                })
        })


        it('should not create user if already signed up', (done)=>{

            chai.request('http://localhost:5000')
                .post('/api/auth/signup')
                .send(testInput)
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("already_signed_up")
                        done()
                    }
                })
        })

    })
})
