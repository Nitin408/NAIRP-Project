let chai = require('chai');
let should = chai.should();
const User = require('../../schemas/userSchema')
var chaiHttp = require('chai-http');
chai.use(chaiHttp);
const app = require('../../server')

describe('Get User Profile', () => {

    let token;
    let testEmail = "test1@gmail.com"

    describe("POST /api/auth/login", () => {

        it('logging in to get token',(done)=>{

            chai.request(app)
                .post('/api/auth/login')
                .send({email: testEmail, password: "Test@1234"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(true)
                        res.body.token.should.be.a("string")
                        token = res.body.token
                        done()
                    }
                })

        })
    })

    describe('POST /api/profile/get_profile',()=>{

        it('detect wrong token',(done)=>{

            chai.request(app)
                .post('/api/profile/get_profile')
                .send({token:"dummy"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(401)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_token")
                        done()
                    }
                })
        })

        it('get profile data',(done)=>{

            chai.request(app)
                .post('/api/profile/get_profile')
                .send({token:token})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(true)
                        res.body.email.should.be.a('string')
                        res.body.firstName.should.be.a('string')
                        res.body.middleName.should.be.a('string')
                        res.body.lastName.should.be.a('string')
                        res.body.educationalLevel.should.be.a('string')
                        res.body.dob.should.be.a('string')
                        res.body.country.should.be.a('string')
                        res.body.state.should.be.a('string')
                        res.body.gender.should.be.a('string')
                        res.body.profession.should.be.a('string')
                        done()
                    }
                })
        })
    
    })

})
