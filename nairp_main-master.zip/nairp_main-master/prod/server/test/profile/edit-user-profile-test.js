let chai = require('chai');
let should = chai.should();
const User = require('../../schemas/userSchema')
var chaiHttp = require('chai-http');
chai.use(chaiHttp);
const app = require('../../server')

describe('Completing missing details', () => {
    let testEmail = "test1@gmail.com"

    describe("POST /api/profile/check_missing_details", () => {
    
        it('should detect non-existing email',(done)=>{
            chai.request(app)
                .post('/api/profile/check_missing_details')
                .send({email: "aasdf"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_user_id")
                        done()
                    }
                })
        })

        it('should detect unauthorised request',(done)=>{

            chai.request(app)
                .post('/api/profile/check_missing_details')
                .send({email: testEmail})
                .end(async (err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(401)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("unauthorized")

                        var user = await User.findOne({email:testEmail})
                        user.missingFields = true
                        await user.save()
                        done()
                    }
                })
        })

        it('should detect missing details',(done)=>{

            chai.request(app)
                .post('/api/profile/check_missing_details')
                .send({email: testEmail})
                .end(async (err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(true)

                        var user = await User.findOne({email:testEmail})
                        user.missingFields = false
                        await user.save()
                        done()
                    }
                })
        })

        
    })

    describe('POST /api/profile/complete_user_details',() => {

        let dummyData = {
            email: testEmail,
            password : 'Test@1234',
            educationalLevel : 'Student',
            dob : '1999-05-04',
            country : 'India',
            state : 'Rajasthan',
            gender : 'Male',
            profession : 'Student',
            missingFields : false
        }

        it('should detect non-existing email',(done)=>{

            chai.request(app)
                .post('/api/profile/complete_user_details')
                .send({email: "aasdf"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_user_id")
                        done()
                    }
                })
        })

        it('should update user information',(done)=>{

            chai.request(app)
                .post('/api/profile/complete_user_details')
                .send(dummyData)
                .end(async (err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(true)

                        let user = await User.findOne({email:dummyData.email})

                        user.educationalLevel.should.equal(dummyData.educationalLevel)
                        user.country.should.equal(dummyData.country)
                        user.state.should.equal(dummyData.state)
                        user.profession.should.equal(dummyData.profession)
                        user.missingFields.should.equal(false)
                        user.gender.should.equal(dummyData.gender)
                        
                        done()
                    }
                })
        })
    })

    describe('POST /api/profile/edit_profile',() => {

        let dummyData = {
            firstName: "first",
            middleName: "middle",
            lastName: "last",
            email: testEmail,
            educationalLevel : 'College',
            dob : '1999-05-04',
            country : 'India',
            state : 'West Bengal',
            gender : 'Female',
            profession : 'Student',
        }

        it('should detect non-existing email',(done)=>{

            chai.request(app)
                .post('/api/profile/edit_profile')
                .send({email: "aasdf"})
                .end((err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(400)
                        res.body.success.should.equal(false)
                        res.body.errcode.should.equal("bad_user_id")
                        done()
                    }
                })
        })

        it('should update user information',(done)=>{

            chai.request(app)
                .post('/api/profile/edit_profile')
                .send(dummyData)
                .end(async (err,res,body)=>{
                    if(err){
                        done(err)
                    }else{
                        res.status.should.equal(200)
                        res.body.success.should.equal(true)

                        let user = await User.findOne({email:dummyData.email})

                        user.firstName.should.equal(dummyData.firstName)
                        user.middleName.should.equal(dummyData.middleName)
                        user.lastName.should.equal(dummyData.lastName)
                        user.educationalLevel.should.equal(dummyData.educationalLevel)
                        user.country.should.equal(dummyData.country)
                        user.state.should.equal(dummyData.state)
                        user.profession.should.equal(dummyData.profession)
                        user.missingFields.should.equal(false)
                        user.gender.should.equal(dummyData.gender)
                        
                        done()
                    }
                })
        })
    })



})
