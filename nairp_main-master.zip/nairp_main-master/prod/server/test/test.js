//this file is intended to specify the order of running the tests

// to run the test in alphabetical(default) order, 
// add this in script
// "test": "./node_modules/.bin/mocha test/**/*.js"

const sinon = require('sinon')
const { stub } = require('sinon')

sinon.stub(console, 'log')  // disable console.log
sinon.stub(console, 'info')  // disable console.info
sinon.stub(console, 'warn')  // disable console.warn
sinon.stub(console, 'error')  // disable console.error


require('./server/server-test')
require('./auth/signup-test')
require('./auth/login-test')
require('./auth/email-verification-test')
require('./auth/password-recovery-test')
require('./profile/edit-user-profile-test')
require('./profile/get-profile-test')
require('./course/get-course-test')
require('./course/course-subscribe-test')

if(process.argv.indexOf("--enable-sagemaker-runtime-testing") !== -1){

    if(process.argv.indexOf("--run-all-sagemaker-tests") !== -1){
        require('./aws_test/aws-long')
    }
    else{
        require('./aws_test/aws')
    }
}
