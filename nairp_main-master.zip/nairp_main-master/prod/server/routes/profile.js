const express = require('express')
const dotenv = require("dotenv");
const jwt = require("jsonwebtoken")
const moment = require("moment")
const router = express.Router()
dotenv.config()

const User = require("../schemas/userSchema")
const authentication = require('../authRoutes')

const verifyCaptchaWithGoogle = require('../utilities/verifyCaptcha').verifyCaptchaWithGoogle
var env = process.env.NODE_ENV || 'development';

router.post('/edit_profile',async (req,res) => {
    var email = req.body.email
    try {
        //////// Verify captcha with Google
        if(env === "production"){
            let captchaVerifyResponse = await verifyCaptchaWithGoogle(req.body.captchaVerifyResponse)
            if(captchaVerifyResponse.success === false){
                res.json(captchaVerifyResponse)
                return
            }
        }

        var user = await User.findOne({ email: email })
        if(!user){
            res.status(400)
            res.json({
                status: 500,
                success: false,
                errcode: "bad_user_id",
                message:"User doesn't exist"
            })
            return
        }

        user.firstName = req.body.firstName
        user.middleName = req.body.middleName
        user.lastName = req.body.lastName
        user.educationalLevel = req.body.educationalLevel
        user.dob = moment(req.body.dob, "YYYY-MM-DD").toDate()
        user.country = req.body.country
        user.state = req.body.state
        user.gender = req.body.gender
        user.profession = req.body.profession
        await user.save();
        console.log("changed")
        res.status(200)
        res.json({
            success: true,
            message: "Changes Saved!!"
        })
    }
    catch (e) {
        console.log(e)
        res.status(500)
        res.json({
            status: 500,
            success: false,
            message: "Internal Server Error! Password reset failed. Please try again"
        })
    }
})

router.post('/get_profile', (req, res) => {
    jwt.verify(req.body.token, process.env.JWT_SECRET_KEY, (err, authData) => {
        console.log("Request at server");
        console.log(req.body.token);
        if (err) {
            console.log("Unauthorized access attempted to /profile")
            res.status(401)
            res.json({
                status: 401,
                success: false,
                errcode :"bad_token",
                message: "Unauthorized access. Please login to view profile information !"
            });
            return;
        }
        console.log("Authorized access to /profile for email: " + authData.user.email);
        User.findOne({ 'email': authData.user.email }, async (err, existingUser) => {
            if (existingUser == null) {
                console.log("Fatal: /profile - authenticated user not found !")
            }
            res.json({
                status: 200,
                success: true,
                email: existingUser.email,
                firstName: existingUser.firstName,
                middleName: existingUser.middleName,
                lastName: existingUser.lastName,
                educationalLevel: existingUser.educationalLevel,
                dob: existingUser.dob,
                country: existingUser.country,
                state: existingUser.state,
                gender: existingUser.gender,
                profession: existingUser.profession
            });
        })
    })
})

//complete user details if logged in first time with google oauth
router.post('/complete_user_details', authentication.complete_user_details)

//check if details are filled already (to prevent changing info via unfair means)
router.post('/check_missing_details', authentication.check_missing_details)


module.exports = router