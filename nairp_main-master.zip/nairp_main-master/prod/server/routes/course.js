const express = require('express')
const router = express.Router()

const User = require("../schemas/userSchema")
const Course = require("../schemas/courseSchema")

router.get('/learn', async (req, res) => {
    // console.log('getting data');
    Course.find({}).then(course => {
        res.json(course);
    })
})

router.post(`/get_course`, async (req, res) => {

    let Courseid = req.body.courseId;
    var course = await Course.findOne({ _id: Courseid });
    if (!course || course.data === []) {
        //console.log('not found');
        res.json({ success: false, errcode:"bad_course_id",message: 'course not found' })
    }
    else {
        res.json({ success: true, data: course })
    }

})

router.put('/subscribe_user_to_course', async function (req, res) {

    let email = req.body.email;
    let courseId = req.body.courseId;
    //var isCourseIdPresent = await User.find({courseId});

    let user = await User.findOne({email})
    let course = await Course.findOne({_id:courseId})

    if(!user || !course){
        res.status(400)
        res.json({
            success: false,
            status: 400,
            errcode: "bad_request",
            message: "user or course doesn't exist"
        })
    }else{
        user.subscribedCourses.push(course._id)
        await user.save()
        res.send(user)
    }
})

router.post('/subscribed_courses', async (req, res) => {

    let userId = req.body.userId;
    //console.log(req)
    try {

        let user = await User.findOne({_id:userId})
        if(!user){
            res.status(400)
            res.json({
                status: 400,
                success: false,
                errcode: "bad_user_id",
                message:"user doesn't exist"
            })
            return
        }else{
            res.send(user.subscribedCourses)
        }
    }
    catch (e) {
        console.log("Error from subscribedCourses");
    }
})

module.exports = router