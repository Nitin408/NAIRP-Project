const express = require('express')
const router = express.Router()
const authentication = require('../authRoutes')


//signup
router.post('/signup', authentication.signup)
//email verification
router.get('/verify-email', authentication.verify_email)
//forgot password - password reset initiation - sending email
router.post('/forgot_password', authentication.forgot_password)
//check if password reset token is correct
router.post('/check_pass_reset', authentication.check_pass_reset)
//reset password
router.post("/reset_password", authentication.reset_password)
//login
router.post('/login', authentication.login)


router.post('/authenticator', authentication.authenticator)


module.exports = router