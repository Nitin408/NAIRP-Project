// ------------------------------packages --------------------------------------//

const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require('body-parser');
const cors = require('cors')
const dotenv = require("dotenv");
const path = require('path');
const passport = require('passport')
const url = require('url');
const converter = require('json-2-csv');
const json2xls = require('json2xls');
const fs = require('fs');
const jwt = require("jsonwebtoken")
const querystring = require('querystring');
const axiosFixed = require('axios-https-proxy-fix')
const solrNode = require('solr-node');
var PdfReader = require("pdfreader").PdfReader;
var AWS = require('aws-sdk');
AWS.config.update({accessKeyId: 'AKIAUOXMI7RNHCK6JRUX', secretAccessKey: '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', region: 'ap-south-1'});
var s3 = new AWS.S3();
dotenv.config()

// ------------------------------ routes --------------------------------------//

const authRoutes = require('./routes/auth')
const profileRoutes = require('./routes/profile')
const courseRoutes = require('./routes/course')

// ?? hardcoded PATH for python?
let python3 ='C:/Users/majum/AppData/Local/Programs/Python/Python38-32/python.exe'
// ------------------------------ Schemas ---------------------------------------//

const User = require("./schemas/userSchema")
const Course = require("./schemas/courseSchema")
const ObjExercise = require("./schemas/objExerciseSchema.js")
const ProgExercise = require("./schemas/progExerciseSchema.js")
const Concept = require("./schemas/conceptSchema.js")
const SaveCourseSchema = require("./schemas/saveCourseSchema.js")
const SaveObjExerciseSchema = require("./schemas/saveObjExerciseSchema.js")
const SaveProgExerciseSchema = require("./schemas/saveProgExerciseSchema.js")
const SaveConceptSchema = require("./schemas/saveConceptSchema.js")
const SaveUserSchema = require("./schemas/saveUserSchema.js")
const monitorObj = require("./schemas/monitorSchema")
const userScore = require("./schemas/userScoreSchema")

// ------------------------------- Files ---------------------------------------//

// DO NOT REMOVE
const passportConfig = require('./config/passportConfig')

const authentication = require('./authRoutes')
const monitorProgram = require("./monitor_service_notifications_handler/src/index")
const authorization = require("./utilities/authorization")
// ------------------------------------------------------------------------------//

var env = process.env.NODE_ENV || "development";

let dbURL
if (env === "test") {
    dbURL = process.env.MONGO_TEST_URL
} else if (env === "production") {
    dbURL = process.env.MONGO_HOST_URL
} else {
    dbURL = process.env.MONGO_HOST_URL 
}

const app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());
app.use(passport.initialize());

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
})

// app.use(passport.session());

////// Connecting to mongodb in localhost
// (MongoDb community server version installed locally with tgz downloaded from https://www.mongodb.com/what-is-mongodb)
// (Installation guide: https://docs.mongodb.com/manual/administration/install-community/)
// (Instructions to upgrade community server to enterprise server: https://docs.mongodb.com/manual/administration/upgrade-community-to-enterprise/)
// (Instructions to run mongod in a different ip other than localhost: https://docs.mongodb.com/manual/release-notes/3.6-compatibility/#bind-ip-compatibility)
mongoose.connect(dbURL, { useNewUrlParser: true, useCreateIndex: true, useUnifiedTopology: true, useFindAndModify: false });
mongoose.connection.once('open', () => {
    console.log("Mongodb hosted at", process.env.MONGO_HOST_NAME, "is now connected. This is", env, "db.")
}).on('error', () => {
    console.log("Some error prevented connecting to mongodb")
})

//passport google oauth2.0
app.get('/auth/google', passport.authenticate('google', {
    session: false,
    scope: ['openid', 'profile', 'email']
}))

//google redirect/callback url
app.get('/auth/google/redirect', passport.authenticate('google', { session: false }), authentication.googleOAuthCallback);

app.use('/api/auth/', authRoutes);
app.use('/api/profile/', profileRoutes);
app.use('/api/course/', courseRoutes);

app.get('/test', (req, res) => {
    res.end("I am alive")
})

function verifyToken(req, res, next) {
    // Format::   Authorization: Bearer <access-token>
    // Get auth header value
    const bearerHeader = req.data;
    // Check if bearer is undefined
    if (typeof bearerHeader !== 'undefined') {
        // Split at the space
        const bearer = bearerHeader.split(' ')
        // get token from array
        const bearerToken = bearer[1];
        // Set the token
        req.token = bearerToken;
        // Next middleware
        next();
    }
    else {
        // Forbidden
        res.sendStatus(403);
    }

}

app.get('/testpost', (req, res) => {
    try {
        let newSal = Math.random() * 10000000;
        let newUser = "User" + newSal;
        axiosFixed.post(`http://dummy.restapiexample.com/api/v1/create`, {
            //proxy: {
            //    host: '172.16.2.30',
            //    port: 8080
            //},
            name: newUser,
            salary: newSal.toString(),
            age: "23"
        })
            .then(response => {
                console.log(response)
                res.end(JSON.stringify(response.data))
            })
            .catch(function (error) {
                console.log(error);
            });
    }
    catch (e) {
        console.log("Test failed")
    }
})

app.get('/get_save_user_data', async (req, res) => {
    SaveUserSchema.find({}).then(user => {
        res.json(user);
    })
})


app.post(`/script_save_course_details`, async (req, res) => {
	console.log("Inside script_save_course_details function", req.body.final_course, req.body.final_module, req.body.final_lecture, req.body.final_obj_exercise, req.body.final_prog_exercise)
	var course_xls = json2xls(req.body.final_course);
	var module_xls = json2xls(req.body.final_module);
	var lecture_xls = json2xls(req.body.final_lecture);
	var worked_out_worksheet_xls = json2xls(req.body.final_worked_out_worksheet);
	var exercise_xls = json2xls(req.body.final_exercise);
	var prog_exercise_xls = json2xls(req.body.final_prog_exercise);
	var obj_exercise_xls = json2xls(req.body.final_obj_exercise);
	//var sub_exercies_xls = json2xls(req.body.common_fields);
	var instructor_xls = json2xls(req.body.final_instructor);
	var concept_xls = json2xls(req.body.final_concept);
	

	fs.writeFileSync('course.xlsx', course_xls, 'binary');
	fs.writeFileSync('module.xlsx', module_xls, 'binary');
	fs.writeFileSync('lecture.xlsx', lecture_xls, 'binary');
	fs.writeFileSync('worked_out_worksheet.xlsx', worked_out_worksheet_xls, 'binary');
	fs.writeFileSync('exercise.xlsx', exercise_xls, 'binary');
	fs.writeFileSync('prog_exercise.xlsx', prog_exercise_xls, 'binary');
	fs.writeFileSync('obj_exercise.xlsx', obj_exercise_xls, 'binary');
	fs.writeFileSync('instructor.xlsx', instructor_xls, 'binary');
	fs.writeFileSync('concept.xlsx', concept_xls, 'binary');
	
	var { spawn } = require("child_process");
	//console.log("Inside script_save_course_details function", req.body.common_fields, req.body.final_module)

    var process = await spawn('python3', ['./Upload_script_for_save_course.py', 'course.xlsx', 'module.xlsx', 'lecture.xlsx', 'worked_out_worksheet.xlsx', 'exercise.xlsx', 'prog_exercise.xlsx', 'obj_exercise.xlsx', 'instructor.xlsx', 'concept.xlsx', '-mongodb_host_url_port', 'localhost:27017', '-mongodb_database_name', 'nairp-test-local-0']);
        
    process.stdout.on('data',async (data) => {
		let ddd = data.toString().trim()
		console.log("Course Successfully saved and the Object_id of the course : ", ddd);
        if(ddd.includes("Errors occur ")){
            res.json({ success: false, data: data.toString() })
        }else if (ddd.length === 24){
		    const save_user_details = new SaveUserSchema({
			    user_object_id : req.body.usersdetails["_id"],
			    course_object_id : ddd
		    })
		    // find whether the coming user is present or not 
		    var find_save_user_count = await SaveUserSchema.countDocuments({ user_object_id : req.body.usersdetails["_id"] });
		    if (find_save_user_count === 0) {
			    await save_user_details.save(); // save new user
			    console.log("User details are also saved successfully.");
		        res.json({ success: true, data: data.toString() })
            
		    }
		    else{
			    var myquery = { user_object_id : req.body.usersdetails["_id"] };
                var newvalues = { $set: {
                    user_object_id : req.body.usersdetails["_id"],
                    course_object_id : ddd
                } };
                SaveUserSchema.updateOne(myquery, newvalues)
                res.json({ success: true,  data: "User details has been updated successfully." })
		    }
        }else{
            res.json({ success: false, data: "while saving the course script generate errors." })
        }

    })
	process.stderr.on('data',(data) => {
		console.error("while saving the course script generate errors : ",data.toString());
        //res.json({ success: true, data: data.toString() })

    })
})


app.get('/get_savecourses_data', async (req, res) => {
    SaveCourseSchema.find({}).then(course => {
        res.json(course);
    })
})



app.get('/GetMediaContentFromS3Bucket',async (req, res )=>{
    var params = {
        Bucket: "aishiksha-media-content", 
       };
       s3.listObjects(params, function(err, data) {
        if (err) console.log(err, err.stack); // an error occurred
        else     res.json(data.Contents);           // successful response
        
      });
})
app.get('/get_saveobjexercise_data', async (req, res) => {
    SaveObjExerciseSchema.find({}).then(exercise => {
        res.json(exercise);
    })
})


app.get('/get_saveprogexercise_data', async (req, res) => {
    SaveProgExerciseSchema.find({}).then(exercise => {
        res.json(exercise);
    })
})


app.get('/get_saveconcept_data', async (req, res) => {
    SaveConceptSchema.find({}).then(concept => {
        res.json(concept);
    })
})

// concept
app.get('/get_concept', async (req, res) => {
    Concept.find({}).then(concept => {
        res.json(concept);
    })
})

// ObjectiveExercise
app.get('/get_objectexercise', async (req, res) => {
    ObjExercise.find({}).then(exercise => {
        res.json(exercise);
    })
})
/////// progexercise
app.get('/get_progexercise', async (req, res) => {
    ProgExercise.find({}).then(exercise => {
        res.json(exercise);
    })
})

app.get('/get_pdf', async (req, res) => {
    new PdfReader().parseFileItems("sample.pdf", function (err, item) {
        if (item && item.text)
            res.send(item.text);
    });
})
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

app.get('/get_user_data_nairp_db', async (req, res) => {
    User.find({}).then(user => {
        res.json(user);
    })
})


app.get('/get_course_grade', callName);

async function callName(req, res) {

    var spawn = require("child_process").spawn;

    var process = spawn("python3", ["./moodle_user_get_grade.py",
        req.query.username,
        req.query.password]);

    process.stdout.on('data', function (data) {

        res.send(data);

    })
}

app.get('/get_exercise', async (req, res) => {
    let dummyExercise = [{
        "courseId": "5e5661bacc73943f2ced832a",
        "lectureId": 1,
        "moduleId": 1,
        "questionType": "mcq",
        "question_has_pdf": false,
        "mcqType": "singlechoice",
        "question": "who invented machine learning",
        "choice_has_pdf": false,
        "listOfChoices": ["joker", "Bane", "Thanos", "Arthur Samuel"],
        "listOfAnswers": ["Arthur Samuel"],
        "marks": 1,
        "topics": ["Machine Learning", "ML", "AI"]
    },
    {
        "courseId": "5e5661bacc73943f2ced832a",
        "lectureId": 1,
        "moduleId": 1,
        "questionType": "fillUp",
        "question_has_pdf": false,
        "mcqType": "none",
        "question": "Full form of ML is $$ ?",
        "choice_has_pdf": false,
        "listOfChoices": ["Machine Learning"],
        "listOfAnswers": ["Machine Learning"],
        "marks": 6,
        "topics": ["Machine Learning", "ML", "AI"]
    },
    {
        "courseId": "5e5661bacc73943f2ced832a",
        "lectureId": 1,
        "moduleId": 1,
        "questionType": "mcq",
        "question_has_pdf": false,
        "mcqType": "multichoice",
        "question": "ML not invented By?",
        "choice_has_pdf": false,
        "listOfChoices": ["joker", "Bane", "Machine Learning", "Arthur Samuel"],
        "listOfAnswers": ["joker", "Bane", "Machine Learning"],
        "marks": 3,
        "topics": ["Machine Learning", "ML", "AI"]
    },
    {
        "courseId": "5e5661bacc73943f2ced832a",
        "lectureId": 1,
        "moduleId": 1,
        "questionType": "mcq",
        "question_has_pdf": true,
        "mcqType": "singlechoice",
        "question": "sample.pdf",
        "choice_has_pdf": false,
        "listOfChoices": ["joker", "Bane", "Thanos", "Arthur Samuel"],
        "listOfAnswers": ["Arthur Samuel"],
        "marks": 1,
        "topics": ["Machine Learning", "ML", "AI"]
    },
    {
        "courseId": "5e5661bacc73943f2ced832a",
        "lectureId": 1,
        "moduleId": 1,
        "questionType": "mcq",
        "question_has_pdf": true,
        "mcqType": "singlechoice",
        "question": "sample2.pdf",
        "choice_has_pdf": false,
        "listOfChoices": ["sigma", "beta", "alpha", "lamba"],
        "listOfAnswers": ["sigma"],
        "marks": 1,
        "topics": ["Machine Learning", "ML", "AI"]
    }
    ]
    // let updatedExercise=[];

    for (let i = 0; i < dummyExercise.length; i++) {
        if (dummyExercise[i].question_has_pdf === true) {

            new PdfReader().parseFileItems(dummyExercise[i].question, function (err, item) {
                if (item && item.text) {
                    dummyExercise[i].question = item.text;

                }
            });
        }

    }
    setTimeout(() => { res.json(dummyExercise) }, 50);

})
// app.get('/all', (req, res)=>{
//     let token = req.body.jwtToken;
//    request(`http://13.232.27.36:9000/sageview/all?token=`+token,function (response, error ){
//         console.log(response);
//     }
// );
// const options = {
//     url: 'https://www.reddit.com/r/funny.json',
//     method: 'GET',
//     headers: {
//         'Accept': 'application/json',
//         'Accept-Charset': 'utf-8',
//         'User-Agent': 'my-reddit-client'
//     }
// };

// app.get('/random',(res, req)=>{
//     request(options, function(err, res, body) {
//         let json = JSON.parse(body);
//         console.log(json);
//         res.send(json);
//         data = json;
//     } )
//     res.send(data);
// })
app.get('/moodle_signup', call_signup);

async function call_signup(req, res) {
    var spawn = require("child_process").spawn;
    var process = await spawn('python3', ["./moodle_signup.py", req.query.username, req.query.email, req.query.password, req.query.fname, req.query.lname]);
    process.stdout.on('data', function (data) {
        res.send(data);
    })
}

app.get('/moodle_question', call_question);

async function call_question(req, res) {
    console.log("Inside moodle_question")
    var spawn = require("child_process").spawn;
    var process = await spawn('python3', ["./direct_moodle_question_page.py", req.query.username, req.query.password]);
    process.stdout.on('data', function (data) {
        res.send(data);
    })
}


////// Solr queries
var solrClient = new solrNode({
    host: process.env.SOLR_HOST,
    port: process.env.SOLR_PORT,
    core: process.env.SOLR_CORE,
    protocol: 'http',
    user: process.env.SOLR_USER,
    password: process.env.SOLR_PASSWORD
});

function processSearchResult(qResult) {
    retObj = {}
    retObj.status = 200
    retObj.found = qResult["numFound"]

    if (qResult.numFound === 0) {
        return retObj
    }

    docs = []
    qResult.docs.forEach(function (item) {
        doc = {}
        doc.id = item["id"]
        doc.title = item["dc.title"]
        doc.resourceType = item["nairp.resourceType"]
        doc.description = item["dc.description"]
        doc.url = item["dc.identifier.uri"]
        doc.author = item["dc.contributor.author"]
        doc.subjects = item["nairp.subject.ai"]
        doc.contributor = item["dc.contributor.other"]
        doc.timeRequired = item["lrmi.timeRequired"]
        doc.relation = item["dc.relation.hasPart"]
        doc.language = item["dc.language.iso"]
        doc.type = item["dc.type"]
        doc.learningResourceType = item["lrmi.learningResourceType"]
        doc.interactivityType = item["lrmi.interactivityType"]
        doc.educationalAlignmentEducationLevel = item["lrmi.educationalAlignment.educationalLevel"]
        doc.evaluationElement = item["nairp.evaluation.element"]
        doc.publisher = item["dc.publisher"]
        doc.creatorResearcher = item["dc.creator.researcher"]
        doc.dateCreated = item["dc.date.created"]
        doc.dateAwarded = item["dc.date.awarded"]
        doc.rights = item["dc.rights.license"]
        doc.educationalAlignmentDifficultyLevel = item["lrmi.educationalAlignment.difficultyLevel"]
        doc.publisherInstitution = item["dc.publisher.institution"]
        doc.publisherDepartment = item["dc.publisher.department"]
        doc.contributorAdvisor = item["dc.contributor.advisor"]
        doc.relationIsPartOf = item["dc.relation.isPartOf"]
        doc.useRightsUrl = item["lrmi.useRightsUrl"]
        doc.formatMimeType = item["dc.format.mimetype"]
        doc.formatExtent = item["dc.format.extent"]
        doc.source = item["dc.source"]
        doc.educationalUse = item["lrmi.educationalUse"]
        doc.rightsAccessRights = item["dc.rights.accessRights"]
        doc.identifierIsbn = item["dc.identifier.isbn"]
        doc.dateModified = item["dc.date.modified"]
        doc.contributorCreator = item["dc.contributor.creator"]
        doc.descriptionAbstract = item["dc.description.abstract"]
        doc.isBasedOnUrl = item["lrmi.isBasedOnUrl"]
        doc.descriptionUri = item["dc.description.uri"]
        doc.subjectOther = item["dc.subject.other"]
        doc.courseType = item["nairp.course.type"]
        doc.courseStartDate = item["nairp.course.startDate"]
        doc.courseEndDate = item["nairp.course.endDate"]
        doc.relationDataSet = item["nairp.relation.dataSet"]
        doc.courseStructureType = item["nairp.course.structureType"]
        doc.questionType = item["nairp.question.type"]
        doc.datasetType = item["nairp.dataset.type"]
        doc.version = item["nairp.version"]
        doc.supportedOS = item["nairp.supportedOS"]
        doc.typeDegree = item["dc.type.degree"]
        doc.relationIsReferenceBy = item["dc.relation.isReferencedBy"]
        doc.relationReferences = item["dc.relation.references"]
        doc.sourceUri = item["dc.source.uri"]
        doc.LinguisticSystem = item["dc.LinguisticSystem"]
        docs.push(doc)
    });
    retObj.docs = docs

    return retObj
}
const setOfJSON1 = {
    "ID": ["3168"],
    "dc.title": "URL Classification Dataset [DMOZ]",
    "dc.contributor.author": ["Ashadullah Shawon"],
    "dc.description": ["This is an url classification dataset from dmoz directory. There are 15 class for classification.  "],
    "dc.type": "[{'fileType': 'csv', 'count': 2, 'totalSize': 260482712}]",
    "nairp.subject.ai": ["??"],
    "dc.date.created": "2018-08-13T14:34:25.3Z",
    "dc.identifier.uri": "https://www.kaggle.com/shawon10/url-classification-dataset-dmoz",
    "dc.contributor.creator": ["Ashadullah Shawon"],
    "dc.source": "https://www.kaggle.com/shawon10",
    "project": "https://www.kaggle.com/shawon10",
    "lot_info": "https://www.kaggle.com/shawon10",
    "dc.date.modified": "2018-08-19T04:38:42.657Z",
    "dc.rights.license": ["CC0: Public Domain"],
    "dc.format.extent": ["72143162"],
    "nairp.version": "2",
    "dc.description.abstract": "dmoz url classification",
    "dc.subject.other": ["['multiclass classification']"],
    "id": "e66496dc-b04e-4a72-b365-81d9b6c25ffe",
    "_version_": 1645838736441737217,
    "lastModified": "2019-09-27T14:22:10.874Z",
    "SolrIndexer.lastIndexed": "2019-09-27T14:22:10.874Z"
}
const setOfJSON2 = {
    "ID": ["3920"],
    "dc.title": "Garbage classification",
    "dc.contributor.author": ["cchangcs"],
    "dc.description": ["For the purpose of training and testing garbage classification model."],
    "dc.type": "[{'fileType': 'other', 'count': 6, 'totalSize': 42944382}]",
    "nairp.subject.ai": ["??"],
    "dc.date.created": "2018-11-24T05:05:59.267Z",
    "dc.identifier.uri": "https://www.kaggle.com/asdasdasasdas/garbage-classification",
    "dc.contributor.creator": ["cchangcs"],
    "dc.source": "https://www.kaggle.com/asdasdasasdas",
    "project": "https://www.kaggle.com/asdasdasasdas",
    "lot_info": "https://www.kaggle.com/asdasdasasdas",
    "dc.date.modified": "2018-11-24T05:09:23.977Z",
    "dc.rights.license": ["Other (specified in description)"],
    "dc.format.extent": ["42573553"],
    "nairp.version": "2",
    "dc.description.abstract": "Garbage classification",
    "dc.subject.other": ["['image data']"],
    "id": "c86a08a6-500f-4a0c-bcf1-43a5daac2d21",
    "_version_": 1645838736616849410,
    "lastModified": "2019-09-27T14:22:10.901Z",
    "SolrIndexer.lastIndexed": "2019-09-27T14:22:10.901Z"
}
const NumOfDataToBePushed = 50;
let dataArray = [];
for (let i = 0; i < NumOfDataToBePushed; i++) {
    dataArray.push(setOfJSON1);
    dataArray.push(setOfJSON2);
}
function getDummyResponse() {

    const qResult = {
        "numFound": 44,
        "start": 1,
        "maxScore": 6.0706058,
        "docs": dataArray
    }
    return qResult
}

app.get('/api/search', function (req, res) {

    console.log(req.url)

    if (req.url === "/api/search/" || req.url === "/api/search") {
        res.json({
            status: 403,
            message: "The search for void is still void !"
        });
        return;
    }
    let parsedUrl = url.parse(req.url); // req.url: /search/?str=nlp&str=boost&title=movie
    let parsedQs = querystring.parse(parsedUrl.query); // parsedUrl.query: str=nlp&str=boost&title=movie
    // let bigindex = querystring.parse(parsedUrl.bigindex);
    // parsedQs: { str: ['nlp','boost'], title: 'movie' }
    console.log(parsedQs)

    let strQuery = ''
    let pageIndex = 0
    let perPageResultCount = 1000
    // if ("prpg" in parsedQs) {
    //     perPageResultCount = parsedQs["prpg"]
    // }
    if ("pg" in parsedQs) {
        pageIndex = parsedQs["pg"]
    }
    let startIndexForQuery = pageIndex * perPageResultCount
    let rowCountForQuery = perPageResultCount

    console.log(startIndexForQuery)
    console.log(rowCountForQuery)

    //if(Object.keys(parsedQs).length === 1 && "str" in parsedQs){
    if ("str" in parsedQs) {
        //console.log("Search|Str:" + parsedQs["str"])
        //const strQuery = solrClient.query().q('productId:9788700075740');
        //const strQuery = solrClient.query().q('*:*');
        //const strQuery = solrClient.query().df('search_text').q('*' + parsedQs["str"] + '*');
        let compositeQstr = 'search_text:('
        if (typeof parsedQs["str"] === 'string') {
            compositeQstr += parsedQs["str"];
        }
        else {
            compositeQstr += parsedQs["str"][0];
            parsedQs["str"].map((val, index) => {
                if (index !== 0) {
                    compositeQstr += " " + val
                }
            })
        }
        compositeQstr += ")"
        console.log(compositeQstr)
        strQuery = solrClient.query().q(compositeQstr).start(startIndexForQuery).rows(rowCountForQuery)
        //strQuery = solrClient.query().q("search_text:" + parsedQs["str"]);
    }

    if (env === "production") {
        solrClient.search(strQuery, function (err, result) {
            if (err) {
                console.log(err);
                res.json({
                    status: 500,
                    success: false,
                    message: "Oops! Search failed now. Please try again later."
                });
                return;
            }
            processedSearchResult = processSearchResult(result.response)
            res.json(processedSearchResult)
        })
    }
    else {
        processedSearchResult = processSearchResult(getDummyResponse())
        res.json(processedSearchResult)
    }
})

const monitor = async () => {
    console.log("We're inside monitor function")
    await monitorProgram()
    setInterval(async () => {
        // console.log("We're inside callback function")
        await monitorProgram()
    }, 60000);
}

app.get('/monitor', authorization, async function (req, res) {

    data = await monitorObj.find({ user_id: req.query.user_id, is_seen: false }).exec()
    res.send(JSON.stringify(data))
})

app.post('/monitorUpdate', authorization, async function (req, res) {

    var id = req.body.id
    monitorObj.findByIdAndUpdate(id, { is_seen: true }, function (err, result) {
        if (err) {
            res.send(err)
        } else {
            res.send(result)
        }
    })
})

app.get('/validateUser', authorization, async function (req, res) {
    resultSet = await monitorObj.findOne({ user_id: req.query.user_id }).exec()
    let flag = true
    if (resultSet != null) {
        if (resultSet.data.length !== 0) {
            console.log(req.query.user_id, resultSet.data.length)
            for (var i = 0; i < resultSet.data.length; i++) {
                console.log(resultSet.data[i].message_id, typeof (req.query.course_id), typeof (resultSet.data[i].course_id))
                if ((resultSet.data[i].course_id == req.query.course_id) && (resultSet.data[i].message_id === 4)) {
                    console.log("User caught for course_id", req.query.course_id)
                    flag = false
                    // return false
                }
            }
        }
    }
    // resultSet[0].data.every(function (element, index) {
    //     console.log(element.message_id, index)
    //     if (element.message_id === 4) {
    //         console.log("User caught")
    //         flag = false
    //         return false
    //     }
    // })
    res.send({ "valid": flag })
})

app.get('/getScore', authorization, async function (req, res) {
    // console.log("A1", req.headers.token)
    count = await userScore.countDocuments({ uid: req.query.uid }).exec()
    console.log(req.query.uid)
    if (count === 0) {
        res.send({ "accuracy": "NA" })
    }
    else {
        try {
            resultSet = await userScore.findOne({ uid: req.query.uid }).exec()
            res.send({ "accuracy": resultSet.accuracy })
        } catch (error) {
            console.log(error)
        }

    }
})

app.post('/userScoreUpdate', authorization, async function (req, res) {


    // console.log(req.body.data)
    // console.log(req.headers.token)
    let data = req.body.data

    function sort_by_key(array, key) {
        return array.sort(function (a, b) {
            var x = a[key]; var y = b[key];
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        });
    }

    if (data.request_data.length != 0) {
        data.request_data = sort_by_key(data.request_data, "question")
    }

    const THRESHOLD = 60

    let count = await userScore.countDocuments({ uid: data.uid })
    if (count === 0) {
        let success_attemps, failed_attemps = 0
        if (data.accuracy > THRESHOLD) {
            success_attemps = 1
        }
        else {
            failed_attemps = 1
        }
        exercise_answers_metadata = []
        for (var i = 0; i < data.request_data.length; i++) {
            single_question = {}
            single_question["question_id"] = data.request_data[i].question
            single_question["last_score"] = data.request_data[i].obtained_marks
            single_question["best_score"] = data.request_data[i].obtained_marks
            exercise_answers_metadata.push(single_question)
        }
        const message = new userScore({
            uid: data.uid,
            user_id: data.user_id,
            course_id: data.course_id,
            module_id: data.module_id,
            question_type: data.question_type,
            accuracy: data.accuracy,
            best_score: data.accuracy,
            response_data: exercise_answers_metadata,
            no_of_successful_attempts: success_attemps,
            no_of_failed_attempts: failed_attemps
        })
        message.save()
            .then(doc => {
                console.log(doc)
                res.send("Data feeded in backend!")
                // return (course_name)
            })
            .catch(err => {
                console.error(err)
            })
    }
    else {
        console.log("Document already exists.")
        try {
            updated_data = {}
            document = await userScore.findOne({ uid: data.uid }).exec()
            // console.log(document.accuracy)
            if (data.accuracy > document.accuracy) {
                updated_data["accuracy"] = data.accuracy
                updated_data["best_score"] = data.accuracy
            }
            else {
                updated_data["accuracy"] = data.accuracy
            }
            if (data.accuracy > THRESHOLD) {
                updated_data["no_of_successful_attempts"] = document.no_of_successful_attempts + 1
            }
            else {
                updated_data["no_of_failed_attempts"] = document.no_of_failed_attempts + 1
            }
            exercise_answers_metadata = []

            for (var i = 0; i < data.request_data.length; i++) {
                // console.log(data.request_data[i].question, document.response_data[i].question_id)
                single_question = {}
                if (data.request_data[i].obtained_marks > document.response_data[i].last_score
                    && data.request_data[i].question == document.response_data[i].question_id) {

                    // console.log("HERE I AM")
                    single_question["last_score"] = data.request_data[i].obtained_marks
                    single_question["best_score"] = data.request_data[i].obtained_marks
                    single_question["question_id"] = data.request_data[i].question
                }
                else {
                    single_question["last_score"] = data.request_data[i].obtained_marks
                    single_question["best_score"] = document.response_data[i].best_score
                    single_question["question_id"] = data.request_data[i].question
                }
                exercise_answers_metadata.push(single_question)
            }
            updated_data["response_data"] = exercise_answers_metadata
            await userScore.findOneAndUpdate({ uid: data.uid }, { $set: updated_data })
            res.send("Data updated in backend!")
        } catch (error) {
            console.log(error)
        }
    }
})

if (process.env.NODE_ENV === "production") {

    app.get('*.js', function(req, res, next) {
        req.url = req.url + '.gz';
        res.set('Content-Encoding', 'gzip');
        res.set('Content-Type', 'text/javascript');
        next();
    });
       
    app.get('*.css', function(req, res, next) {
        req.url = req.url + '.gz';
        res.set('Content-Encoding', 'gzip');
        res.set('Content-Type', 'text/css');
        next();
    });

    app.use(express.static('../client/build'));

    app.get('*', (req, res) => {
        res.sendFile(path.join(__dirname, '..', 'client', 'build', 'index.html'));
    })
}

app.listen(process.env.PORT, () => {
    console.log("Server is listening to port:", process.env.PORT)
})

monitor()
module.exports = app;
