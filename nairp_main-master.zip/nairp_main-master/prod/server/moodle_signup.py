import requests
import json
import pprint
import sys
from cryptography.fernet import Fernet
import hashlib

import os
os.environ['no_proxy']= '10.5.30.191'
os.environ['NO_PROXY']= '10.5.30.191'


username = "admin"
password = "Admin@123" 
service = "Sou_Auth_Service"
argu = {'username' : username, 'password' : password, 'service' : service}
URL = "http://10.5.30.191:8888/moodle/login/token.php"    #?username="# + username + "&password=" + password + "&service=" + service
response = requests.post(url = URL, data= argu) 

data = response.json()
token = data ['token']

user_function ="core_user_create_users"
new_username=sys.argv[1] 
email = sys.argv[2] 
auth="manual"
password=sys.argv[3]
firstname=sys.argv[4]
lastname=sys.argv[5]

m = hashlib.sha224()
m.update(password.encode('utf-8'))

password = m.hexdigest()

user_argu = {'wstoken' : token, 'wsfunction' : user_function, 'moodlewsrestformat' : 'json', 'users[0][username]' : new_username, 'users[0][auth]' : auth, 'users[0][password]' : password, 'users[0][firstname]' : firstname, 'users[0][lastname]' : lastname, 'users[0][email]' : email} #, 'users[0][idnumber]' : idnumber}
user = "http://10.5.30.191:8888/moodle/webservice/rest/server.php"
user_response = requests.post(url = user, data=user_argu) 
print(user_response.status_code)

