import React, { Component } from 'react'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'

class AdvSearch extends Component
{
    state = {
        clauseList : [
            {
                clauseId     : 1,
                field        : "",
                value        : "",
                subClauseIds : [],
                bracketBefore: 0,
                bracketAfter : 0,
                not_ed       : "no",
                and_ed       : "no",    
                or_ed        : "no"
            }
        ]
    }

    render(){
        return (
          <div>
            <Container className="containerForTbd">
              <Row>
                <Col>
                  Advance search page will be implemented soon !
                </Col>
              </Row>
            </Container>
          </div>
        )
    }
}

export default AdvSearch