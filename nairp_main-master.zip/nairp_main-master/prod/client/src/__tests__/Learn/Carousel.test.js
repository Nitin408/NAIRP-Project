import React, { Component } from 'react';
import ReactDom from "react-dom";
import { render, cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";
import "@testing-library/jest-dom/extend-expect";
import {CarouselComponent} from "../../_learn/components/Carousel"
import {serverUrl} from "../../clientMisc"
import axios from 'axios';
const bannerArray =["/static/media/5e004fe9092d170577a5c8db.0bf7a676.jpg", "/static/media/5e004fe9092d170577a5c8dc.330af33b.png"];
it('Carousel rendered without break',async ()=>{
   var courseData =  await axios.get(serverUrl+'/api/course/learn');
    const tree = renderer.create(<CarouselComponent bannerArray={bannerArray} courseData={courseData.data} />).toJSON();
    expect(tree).toMatchSnapshot();
})
