import React, { Component } from 'react';
import ReactDom from "react-dom";
import { render, cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";
import "@testing-library/jest-dom/extend-expect";
import { MemoryRouter } from "react-router-dom";
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import toJson from 'enzyme-to-json';
import { shallow } from 'enzyme'
import axios from 'axios';
import {serverUrl} from "../../clientMisc"
import {CourseModuleSideBoxComponent} from "../../_learn/components/CourseModuleSideBoxComponent"
// import * as requiredData from "./requiredData.json";

it("Course module side box component renders without break",async()=>{
    var requiredData =  await axios.post(serverUrl+'/api/course/get_course', { courseId: '6071d0dee93eaff9ab201571' });
    const tree = renderer.create(
        <CourseModuleSideBoxComponent requiredData={requiredData.data.data}/>
    ).toJSON();
    expect(tree).toMatchSnapshot();
})
