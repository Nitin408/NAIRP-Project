import React, { Component } from 'react';
import ReactDom from "react-dom";
import { render, cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";
import { MemoryRouter } from "react-router-dom";
import {SubscribedCourses} from "../../_learn/components/SubscribedCourses"
const RegisteredCoursesList=[{_id: "5e004fe9092d170577a5c8dc", course_title: "Machine Learning Fundamentals"}, {_id: "5e004fe9092d170577a5c8db", course_title: "Artificial Intelligence"}];
it("Subscribed courses component renders without break", ()=>{
    const tree = renderer.create(
        <MemoryRouter initialEntries={[ '/courseintro/${RegisteredCoursesList[0]._id}' ]}>
            <SubscribedCourses arg={RegisteredCoursesList[0]} index={0}/>
        </MemoryRouter>
    ).toJSON();
    expect(tree).toMatchSnapshot();
})