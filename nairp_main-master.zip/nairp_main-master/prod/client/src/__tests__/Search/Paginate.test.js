import React, { Component } from 'react';
import ReactDom from "react-dom";
import { render, cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";
import "@testing-library/jest-dom/extend-expect";
import { MemoryRouter } from "react-router-dom";
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import toJson from 'enzyme-to-json';
import { shallow, mount } from 'enzyme'
configure({ adapter: new Adapter() });
import Paginate from "../../components/Paginate"
import {PagesInOneSlot} from '../../clientMisc'
const resultsPerPage= 5;
import * as docs from "./docs.json"
//if present inside campus net please uncomment 
// import axios from 'axios';
// const docs  = axios.get('/api/search/?str=' + "machine") 
let total = docs.docs.length;

const searchString= "ml"
const type= "posts";
const lastpage = Math.ceil(total/resultsPerPage)
const paginate = (page) => {
 
}
// const updated= 
it("pagination renders without break", ()=>{
  //let docs  = await axios.get('/api/search/?str=' + "machine")
  //const total = docs.data.docs.length;
    const tree= renderer.create(
        <MemoryRouter>
            <Paginate total={total} searchString={searchString} type={type}  />
        </MemoryRouter>
    ).toJSON();
    expect(tree).toMatchSnapshot();
});


it("testing default page of pagination", ()=>{
  const wrapper = shallow(
      <Paginate total={total} searchString={searchString} type={type} paginate={paginate}/>
  );
  const activePage = wrapper.state().activePage;
  expect(activePage).toBe(1);
})


it("testing next button of pagination", ()=>{
  const wrapper = shallow(
      <Paginate total={total} searchString={searchString} type={type} paginate={paginate}/>
  );

  let initialPage = wrapper.state().activePage;
  wrapper.find("#paginateNext").simulate("click");
  let currentPage = wrapper.state().activePage;
  expect(currentPage-initialPage).toBe(1);
})


it("testing prev button of pagination", ()=>{
  const wrapper = shallow(
      <Paginate total={total} searchString={searchString} type={type} paginate={paginate}/>
  );
  wrapper.find("#paginateNext").simulate("click");
  let initialPagePrev = wrapper.state().activePage;
  wrapper.find("#paginatePrev").simulate("click");
  let currentPagePrev = wrapper.state().activePage;
  expect(initialPagePrev - currentPagePrev).toBe(1);

})
it("testing pagination.first button of pagination", ()=>{
  const wrapper = shallow(
      <Paginate total={total} searchString={searchString} type={type} paginate={paginate}/>
  );
  wrapper.find('#paginateFirst').simulate('click');
  expect(wrapper.state().activePage).toBe(1);

})


// active page not working in last page
// it("testing pagination.Last button of pagination", ()=>{
//   const wrapper = shallow(
//       <Paginate total={total} searchString={searchString} type={type} paginate={paginate}/>
//   );
//   wrapper.find('#paginateLast').simulate('click');
//   // expect(wrapper.state().activePage).toBe(83);
//   console.log(wrapper.state().activePage);
// })


it("testing paginationNextSlot and previous slot button in pagination", ()=>{
  const wrapper = shallow(
      <Paginate total={total} searchString={searchString} type={type} paginate={paginate}/>
  );

  wrapper.find('#paginateFirst').simulate('click');
  wrapper.find('#paginateNextSlot').simulate('doubleclick');
  expect(wrapper.state().activeSlot).toBe(2);

  wrapper.find('#paginatePrevSlot').simulate('doubleclick');
  expect(wrapper.state().activeSlot).toBe(1);

})
