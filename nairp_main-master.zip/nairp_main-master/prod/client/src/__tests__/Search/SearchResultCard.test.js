import React, { Component } from 'react';
import ReactDom from "react-dom";
import { render, cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";
import "@testing-library/jest-dom/extend-expect";
import SearchResultCard from "../../components/SearchResultCard";
const doc=[{
    "ID": ["3920"],
    "dc.title": "Garbage classification",
    "dc.contributor.author": ["cchangcs"],
    "dc.description": ["For the purpose of training and testing garbage classification model."],
    "dc.type": "[{'fileType': 'other', 'count': 6, 'totalSize': 42944382}]",
    "nairp.subject.ai": ["??"],
    "dc.date.created": "2018-11-24T05:05:59.267Z",
    "dc.identifier.uri": "https://www.kaggle.com/asdasdasasdas/garbage-classification",
    "dc.contributor.creator": ["cchangcs"],
    "dc.source": "https://www.kaggle.com/asdasdasasdas",
    "project": "https://www.kaggle.com/asdasdasasdas",
    "lot_info": "https://www.kaggle.com/asdasdasasdas",
    "dc.date.modified": "2018-11-24T05:09:23.977Z",
    "dc.rights.license": ["Other (specified in description)"],
    "dc.format.extent": ["42573553"],
    "nairp.version": "2",
    "dc.description.abstract": "Garbage classification",
    "dc.subject.other": ["['image data']"],
    "id": "c86a08a6-500f-4a0c-bcf1-43a5daac2d21",
    "_version_": 1645838736616849410,
    "lastModified": "2019-09-27T14:22:10.901Z",
    "SolrIndexer.lastIndexed": "2019-09-27T14:22:10.901Z"
}];
it("Search Result cards Render without break",()=>{
    //let docs  = await axios.get('/api/search/?str=' + "machine")
    const tree= renderer.create(
        <SearchResultCard 
        doc={doc[0]}
        //doc = {docs.data.docs[0]}    
        />
    ).toJSON();
    expect(tree).toMatchSnapshot();
})