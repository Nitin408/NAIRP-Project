import React, { Component } from 'react'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'

class Browse extends Component
{
    render(){
        return (
          <div>
            <Container className="containerForTbd">
              <Row>
                <Col>
                  Browse page will be implemented soon !
                </Col>
              </Row>
            </Container>
          </div>
        )
    }

}

export default Browse