import React, { Component } from "react";
import queryString from 'query-string'
import { /*Switch, Link*/ Route, withRouter } from "react-router-dom";
import Home from "./_home/Home.js";
import FooTer from "./_home/Footer.js";
import TopNavbar from "./_home/TopNavbar.js";
import AdvSearch from "./_advSearch/AdvSearch.js";
import Learn from "./_learn/Learn.js";
import Login from "./_auth/Login.js";
import CompleteUserDetails from './_auth/CompleteUserDetails'
import VerifyEmail from './_auth/VerifyEmail.js'
import ForgotPassword from './_auth/ForgotPassword.js'
import ResetPassword from './_auth/ResetPassword.js'
import Logout from "./_auth/Logout.js";
import Profile from "./_profile/Profile.js";
import EditProfile from "./_profile/EditProfile.js";
import Signup from "./_auth/Signup.js";
//import Authenticator from "./_auth/Authenticator.js";
import SearchResultPage from "./_search/SearchResultPage.js";
import courseDetails from './_learn/CourseModule.js'
// import ShowVideo from './_course/upload/video/showVideo.js'
// import DeleteVideo from './_course/upload/video/deleteVideo.js'
import UploadVideo from './_course/upload/video/uploadVideo.js'
import ObjectiveExercise from "./_learn/ObjectiveExercise.js"
//import Browse                                 from './_browse/Browse.js'
import "./App.css";
import CourseIntro from "./_learn/CourseIntro.js";
import UploadCourseMethod from "./_course/UploadCourseMethod.js"
import PreviewCourse from "./_course/PreviewCourse.js"
import UploadCourse from "./_course/UploadCourse.js"

import {connect} from 'react-redux'
import {getResourcesFromS3} from './store/resource/action'


class App extends Component {
  state = {
    loggedIn: false,
    userEmail: "Unknown",
    authKey: "",
    searchString: ""
  };
  isLoggedIn = loggedIn => {
    this.setState({ loggedIn: loggedIn });
  };
  getUserEmail = userEmail => {
    this.setState({ userEmail: userEmail });
  };
  getAuthKey = authKey => {
    this.setState({ authKey: authKey });
  };
  getSearchString = searchString => {
    this.setState({ searchString: searchString });
  };

  componentDidMount(){
    this.props.getResourcesFromS3()
  }

  render() {
    return (
        <div>
        <TopNavbar
          loggedIn={this.isLoggedIn}
          userEmail={this.getUserEmail}
          authKey={this.getAuthKey}
          searchString={this.getSearchString}
        />
        <Route exact path="/" component={Home} />
        <Route exact path="/home" component={Home} />
        <Route exact path="/search" render={props => (
          <SearchResultPage
            key={queryString.parse(props.location.search).query}
            {...props}
            searchString={this.state.searchString}
          />
        )} />
        <Route exact path="/advsearch" component={AdvSearch} />
        <Route exact path="/learn" component={Learn} />
        <Route exact path="/objective_exercise" component={ObjectiveExercise} />
        <Route exact path="/signup" component={Signup} />
        <Route exact path="/login" component={Login} />
        <Route exact path="/login/:token" component={Login} />
        <Route exact path="/complete_user_details/:email" component={CompleteUserDetails} />
        <Route exact path="/logout" component={Logout} />
        <Route exact path="/profile" component={Profile} />
        <Route exact path="/verify_email" component={VerifyEmail} />
        <Route exact path="/forgot_password" component={ForgotPassword} />
        <Route exact path="/reset_password/:user/:token" component={ResetPassword} />
        <Route exact path='/courseDetails/:_id' component={courseDetails} />
        <Route exact path="/edit_profile" component={EditProfile} />
        <Route exact path="/courseintro/:_id" component={CourseIntro} />
        <Route exact path="/uploadVideo" component={UploadVideo} />
        {/* <Route exact path="/showVideo" component={ShowVideo} />
        <Route exact path="/deleteVideo" component={DeleteVideo} /> */}
		<Route exact path="/uploadCourseMethod" component={UploadCourseMethod} />
		<Route exact path="/previewCourse" component={PreviewCourse} />
		<Route exact path="/uploadCourse" component={UploadCourse} />

        {/* <Authenticator> */}
        {/* A protected component  */}
        {/* </Authenticator> */}
        {/*<Route exact path="/register" component={Register} />
          {/*<Route exact path="/compute" component={Compute} />
          <Route exact path="/browse" component={Browse} />
          <Route exact path="/forum" component={Forum} />*/}
        <FooTer />
      </div>
    );

    
  }
}

const mapStateToProps = (state) => {
  return {}
}

const mapDispatchToProps = {
  getResourcesFromS3: getResourcesFromS3
}


export default connect(mapStateToProps,mapDispatchToProps)(withRouter(App));
