import React from 'react';
import Accordion from 'react-bootstrap/Accordion'
import Button from 'react-bootstrap/Button'
import Card from 'react-bootstrap/Card'

export const FilterComponent=({keyword })=>{
    return (
        <Accordion style={{ width: '100%', height: '100%', margin: 0, padding: 0 }}>
                    <Card style={{ margin: 0, padding: 0 }}>
                        <Accordion.Toggle as={Button} variant="link" eventKey="0" style={{ textDecoration: 'none', backgroundColor: '#30797e', margin: 0, padding: 0 }} >
                            <Card.Header style={{ background: 'none', margin: 0, height: '40px', justifyContent: 'center', alignItems: 'center', textAlign: 'center' }}>
                                <p style={{ fontSize: 'medium', color: '#fff' }}> {keyword} </p>
                            </Card.Header>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="0" style={{ margin: 0, padding: 0 }} >
                            <Card.Body style={{ marginTop:5,marginBottom:5,  padding: 3 , justifyContent: 'center', alignItems: 'center', textAlign: 'center'}}>
                            <form style={{}}>
                            <input label ="search" onChange={e=>this.handleChange(e,index,key, arg )} />
                            </form>
                            </Card.Body>
                        </Accordion.Collapse>
                    </Card>
                </Accordion>
    )
}