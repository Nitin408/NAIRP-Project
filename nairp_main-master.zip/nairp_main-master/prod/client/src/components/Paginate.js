import React, {Component} from 'react'
import { PagesInOneSlot } from '../clientMisc'
import Pagination from 'react-bootstrap/Pagination'


export default class Paginate extends Component {

    state = {
        activePage : 1,
        activeSlot : 1,
        lastSlot: 1,
        lastpage: 1,
        currentPages : [],
        pageNumbers : [],
        type: ""
    }

    componentDidMount(){
        this.updateSlotCount()
    }

    updateSlotCount = async () => {
        const lastpage = Math.ceil(this.props.total/this.props.resultsPerPage) 
        this.setState({lastpage})
        let pageNumbers = []
        for(let i=1; i<=lastpage; i++){
            pageNumbers.push(i);
        }
        this.setState({pageNumbers})

        let activeSlot = 1
        let lastSlot = Math.ceil(lastpage/PagesInOneSlot) 
        let rightIndex = activeSlot*PagesInOneSlot
        let leftIndex = rightIndex - PagesInOneSlot
        let currentPages = pageNumbers.slice(leftIndex, rightIndex)
        // console.log(pageNumbers,"all pages")
        // console.log(currentPages, "current pages")
        this.setState({currentPages, activeSlot:1, lastSlot, activePage:1})
    }

    updateSlot = (page) => {
        var {pageNumbers} = this.state
        let newSlot = Math.ceil(page/PagesInOneSlot)

        let rightIndex = newSlot*PagesInOneSlot
        let leftIndex = rightIndex - PagesInOneSlot
        let currentPages = pageNumbers.slice(leftIndex, rightIndex)
        this.setState({currentPages,activeSlot:newSlot})
    }

    switchSlot = (action) => {
        let newSlot = this.state.activeSlot + action
        let rightIndex = newSlot*PagesInOneSlot
        let leftIndex = rightIndex - PagesInOneSlot
        let currentPages = this.state.pageNumbers.slice(leftIndex, rightIndex)

        if(action===-1){
            let activePage = currentPages[PagesInOneSlot -1]
            this.setState({activePage})
            this.props.paginate(activePage)
        }
        if(action===+1){
            let activePage = currentPages[0]
            this.setState({activePage})
            this.props.paginate(activePage)
        }

        this.setState({currentPages,activeSlot:newSlot})
    }

    componentDidUpdate(prevProps) {
        
        if (prevProps.searchString !== this.props.searchString) {
            this.setPage(1)
        }

        if(prevProps.resultsPerPage !== this.props.resultsPerPage) {
            this.updateSlotCount()
            this.props.paginate(1)
        }

        if(prevProps.type !== this.props.type) { //forced update of component on showing filtered posts
            this.props.paginate(1)
            this.updateSlotCount()
        }

        if(prevProps.updated !== this.props.updated) { //forced update of component on showing filtered posts when query updates
            this.updateSlotCount()
        }
    }

    setPage = (page) => {
        this.setState({activePage: page})
        this.updateSlot(page)
        this.props.paginate(page)
    }

    render(){
        let {activePage,lastpage,currentPages,lastSlot,activeSlot} = this.state

        return(
            <div>
                <Pagination>
                    <Pagination.First id="paginateFirst" onClick={()=>{this.setPage(1)}} disabled={activePage===1} />
                    <Pagination.Prev id="paginatePrev" onClick={()=>{this.setPage(activePage - 1)}} disabled={activePage===1}/>
                    {(activeSlot!==1)?(<Pagination.Ellipsis id="paginatePrevSlot" onDoubleClick={() => this.switchSlot(-1)} />):('')}
                    {currentPages.map((page)=>{
                        return(
                            <Pagination.Item id="paginate" key={page} onClick={()=>{this.setPage(page)}} active={activePage === page}>{page}</Pagination.Item>
                        )
                    })}
                    {(activeSlot!==lastSlot)?(<Pagination.Ellipsis id="paginateNextSlot" onDoubleClick={() => this.switchSlot(+1)} />):('')}
                    <Pagination.Next id='paginateNext' onClick={()=>{this.setPage(activePage + 1)}} disabled={activePage===lastpage}/>
                    <Pagination.Last id="paginateLast" onClick={()=>{this.setPage(lastpage)}} disabled={activePage===lastpage}/> 
                </Pagination>
            </div>
        )
    }
}