import React, { Component } from 'react';
import Accordion from 'react-bootstrap/Accordion'
import Button from 'react-bootstrap/Button'
import InputGroup from 'react-bootstrap/InputGroup'
import Card from 'react-bootstrap/Card'
import { FilterSelect } from "../FilterConfig.js"


export default class Filter extends Component {
    state = {
        docs: this.props.docs,
        resourceType: this.props.resourceType,
        Author: this.props.Author,
        sideBoxHeadings: this.props.sideBoxHeadings,
        sideBoxSubheadings: this.props.sideBoxSubheadings,
        value: this.props.value,
        checkArray: this.props.checkArray,
        checked: this.props.checked,
        checkedValue: this.props.checkedValue,
        checkBox: this.props.checkBox,
        sideBoxDummyArray: this.props.sideBoxDummyArray,
        FilteredArray: null,

    }
    
    ///main array for the filtering process
    isKeyValuePresent = async (array, key, value) => {
        let t1 = performance.now();
        let concatinatedArgs = key + ':' + value;
        let checkBool = false;
        let add = true;
        let remove = false;

        if (array.length !== 0) {
            for (let i = 0; i < array.length; i++) {
                if (concatinatedArgs === array[i]) {

                    remove = true;
                    add = false;

                }
            }
            for (let v = 0; v < array.length; v++) {
                if (array[v] === concatinatedArgs) {
                    array.splice(v, 1);
                    checkBool = true;
                }
            }
            if (array.length === 0) {
                this.setState({ FilteredArray: [] }, () => {
                    //console.log(this.state.FilteredArray);
                    this.props.callbackFunction(this.state.FilteredArray);
                })
            }

            if (!checkBool) {
                await array.push(concatinatedArgs);
            }
            if (remove) {
                var removedArray = [];
                for (let j = 0; j < array.length; j++) {
                    //console.log(array[j].split(":")[1]);
                    for (let i = 0; i < this.state.docs.length; i++) {
                        if (array[j].split(":")[1] === this.state.docs[i][key]) {

                            removedArray.push(this.state.docs[i]);
                            //console.log(removedArray)
                        }
                    }
                }
                this.setState({ FilteredArray: removedArray }, () => { console.log(this.state.FilteredArray); this.props.callbackFunction(this.state.FilteredArray) })
            }
        }
        else {
            array.push(concatinatedArgs)
        }
        if (this.state.FilteredArray === null || this.state.FilteredArray === [] || array === [] || array === null || array === []) {

            var randomArray = [];
            for (let i = 0; i < this.state.docs.length; i++) {
                if (this.state.docs[i][key] === value) {
                    randomArray.push(this.state.docs[i]);
                }
            }
            this.setState({ FilteredArray: randomArray }, () => {
                //console.log(this.state.FilteredArray);  
                this.props.callbackFunction(this.state.FilteredArray);

            });
        }
        else {
            // console.log(this.state.FilteredArray)
            for (let j = 0; j < this.state.FilteredArray.length; j++) {
                if (value === this.state.FilteredArray[j][key]) {
                    add = false;
                }
            }
            if (add) {

                for (let i = 0; i < this.state.docs.length; i++) {

                    if (this.state.docs[i][key] === value) {
                        this.state.FilteredArray.push(this.state.docs[i]);

                    }
                }
                //console.log(this.state.FilteredArray);  
                this.props.callbackFunction(this.state.FilteredArray);
            }
            //    var anotherRandomArray = [];
            //    var dataPresent=false;
            //    for(let i=0 ; i<this.state.FilteredArray.length; i++){
            //        if(this.state.FilteredArray[i][key]===value){
            //            anotherRandomArray.push(this.state.FilteredArray[i]);
            //            dataPresent=true;
            //        }

            //    }
            //    this.props.callbackFunction(this.state.FilteredArray);
            //    if(dataPresent===false){
            //        this.setState({FilteredArray:[]}, ()=>this.props.callbackFunction(this.state.FilteredArray));
            //    }

            //this.props.callbackFunction(this.state.FilteredArray);
        }
        //console.log(this.state.FilteredArray)
        let t2 = performance.now();
        let diff = t2 - t1;
        console.log("time for filtering(in ms): " + diff)
    }

    componentDidMount() {
        //console.log(FilterSelect)
        this.setState({ sideBoxDummyArray: this.state.sideBoxSubheadings });
        let sideBoxHeadings = [];
        let resourceTypeArray = [];
        let Author = [];
        if (this.state.docs != null) {

            for (let k = 0; k < this.state.docs.length; k++) {
                resourceTypeArray.push(this.state.docs[k].resourceType);
                Author.push(this.state.docs[k].author);
                for (let l = 0; l < Object.keys(this.state.docs[k]).length; l++) {
                    if (Object.keys(this.state.docs[k])[l] !== 'id' && Object.keys(this.state.docs[k])[l] !== 'dateCreated' && Object.keys(this.state.docs[k])[l] !== 'descriptionAbstract' && Object.keys(this.state.docs[k])[l] !== 'relationReferences' && Object.keys(this.state.docs[k])[l] !== 'description')
                        sideBoxHeadings.push(Object.keys(this.state.docs[k])[l])
                }
            }
        }
        function removeDups(names) {
            let unique = {};
            names.forEach(function (i) {
                if (!unique[i]) {
                    unique[i] = true;
                }
            });
            return Object.keys(unique);
        }
        // let uniqueResourceType = removeDups(resourceTypeArray);
        // //console.log(uniqueResourceType);
        // let uniqueAuthor = removeDups(Author);
        // //console.log(uniqueAuthor)
        let uniqueSideBoxHeadings = removeDups(sideBoxHeadings);
        // //console.log(uniqueSideBoxHeadings)
        // for (let i = 0; i < uniqueResourceType.length; i++) {
        //     this.state.resourceType.push(uniqueResourceType[i]);
        // }
        // for (let j = 0; j < uniqueAuthor.length; j++) {
        //     this.state.Author.push(uniqueAuthor[j]);
        // }
        for (let k = 0; k < uniqueSideBoxHeadings.length; k++) {
            this.state.sideBoxHeadings.push(uniqueSideBoxHeadings[k]);
        }

        this.state.sideBoxHeadings.map((arg) => {
            let dumpVar = [];
            let dumpVarJson = {};
            this.state.docs.map((arg2) => {

                if (typeof (arg2[arg]) === 'object') {

                    arg2[arg] = arg2[arg][0];

                }
                return dumpVar.push(arg2[arg]);
            })

            dumpVarJson[arg] = removeDups(dumpVar);
            //console.log(arg);

            return this.state.sideBoxSubheadings.push(dumpVarJson);


        })
        // console.log(this.state.sideBoxHeadings);
        // console.log(this.state.sideBoxSubheadings, "*sidebox sub headings");
        // console.log(this.state.sideBoxDummyArray, "*sidebox dummy array headings");
    }

    handleChange = async (event, index, key, arg) => {
        const { value } = event.target;
        this.state.value = value;
        if (value.length !== 0) {
            var sideBoxDummyArray = this.state.sideBoxDummyArray;
            var dummyArray = await sideBoxDummyArray[index][key].filter(name => name.includes(this.state.value));
            this.setState({ checkArray: dummyArray }, () => {
                var filteredArray = this.state.checkArray;
                sideBoxDummyArray[index][key] = filteredArray;
                this.setState({ sideBoxDummyArray: sideBoxDummyArray });
                // console.log(this.state.sideBoxDummyArray)
            });
            //console.log(this.state.checkArray);
            console.log("prasanna"+Object.values(this.state.checkArray));
        }

    };

    render() {

        return (
                <div>
                {
                    this.state.sideBoxSubheadings.map((arg, index) => {
                        for (var key in arg);
                        //console.log(key)
                        var keyword = ""
                        if (key === 'title') { keyword = 'Title' }
                        if (key === 'resourceType') { keyword = 'Resource Type' }
                        if (key === 'subjects') { keyword = 'Subject' }
                        if (key === 'description') { keyword = 'Description' }
                        if (key === 'author') { keyword = 'Author' }
                        if (key === 'url') { keyword = 'URL' }
                        if (key === 'contributor') { keyword = 'Contributor' }
                        if (key === 'timeRequired') { keyword = 'Time Required' }
                        if (key === 'relation') { keyword = 'Relation' }
                        if (key === 'language') { keyword = 'Language' }
                        if (key === 'type') { keyword = 'Type' }
                        if (key === 'learningResourceType') { keyword = 'Learning Resource' }
                        if (key === 'interactivityType') { keyword = 'Interactivity Type' }
                        if (key === 'educationalAlignmentEducationLevel') { keyword = 'Education Level' }
                        if (key === 'evaluationElement') { keyword = 'Evaluation' }
                        if (key === 'publisher') { keyword = 'Publisher' }
                        if (key === 'creatorResearcher') { keyword = 'Creator Researcher' }
                        if (key === 'dateCreated') { keyword = 'Date Created' }
                        if (key === 'dateAwarded') { keyword = 'Date Awarded' }
                        if (key === 'rights') { keyword = 'Rights' }
                        if (key === 'educationalAlignmentDifficultyLevel') { keyword = 'Difficulty Level' }
                        if (key === 'publisherInstitution') { keyword = 'Publisher Institution' }
                        if (key === 'publisherDepartment') { keyword = 'Publisher Department' }
                        if (key === 'contributorAdvisor') { keyword = 'Contributor Advisor' }
                        if (key === 'relationIsPartOf') { keyword = 'Relation Is Part Of' }
                        if (key === 'useRightsUrl') { keyword = 'Use Right URL' }
                        if (key === 'formatMimeType') { keyword = 'Format Mime' }
                        if (key === 'formatExtent') { keyword = 'Format Extent' }
                        if (key === 'source') { keyword = 'Source' }
                        if (key === 'educationalUse') { keyword = 'Educational Use' }
                        if (key === 'rightsAccessRights') { keyword = 'Rights Access Rights' }
                        if (key === 'identifierIsbn') { keyword = 'Indentifier' }
                        if (key === 'dateModified') { keyword = 'Date Modified' }
                        if (key === 'contributorCreator') { keyword = 'Contributor Creator' }
                        if (key === 'descriptionAbstract') { keyword = 'Description Abstract' }
                        if (key === 'isBasedOnUrl') { keyword = 'Is Based On URL' }
                        if (key === 'descriptionUri') { keyword = 'Decsription URI' }
                        if (key === 'subjectOther') { keyword = 'Subject Other' }
                        if (key === 'courseType') { keyword = 'Course Type' }
                        if (key === 'courseStartDate') { keyword = 'Start Date' }
                        if (key === 'courseEndDate') { keyword = 'End Date' }
                        if (key === 'relationDataSet') { keyword = 'Relation Data Set' }
                        if (key === 'courseStructureType') { keyword = 'Course Structure' }
                        if (key === 'questionType') { keyword = 'Question Type' }
                        if (key === 'datasetType') { keyword = 'Dataset Type' }
                        if (key === 'version') { keyword = 'Version' }
                        if (key === 'supportedOS') { keyword = 'Supported OS' }
                        if (key === 'typeDegree') { keyword = 'Type Degree' }
                        if (key === 'relationIsReferenceBy') { keyword = 'Relation is Reference by' }
                        if (key === 'relationReferences') { keyword = 'Relation Reference' }
                        if (key === 'sourceUri') { keyword = 'Source URI' }
                        if (key === 'LinguisticSystem') { keyword = 'Linguistic System' }
                        return (
                            (FilterSelect[key] === true) ? (
                                <Accordion key={index}>
                                    <Card style={{margin: 0 , padding:0}}>
                                        <Accordion.Toggle as={Button} variant="link" eventKey="0" style={{textDecoration: 'none', backgroundColor: '#30797e', margin: 0, height: '35px' }} >
                                            <Card.Header style={{ margin: 0, height: '35px',paddingTop:0, paddingBottom:'5px', paddingLeft:0, paddingRight:0}}>
                                                <b style={{fontSize: 'small', color: '#fff' }}> {keyword} </b>
                                            </Card.Header>
                                        </Accordion.Toggle>
                                        <Accordion.Collapse eventKey="0" style={{ margin: 0, padding: 0 }} > 
                                            <Card.Body style={{ marginTop: 5, marginBottom: 5, padding: 3}}>
                                                <form style={{}}>
                                                    <input label="search" placeholder="Search" id={`search-${index}`} onChange={e => this.handleChange(e, index, key, arg)} />
                                                </form>
                                                <InputGroup>
                                                    <div style={{ height: 200, "overflow": "scroll", width: '100%' }}>
                                                        {(this.state.value.length === 0) ? (arg[key].map(el => (
                                                            <div>
                                                                <InputGroup.Prepend style={{ margin: 3 }} onClick={() => {
                                                                    this.setState({ checked: !this.state.checked, checkedValue: el, });
                                                                    //this.state.checkBox.push(key + ":" + el);
                                                                }}
                                                                >
                                                                    <InputGroup.Checkbox onClick={() => { this.isKeyValuePresent(this.state.checkBox, key, el) }} style={{ backgroundColor: '#fff' }}
                                                                    /><div style={{ "text-align": "left" }}><p>{el}</p></div><br />
                                                                </InputGroup.Prepend>
                                                            </div>
                                                        ))) : (this.state.sideBoxDummyArray[index][key].map((index, el) => (
                                                            <div key={index}>
                                                                <InputGroup.Prepend style={{ margin: 3 }} onClick={() => {
                                                                    this.setState({ checked: !this.state.checked, checkedValue: el, });
                                                                    //this.state.checkBox.push(key + ":" + el);
                                                                }}
                                                                >
                                                                    <InputGroup.Checkbox onClick={() => {
                                                                        this.isKeyValuePresent(this.state.checkBox, key, el);
                                                                        // console.log(this.state.checkBox);
                                                                    }} style={{ backgroundColor: '#fff' }}
                                                                    /><div style={{ "text-align": "left" }}><p>{el}</p></div> <br />
                                                                </InputGroup.Prepend>
                                                            </div>
                                                        )))}
                                                    </div>
                                                </InputGroup>
                                            </Card.Body>
                                        </Accordion.Collapse>
                                    </Card>
                                </Accordion>) : ("")
                        )
                    })
                }
            </div>
        )
    }
}