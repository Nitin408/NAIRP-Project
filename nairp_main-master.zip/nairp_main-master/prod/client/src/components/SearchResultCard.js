import React, {Component} from 'react';
import ShowMoreText from 'react-show-more-text';
import Card from 'react-bootstrap/Card'
import Accordion from 'react-bootstrap/Accordion'
import Button from 'react-bootstrap/Button'

export default class SearchResultCard extends Component{
        constructor(props) {
            super(props);
            this.state = {
                    opened: false,
            };
            this.moreDetails = this.moreDetails.bind(this);
	}
  
	moreDetails() {
            const { opened } = this.state;
            this.setState({
                    opened: !opened,
            });
            
	}
        
    render(){
        var {doc} = this.props;    //to retrieve results data
        var { details, children } = this.props;
        const { opened } = this.state;
        if (opened){
            details = <span style={{ fontSize: 'small', color:"#1890ff", cursor: "pointer" }}>Hide Details</span>
        }else{
            details = <span style={{ fontSize: 'small', color:"#1890ff", cursor: "pointer" }}>Expand Details</span>
            
        }
        
        var descrip = "Lorem ipsum dolor sit amet, consectetur  ut labore et dolore magna amet, consectetur adipiscing elit,  sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad Lorem ipsum dolor sit amet, consectetur  ut labore et dolore magna amet, consectetur adipiscing elit,  sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad";
                
        
        return (
                <div class="mb-1">
            <Card bg="light" text="black" border="success" style={{'marginTop': '0px', 'marginBottom': '0px', display: 'flex', flexDirection: 'row', padding:0 }}>
                <Card.Body style={{marginTop: '0px', 'marginBottom': '0px'}}>
                    <b>{(doc.title) ? (<b href={doc.url} style={{ fontSize: 'medium', 'marginTop': '0px', 'marginBottom': '0px', cursor: "pointer", color:'blue'}} onClick={() => { window.open(doc.url) }}>{doc.title}</b>) : ("")}</b>
                    <table>
                        <tbody>
                            
                            {(opened) ? <div>
                        {opened && (					
                            <div class='table_data'>
                            {children}
                            {(doc.resourceType) ? (<tr><td> <b>Resource Type  </b></td><td> {doc.resourceType}</td></tr>) : ("")}
                            {(doc.subjects) ? (<tr> <td><b>Subject  </b></td><td> {doc.subjects} </td></tr>) : ("")}
                            {(doc.description !== [] && doc.description && doc.description!==undefined) ? (<tr><td><b>Description  </b></td><td> {doc.description}</td></tr>) : ("")}            
                            {(doc.author) ? (<tr><td> <b>Author</b></td><td> {doc.author}</td></tr>) : ("")}
                            {(doc.contributor) ? (<tr><td> <b>Contributor </b></td> <td>{doc.contributor}</td></tr>) : ("")}
                            {(doc.timeRequired) ? (<tr> <td><b>Time Required </b> </td><td>{doc.timeRequired}</td></tr>) : ("")}
                            {(doc.relation) ? (<tr> <td><b>Relation </b></td> <td>{doc.relation}</td></tr>) : ("")}
                            {(doc.language) ? (<tr><td> <b>Language </b> </td><td>{doc.language}</td></tr>) : ("")}
                            {(doc.type) ? (<tr> <td><b>Type </b></td> <td>{doc.type}</td></tr>) : ("")}
                            {(doc.learningResourceType) ? (<tr><td> <b>Learning Resource Type </b></td><td> {doc.learningResourceType}</td></tr>) : ("")}
                            {(doc.interactivityType) ? (<tr> <td><b>Interactivity Type </b></td><td> {doc.interactivityType}</td></tr>) : ("")}
                            {(doc.educationalAlignmentEducationLevel) ? (<tr> <td><b>Education Level </b></td><td> {doc.educationalAlignmentEducationLevel}</td></tr>) : ("")}
                            {(doc.evaluationElement) ? (<tr><td> <b>Evaluation Element </b></td><td> {doc.evaluationElement}</td></tr>) : ("")}
                            {(doc.publisher) ? (<tr><td> <b>Publisher </b> </td><td>{doc.publisher}</td></tr>) : ("")}
                            {(doc.creatorResearcher) ? (<tr><td> <b>Creator </b> </td><td>{doc.creatorResearcher}</td></tr>) : ("")}
                            {(doc.dateCreated) ? (<tr><td> <b>Date Created </b></td><td> {doc.dateCreated}</td></tr>) : ("")}
                            {(doc.dateAwarded) ? (<tr><td> <b>Date Awarded </b></td><td> {doc.dateAwarded}</td></tr>) : ("")}
                            {(doc.rights) ? (<tr><td> <b>Rights </b></td><td> {doc.rights}</td></tr>) : ("")}
                            {(doc.educationalAlignmentDifficultyLevel) ? (<tr><td> <b>Difficulty Level </b></td> <td>{doc.educationalAlignmentDifficultyLevel}</td></tr>) : ("")}
                            {(doc.publisherInstitution) ? (<tr> <td><b>Publisher Institution </b></td> <td>{doc.publisherInstitution}</td></tr>) : ("")}
                            {(doc.publisherDepartment) ? (<tr><td> <b>Publisher Department </b></td> <td>{doc.publisherDepartment}</td></tr>) : ("")}
                            {(doc.contributorAdvisor) ? (<tr><td> <b>Contributor Advisor </b></td> <td>{doc.contributorAdvisor}</td></tr>) : ("")}
                            {(doc.relationIsPartOf) ? (<tr><td> <b>Relation Is Part Of </b></td> <td>{doc.relationIsPartOf}</td></tr>) : ("")}
                            {(doc.useRightsUrl) ? (<tr><td> <b>Use Rights Url </b></td><td> {doc.useRightsUrl}</td></tr>) : ("")}
                            {(doc.formatMimeType) ? (<tr> <td><b>Format Mime Type </b></td> <td>{doc.formatMimeType}</td></tr>) : ("")}
                            {(doc.formatExtent) ? (<tr><td> <b>Format Extent </b></td> <td>{doc.formatExtent}</td></tr>) : ("")}
                            {(doc.source) ? (<tr> <td><b>Source </b></td><td><a style={{cursor: "pointer", color:'blue'}} onClick={() => { window.open(doc.url) }}> {doc.source}</a></td></tr>) : ("")}
                            {(doc.educationalUse) ? (<tr><td> <b>Educational Use </b></td><td> {doc.educationalUse}</td></tr>) : ("")}
                            {(doc.rightsAccessRights) ? (<tr><td> <b>Rights Access Rights </b></td><td> {doc.rightsAccessRights}</td></tr>) : ("")}
                            {(doc.identifierIsbn) ? (<tr><td> <b>Identifier Isbn </b></td><td> {doc.identifierIsbn}</td></tr>) : ("")}
                            {(doc.dateModified) ? (<tr> <td><b>Date Modified </b> </td><td>{doc.dateModified}</td></tr>) : ("")}
                            {(doc.contributorCreator) ? (<tr> <td><b>Contributor Creator</b></td><td> {doc.contributorCreator}</td></tr>) : ("")}
                            {(doc.descriptionAbstract) ? (<tr> <td><b>Abstract </b></td> <td>{doc.descriptionAbstract}</td></tr>) : ("")}
                            {(doc.isBasedOnUrl) ? (<tr> <td><b>Is Based On Url </b></td> <td>{doc.isBasedOnUrl}</td></tr>) : ("")}
                            {(doc.descriptionUri) ? (<tr> <td><b>Description Uri </b> </td><td>{doc.descriptionUri}</td></tr>) : ("")}
                            {(doc.subjectOther) ? (<tr> <td><b>Subject Other </b> </td><td>{doc.subjectOther}</td></tr>) : ("")}
                            {(doc.courseType) ? (<tr> <td><b>Course Type </b></td><td> {doc.courseType}</td></tr>) : ("")}
                            {(doc.courseStartDate) ? (<tr> <td><b>Course Start Date </b></td> <td>{doc.courseStartDate}</td></tr>) : ("")}
                            {(doc.courseEndDate) ? (<tr> <td><b>Course End Date </b></td><td> {doc.courseEndDate}</td></tr>) : ("")}
                            {(doc.relationDataSet) ? (<tr> <td><b>Relation Data Set </b></td> <td>{doc.relationDataSet}</td></tr>) : ("")}
                            {(doc.courseStructureType) ? (<tr><td> <b>Course Structure Type </b></td><td> {doc.courseStructureType}</td></tr>) : ("")}
                            {(doc.questionType) ? (<tr><td> <b>Question Type </b></td><td> {doc.questionType}</td></tr>) : ("")}
                            {(doc.datasetType) ? (<tr> <td><b>Dataset Type </b></td><td> {doc.datasetType}</td></tr>) : ("")}
                            {(doc.version) ? (<tr><td> <b>Version </b> </td><td>{doc.version}</td></tr>) : ("")}
                            {(doc.supportedOS) ? (<tr> <td><b>Supported OS </b></td> <td>{doc.supportedOS}</td></tr>) : ("")}
                            {(doc.typeDegree) ? (<tr> <td><b>Type Degree </b></td><td> {doc.typeDegree}</td></tr>) : ("")}
                            {(doc.relationIsReferenceBy) ? (<tr><td> <b>Relation Is Reference By </b></td><td> {doc.relationIsReferenceBy}</td></tr>) : ("")}
                            {(doc.relationReferences) ? (<tr> <td><b>Relation References </b></td><td> {doc.relationReferences}</td></tr>) : ("")}
                            {(doc.sourceUri) ? (<tr> <td><b>Source Uri </b></td><td> {doc.sourceUri}</td></tr>) : ("")}
                            {(doc.LinguisticSystem) ? (<tr><td> <b>Linguistic System </b></td> <td>{doc.LinguisticSystem}</td></tr>) : ("")}
                            </div>
                        )}
                        </div> : 
                            <div class='table_data'>
                            {(doc.resourceType) ? (<tr> <td><b>Resource Type </b></td><td> {doc.resourceType}</td></tr>) : ("")}
                            {(doc.subjects) ? (<tr> <td><b>Subject </b></td><td> {doc.subjects} </td></tr>) : ("")}
                            {(doc.description !== [] && doc.description && doc.description!==undefined) ? (<tr><td>  <b>Description </b></td><td><ShowMoreText lines={2} more='Show more' less='Show less' onClick={this.executeOnClick} expanded={false} width={790}> {doc.description}</ShowMoreText></td></tr>) : ("")}            
                            {(doc.author) ? (<tr><td> <b>Author </b></td><td> {doc.author}</td></tr>) : ("")}
                            </div>            
                    }
                            <div  onClick={this.moreDetails}>
                                {details}
                            </div>
                   
                        </tbody>
                    </table>
                </Card.Body>
            </Card>
            </div>
        )
    }
}