const initState = {
    isLogin: 'false',
    profile: {}
}


const rootReducer = (state = initState, action) => {
    console.log(action)
    if (action.type === 'ADD_PROFILE') {
        return {
            ...state,
            isLogin: 'true',
            profile: { firstName: action.firstName, middleName: action.middleName, lastName: action.lastName, email: action.email, educationalLevel: action.educationalLevel, dob: action.dob, country: action.country, state: action.state, gender: action.gender, profession: action.profession }
        }
    }

    if (action.type === 'EDIT_PROFILE') {
        return {
            ...state,
            isLogin: 'true',
            profile: { firstName: action.firstName, middleName: action.middleName, lastName: action.lastName, email: action.email, educationalLevel: action.educationalLevel, dob: action.dob, country: action.country, state: action.state, gender: action.gender, profession: action.profession }
        }
    }
    if (action.type === 'LOGOUT_USER') {
        return {
            ...state,
            isLogin: 'false',
            profile: {}
        }
    }

    return state;
}

export default rootReducer