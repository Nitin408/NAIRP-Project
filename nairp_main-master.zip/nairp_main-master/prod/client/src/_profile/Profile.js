import React from "react";
import {getProfile} from '../store/profile/action'
import {connect} from 'react-redux'
import { Link } from "react-router-dom";

class Profile extends React.Component {

  componentDidMount() {
    const jwt = localStorage.getItem("my-jwt");
    if (!jwt) {
      this.props.history.push('/login');
    }

    if(this.props.profile.email===""){
      this.props.getProfile()
    }
  }

  render() {
    return (
      <>
        {this.props.profile.email.length ? (
          <center>
            <div className="app-content">
              <table>
                <thead>
                  <tr>
                    <td><h5>First Name: {this.props.profile.firstName}</h5> <br></br></td>
                  </tr>
                  <tr>
                    <td><h5>Middle Name: {this.props.profile.middleName}</h5> <br></br></td>
                  </tr>
                  <tr>
                    <td><h5>Last Name: {this.props.profile.lastName}</h5> <br></br></td>
                  </tr>
                  <tr>
                    <td><h5>Email: {this.props.profile.email}</h5><br></br></td>
                  </tr>
                  <tr>
                    <td><h5>Educational Level: {this.props.profile.educationalLevel}</h5> <br></br></td>
                  </tr>
                  <tr>
                    <td><h5>DOB: {this.props.profile.dob}</h5> <br></br></td>
                  </tr>
                  <tr>
                    <td><h5>Country: {this.props.profile.country}</h5> <br></br></td>
                  </tr>
                  <tr>
                    <td> <h5>Gender: {this.props.profile.gender}</h5> <br></br></td>
                  </tr>
                  <tr>
                    <td><h5>Profession: {this.props.profile.profession}</h5> <br></br></td>
                  </tr>

                </thead>
              </table>

              <h4><u>Actions</u></h4><br></br>
              <Link to="/edit_profile" style={{ color: "white" }}><button className="btn btn-info">Edit Profile</button></Link> {'\u00A0'}{'\u00A0'}
              <Link to="/forgot_password" style={{ color: "white" }}><button className="btn btn-info">Change Password</button></Link> {'\u00A0'}{'\u00A0'}
            </div>
          </center>


        ):(<div>Loading Profile../</div>)}

      </>
    )
  }

}

const mapStateToProps = ({profile}) => {
  return {
    profile: profile
  }
}

const mapDispatchToProps = {
  getProfile: getProfile
}

export default connect(mapStateToProps,mapDispatchToProps)(Profile)