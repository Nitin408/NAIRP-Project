import React from "react";
import { Link } from "react-router-dom";
import { connect } from 'react-redux'
import { ListOfAllCountries, ListOfAllIndianStates, ListOfAllGenders, ListOfAllEducationalLevels, ListOfAllProfessions } from "../clientMisc";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { Formik } from "formik";
import * as yup from "yup";
import Recaptcha from 'react-recaptcha'
import {editProfile} from '../store/profile/action'

class EditProfile extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            captchaVerified: false,
            captchaVerifyReponse: ""
        };
    }

    captchaOnloadCallback = () => {
        //console.log("Signup page Captcha loaded")
    };

    captchaVerifyCallback = response => {
        if (response) {
            //console.log('captchaVerifyResponse:',response)
            this.setState({ captchaVerified: true, captchaVerifyResponse: response });
        }
    };

    componentDidMount() {
        const jwt = localStorage.getItem("my-jwt");
        if (!jwt) {
            this.props.history.push('/login');
        }
    };



    render() {
        let captchaRef;
        console.log(this.props);

        // return (
        //     <div><center>
        //         <div className="app-content">
        //             <h5>First Name: <input value={this.props.profile.firstName}></input></h5> <br></br>
        //             <h5>Middle Name: <input value={this.props.profile.middleName}></input></h5> <br></br>
        //             <h5>Last Name: <input value={this.props.profile.lastName}></input></h5> <br></br>
        //             <h5>Educational Level: <input value={this.props.profile.educationalLevel}></input></h5> <br></br>
        //             <h5>dob: <input value={this.props.profile.dob}></input></h5> <br></br>
        //             <h5>State: <input value={this.props.profile.state}></input></h5> <br></br>
        //             <h5>Country: <input value={this.props.profile.country}></input></h5> <br></br>
        //             <h5>Gender: <input value={this.props.profile.gender}></input></h5> <br></br>
        //             <h5>Profession: <input value={this.props.profile.profession}></input></h5> <br></br>
        //             <h5>Email: {this.props.profile.email}</h5><br></br><br></br>

        //             <h5><button><Link to="/forgot_password">Save</Link></button></h5>
        //         </div>
        //     </center>
        //     </div>
        // )

        const schema = yup.object({
            firstName: yup
                .string()
                .trim()
                .required("First name is required")
                .max(30, "First name must be 30 characters at maximum"),
            email: yup
                .string()
                .trim()
                .required("Email address is required")
                .lowercase()
                .email("Invalid email address")
                .max(50, "Email must be 50 characters at maximum"),
            middleName: yup
                .string()
                .trim()
                .max(30, "Middle name must be 30 characters at maximum"),
            lastName: yup
                .string()
                .trim()
                .required("Last name is required")
                .max(30, "Last name must be 30 characters at maximum"),
            dob: yup
                .date()
                .required("Date of birth is required")
                .min("1900-01-01", "Date of birth can not be earlier than 1900-01-01") //new Date(1900, 1, 1)
                .max("2018-01-01", "Date of birth can not be later than 2018-01-01"),
            gender: yup
                .string()
                .trim()
                .required("Gender is required")
                .oneOf(ListOfAllGenders)
                .notOneOf(["Please select"]),
            educationalLevel: yup
                .string()
                .trim()
                .required("Educational Level is required")
                .oneOf(ListOfAllEducationalLevels)
                .notOneOf(["Please select"]),
            profession: yup
                .string()
                .trim()
                .required("Profession is required")
                .oneOf(ListOfAllProfessions)
                .notOneOf(["Please select"]),
            country: yup
                .string()
                .trim()
                .required("Country is required")
                .oneOf(ListOfAllCountries),
            state: yup
                .string()
                .trim()
                .required("State is required")
            ////terms: yup.bool().required(),
        });


        return (
            <Formik
                initialValues={{
                    firstName: this.props.profile.firstName,
                    middleName: this.props.profile.middleName,
                    lastName: this.props.profile.lastName,
                    email: this.props.profile.email,
                    dob: this.props.profile.dob,
                    gender: this.props.profile.gender,
                    educationalLevel: this.props.profile.educationalLevel,
                    profession: this.props.profile.profession,
                    country: this.props.profile.country,
                    state: this.props.profile.state
                }}
                validationSchema={schema}
                onSubmit={(values, { setSubmitting }) => {

                    if (this.state.captchaVerified === false) {
                        alert("Please verify that you're not a robot.");
                        return;
                    }
                    const captchaVerifyResponseLocal = this.state.captchaVerifyResponse;


                    setSubmitting(false);

                    values.firstName = values.firstName.trim();
                    values.middleName = values.middleName.trim();
                    values.lastName = values.lastName.trim();
                    values.dob = values.dob.trim();
                    values.gender = values.gender.trim();
                    values.educationalLevel = values.educationalLevel.trim();
                    values.profession = values.profession.trim();
                    values.country = values.country.trim();
                    values.state = values.country !== "India" ? "" : values.state.trim();
                    values.captchaVerifyResponse = captchaVerifyResponseLocal
                    values.email = this.props.profile.email

                    this.props.editProfile(values)

                    captchaRef.reset();
                    this.setState({ captchaVerified: false, captchaVerifyResponse: "" });

                }}
            >
                {({
                    values,
                    errors,
                    touched,
                    handleChange,
                    handleBlur,
                    handleSubmit,
                    isValid,
                    isSubmitting
                }) => (
                        <Form noValidate onSubmit={handleSubmit}>
                            <Container>
                                <Row>
                                    {" "}
                                    <Col></Col>{" "}
                                    <Col xs={4}>
                                        <Form.Group controlId="gFirstName">
                                            <Form.Label>First Name</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="firstName"
                                                value={values.firstName}
                                                size="m"
                                                placeholder=""
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                isValid={touched.firstName && !errors.firstName}
                                                isInvalid={
                                                    errors.firstName &&
                                                    touched.firstName &&
                                                    errors.firstName
                                                }
                                                disabled
                                            />
                                            <Form.Control.Feedback type="valid">
                                                {" "}
                                                Looks good !{" "}
                                            </Form.Control.Feedback>
                                            <Form.Control.Feedback type="invalid">
                                                {" "}
                                                {errors.firstName}{" "}
                                            </Form.Control.Feedback>
                                        </Form.Group>


                                        <Form.Group controlId="gMiddleName">
                                            <Form.Label>Middle Name</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="middleName"
                                                value={values.middleName}
                                                size="m"
                                                placeholder=""
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                isValid={touched.middleName && !errors.middleName}
                                                isInvalid={
                                                    errors.middleName &&
                                                    touched.middleName &&
                                                    errors.middleName
                                                }
                                                disabled
                                            />
                                            <Form.Control.Feedback type="valid">
                                                {" "}
                                                Looks good !{" "}
                                            </Form.Control.Feedback>
                                            <Form.Control.Feedback type="invalid">
                                                {" "}
                                                {errors.middleName}{" "}
                                            </Form.Control.Feedback>
                                        </Form.Group>


                                        <Form.Group controlId="gLastName">
                                            <Form.Label>Last Name</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="lastName"
                                                value={values.lastName}
                                                size="m"
                                                placeholder=""
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                isValid={touched.lastName && !errors.lastName}
                                                isInvalid={
                                                    errors.lastName && touched.lastName && errors.lastName
                                                }
                                                disabled
                                            />
                                            <Form.Control.Feedback type="valid">
                                                {" "}
                                                Looks good !{" "}
                                            </Form.Control.Feedback>
                                            <Form.Control.Feedback type="invalid">
                                                {" "}
                                                {errors.lastName}{" "}
                                            </Form.Control.Feedback>


                                        </Form.Group>

                                        <Form.Group controlId="gEmail">
                                            <Form.Label>Email</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="Email"
                                                value={values.email}
                                                size="m"
                                                placeholder=""
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                isValid={touched.email && !errors.email}
                                                isInvalid={
                                                    errors.email &&
                                                    touched.email &&
                                                    errors.email
                                                }
                                                disabled
                                            />
                                            <Form.Control.Feedback type="valid">
                                                {" "}
                                                Looks good !{" "}
                                            </Form.Control.Feedback>
                                            <Form.Control.Feedback type="invalid">
                                                {" "}
                                                {errors.email}{" "}
                                            </Form.Control.Feedback>
                                        </Form.Group>



                                    </Col>{" "}
                                    <Col></Col>{" "}
                                </Row>

                                <Row>
                                    {" "}
                                    <Col></Col>{" "}
                                    <Col>
                                        <Form.Group controlId="gGender">
                                            <Form.Label>Gender</Form.Label>
                                            <Form.Control
                                                as="select"
                                                type="select"
                                                name="gender"
                                                value={values.gender}
                                                size="m"
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                isValid={touched.gender && !errors.gender}
                                                isInvalid={
                                                    errors.gender && touched.gender && errors.gender
                                                }
                                            >
                                                {ListOfAllGenders.map((value, index) => {
                                                    if (index === 0) {
                                                        return (
                                                            <option key={index} disabled="True">
                                                                {value}
                                                            </option>
                                                        );
                                                    } else {
                                                        return <option key={index}>{value}</option>;
                                                    }
                                                })}
                                            </Form.Control>
                                            <Form.Control.Feedback type="valid">
                                                {" "}
                                                Looks good !{" "}
                                            </Form.Control.Feedback>
                                            <Form.Control.Feedback type="invalid">
                                                {" "}
                                                Gender is required{" "}
                                            </Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>{" "}
                                    <Col></Col>{" "}
                                </Row>
                                <Row>
                                    {" "}
                                    <Col></Col>{" "}
                                    <Col>
                                        <Form.Group controlId="gEducationalLevel">
                                            <Form.Label>Educational Level</Form.Label>
                                            <Form.Control
                                                as="select"
                                                type="select"
                                                name="educationalLevel"
                                                value={values.educationalLevel}
                                                size="m"
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                isValid={
                                                    touched.educationalLevel && !errors.educationalLevel
                                                }
                                                isInvalid={
                                                    errors.educationalLevel &&
                                                    touched.educationalLevel &&
                                                    errors.educationalLevel
                                                }
                                            >
                                                {ListOfAllEducationalLevels.map((value, index) => {
                                                    if (index === 0) {
                                                        return (
                                                            <option key={index} disabled="True">
                                                                {value}
                                                            </option>
                                                        );
                                                    } else {
                                                        return <option key={index}>{value}</option>;
                                                    }
                                                })}
                                            </Form.Control>
                                            <Form.Control.Feedback type="valid">
                                                {" "}
                                                Looks good !{" "}
                                            </Form.Control.Feedback>
                                            <Form.Control.Feedback type="invalid">
                                                {" "}
                                                Educational Level is required{" "}
                                            </Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>{" "}
                                    <Col></Col>{" "}
                                </Row>

                                <Row>
                                    {" "}
                                    <Col></Col>{" "}
                                    <Col xs={4}>
                                        <Form.Group controlId="gDob">
                                            <Form.Label>Date of Birth (choose if changing)</Form.Label>
                                            <Form.Control
                                                as="input"
                                                type="date"
                                                name="dob"
                                                value={values.dob}
                                                size="m"
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                isValid={touched.dob && !errors.dob}
                                                isInvalid={errors.dob && touched.dob && errors.dob}
                                            />
                                            <Form.Control.Feedback type="valid">
                                                {" "}
                                                Looks good !{" "}
                                            </Form.Control.Feedback>
                                            <Form.Control.Feedback type="invalid">
                                                {" "}
                                                {errors.dob}{" "}
                                            </Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>{" "}
                                    <Col></Col>{" "}
                                </Row>


                                <Row>
                                    {" "}
                                    <Col></Col>{" "}
                                    <Col>
                                        <Form.Group controlId="gProfession">
                                            <Form.Label>Profession</Form.Label>
                                            <Form.Control
                                                as="select"
                                                type="select"
                                                name="profession"
                                                value={values.profession}
                                                size="m"
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                isValid={touched.profession && !errors.profession}
                                                isInvalid={
                                                    errors.profession &&
                                                    touched.profession &&
                                                    errors.profession
                                                }
                                            >
                                                {ListOfAllProfessions.map((value, index) => {
                                                    if (index === 0) {
                                                        return (
                                                            <option key={index} disabled="True">
                                                                {value}
                                                            </option>
                                                        );
                                                    } else {
                                                        return <option key={index}>{value}</option>;
                                                    }
                                                })}
                                            </Form.Control>
                                            <Form.Control.Feedback type="valid">
                                                {" "}
                                                Looks good !{" "}
                                            </Form.Control.Feedback>
                                            <Form.Control.Feedback type="invalid">
                                                {" "}
                                                Profession is required{" "}
                                            </Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>{" "}
                                    <Col></Col>{" "}
                                </Row>
                                <Row>
                                    {" "}
                                    <Col></Col>{" "}
                                    <Col>
                                        <Form.Group controlId="gCountry">
                                            <Form.Label>Country</Form.Label>
                                            <Form.Control
                                                as="select"
                                                type="select"
                                                name="country"
                                                value={values.country}
                                                size="m"
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                isValid={touched.country && !errors.country}
                                                isInvalid={
                                                    errors.country && touched.country && errors.country
                                                }
                                            >
                                                {ListOfAllCountries.map((value, index) => {
                                                    return <option key={index}>{value}</option>;
                                                })}
                                            </Form.Control>
                                            <Form.Control.Feedback type="valid">
                                                {" "}
                                                Looks good !{" "}
                                            </Form.Control.Feedback>
                                            <Form.Control.Feedback type="invalid">
                                                {" "}
                                                {errors.country}{" "}
                                            </Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>{" "}
                                    <Col></Col>{" "}
                                </Row>
                                <Row>
                                    {" "}
                                    <Col></Col>{" "}
                                    <Col>
                                        <Form.Group controlId="gState">
                                            {(() => {
                                                if (values.country === "India") {
                                                    //return <Form.Control required size="m" as="select" defaultValue="Andaman and Nicobar Islands" onChange={this.handleState}>
                                                    return (
                                                        <div>
                                                            <Form.Label>State</Form.Label>
                                                            <Form.Control
                                                                as="select"
                                                                type="select"
                                                                name="state"
                                                                value={values.state}
                                                                size="m"
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                isValid={touched.state && !errors.state}
                                                                isInvalid={
                                                                    errors.state && touched.state && errors.state
                                                                }
                                                            >
                                                                {ListOfAllIndianStates.map((value, index) => {
                                                                    return <option key={index}>{value}</option>;
                                                                })}
                                                            </Form.Control>
                                                            <Form.Control.Feedback type="valid">
                                                                {" "}
                                                                Looks good !{" "}
                                                            </Form.Control.Feedback>
                                                            <Form.Control.Feedback type="invalid">
                                                                {" "}
                                                                State is required{" "}
                                                            </Form.Control.Feedback>
                                                        </div>
                                                    );
                                                }
                                            })()}
                                        </Form.Group>
                                    </Col>{" "}
                                    <Col></Col>{" "}
                                </Row><br></br>
                                <Row>
                                    {" "}
                                    <Col></Col>{" "}
                                    <Col><center>
                                        <Recaptcha
                                            size="normal"
                                            ref={e => (captchaRef = e)}
                                            sitekey="6LdFscIUAAAAAKHF6JSkSwiux70z4V6wGtj1H5H5"
                                            render="explicit"
                                            onloadCallback={this.captchaOnloadCallback}
                                            verifyCallback={this.captchaVerifyCallback}
                                        /></center>
                                    </Col>{" "}
                                    <Col></Col>{" "}
                                </Row><br></br>
                                <Row>
                                    {" "}
                                    <Col></Col>{" "}
                                    <Col>
                                        <center><Button variant="info" type="submit" size="m">
                                            Save changes!
                        </Button> {'\u00A0'}{'\u00A0'}
                                            <Link to="/profile" style={{ color: "white" }}><button className="btn btn-info">Back</button></Link></center>
                                    </Col>{" "}
                                    <Col></Col>{" "}
                                </Row><br></br>
                            </Container>
                        </Form>
                    )}
            </Formik>
        );


    }

}
const mapStateToProps = ({profile}) => {
    return {
        profile: profile
    }
}

const mapDispatchToProps = {
    editProfile: editProfile
}

export default connect(mapStateToProps, mapDispatchToProps)(EditProfile);
