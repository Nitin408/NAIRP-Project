import 'bootstrap/dist/css/bootstrap.min.css';
import React from 'react';
import ReactDOM from 'react-dom';
import { Router } from "react-router-dom";
import {history} from './clientMisc'
import App from './App';
// import 'font-awesome/css/font-awesome.css';
//import './index.css';


import { Provider } from 'react-redux'
import { PersistGate } from 'redux-persist/integration/react'
import {store, persistor} from './store'


ReactDOM.render(
  <Provider store={store}> 
    <PersistGate loading={null} persistor={persistor}>
      <Router history={history}>
        <App />  
      </Router> 
    </PersistGate>
  </Provider>,
  document.getElementById('root')
);


// ReactDOM.render(
//   <Provider store={store}> 
//       <BrowserRouter>
//         <App />
//       </BrowserRouter> 
//   </Provider>,
//   document.getElementById('root')
// );

// function saveToLocalStorage(state) {
//   try {
//     const serlizedState = JSON.stringify(state)
//     localStorage.setItem('state', serlizedState)
//   } catch (e) {
//     console.log(e)
//   }
// }

// function loadFromLocalStorage() {
//   try {
//     const serlizedState = localStorage.getItem('state')
//     if (serlizedState === null) return undefined
//     return JSON.parse(serlizedState)
//   } catch (e) {
//     console.log(e)
//     return undefined
//   }
// }

// const persistedState = loadFromLocalStorage()

// export const store = createStore(rootReducer, persistedState);

// store.subscribe(() => saveToLocalStorage(store.getState()))