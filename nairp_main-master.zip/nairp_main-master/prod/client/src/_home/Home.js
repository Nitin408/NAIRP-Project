import React, { Component } from 'react'
import Carousel from 'react-bootstrap/Carousel'
//import Carousel from '../../node_modules/react-bootstrap/Carousel'
import CrossfadeImage from "react-crossfade-image";
import { LinkContainer } from 'react-router-bootstrap'
import Card from 'react-bootstrap/Card';

import { connect } from 'react-redux'
import { getResourcesFromS3 } from '../store/resource/action'

class Home extends Component {
    state = {
        imageIndex: 0,
        s3MediaFolder: [],
        home_carousal_page_info_ads: [],
        home_carousal_new_courses: [],
        home_project_info_slideshow: []

    }
    async componentDidMount() {

        // if(this.props.resource.s3data.length === 0){
        //     await this.props.getResourcesFromS3()
        // }

        this.setState({
            s3MediaFolder: this.props.resource.s3data,
            home_carousal_page_info_ads: this.props.resource.home_carousal_page_info_ads,
            home_carousal_new_courses: this.props.resource.home_carousal_new_courses,
            home_project_info_slideshow: this.props.resource.home_project_info_slideshow
        });

        setInterval(() => {
            if (this.state.imageIndex === 0) {
                this.setState({ imageIndex: 1 })
            }
            else {
                this.setState({ imageIndex: 0 })
            }
        }, 3000)
    }
    render() {
        return (
            <div style={{ width: '100%', alignItems: 'center', justifyContent: 'center', borderRadius: 10 }}>
                <div style={{ width: '80%', marginLeft: '10%', borderRadius: 10, marginRight: '10%' }}>

                    <Carousel interval={1500} style={{ width: "100%", borderRadius: 10, borderColor: '#000', borderWidth: 2 }} >

                        {this.props.resource.home_carousal_new_courses.map((arg, i) => {
                            return (
                                <Carousel.Item key={i} style={{ borderRadius: 10, borderColor: '#000', borderWidth: 2 }}>
                                    <img
                                        className="d-block w-100"
                                        src={arg}
                                        alt="loading..."
                                        style={{ width: '100%', height: '100%' }}
                                    />

                                </Carousel.Item>
                            )
                        })}
                        {this.props.resource.home_carousal_page_info_ads.map((arg, i) => {
                            return (
                                <Carousel.Item key={i} style={{ borderRadius: 10, borderColor: '#000', borderWidth: 2 }}>

                                    <img
                                        className="d-block w-100"
                                        src={arg}
                                        alt="loading..."
                                        style={{ width: '100%', height: '100%' }}
                                    />

                                </Carousel.Item>
                            )
                        })}


                    </Carousel>
                </div>
                <div style={{ width: '80%', marginTop: 20, marginLeft: "10%", marginRight: "10%", height: 230, display: 'flex', flexDirection: 'row' }}>
                    <div style={{ height: 230, alignItems: 'center', width: '70%', float: 'left' }}>
                        <CrossfadeImage
                            style={{ height: '100%', width: '100%' }}
                            src={this.props.resource.home_project_info_slideshow[this.state.imageIndex]}
                            duration={1000}
                            timingFunction={"ease-out"}
                        />
                    </div>
                    <div style={{ width: '30%', height: 330 }}>

                        <LinkContainer to={{
                            pathname: `courseintro/6071d0dee93eaff9ab201571`,

                        }} >
                            <a href={`courseintro/6071d0dee93eaff9ab201571`}>

                                <Card style={{ width: '70%', marginLeft: '15%', height: '100%', elevation: 10, borderRadius: 10, boxShadow: "1px 1px 5px #9E9E9E", }} >

                                    <div >
                                        <Card.Img variant="top" src={"https://nairpcoursevideos-source-11yip8w7pm5e8.s3.ap-south-1.amazonaws.com/courses/3/card_image.png"} style={{ height: "70%", width: '100%' }} />

                                        <Card.Body style={{ height: "30%", lineHeight: 1, alignItems: 'center', textAlign: 'center' }}>
                                            <Card.Title >
                                            Machine Learning
                            </Card.Title>

                                            <div style={{ color: '#666', display: 'flex', flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around' }}>
                                            Assistant Prof. Adway Mitra     Prof. Sudeshna Sarkar
                            </div>
                                            <div style={{ flexDirection: 'row', display: 'flex', justifyContent: 'space-around' }}>
                                                <p style={{ fontSize: 10, color: '#2e2e2e' }}>Course Credit: 10</p>
                                                <p style={{ fontSize: 10, color: '#2e2e2e' }}>Duration(Minutes): 793</p>
                                            </div>
                                        </Card.Body>

                                    </div>

                                </Card>

                            </a>
                        </LinkContainer>

                    </div>
                </div>
                <div>

                </div>
            </div>
        )
    }
}

const mapStateToProps = ({ resource }) => {
    return {
        resource: resource
    }
}

const mapDispatchToProps = {
    getResourcesFromS3: getResourcesFromS3
}


export default connect(mapStateToProps, mapDispatchToProps)(Home)