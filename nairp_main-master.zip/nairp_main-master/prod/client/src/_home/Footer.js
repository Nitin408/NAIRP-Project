import React from '../../node_modules/react'
import "./styles.css";
import { Layout, Space, List, Typography, Divider } from "antd";
import "antd/dist/antd.css";
import { connect } from 'react-redux'
const { Link } = Typography;
const { Footer } = Layout;

const dataProductos = [
  "About",
  "Help",
  "Contact"
];

const dataServicios = [
  "Disclaimer",
  "FAQ"
];
class FooTer extends React.Component {
  state = {
    logo:[]
  }
  componentDidMount() {
    this.setState({
      logo: this.props.resource.logo
    });
}
    render() {
      return (
              <div style={{paddingTop:'100px' }}>
            <Footer class="footer" style={{ paddingTop :'5px', paddingBottom:'5px' ,paddingLeft: '10%',paddingRight:'10%'}}>
                
                <div class="row" style={{display:'flex', justifyContent:'space-between', paddingLeft:'15%', paddingRight:'15%'}}>
                    <div>
                        <i class="fa fa-lg fa-info-circle" />
                        <a  > About</a>
                    </div>
                    <div >
                        <i class="fa fa-lg fa-question-circle" />
                        <a  > Help</a>
                    </div>
                    <div >
                    <i class="fa fa-lg fa-phone-square" />
                        <a  > Contact</a>
                    </div>
                    <div >
                        <i class="fa fa-lg fa-legal" />
                        <a  > Disclaimer </a>
                    </div>
                    <div >
                        <i class="fa fa-lg fa-puzzle-piece" />
                        <a  > FAQ</a>
                    </div>
                </div>

                <div style={{align:"center", justifyContent:'center', alignItems: 'center', display: 'flex', flexDirection: 'row'}}>
                <a href={`/home`} style={{color:'bliue'}}>AIShiksha</a>
                    <span>&copy; 2021 AIShiksha. All rights reserved.</span>
                </div>
            </Footer>
            </div>
      );
    }
  }


const mapStateToProps = ({resource}) => {
  return {
    resource: resource
  }
}
  
const mapDispatchToProps = {}
  
  
export default connect(mapStateToProps,mapDispatchToProps)(FooTer)
