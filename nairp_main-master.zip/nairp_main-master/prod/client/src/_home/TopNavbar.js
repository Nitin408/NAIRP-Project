import React from 'react'
import Navbar from 'react-bootstrap/Navbar'
import Nav from 'react-bootstrap/Nav'
import NavDropdown from 'react-bootstrap/NavDropdown'
import Form from 'react-bootstrap/Form'
import FormControl from 'react-bootstrap/FormControl'
import Button from 'react-bootstrap/Button'
import { LinkContainer } from 'react-router-bootstrap'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import { withRouter } from 'react-router-dom'
import { connect } from 'react-redux'
import queryString from 'query-string'

import Monitoring from './Monitoring'

class TopNavbar extends React.Component {
  state = {
    loggedIn: false,
    userEmail: 'Unknown',
    authKey: '',
    searchString: queryString.parse(this.props.location.search).query,
    logo:[],
    searchString1:''
  }

  componentWillReceiveProps(){
    this.setState({searchString: queryString.parse(this.props.location.search).query})
  }

  handleSearchSubmit = async(e) => {
    console.log(this.state.searchString)
    localStorage.setItem("searchLoading",true)
    e.preventDefault()
    if(this.state.searchString===undefined){
      this.setState({searchString:" "}, ()=>{
        let searchString = this.state.searchString.trim()
    //this.setState({searchString: ''})
    this.props.searchString(searchString)
    this.props.history.push("/search?query=" + searchString)
      })
    }
    else
    {
    let searchString = this.state.searchString.trim()
    //this.setState({searchString: ''})
    this.props.searchString(searchString)
    this.props.history.push("/search?query=" + searchString)
  }
  await this.setState({searchString:queryString.parse(this.props.location.search).query})
  }

  handleSearchTextChange = (e) => {
    this.setState({ searchString: e.target.value, searchString1:e.target.value })
  }

  async componentDidMount() {

    // if(this.props.resource.logo.length === 0){
    //   await this.props.getResourcesFromS3()
    // }

    this.setState({
      logo: this.props.resource.logo
    });
}

  render() {
    let navContent, notification;
    const jwtToken = localStorage.getItem("my-jwt");

    if (this.props.loggedIn === false && !jwtToken) {
      notification = null
      navContent = <div>
        <LinkContainer to="/login">
          <NavDropdown.Item href="/logIn">Login</NavDropdown.Item>
        </LinkContainer>
        <LinkContainer to="/signup">
          <NavDropdown.Item href="/signup">Signup (New User)</NavDropdown.Item>
        </LinkContainer>
      </div>;
    } else {
      notification = null
      navContent = <div>
        <Navbar.Text>
          Logged in as: {this.props.profile.firstName}
        </Navbar.Text>
        <LinkContainer to="/profile">
          <NavDropdown.Item href="/profile ">Profile</NavDropdown.Item>
        </LinkContainer>
        {(this.props.profile.profession==="Admin")?(<LinkContainer to="/uploadCourseMethod">
          <NavDropdown.Item href="/uploadCourseMethod">Upload course</NavDropdown.Item>
        </LinkContainer>):("")}
        <LinkContainer to="/logout">
          <NavDropdown.Item href="/logout ">Logout</NavDropdown.Item>
        </LinkContainer>
      </div>
      notification = <Monitoring />
    }
    
    //disable the search button when there is empty string
    var searchValue = this.state.searchString;
    
    
    return (
      <div>
        <Navbar style={{paddingLeft:'0.5%'}} collapseOnSelect expand="lg" className="topnavbar" fixed="top">
          <LinkContainer  to="/home" id="HomePageNavigator">
            <Navbar.Brand href="/home">
              <img src={this.props.resource.logo[1]}
                width="120"
                height="40"
                className="d-inline-block align-top"
                alt="AIShiksha"
                
              />

            </Navbar.Brand>
          </LinkContainer>
          <Navbar.Toggle aria-controls="basic-navbar-nav"  />
          <Navbar.Collapse style={{paddingLeft:'9%'}} id="basic-navbar-nav" className="justify-content-center">
            <Nav >
              <Container>
                <Row>
                  <Col>
                    <Form inline onSubmit={this.handleSearchSubmit}>
                      <FormControl style={{width:400}} type="text" id="searchValue" value={searchValue} onChange={this.handleSearchTextChange} placeholder="Search" className="mr-sm-2" />
                      <Button type="submit" variant="success" id="mybutton" className="justify-content-end" disabled={!searchValue}>Search</Button>
                    </Form>
                  </Col>
                </Row>
              </Container>
              <LinkContainer to="/learn">
                <Nav.Link href="/learn">Learn</Nav.Link>
              </LinkContainer>

              <NavDropdown title="Account" id="basic-nav-dropdown" drop="down">

                {navContent}
              </NavDropdown>
              {notification}
            </Nav>
          </Navbar.Collapse>
        </Navbar>
      </div>
    )
  }
}





/*{<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <Link to="/" class="navbar-brand text-secondary">
    <b id="id1">N</b>ational <b id="id1">A</b>rtificial{" "}
    <b id="id1">I</b>ntelligence <b id="id1">R</b>esource{" "}
    <b id="id1">P</b>ortal
  </Link>
  <button
    class="navbar-toggler"
    type="button"
    data-toggle="collapse"
    data-target="#navbarSupportedContent"
    aria-controls="navbarSupportedContent"
    aria-expanded="false"
    aria-label="Toggle navigation"
  >
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto topnav">
      <li class="nav-item active">
        <Link to="/search" class="nav-link">
          Search
        </Link>
      </li>
      <li class="nav-item">
        <Link to="/browse" class="nav-link">
          Browse
        </Link>
      </li>
      <li class="nav-item">
        <Link to="/learn" class="nav-link">
          Learn
        </Link>
      </li>
      <li class="nav-item">
        <Link to="/compute" class="nav-link">
          Compute
        </Link>
      </li>
      <li class="nav-item">
        <Link to="/forum" class="nav-link">
          Forum
        </Link>
      </li>

      <li class="nav-item">
        <a
          id="id5"
          class="nav-link btn btn-primary text-white"
          type="button"
          href="#"
          data-toggle="modal"
          data-target="#myModal"
        >
          Sign In
        </a>
      </li>
      <li class="nav-item">
        <a
          id="id5"
          class="nav-link btn btn-danger text-white"
          type="button"
          href="#"
          data-toggle="modal"
          data-target="#myModal"
        >
          Register
        </a>
      </li>
    </ul>
  </div>

  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Customer Sign In</h4>
          <button type="button" class="close" data-dismiss="modal">
            ×
          </button>
        </div>

        <div class="modal-body">
          <form>
            <label class="sr-only" for="usrname">
              Username
            </label>
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">
                  <i class="fa fa-user"></i>
                </span>
              </div>
              <input
                type="text"
                class="form-control"
                placeholder="Username"
                aria-label="Username"
                aria-describedby="basic-addon1"
              />
            </div>

            <label class="sr-only" for="Password">
              Name
            </label>
            <div class="input-group mb-2">
              <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon2">
                  <i class="fa fa-key"></i>
                </span>
              </div>
              <input
                id="Password"
                type="password"
                class="form-control"
                placeholder="Password"
                aria-label="Password"
                aria-describedby="basic-addon2"
              />
            </div>
          </form>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">
            Sign In
          </button>
          <button
            type="button"
            class="btn btn-danger"
            data-dismiss="modal"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  </div>
</nav>
 
</Router>
</div>
)
}}*/

const mapStateToProps = ({auth,profile,resource}) => {
  return {
    profile: profile,
    loggedIn: auth.loggedIn,
    resource: resource
  }
}

const mapDispatchToProps = {}


export default connect(mapStateToProps,mapDispatchToProps)(withRouter(TopNavbar))