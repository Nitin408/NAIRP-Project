import NotifyMe from 'react-notification-timeline'
import React from 'react'
import jwt from 'jsonwebtoken'
import { JWT_SECRET_KEY } from '../clientMisc'
import axios from 'axios'

class Monitoring extends React.Component {

    // this.handleMonitoringChange = this.handleMonitoringChange.bind(this)
    // this.getUserData = this.getUserData.bind(this)
    state = {
        data: [],
        updateIDs: [],
        userID: '',
        timeout: 60000
    }

    componentDidMount() {
        this.handleMonitoringChange()
        this.interval = setInterval(async () => {
            await this.handleMonitoringChange()
        }, this.state.timeout)
    }

    componentWillUnmount() {
        // console.log("Unmounting!!")
        clearInterval(this.interval)
    }

    updateUtility = async (idArr) => {
        idArr.forEach((id) => {
            axios.post('/monitorUpdate', {
                id: id
            })
                .then(response => {
                    // console.log(response)
                }, error => {
                    console.log(error)
                })
        }
        )
    }

    getUserData = async () => {
        const JwtToken = localStorage.getItem("my-jwt")
        if (JwtToken != null) {
            var userDetails = jwt.verify(JwtToken, JWT_SECRET_KEY)
            this.setState({ userID: userDetails.user._id })
        }
    }

    handleMonitoringChange = async () => {

        await this.getUserData()
        // console.log(this.state.userID)
        var id = []
        var config = {
            method: 'get',
            // ${this.state.userID}
            url: `/monitor?user_id=${this.state.userID}`,
            headers: {
                'Content-Type': 'application/json',
                'token': localStorage.getItem("my-jwt")
            }
        }
        // console.log(config)
        axios(config)
            .then(async (response) => {
                // console.log("API DONE", response, response.data.length)
                console.log("Ver2")
                if (response.data.length !== 0) {
                    let res = JSON.stringify(response.data[0])
                    res = JSON.parse(res)
                    const notificationDump = {
                        0: "There was some problem with the NAIRP servers and unfortunately your instances were stopped",
                        1: "You've exceeded 50 % usage of your alloted AWS credits for the Course TEMP",
                        2: "You've exceeded 70 % usage of your alloted AWS credits for the Course TEMP",
                        3: "You've exceeded 90 % usage of your alloted AWS credits for the Course TEMP",
                        4: "You've exceeded 100 % usage of your alloted AWS credits for the Course TEMP",
                        5: "Your notebook instance for Course TEMP1 Module TEMP2 has been stopped because of Inactivity",
                        6: "Your notebook instance for Course TEMP1 Module TEMP2 Lecture TEMP3 Worksheet TEMP4 has been stopped because of Inactivity"
                    }
                    let joined = []
                    res.data.forEach(element => {
                        // console.log(element._id)
                        const t = new Date(element.time)
                        var unixTime = t.getTime()
                        let monitorData = []
                        if (element.exercise_id === undefined) {
                            monitorData = [
                                {
                                    "update": notificationDump[element.message_id].replace("TEMP", element.course_name),
                                    "timestamp": unixTime
                                }
                            ]
                        }
                        else {
                            if (element.exercise_id % 1000000 === 0) {

                                let e_id = element.exercise_id / 1000000
                                let t1 = notificationDump[element.message_id].replace("TEMP1", element.course_name)
                                let t2 = t1.replace("TEMP2", e_id)
                                monitorData = [
                                    {
                                        "update": t2,
                                        "timestamp": unixTime
                                    }
                                ]
                            } else {
                                let e_id = Math.floor(element.exercise_id / 1000000)
                                let rem = element.exercise_id % 1000000
                                let l_id = Math.floor(rem / 1000)
                                let w_id = rem % 100
                                let t1 = notificationDump[6].replace("TEMP1", element.course_name)
                                let t2 = t1.replace("TEMP2", e_id)
                                let t3 = t2.replace("TEMP3", l_id)
                                let t4 = t3.replace("TEMP4", w_id)
                                monitorData = [
                                    {
                                        "update": t4,
                                        "timestamp": unixTime
                                    }
                                ]
                            }
                        }
                        // console.log(unixTime)
                        joined = this.state.data.concat(monitorData)
                        this.setState((previousState) => {
                            if (!previousState.updateIDs.includes(element._id)) {
                                return ({ data: joined, updateIDs: [...previousState.updateIDs, element._id] })
                            }
                        })
                        id.push(element._id)
                    })
                }
                else {
                    // console.log("No data for this user in Monitoring yet! ")
                }
                // await this.updateUtility(id)
            })
            .catch(function (error) {
                console.log(error)
            })
    }

    render() {
        return (
            <NotifyMe
                data={this.state.data}
                storageKey='notific_key'
                notific_key='timestamp'
                notific_value='update'
                heading='Monitoring Alerts'
                sortedByKey={false}
                showDate={true}
                size={20}
                color="yellow"
            />
        )
    }
}

export default Monitoring