import React, {Component} from 'react'
import SearchResultCard from "../components/SearchResultCard"


export default class SearchResults extends Component{
    render(){

         var {currentPosts} = this.props

        return (
            <div style={{width:'100%'}}>
                {currentPosts && currentPosts.length ? (         
                    currentPosts.map((doc, index) => {
                        return (
                            <div className="searchResultCardDiv" key={index}  >
                                <SearchResultCard doc={doc} />
                            </div>
                        )
                    })
                ) : (
                    <div className="center">No documents found</div>
                )}
            </div>
        )
    }
}