import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import axios from 'axios'
import Navbar from 'react-bootstrap/Navbar'
import Nav from 'react-bootstrap/Nav'

// import {PerPageSearchResultCount} from '../clientMisc'
import queryString from 'query-string'
import Form from 'react-bootstrap/Form'
//import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import SearchResults from "./SearchResults"
import Paginate from "../components/Paginate"
import Filter from "../components/Filter.js";
import { serverUrl } from '../clientMisc'
import loader from '../images/rubiks_cube.gif'

class SearchResultPage extends Component {
    state = {
        resultPageIndex: 0,
        numFound: 0,
        docs: [],
        docsDataPresent: false,
        resourceType: [],
        Author: [],
        filteredResourceType: [],
        filteredAuthor: [],
        filteredCurrentPosts: [],
        filteredActivePage: 1,
        updated: 1,
        value: '',
        sideBoxHeadings: [],
        sideBoxSubheadings: [],
        checkedValue: '',
        checked: true,
        checkBox: [],
        checkArray: null,
        activePage: 1,
        currentPosts: [],
        sideBoxDummyArray: null,
        FilteredArray: null,
        resultsPerPage: 10,
        searchLoading: true
    }

    searchAndGetResponse = async () => {

        let t1 = performance.now()
        let searchResponse = ""

        // let searchString = this.props.searchString
        let searchString = queryString.parse(this.props.location.search).query

        if (searchString !== "" && searchString !== undefined) {
            //console.log("### Calling search")
            let uri = serverUrl + '/api/search/'
            uri += '?str=' + searchString
            // uri += '&prpg=' + this.state.resultsPerPage
            uri += '&pg=0'    // SOUTBD: This index should change per page
            await axios.get(encodeURI(uri))
                .then(res => {
                    searchResponse = res.data.docs;
                    this.setState({ numFound: res.data.found })
                    if (res.data.docs !== undefined) {
                        this.setState({ searchLoading: false }, ()=>{console.log(this.state.searchLoading)})
                        var indexOfLastPost = this.state.activePage * this.state.resultsPerPage;
                        var indexOfFirstPost = indexOfLastPost - this.state.resultsPerPage;

                        var currentPosts = searchResponse.slice(indexOfFirstPost, indexOfLastPost);
                        this.setState({ docs: searchResponse, docsDataPresent: true, currentPosts: currentPosts })
                        console.log(this.state.docs, "search response")
                        console.log(this.state.currentPosts, "currentPosts")
                    }
                })
        }
        else {
            let blankList = []
            this.setState({ resultPageIndex: 0, docs: blankList })
        }
        let t2 = performance.now()
        let diff = t2 - t1
        console.log("time of execution in search(in ms): " + diff)
        
    }

    paginate = (page) => {
        const { docs } = this.state

        if (docs.length <= 0) return
        this.setState({ activePage: page })
        var indexOfLastPost = page * this.state.resultsPerPage;
        var indexOfFirstPost = indexOfLastPost - this.state.resultsPerPage;
        var currentPosts = docs.slice(indexOfFirstPost, indexOfLastPost);
        this.setState({ currentPosts: currentPosts })
    }

    filteredPaginate = (page) => {
        const { FilteredArray } = this.state

        if (FilteredArray.length <= 0) return
        this.setState({ filteredActivePage: page })
        var indexOfLastPost = page * this.state.resultsPerPage;
        var indexOfFirstPost = indexOfLastPost - this.state.resultsPerPage;
        var currentPosts = FilteredArray.slice(indexOfFirstPost, indexOfLastPost);
        this.setState({ filteredCurrentPosts: currentPosts })
    }

    componentDidUpdate(prevProps) {

        if (prevProps.searchString !== this.props.searchString) {
            this.setState({ activePage: 1, filteredActivePage: 1 })
            this.setState({ FilteredArray: [] })
            this.searchAndGetResponse()
        }
    }

    componentDidMount() {
        console.log(localStorage.getItem("searchLoading"));
        console.log("mounted")
        this.searchAndGetResponse();
        this.setState({ resourceType: [], Author: [], sideBoxHeadings: [] })
    }

    componentWillUnmount() {
        let blankList = []
        this.setState({ resultPageIndex: 0, docs: blankList })
    }

    myCallback = (datafromChild) => {
        this.setState({ FilteredArray: datafromChild });
        this.setState(prevState => ({ updated: prevState.updated + 1 }))
        if (datafromChild.length) {
            var indexOfLastPost = 1 * this.state.resultsPerPage;
            var indexOfFirstPost = indexOfLastPost - this.state.resultsPerPage;
            var currentPosts = datafromChild.slice(indexOfFirstPost, indexOfLastPost);
            this.setState({ filteredCurrentPosts: currentPosts, filteredActivePage: 1 })
        }
    }

    handleChange = (e) => {
        this.setState({ resultsPerPage: e.target.value })
        this.paginate(1);
        if (this.state.FilteredArray && this.state.FilteredArray.length > 0) {
            this.filteredPaginate(1);
        }

         console.log("prasanna "+this.state.currentPosts.author)
    }

    render() {
        const { docs, currentPosts, FilteredArray } = this.state;
        const totalPosts = docs.length;

        return (
                <div class="container-fluid">
                <div class="row">
                    <div class="filterBar col-xs-3 col-sm-2 " style={{height: '200%', width: '100%', paddingLeft:'5px', paddingRight:0}}>
                        <div>
                            {(this.state.docs && this.state.docs.length > 0) ? (
                                //this.renderSideFilter()
                                <Filter
                                    docs={this.state.docs}
                                    callbackFunction={this.myCallback}
                                    resourceType={this.state.resourceType}
                                    Author={this.state.Author}
                                    sideBoxHeadings={this.state.sideBoxHeadings}
                                    sideBoxSubheadings={this.state.sideBoxSubheadings}
                                    value={this.state.value} checkArray={this.state.checkArray}
                                    checked={this.state.checked} checkedValue={this.state.checkedValue}
                                    checkBox={this.state.checkBox}
                                    sideBoxDummyArray={this.state.sideBoxDummyArray} />
                            ) : ("")}
                        </div>
                    </div>
                    <div className="col-xs-9 col-sm-8" style={{paddingLeft:"0px", paddingRight:'0px'}}>
                        <div>
                            {(!this.state.searchLoading) ? 
                                (<div style={{height: '100%',width: '100%' }}>
                                    {(docs.length && docs.length > 0 && currentPosts.length && currentPosts.length > 0 && this.state.searchLoading === false) ?
                                        (
                                        <div class="container">
                                            {(FilteredArray === null || FilteredArray === [] || FilteredArray.length === 0) ?
                                                (
                                                    <div>
                                                        <div class="row" style={{display:'flex',justifyContent:'space-between', paddingLeft:'0.5%', paddingRight:'0.5%', marginBottom:"-8px"}}>
                                                            <div>
                                                                <Paginate total={totalPosts} type={"posts"} paginate={this.paginate} activePage={this.state.activePage} resultsPerPage={this.state.resultsPerPage} />
                                                            </div>
                                                            <div>
                                                                <Form style={{width:'auto'}}>
                                                                    <Form.Group align="center">
                                                                        <Form.Control id="form" as="select" size="sm" value={this.state.resultsPerPage} onChange={(e) => { this.handleChange(e) }} custom>
                                                                            <option id="first" value={5}>5 per page</option>
                                                                            <option id="default" value={10}>10 per page</option>
                                                                            <option value={25}>25 per page</option>
                                                                            <option id="last" value={50}>50 per page</option>
                                                                        </Form.Control>
                                                                    </Form.Group>
                                                                </Form>
                                                            </div>
                                                            
                                                        </div>
                                                        <div class="row results_box" style={{paddingLeft:'0.5%', paddingRight:'0.5%'}}>
                                                            <div><i class="fa fa-lg fa-info-circle" /> Total search results found: {this.state.numFound} &nbsp;</div>
                                                            <div>Books: &nbsp;</div>
                                                            <div>Articles: &nbsp;</div>
                                                            <div>Thesis: &nbsp;</div>
                                                            <div>Courses: &nbsp;</div>
                                                            <div>Course Offering: &nbsp;</div>
                                                            <div>Video Lecture: &nbsp;</div>
                                                            <div>Lecture Notes: &nbsp;</div>
                                                            <div>Presentation: &nbsp;</div>
                                                            <div>Q & A: &nbsp;</div>
                                                            <div>Dataset: &nbsp;</div>
                                                            <div>Software Library: &nbsp;</div>
                                                            <div>Software Platform: &nbsp;</div>
                                                            <div>Web Q & A: &nbsp;</div>
                                                            <div>Worksheet: &nbsp;</div>
                                                            <div>Forum: &nbsp;</div>
                                                        </div>
                                                       <div class="row" style={{paddingLeft:'0.7%', paddingRight:'0.7%'}}> 
                                                        <SearchResults currentPosts={this.state.currentPosts} />
                                                       </div> 
                                                        <div class="row" style={{display:'flex',justifyContent:'space-between', paddingLeft:'0.5%', paddingRight:'0.5%'}}>
                                                            <div>
                                                                <Paginate total={totalPosts} type={"posts"} paginate={this.paginate} activePage={this.state.activePage} resultsPerPage={this.state.resultsPerPage} />
                                                            </div>
                                                            <div>
                                                                <Form style={{width:'auto'}}>
                                                                    <Form.Group>
                                                                        <Form.Control id="form" as="select" size="sm" value={this.state.resultsPerPage} onChange={(e) => { this.handleChange(e) }} custom>
                                                                            <option id="first" value={5}>5 per page</option>
                                                                            <option id="default" value={10}>10 per page</option>
                                                                            <option value={25}>25 per page</option>
                                                                            <option id="last" value={50}>50 per page</option>
                                                                        </Form.Control>
                                                                    </Form.Group>
                                                                </Form>
                                                            </div>
                                                            
                                                        </div>
                                                    </div>
                                                )
                                                : (
                                                    <div class="">
                                                        
                                                        <div class="row" style={{display:'flex',justifyContent:'space-between', paddingLeft:'0.5%', paddingRight:'0.5%', marginBottom:"-8px"}}>
                                                            <div>
                                                                <Paginate total={FilteredArray.length} type={"filtered"} updated={this.state.updated} paginate={this.filteredPaginate} activePage={this.state.filteredActivePage} resultsPerPage={this.state.resultsPerPage} />
                                                            </div>
                                                            <div>
                                                                <Form style={{width:'auto'}}>
                                                                    <Form.Group >
                                                                        <Form.Control as="select" size="sm" value={this.state.resultsPerPage} onChange={(e) => { this.handleChange(e) }} custom>
                                                                            <option id="first" value={5}>5 per page</option>
                                                                            <option id="default" value={10}>10 per page</option>
                                                                            <option value={25}>25 per page</option>
                                                                            <option id="last" value={50}>50 per page</option>
                                                                        </Form.Control>
                                                                    </Form.Group>
                                                                </Form>
                                                            </div>
                                                        </div>
                                                        <div class="row results_box" style={{paddingLeft:'0.5%', paddingRight:'0.5%'}}>
                                                            <div><i class="fa fa-lg fa-info-circle" /> Total filtered results found: {FilteredArray.length} &nbsp;</div>
                                                            <div>Books: &nbsp;</div>
                                                            <div>Articles: &nbsp;</div>
                                                            <div>Thesis: &nbsp;</div>
                                                            <div>Courses: &nbsp;</div>
                                                            <div>Course Offering: &nbsp;</div>
                                                            <div>Video Lecture: &nbsp;</div>
                                                            <div>Lecture Notes: &nbsp;</div>
                                                            <div>Presentation: &nbsp;</div>
                                                            <div>Q & A: &nbsp;</div>
                                                            <div>Dataset: &nbsp;</div>
                                                            <div>Software Library: &nbsp;</div>
                                                            <div>Software Platform: &nbsp;</div>
                                                            <div>Web Q & A: &nbsp;</div>
                                                            <div>Worksheet: &nbsp;</div>
                                                            <div>Forum: &nbsp;</div>
                                                        </div>
                                                        
                                                       <div class="row" style={{paddingLeft:'0.7%', paddingRight:'0.7%'}}> 
                                                        <SearchResults currentPosts={this.state.filteredCurrentPosts} />
                                                       </div> 
                                                       
                                                        <div class="row" style={{display:'flex',justifyContent:'space-between', paddingLeft:'0.5%', paddingRight:'0.5%'}}>
                                                            <div>
                                                                <Paginate total={FilteredArray.length} type={"filtered"} updated={this.state.updated} paginate={this.filteredPaginate} activePage={this.state.filteredActivePage} resultsPerPage={this.state.resultsPerPage} />
                                                            </div>
                                                            <div>
                                                                <Form style={{width:'auto'}}>
                                                                    <Form.Group >
                                                                        <Form.Control as="select" size="sm" value={this.state.resultsPerPage} onChange={(e) => { this.handleChange(e) }} custom>
                                                                            <option id="first" value={5}>5 per page</option>
                                                                            <option id="default" value={10}>10 per page</option>
                                                                            <option value={25}>25 per page</option>
                                                                            <option id="last" value={50}>50 per page</option>
                                                                        </Form.Control>
                                                                    </Form.Group>
                                                                </Form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                )}
                                        </div>
                                    )
                                    : (
                                        <div>No results found.</div>
                                    )}

                            </div>) : (
                                        <div style={{overflow:'hidden', height:'81vh'}}><div style={{left: '50%', top:'40%',height: 'auto', width: 'auto', position:'relative'}}>
                                            <Row><img src = {loader} alt="Loading" /></Row>
                                            <Row style={{color:'teal' ,align:'center', fontWeight:'bold', paddingTop:'10px'}}>Searching...</Row>
                                        </div></div>
                                    )
                            }
                        </div>
                    </div>
                    <div className="col-md-2 col-sm-2 hidden-xs"></div>
                </div>

            </div>
        )
    }
};

export default withRouter(SearchResultPage)