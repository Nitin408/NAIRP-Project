import React from 'react';

class FormErrorCheck extends React.Component {
  constructor(props) {
    super();

    this.state = {
		course_title: ['The value has at least one word.', 'Word must contains more than 2 alphabets (not numbers) in it.', "Please make sure that the course title doesn't belong to any existing course."],
		course_short_name: ['The value has at least one word.', 'Word must contains more than 2 alphabets (not numbers) in it.', "Please make sure that the course short name doesn't belong to any existing course."],
		created_on: ["Please make sure date doesn't belong to future.", "Year must be greater than 2000."],
		offering_date:["Please make sure that from date must be greater than 01-01-2020.", "The from date must be less than To date"],
		credit: ["The course credit ust be an integer within range 0 to 10."],
		duration: ["This is to denote approximately how many minutes a learner has to spend to complete the course, including taking all its exercises.", "The course duration ust be an integer greater then equal to 1."],
		course_description: ["Description should not overshoot more than 1000 words.", "The file path provided here must be a path relative to this excel file's directory."],
		course_video: ["The file is at least 10 KB in size.", "Its extension is '.mp4'."],
		course_image: ["File type is '.jpg' or '.png'.", "Minimum height is 1080 pixels.", "Minimum width is 1920 pixels.", "Minimum size is 50KB."],
		prerequisite_preexisting_course: ["That there indeed exists courses in the NAIRP system with the given names."],
		prerequisite_knowledge_file: ["That the file is non-empty.", "File name ends with '.txt'."],
		reference_material_file: ["That the file is non-empty.", "File name ends with '.txt'.", "In every group of 4 lines from the top of the file:"], 
		reference_material_file2:["1st line is an integer serial number,", "2nd line is a name of the reference resource,", "3rd line is an accessible URL to the reference resource,", "4th line is a blank line."],
		copyright_message: ["The given file exists.", "The extension is '.txt'.", "The file is non-empty."],
		ins_name: ["Value contains only alphabets, dot (.), blank-space.", "Each word must be separated by blank-space.", "The first letter of each word is a capital letter."],
		ins_designation: [ "The file is non-empty.", "The file size is minimum 1 KB"],
		ins_profile: ["If the file is provided, it is non-empty.", "If the file is provided, the file size is minimum 1 KB."],
		module_title:["Each module title must be unique."],
		lec_title: ["Each module title must be unique."],
		lec_topic: ["Use maximum 5-6 words to describe the topic of the lecture."],
		lec_video: ["The file is at least 10 KB in size.", "File type is '.mp4'."],
		lec_note: ["The file is at least 10 KB in size.", "It's extension is '.pdf'."],
		lec_worksheet: ["The file is at least 1 KB in size.", "It's extension is '.ipynb' [openable by Jupyter Notebook App]"],
		concept: ["Value shouldn't be empty."],
		prog_mark: [ "This is the total marks of all problems in an entire Jupyter notebook.","Value is an integer.", "0 <= value <= 100"],
		prog_evufun: ["The file is at least 1 KB in size.","It's extension is '.py'."],
		prog_dataset: ["Each file is at least 1 KB in size."],
		obj_que_type: [ "Value is either 'mcq' or 'fillup'.", "Use 'mcq' for multiple choice questions.", "Use 'fillup' for fill-in-the-blanks questions."],
		obj_mcq_type: ["Value is either of the following: 'multichoice', 'singlechoice', 'none'.", "If question_type is 'mcq', value is either of 'multichoice' or 'singlechoice'.", "Use 'multichoice' when there are more than one correct answers.", "Use 'singlechoice' when there is one correct answer.", "If question_type is 'fillup', value is 'none'." ],
		obj_que_text: ["Value is non-empty.", "If question_type is 'fillup', value has exactly one '$$' or '$#' symbol (either one of these) contained in it.", "The '$$' or '$#' symbol should be used in place of 'blank' as should appear in the question.", "If question_type is 'mcq', value does not have any '$$' or '$#' symbol contained in it."],
		obj_que_choice: ["Value is non-empty.","Each pipe '|||' separated value is unique.", "If question_type is 'mcq', then number of pipe '|||' separated values are more than 1, but less than 5. ", "If question_type is 'fillup', then only single value is present without any pipe '|||' in it"],
		obj_que_answer: ["Value is non-empty.", "If multiple pipe '|||' separated values are provided, then each value is unique.", "If 'question_type' is 'mcq', then each value here matches exactly as one value from the list_of_choices.", "If 'question_type' is 'mcq', and 'mcq_type' is 'singlechoice', only single value is present without any pipe '|||'.", "If 'question_type' is 'mcq', and 'mcq_type' is 'multichoice', number of pipe '|||' separated values should be more than 1, but less than 5.", "If 'question_type' is 'fillup', value should be same as value of the column list_of_choices."],
		save: ["Once successfully saved then only Preview and Submit button will appear."]
	}

  }
  
  render() { 
		let fields = this.props.AllFeilds.common_fields;
        let errors = {};
        let formIsValid = this.props.AllFeilds.formIsValid;

        //course_title
       /* if(!fields["course_title"]){
            formIsValid = false;
            errors["course_title"] = "Can't be empty!";
        }
      
        if(typeof fields["course_title"] !== "undefined"){
			if(!fields["course_title"].match(/^[a-zA-Z]+$/)){
                formIsValid = false;
                errors["course_title"] = "Only letters are allowed!";
            }  
			else{
				let existing_course = this.state.existing_course;
				for (let j = 0; j<existing_course.length; j++){
					if(fields["course_title"].match(existing_course[j].course_title)){
						formIsValid = false;
						errors["course_title"] = "This course title's already present in our system!";
					}  
				}
			}
        }
		
		//course_title
        if(!fields["course_short_name"]){
            formIsValid = false;
            errors["course_short_name"] = "Can't be empty!";
        }
      
        if(typeof fields["course_short_name"] !== "undefined"){
			if(!fields["course_short_name"].match(/^[a-zA-Z]+$/)){
                formIsValid = false;
                errors["course_short_name"] = "Only letters are allowed!";
            }
			else if(!fields["course_short_name"].match(/^[A-Z]+$/)){
                formIsValid = false;
                errors["course_short_name"] = "Course Short Name must be capital letter!";
            }
			else if(fields["course_short_name"].length < 2){
                formIsValid = false;
                errors["course_short_name"] = "Course Short Name length must be >=  2!";
            }
			else{
				let existing_course = this.state.existing_course;
				for (let j = 0; j<existing_course.length; j++){
					if(fields["course_short_name"].match(existing_course[j].course_short_name)){
						formIsValid = false;
						errors["course_short_name"] = "This course short name's already present in our system!";
					}  
				}
			}
        }
        
		//communication_language
        if(!fields["communication_language"]){
            formIsValid = false;
            errors["communication_language"] = "Can't be empty!";
        }
      
        if(typeof fields["communication_language"] !== "undefined"){
			if( fields["communication_language"] === "Select.."){
                formIsValid = false;
                errors["communication_language"] = "Please select a valid Communication language!";
            }
        }
		
		
		//created_on
        if(!fields["created_on"]){
            formIsValid = false;
            errors["created_on"] = "Can't be empty!";
        }
      
        if(typeof fields["created_on"] !== "undefined"){
			let year = fields["created_on"].split('-')[0];
			if( year < 2000){
                formIsValid = false;
                errors["created_on"] = "Year is at least 2000!";
            }
			else if( year > 2020){
                formIsValid = false;
                errors["created_on"] = "Year is belongs to future!";
            }
        }
		//offering_period_from
        if(!fields["offering_period_from"] && this.state.fixed_offering_date === true){
            formIsValid = false;
            errors["offering_period_from"] = "Can't be empty!";
        }
      
        if(typeof fields["offering_period_from"] !== "undefined"  && this.state.fixed_offering_date === true){
			let year = fields["offering_period_from"].split('-')[0];
			if( year >= 2020){
                formIsValid = false;
                errors["offering_period_from"] = "Year can't be < 2020!";
            }
			
        }
		//offering_period_to
        if(!fields["offering_period_to"]  && this.state.fixed_offering_date === true){
            formIsValid = false;
            errors["offering_period_to"] = "Can't be empty!";
        }
      
        if(typeof fields["offering_period_to"] !== "undefined"  && this.state.fixed_offering_date === true){
			let year_to = fields["offering_period_to"].split('-')[0];
			let year_from = fields["offering_period_from"].split('-')[0];
			if( year_to >= 2020){
                formIsValid = false;
                errors["offering_period_to"] = "Year can't be < 2020!";
            }
			else if( year_to < year_from ){
                formIsValid = false;
                errors["offering_period_to"] = "To date can't be < From date!";
            }
			
        }
		//credit
        if(!fields["credit"]){
            formIsValid = false;
            errors["credit"] = "Can't be empty!";
        }
      
        if(typeof fields["credit"] !== "undefined"){
			
			if( fields["credit"] < 0 || fields["credit"] > 10){
                formIsValid = false;
                errors["credit"] = "Credit can't be > 10 and < 0!";
            }
			
        }
		//duration_in_min
        if(!fields["duration_in_min"]){
            formIsValid = false;
            errors["duration_in_min"] = "Can't be empty!";
        }
      
        if(typeof fields["duration_in_min"] !== "undefined"){
			if( fields["duration_in_min"] < 1){
                formIsValid = false;
                errors["duration_in_min"] = "Duration can't be < 1!";
            }
			
        }
		//course_description
        if(fields.course_description.length === 0 && this.state.custom_course_description === false){
            formIsValid = false;
            errors["course_description"] = "Can't be empty!";
			errors["course_description_text"] = "";
        }
      
        if(fields.course_description.length > 0 && this.state.custom_course_description === false){
			if( typeof fields["course_description"] !== "string"){
                formIsValid = false;
                errors["course_description"] = "It only accept path(string)!";
				errors["course_description_text"] = "";
            }
			let path = fields["course_description"].split('.')[1]
			if( path !== "txt"){
                formIsValid = false;
                errors["course_description"] = "Only .txt file are allowed!";
				errors["course_description_text"] = "";
            }
			
        }
		
		if(!fields["course_description_text"] && this.state.custom_course_description === true){
            formIsValid = false;
            errors["course_description_text"] = "Can't be empty!";
			errors["course_description"] = "";
        }
      
        if(typeof fields["course_description_text"] !== "undefined" && this.state.custom_course_description === true){
			if(!fields["course_description_text"].match(/^[a-zA-Z]+$/)){
                formIsValid = false;
				errors["course_description"] = "";
                errors["course_description_text"] = "Only letters are allowed!";
            }
        }
		
		//prerequisite_knowledge_file
      
        if(fields.prerequisite_knowledge_file.length > 0 && this.state.custom_prerequisite_knowledge_file === false){
			if( typeof fields["prerequisite_knowledge_file"] !== "string"){
                formIsValid = false;
                errors["prerequisite_knowledge_file"] = "It only accept path(string)!";
				errors["course_prerequisite_knowledge_file_text"] = "";
            }
			let path = fields["prerequisite_knowledge_file"].split('.')[1]
			if( path !== "txt"){
                formIsValid = false;
                errors["prerequisite_knowledge_file"] = "Only '.txt' file are allowed!";
				errors["course_prerequisite_knowledge_file_text"] = "";
            }
			
        }
      
        if(typeof fields["course_prerequisite_knowledge_file_text"] !== "undefined" && this.state.custom_prerequisite_knowledge_file === true){
			if(!fields["course_prerequisite_knowledge_file_text"].match(/^[a-zA-Z]+$/)){
                formIsValid = false;
				errors["prerequisite_knowledge_file"] = "";
                errors["course_prerequisite_knowledge_file_text"] = "Only letters are allowed!";
            }
        }
		//reference_material_file
      
        if(fields.reference_material_file.length > 0 && this.state.custom_reference_material_file === false){
			if( typeof fields["reference_material_file"] !== "string"){
                formIsValid = false;
                errors["reference_material_file"] = "It only accept path(string)!";
				errors["course_reference_material_file_text"] = "";
            }
			let path = fields["reference_material_file"].split('.')[1]
			if( path !== "txt"){
                formIsValid = false;
                errors["reference_material_file"] = "Only '.txt' file are allowed!";
				errors["course_reference_material_file_text"] = "";
            }
			
        }
      
        if(typeof fields["course_reference_material_file_text"] !== "undefined" && this.state.custom_reference_material_file === true){
			if(!fields["course_reference_material_file_text"].match(/^[a-zA-Z]+$/)){
                formIsValid = false;
				errors["reference_material_file"] = "";
                errors["course_reference_material_file_text"] = "Only letters are allowed!";
            }
        }
		
		
		//course_intro_video
        if(fields.course_intro_video.length === 0){
            formIsValid = false;
            errors["course_intro_video"] = "Can't be empty!";
        }
      
        if(fields.course_intro_video.length > 0){
			if( typeof fields["course_intro_video"] !== "string"){
                formIsValid = false;
                errors["course_intro_video"] = "It only accept path(string)!";
            }
			let path = fields["course_intro_video"].split('.')[1]
			console.log(path)
			if( path !== "mp4"){
                formIsValid = false;
                errors["course_intro_video"] = "Only .mp4 file are allowed to upload!";
            }
			
        }
		// course_advertisement_image
		if(fields.course_advertisement_image.length === 0){
            formIsValid = false;
            errors["course_advertisement_image"] = "Can't be empty!";
        }
      
        if(fields.course_advertisement_image.length > 0){
			if( typeof fields["course_advertisement_image"] !== "string"){
                formIsValid = false;
                errors["course_advertisement_image"] = "It only accept path(string)!";
            }
			/*
			let path = fields["course_advertisement_image"].split('.')[1]
			if( path !== "jpg" || path !== "png" || path !== "JPG"){
                formIsValid = false;
                errors["course_advertisement_image"] = "Only .jpg or .png file are allowed to upload!";
            }
			
			
        }
		// course_card_image
		if(fields.course_card_image.length === 0){
            formIsValid = false;
            errors["course_card_image"] = "Can't be empty!";
        }
      
        if(fields.course_card_image > 0){
			if( typeof fields["course_card_image"] !== "string"){
                formIsValid = false;
                errors["course_card_image"] = "It only accept path(string)!";
            }
			let path = fields["course_card_image"].split('.')[1]
			if( path !== "jpg" || path !== "png" || path !== "JPG"){
                formIsValid = false;
                errors["course_card_image"] = "Only .jpg or .png file are allowed to upload!";
            }
			
			
        }
		// copyright_message_file
		if(fields.copyright_message_file.length === 0){
            formIsValid = false;
            errors["copyright_message_file"] = "Can't be empty!";
        }
      
        if(fields.copyright_message_file.length > 0){
			if( typeof fields["copyright_message_file"] !== "string"){
                formIsValid = false;
                errors["copyright_message_file"] = "It only accept path(string)!";
            }
			let path = fields["copyright_message_file"].split('.')[1]
			if( path !== "txt"){
                formIsValid = false;
                errors["copyright_message_file"] = "Only '.txt' file are allowed!";
            }
			
			
        }*/
		// Module 
		
		let module = this.props.AllFeilds.module;
        let mod_errors = {};
		if(module.length === 0){
			console.log("module")
            formIsValid = false;
            mod_errors["no_data_on_module"] = "Course should have atleast one Module!";
        }
		
		if (module.length > 0){
			for (let i = 0; i<module.length; i++){
				/*if(module[i].module_title.length === 0){
					formIsValid = false;
					module[i]["error_in_title"] = "Can't be empty!";
				}
      
				if(module[i].module_title.length > 0){
					if(!module[i].module_title.match(/^[a-zA-Z]+$/)){
						formIsValid = false;
						module[i]["error_in_title"] = "Only letters are allowed!";
					}else{
						module[i]["error_in_title"] = "";
					}						
				}*/
				// lecture
				if(module[i].lecture.length === 0){
					console.log("module")
					formIsValid = false;
					module[i]["no_data_on_module_lecture"] = "Module should have Lecture details!";
				}
				if (module[i].lecture.length > 0){
					module[i]["no_data_on_module_lecture"] = "";
					for (let j = 0; j<module[i].lecture.length; j++){
						// title
						/*if(module[i].lecture[j].lecture_title.length === 0){
							formIsValid = false;
							module[i].lecture[j]["error_in_title"] = "Can't be empty!";
						}
      
						if(module[i].lecture[j].lecture_title.length > 0){
							if(!module[i].lecture[j].lecture_title.match(/^[a-zA-Z]+$/)){
								formIsValid = false;
								module[i].lecture[j]["error_in_title"] = "Only letters are allowed!";
							}else{
								module[i].lecture[j]["error_in_title"] = "";
							}						
						}
						// topic
						if(module[i].lecture[j].topic.length === 0){
							formIsValid = false;
							module[i].lecture[j]["error_in_topic"] = "Can't be empty!";
						}
      
						if(module[i].lecture[j].topic.length > 0){
							if(!module[i].lecture[j].topic.match(/^[a-zA-Z]+$/)){
								formIsValid = false;
								module[i].lecture[j]["error_in_topic"] = "Only letters are allowed!";
							}else{
								module[i].lecture[j]["error_in_topic"] = "";
							}						
						}
						// video
						if(module[i].lecture[j].lecture_video.length === 0){
							formIsValid = false;
							module[i].lecture[j]["error_in_video"] = "Can't be empty!";
						}
      
						if(module[i].lecture[j].lecture_video.length > 0){
							let path = module[i].lecture[j].lecture_video.split('.')[1]
							let c = 0;
							if( path !== "mp4"){
								formIsValid = false;
								module[i].lecture[j]["error_in_video"] = "Only '.mp4 ' file are allowed to upload!";
								c ++;
							}
							if (c === 0){
								if(module[i].lecture[j].lecture_video.size < 10240){
									formIsValid = false;
									module[i].lecture[j]["error_in_video"] = "File size <10 KB isn't allowed!";
								}else{
									module[i].lecture[j]["error_in_video"] = "";
								}
							}
													
						}
						if(module[i].lecture[j].lecture_note.length > 0){
							let path = module[i].lecture[j].lecture_note.split('.')[1]
							let c = 0;
							if( path !== "pdf"){
								formIsValid = false;
								module[i].lecture[j]["error_in_note"] = "Only '.pdf ' file are allowed to upload!";
								c ++;
							}
							if (c === 0){
								if(module[i].lecture[j].lecture_note.size < 10240){
									formIsValid = false;
									module[i].lecture[j]["error_in_note"] = "File size <10 KB isn't allowed!";
								}else{
									module[i].lecture[j]["error_in_note"] = "";
								}
							}
													
						}
      
						if(module[i].lecture[j].lecture_worksheet.length > 0){
							let path = module[i].lecture[j].lecture_worksheet.split('.')[1]
							let c = 0;
							if( path !== "ipynb"){
								formIsValid = false;
								module[i].lecture[j]["error_in_worksheet"] = "Only '.ipynb ' file are allowed to upload!";
								c ++;
							}
							if (c === 0){
								if(module[i].lecture[j].lecture_worksheet.size < 1024){
									formIsValid = false;
									module[i].lecture[j]["error_in_worksheet"] = "File size <1 KB isn't allowed!";
								}else{
									module[i].lecture[j]["error_in_worksheet"] = "";
								}
							}
													
						}*/
						/*if(module[i].lecture[j].concept.length === 0){
							console.log("module")
							formIsValid = false;
							module[i].lecture[j]["no_data_on_lecture_concept"] = "Lecture should have concept details!";
						}
						else{*/
							for (let g = 0; g<module[i].lecture[j].concept.length; g++){
								if(module[i].lecture[j].concept[g].existing_concept && module[i].lecture[j].concept[g].concept_text_checkbox === false){
									formIsValid = false;
									module[i].lecture[j].concept[g]["error_in_concept_text"] = "";
									module[i].lecture[j].concept[g]["error_in_existing_concept"] = "Can't be empty!";
								}
								if(!module[i].lecture[j].concept[g].concept_text && module[i].lecture[j].concept[g].concept_text_checkbox === true){
									formIsValid = false;
									module[i].lecture[j].concept[g]["error_in_concept_text"] = "Can't be empty!";
									module[i].lecture[j].concept[g]["error_in_existing_concept"] = "";
								}else if (typeof module[i].lecture[j].concept[g].concept_text !== "undefined" && module[i].lecture[j].concept[g].concept_text_checkbox === true ){
									if(!module[i].lecture[j].concept[g].concept_text.match(/^[a-zA-Z]+$/)){
										formIsValid = false;
										module[i].lecture[j].concept[g]["error_in_existing_concept"] = "";
										module[i].lecture[j].concept[g]["error_in_concept_text"] = "Only letters are allowed!";
									}
								}
							
							}
						//}
				}
				if (module[i].exercise.length > 0){
					for (let j = 0; j<module[i].exercise.length; j ++){
						/*if (module[i].exercise[j].obj_exercise.length > 0){
							for (let k = 0; j<module[i].exercise[j].obj_exercise.length; k ++){
								if( !module[i].exercise[j].obj_exercise[k]["question_type"]){
									formIsValid = false;
									module[i].exercise[j].obj_exercise[k]["error_in_question_type"] = "Please select a valid question type!";
								}else{
									module[i].exercise[j].obj_exercise[k]["error_in_question_type"] = "";
								}
								if(module[i].exercise[j].obj_exercise[k].obj_marks !== 0){
									formIsValid = false;
									module[i].exercise[j].obj_exercise[k]["error_in_obj_marks"] = "Can't be empty!";
								}
								if(module[i].exercise[j].obj_exercise[k].obj_marks> 0){
									if(module[i].exercise[j].obj_exercise[k].obj_marks < 0 || module[i].exercise[j].obj_exercise[k].obj_marks > 100){
										formIsValid = false;
										module[i].exercise[j].obj_exercise[k]["error_in_obj_marks"] = "Value must be >= 0 and <= 100!";
									}else{
										module[i].exercise[j].obj_exercise[k]["error_in_obj_marks"] = "";
									}
								}
								if(module[i].exercise[j].obj_exercise[k].question_text.length === 0){
									formIsValid = false;
									module[i].exercise[j].obj_exercise[k]["error_in_question_text"] = "Can't be empty!";
								}
								if(module[i].exercise[j].obj_exercise[k].question_text.length > 0){
									if(!module[i].exercise[j].obj_exercise[k].question_text.match(/^[a-zA-Z$#]+$/)){
										formIsValid = false;
										module[i].exercise[j].obj_exercise[k]["error_in_question_text"] = "Only letters and some special characters are allowed!";
									}else{
										module[i].exercise[j].obj_exercise[k]["error_in_question_text"] = "";
									}
								}
								
							}
						}*/
						/*if (module[i].exercise[j].prog_exercise.length > 0){
							for (let k = 0; j<module[i].exercise[j].prog_exercise.length; k ++){
								console.log(module[i].exercise[j].prog_exercise)
								if( module[i].exercise[j].prog_exercise[k]["prog_marks"] === ""){
									formIsValid = false;
									module[i].exercise[j].prog_exercise[k]["error_in_prog_marks"] = "Can't be empty!";
								}else{
									module[i].exercise[j].prog_exercise[k]["error_in_prog_marks"] = "";
								}
								
								if( module[i].exercise[j].prog_exercise[k].prog_worksheet.length === 0){
									formIsValid = false;
									module[i].exercise[j].prog_exercise[k]["error_in_worksheet"] = "Can't be empty!";
								}else if(module[i].exercise[j].prog_exercise[k].prog_worksheet.length > 0){
									let path = module[i].exercise[j].prog_exercise[k].prog_worksheet.split('.')[1]
									let c = 0;
									if( path !== "ipynb"){
										formIsValid = false;
										module[i].exercise[j].prog_exercise[k]["error_in_worksheet"] = "Only '.ipynb ' file are allowed to upload!";
										c ++;
									}
									if (c === 0){
										if(module[i].exercise[j].prog_exercise[k].prog_worksheet.size < 1024){
											formIsValid = false;
											module[i].exercise[j].prog_exercise[k]["error_in_worksheet"] = "File size <1 KB isn't allowed!";
										}else{
											module[i].exercise[j].prog_exercise[k]["error_in_worksheet"] = "";
										}
									}
													
								}
								
								
							}
						}*/
					}
				}
			}
			
		}
		}
		// Instructor 
		
		let instructor = this.props.AllFeilds.instructor;
        let ins_errors = {};
		/*if(instructor.length === 0){
            formIsValid = false;
            ins_errors["no_data_on_instructor"] = "Course should have atleast one Instructor!";
        }
		if(instructor.length > 0){
			for (let i=0; i<instructor.length; i++){
				if(instructor[i].instructor_name.length === 0){
					formIsValid = false;
					instructor[i]["error_in_name"] = "Can't be empty!";
				}
				else if(instructor[i].instructor_name.length > 0){
					let c = 0
					if (!instructor[i].instructor_name.match(/^[a-zA-Z. ]+$/)){
						formIsValid = false;
						instructor[i]["error_in_name"] = "Only letters and dots are allowed!";
						c ++;
					}
					if (c === 0){
						let name = instructor[i].instructor_name.split(' ')
						for (let i=0; i<name.length; i++){
							if(!name[i][0].match(/^[A-Z]+$/)){
								formIsValid = false;
								instructor[i]["error_in_name"] = "The first letter of each word must be in capital!";
								break
							}	
						}
					}
					
				}
				//// designation
				if( instructor[i].instructor_designation.length === 0 && instructor[i].instructor_designation_text_on === false){
						formIsValid = false;
						instructor[i]["error_in_designation"] = "Can't be empty!";
						instructor[i]["error_in_instructor_designation_text"] = "";
				}	
				else if (instructor[i].instructor_designation.length > 0 && instructor[i].instructor_designation_text_on === false){
					let path = instructor[i].instructor_designation.split('.')[1]
					console.log(path)
					let c = 0;
					if( path !== "txt"){
						formIsValid = false;
						instructor[i]["error_in_designation"] = "Only '.txt' file are allowed!";
						instructor[i]["error_in_instructor_designation_text"] = "";
						c ++;
					}
					if (c === 0){
						if(instructor[i].instructor_designation.size < 1024){
							formIsValid = false;
							instructor[i]["error_in_designation"] = "File size <1 KB isn't allowed!";
							instructor[i]["error_in_instructor_designation_text"] = "";
						}else{
							instructor[i]["error_in_designation"] = "";
							instructor[i]["error_in_instructor_designation_text"] = "";
						}
					}
				}
				
				if( instructor[i].instructor_designation_text.length === 0 && instructor[i].instructor_designation_text_on === true){
						formIsValid = false;
						instructor[i]["error_in_instructor_designation_text"] = "Can't be empty!";
						instructor[i]["error_in_designation"] = "";
				}	
				else if (instructor[i].instructor_designation_text.length > 0 && instructor[i].instructor_designation_text_on === true){
					if (!instructor[i].instructor_designation_text.match(/^[a-zA-Z. ]+$/)){
						formIsValid = false;
						instructor[i]["error_in_instructor_designation_text"] = "Only letters and dots are allowed!";
						instructor[i]["error_in_designation"] = "";
					}
				}
				
				// Profile
				if (instructor[i].instructor_profile.length > 0 && instructor[i].instructor_profile_text_on === false ){
					let path = instructor[i].instructor_profile.split('.')[1]
					console.log(path)
					let c = 0;
					if( path !== "txt"){
						formIsValid = false;
						instructor[i]["error_in_profile"] = "Only '.txt' file are allowed!";
						instructor[i]["error_in_instructor_profile_text"] = "";
						c ++;
					}
					if (c === 0){
						if(instructor[i].instructor_profile.size < 1024){
							formIsValid = false;
							instructor[i]["error_in_profile"] = "File size <1 KB isn't allowed!";
							instructor[i]["error_in_instructor_profile_text"] = "";
						}else{
							instructor[i]["error_in_profile"] = "";
							instructor[i]["error_in_instructor_profile_text"] = "";
						}
					}
				}
				
				if (instructor[i].instructor_profile_text.length > 0 && instructor[i].instructor_profile_text_on === true ){
					if (!instructor[i].instructor_profile_text.match(/^[a-zA-Z. ]+$/)){
						formIsValid = false;
						instructor[i]["error_in_instructor_profile_text"] = "Only letters and dots are allowed!";
						instructor[i]["error_in_profile"] = "";
					}
				}
				
				
			}
        }*/
        this.props.AllFeilds({errors: errors});
		this.props.AllFeilds({ins_errors: ins_errors});
		this.props.AllFeilds({mod_errors: mod_errors});
		this.props.AllFeilds({formIsValid: formIsValid});
        return formIsValid;
  }

}




export default FormErrorCheck;