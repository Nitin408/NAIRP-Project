import React from 'react';

let dialogstyle_course_title = {
	width: 'auto',
	height: 'auto',
	maxWidth: '100%',
	margin: '0 auto',
	position: 'fixed',
	left: '50%',
	top: '50%',
	transform: 'translate(-50%, -50%)',
	zIndex: '999',
	backgroundColor: '#eee',
	padding: '10px 20px 40px',
	borderRadius: '8px',
	display: 'flex',
	flexDirection: 'column'
};
/*let dialogstyle_created_on_from_to = {
	width: '500px',
	height: '250px',
	maxWidth: '100%',
	margin: '0 auto',
	position: 'fixed',
	left: '50%',
	top: '67.5%',
	transform: 'translate(-50%, -50%)',
	zIndex: '999',
	backgroundColor: '#eee',
	padding: '10px 20px 40px',
	borderRadius: '8px',
	display: 'flex',
	flexDirection: 'column'
};
let dialogstyle_credit_duration ={
	width: '500px',
	height: '190px',
	maxWidth: '100%',
	margin: '0 auto',
	position: 'fixed',
	left: '50%',
	top: '75%',
	transform: 'translate(-50%, -50%)',
	zIndex: '999',
	backgroundColor: '#eee',
	padding: '10px 20px 40px',
	borderRadius: '8px',
	display: 'flex',
	flexDirection: 'column'
};
let dialogClose = {
	marginBottom: '15px',
	padding: '3px 8px',
	curor: 'pointer',
	borderRadius: '50%',
	border: 'none',
	width: '30px',
	height: '30px',
	fontWeight: 'bold',
	alignSelf: 'flex-end'
}*/

class SimpleDialog extends React.Component {
  constructor(props) {
    super();

    this.state = {
		course_title: ['The value has at least one word.', 'Word must contains more than 2 alphabets (not numbers) in it.', "Please make sure that the course title is unique for this please refer to the list of existing course name."],
		course_short_name: ['The value has at least one word.', 'Word must contains more than 2 alphabets (not numbers) in it.', "Please make sure that the course short name is unique for this please refer to the list of existing course name."],
		created_on: ["Please make sure date doesn't belong to future.", "Year must be greater than 2000."],
		offering_date:["Please make sure that from date must be greater than 01-01-2020.", "The from date must be less than To date"],
		credit: ["The course credit ust be an integer within range 0 to 10."],
		duration: ["This is to denote approximately how many minutes a learner has to spend to complete the course, including taking all its exercises.", "The course duration ust be an integer greater then equal to 1."],
		course_description: ["Description should not overshoot more than 1000 words.", "The file path provided here must be a path relative to this excel file's directory."],
		course_video: ["The file is at least 10 KB in size.", "Its extension is '.mp4'."],
		course_image: ["File type is '.jpg' or '.png'.", "Minimum height is 1080 pixels.", "Minimum width is 1920 pixels.", "Minimum size is 50KB."],
		prerequisite_preexisting_course: ["That there indeed exists courses in the NAIRP system with the given names."],
		prerequisite_knowledge_file: ["That the file is non-empty.", "File name ends with '.txt'."],
		reference_material_file: ["That the file is non-empty.", "File name ends with '.txt'.", "In every group of 4 lines from the top of the file:"], 
		reference_material_file2:["1st line is an integer serial number,", "2nd line is a name of the reference resource,", "3rd line is an accessible URL to the reference resource,", "4th line is a blank line."],
		copyright_message: ["The given file exists.", "The extension is '.txt'.", "The file is non-empty."],
		ins_name: ["Value contains only alphabets, dot (.), blank-space.", "Each word must be separated by blank-space.", "The first letter of each word is a capital letter."],
		ins_designation: [ "The file is non-empty.", "The file size is minimum 1 KB"],
		ins_profile: ["If the file is provided, it is non-empty.", "If the file is provided, the file size is minimum 1 KB."],
		module_title:["Each module title must be unique."],
		lec_title: ["Each module title must be unique."],
		lec_topic: ["Use maximum 5-6 words to describe the topic of the lecture."],
		lec_video: ["The file is at least 10 KB in size.", "File type is '.mp4'."],
		lec_note: ["The file is at least 10 KB in size.", "It's extension is '.pdf'."],
		lec_worksheet: ["The file is at least 1 KB in size.", "It's extension is '.ipynb' [openable by Jupyter Notebook App]"],
		concept: ["Value shouldn't be empty."],
		prog_mark: [ "This is the total marks of all problems in an entire Jupyter notebook.","Value is an integer.", "0 <= value <= 100"],
		prog_evufun: ["The file is at least 1 KB in size.","It's extension is '.py'."],
		prog_dataset: ["Each file is at least 1 KB in size."],
		obj_que_type: [ "Value is either 'mcq' or 'fillup'.", "Use 'mcq' for multiple choice questions.", "Use 'fillup' for fill-in-the-blanks questions."],
		obj_mcq_type: ["Value is either of the following: 'multichoice', 'singlechoice', 'none'.", "If question_type is 'mcq', value is either of 'multichoice' or 'singlechoice'.", "Use 'multichoice' when there are more than one correct answers.", "Use 'singlechoice' when there is one correct answer.", "If question_type is 'fillup', value is 'none'." ],
		obj_que_text: ["Value is non-empty.", "If question_type is 'fillup', value has exactly one '$$' or '$#' symbol (either one of these) contained in it.", "The '$$' or '$#' symbol should be used in place of 'blank' as should appear in the question.", "If question_type is 'mcq', value does not have any '$$' or '$#' symbol contained in it."],
		obj_que_choice: ["Value is non-empty.","Each pipe '|||' separated value is unique.", "If question_type is 'mcq', then number of pipe '|||' separated values are more than 1, but less than 5. ", "If question_type is 'fillup', then only single value is present without any pipe '|||' in it"],
		obj_que_answer: ["Value is non-empty.", "If multiple pipe '|||' separated values are provided, then each value is unique.", "If 'question_type' is 'mcq', then each value here matches exactly as one value from the list_of_choices.", "If 'question_type' is 'mcq', and 'mcq_type' is 'singlechoice', only single value is present without any pipe '|||'.", "If 'question_type' is 'mcq', and 'mcq_type' is 'multichoice', number of pipe '|||' separated values should be more than 1, but less than 5.", "If 'question_type' is 'fillup', value should be same as value of the column list_of_choices."],
		save: ["Once successfully saved then only Preview and Submit button will appear."]
	}

  }
  
  render() { 
	let dialog
	if (this.props.target === 'course_title'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Title</div>
				<ul>
					{this.state.course_title.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'course_short_name'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Short name</div>
				<ul>
					{this.state.course_short_name.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'created_on'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Created On</div>
				<ul>
					{this.state.created_on.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'offering_period_from'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Offering Period From</div>
				<ul>
					{this.state.offering_date.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'offering_period_to'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Offering Period To</div>
				<ul>
					{this.state.offering_date.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'course_credit'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Credit</div>
				<ul>
					{this.state.credit.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'course_duration'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Duration</div>
				<ul>
					{this.state.duration.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'prerequisite_preexisting_course'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Prerequisite Preexisting Course</div>
				<ul>
					{this.state.prerequisite_preexisting_course.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'course_intro_video'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Introduction Video</div>
				<ul>
					{this.state.course_video.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'course_advertisement_image'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Advertisement Image</div>
				<ul>
					{this.state.course_image.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'course_card_image'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Card Image</div>
				<ul>
					{this.state.course_image.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'course_description'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Duration</div>
				<ul>
					{this.state.course_description.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'prerequisite_knowledge_file'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Duration</div>
				<ul>
					{this.state.prerequisite_knowledge_file.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'reference_material_file'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Duration</div>
				<ul>
					{this.state.reference_material_file.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				<ul>
					<ul>
						{this.state.reference_material_file2.map((a) => <li key = {a}>{a}</li>)}
					</ul>
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'copyright_message_file'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Course Duration</div>
				<ul>
					{this.state.copyright_message.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'instructor_name'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Instructor Name</div>
				<ul>
					{this.state.ins_name.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'instructor_designation'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Instructor Designation</div>
				<ul>
					{this.state.ins_designation.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'instructor_profile'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Instructor Profile</div>
				<ul>
					{this.state.ins_profile.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'module_title'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Module Title</div>
				<ul>
					{this.state.module_title.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'lecture_title'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Lecture Title</div>
				<ul>
					{this.state.lec_title.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'lecture_topic'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Lecture Topic</div>
				<ul>
					{this.state.lec_topic.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'lecture_note'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Lecture Note</div>
				<ul>
					{this.state.lec_note.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'lecture_video'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Lecture Video</div>
				<ul>
					{this.state.lec_video.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'lecture_worksheet'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Lecture Worksheet</div>
				<ul>
					{this.state.lec_worksheet.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'concept_text'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Concept Text</div>
				<ul>
					{this.state.concept.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'prog_marks'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Program Marks</div>
				<ul>
					{this.state.prog_mark.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'prog_worksheet'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Program Worksheet</div>
				<ul>
					{this.state.lec_worksheet.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'prog_evaluation_fn'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Program Evulation Function</div>
				<ul>
					{this.state.prog_evufun.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'prog_dataset'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Program Dataset</div>
				<ul>
					{this.state.prog_dataset.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'question_type'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Question Type</div>
				<ul>
					{this.state.obj_que_type.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'mcq_type'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>MCQ Type</div>
				<ul>
					{this.state.obj_mcq_type.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'obj_marks'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Marks</div>
				<ul>
					{this.state.prog_mark.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'question_text'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Question Text</div>
				<ul>
					{this.state.obj_que_text.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'obj_choices'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Question Choices</div>
				<ul>
					{this.state.obj_que_choice.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}else if (this.props.target === 'save'){
		dialog = (
			<div style={dialogstyle_course_title}>
				<div>Save</div>
				<ul>
					{this.state.save.map((a) => <li key = {a}>{a}</li>)}
				</ul>
				
			</div>
		)
	}
	
	
	if (! this.props.isOpen){
		dialog = null;
	}
    return (
		<div>
			{dialog}
		</div>	
    )
  }

}




export default SimpleDialog;