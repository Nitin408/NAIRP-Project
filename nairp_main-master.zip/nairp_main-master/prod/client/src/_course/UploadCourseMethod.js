import React from "react";
//import { Link } from "react-router-dom";
//import { /*Switch, Link*/ Route, withRouter } from "react-router-dom";
// import Container from "react-bootstrap/Container";
// import Row from "react-bootstrap/Row";
// import Col from "react-bootstrap/Col";
//import { connect } from 'react-redux'
//import axios from 'axios'
import Card from 'react-bootstrap/Card';
//import Form from "../../node_modules/react-bootstrap/Form";
//import Col from "../../node_modules/react-bootstrap/Col";
//import { Link } from "react-router-dom";
//import Button from "react-bootstrap/Button";
//export const jwt = localStorage.getItem("my-jwt");
//import UploadCourse from "./components/UploadCourse.js"
import jwt from 'jsonwebtoken';
import {serverUrl, JWT_SECRET_KEY} from '../clientMisc'

class UploadCourse_1 extends React.Component {
  constructor(props) {
    super();
	this.state = {
		userDetails: "",
		usersdetails: [],
		isLoggedIn: false,
		savedcoursepresent:false,
		fulluserdata: [],
		profession: ""
	}
  }
  
  async componentDidMount() {
	  
	  const JwtToken = localStorage.getItem("my-jwt");
	  if(JwtToken!=null){
			var userDetails =await jwt.verify(JwtToken, JWT_SECRET_KEY);
			this.setState({userDetails:userDetails.user});
			this.setState({isLoggedIn:true})
		}
		
		await fetch(serverUrl+'/get_save_user_data')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ usersdetails: Data });
					let user_id = this.state.userDetails["_id"];
	  				let usersdetails = this.state.usersdetails;
	  				if (usersdetails.length > 0){
						for (let i = 0; i<usersdetails.length; i++){
							if (usersdetails[i]["user_object_id"] === user_id){
								this.setState({savedcoursepresent : true})
							}
						}
	  				}
                })

            })
		.catch(error => {
            console.log(error);
		});

		await fetch(serverUrl+'/get_user_data_nairp_db')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ fulluserdata: Data });
					let user_id = this.state.userDetails["_id"];
	  				let user_data = this.state.fulluserdata;
					for (let i = 0; i<user_data.length; i++){
						if (user_data[i]._id === user_id){
							let profession = user_data[i].profession
							this.setState({ profession : profession})
						}
					}
                })

            })
		.catch(error => {
      		console.log(error);
    	});
		
	}
  
  	UploadNewCourse=()=>{ this.props.history.push(`/uploadCourse`, 'UploadNewCourse')}
  	LoadSavedCourse=()=>{this.props.history.push(`/uploadCourse`, 'LoadSavedCourse')}

  	render() {  
    return ( (this.state.profession === "Admin" && this.state.isLoggedIn === true) ?(
      <center >
        <div >
			<Card style={{ width: '90%', height: '100%' }}>
				<Card.Header className="text-center" > Upload Course </Card.Header>
				<Card.Body>
					<button className="btn btn-info" style={{ width: '15%'}} disabled={this.state.savedcoursepresent} onClick={this.UploadNewCourse}>Create New Course</button> {'\u00A0'}{'\u00A0'}
					<button className="btn btn-info " style={{ width: '15%'}} disabled={!this.state.savedcoursepresent} onClick={this.LoadSavedCourse}>Load Saved Course</button>
				</Card.Body>
			</Card>
			<br/>
        </div>
        <hr />

      </center>):(
	  	<center >
		  	<div>
	 	 		<Card style={{ width: '90%', height: '100%' }}>
		 		 	<Card.Body>
						<Card.Text>
		  					You are not an Admin user.
		  				</Card.Text>
		 	 		</Card.Body>
				</Card>
			</div>
		</center>
		)
    )
  }

}




export default UploadCourse_1;