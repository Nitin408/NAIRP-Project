import React from 'react'
import AWS from 'aws-sdk'
import {AwsConfigForCourseVideo} from '../../../clientMisc.js'
class ShowVideo extends React.Component{
    state={
        finalData:[],

    }
    componentDidMount(){
        AWS.config.update({
            region: AwsConfigForCourseVideo.region,
            endpoint: AwsConfigForCourseVideo.dynamodbEndpoint,
            accessKeyId: AwsConfigForCourseVideo.accessKeyId,
            secretAccessKey: AwsConfigForCourseVideo.secretAccessKey
          });
        let docClient = new AWS.DynamoDB.DocumentClient();
        var params = {
            TableName : AwsConfigForCourseVideo.tableName,//make it nairp_course
          
        };
        docClient.scan(params, ((err, data)=> {
            if (err) {
                alert("Couldn't fetch video details from AWS. Please try again!");
            } else {
                var dummyArray = [];
                data.Items.forEach(function(item) {
                    dummyArray.push(item);
                }
                
                );
                this.setState({finalData:dummyArray})
            }
        }));
    }
    render(){
        return (
        <table className="table table-bordered table-responsive">
            <thead>
                <tr>
                    <th>Video ID</th>
                    <th>Video Link</th>
                    <th>Video Name</th>
                </tr>
            </thead>
            <tbody>
                {this.state.finalData.map((arg)=>{
                    return (<tr>
                        <td>{arg.guid}</td>
                        <td><a href={arg.mp4Urls[0]}>{arg.mp4Urls[0]}</a></td>
                        <td>{arg.srcVideo}</td>
                    </tr>)
                })

                }
            </tbody>
        </table>
        );
}
};
export default ShowVideo