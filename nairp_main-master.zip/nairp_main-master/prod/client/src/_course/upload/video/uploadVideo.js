import React,{Component} from 'react'
import {AwsConfigForCourseVideo} from '../../../clientMisc.js'
class UploadVideo extends Component {

    render(){
      return (
        <div style={{textAlign:'center'}}>
          <meta httpEquiv="Content-Type" content="text/html; charset=UTF-8" />
          <form action={AwsConfigForCourseVideo.s3SourceBucketAddr} method="post" encType="multipart/form-data">
            {/*eslint-disable-next-line*/}
            <input type="hidden" name="key" defaultValue="${filename}" /><br />
            <input type="hidden" name="acl" defaultValue="public-read" />
            <input type="file" name="file" /> <br />
            {/* The elements after this will be ignored */}
            <input type="submit" name="submit" defaultValue="Upload to Amazon S3" />
          </form>
        </div>
      );
    }
    };
export default UploadVideo