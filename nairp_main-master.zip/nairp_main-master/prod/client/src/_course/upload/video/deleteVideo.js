import React from 'react'
import AWS from 'aws-sdk'
import {AwsConfigForCourseVideo} from '../../../clientMisc.js'
class DeleteVideo extends React.Component{
    state={
        finalData:[],
        value :'',
    }
    componentDidMount(){
        AWS.config.update({
            region: AwsConfigForCourseVideo.region,
            endpoint: AwsConfigForCourseVideo.dynamodbEndpoint,
            accessKeyId: AwsConfigForCourseVideo.accessKeyId,
            secretAccessKey: AwsConfigForCourseVideo.secretAccessKey
          });
        let docClient = new AWS.DynamoDB.DocumentClient();
        var params = {
            TableName : AwsConfigForCourseVideo.tableName,
          
        };
        docClient.scan(params, ((err, data)=> {
            if (err) {
                console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
            } else {
                console.log("Query succeeded.");
                var dummyArray = [];
                data.Items.forEach(function(item) {
                    dummyArray.push(item);
                    
                    
                }
                
                );
                this.setState({finalData:dummyArray})
          
            }
        }));
    }
    update = (id,change) =>{
        console.log(change)
        AWS.config.update({
            region: AwsConfigForCourseVideo.region,
            endpoint: AwsConfigForCourseVideo.dynamodbEndpoint,
            accessKeyId: AwsConfigForCourseVideo.accessKeyId,
            secretAccessKey: AwsConfigForCourseVideo.secretAccessKey
          });
        let docClient = new AWS.DynamoDB.DocumentClient();
        var params1 = {
            TableName:AwsConfigForCourseVideo.tableName,
            Key:{
                "guid": id,
            },
            UpdateExpression: "set srcVideo = :r",
            ExpressionAttributeValues:{
                ':r': change,
    },
        };
        
        docClient.update(params1, function(err, data) {
            if (err) {
              alert("Unable to update! Please try again");
              window.location.reload();
            } else {
                alert("Updated the name of the Video");
                window.location.reload();
            }
        });
        
    }
    delete = (id,name) =>{
        const result = window.confirm("Are you sure you want to delete the video?");
        if(result){
        AWS.config.update({
            region: AwsConfigForCourseVideo.region,
            endpoint: AwsConfigForCourseVideo.dynamodbEndpoint,
            accessKeyId: AwsConfigForCourseVideo.accessKeyId,
            secretAccessKey: AwsConfigForCourseVideo.secretAccessKey
          });
        let docClient = new AWS.DynamoDB.DocumentClient();
        var params2 = {
            TableName: AwsConfigForCourseVideo.tableName,
            Key:{
                "guid": id,
            },
        };
        
        docClient.delete(params2, function(err, data) {
            if (err) {
              alert("Couldn't delete the video. Please try again!");
              window.location.reload();
            } else {
                alert('Deleted object Successfully'); 
                window.location.reload();
            }
        });
    } 
    }
    render(){
        
       return (<table className="table table-bordered table-responsive">
            <thead>
                <tr>
                    <th>Video Name</th>
                    <th>Video Link</th>
                    {/* <th>Video Name</th> */}
                    <th>Update Status</th>
                    <th>Delete Video</th>
                </tr>
            </thead>
            <tbody>
                {this.state.finalData.map((arg)=>{
                    return (<tr>
                        <td><input type="text" placeholder={arg.srcVideo} name="name" onChange = {e => this.setState({value:e.target.value})}/>
                        </td>
                        <td><a href={arg.mp4Urls[0]}>{arg.mp4Urls[0]}</a></td>
                        
                        <td><button onClick={()=>{
                    this.update(arg.guid,this.state.value)
                  
                        }}>Click to Update</button></td>
                        <td><button onClick={()=>{
                    this.delete(arg.guid,arg.srcVideo)
                  
                        }}>Delete Video</button></td>
                    </tr>)
                })

                }
            </tbody>
        </table>);
    }
};
export default DeleteVideo