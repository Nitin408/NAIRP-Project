import React from "react";
import { Link } from "react-router-dom";
import { /*Switch, Link*/ Route, withRouter } from "react-router-dom";
// import Container from "react-bootstrap/Container";
// import Row from "react-bootstrap/Row";
// import Col from "react-bootstrap/Col";
import { connect } from 'react-redux'
import axios from 'axios'
import Card from 'react-bootstrap/Card';
import Form from "../../node_modules/react-bootstrap/Form";
import Col from "../../node_modules/react-bootstrap/Col";
import {serverUrl} from "../clientMisc.js"
//import { Link } from "react-router-dom";
//import Button from "react-bootstrap/Button";
//export const jwt = localStorage.getItem("my-jwt");

const ExistingCourse = []

class UploadCourse extends React.Component {
  constructor(props) {
    super();

    this.state = {
		courses: [],
		add_to_carousal: 'False',
		values: []
    }
	this.handleChange = this.handleChange.bind(this);

  }
  async componentDidMount() {
	  fetch(serverUrl+'/api/course/learn')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ courses: Data });
					console.log(this.state.courses)
                })

            })
		.catch(error => {
      console.log(error);
    });
  }
  createModuleUI(){
     return this.state.values.map((el, i) => 
		<center>
         <div key={i}>
			<Card style={{ width: '90%', height: '100%' }}>
				<Card.Body>
					<Form className="text-left">
						<Form.Row>
							<Form.Group as={Col} controlId="formBasicName">
								<Form.Label>Module Title</Form.Label>
								<Form.Control type="text"  onChange={this.handleChangeModule.bind(this, i)} name="module_title" placeholder="Like Pandas" />
								<Form.Text className="text-muted">
									Module title must be uniqe.
								</Form.Text>
							</Form.Group>
							<Form.Group as={Col} controlId="formBasicID">
								<Form.Label>Module ID</Form.Label>
								<Form.Control type="number"  onChange={this.handleChangeModule.bind(this, i)} name="module_id" placeholder="Like 1" />
								<Form.Text className="text-muted">
									Module ID must be uniqe.
								</Form.Text>
							</Form.Group>
						</Form.Row>
					</Form>
					<br/>
					<footer className="text-right">
						<button className="btn-info" style={{ width: '11%'}} onClick={this.removeClick.bind(this, i)}>Remove</button>
					</footer>
				</Card.Body>
			</Card>
    	    
         </div> 
		 <br/>
		 </center>         
     )
  }

  handleChangeModule(i, event) {
     let values = [...this.state.values];
     values[i] = event.target.value;
     this.setState({ values });
  }
  
  addClick(){
    this.setState(prevState => ({ values: [...prevState.values, '']}))
	console.log(this.state.values)
  }
  
  removeClick(i){
     let values = [...this.state.values];
     values.splice(i,1);
     this.setState({ values });
  }

  /*handleSubmit(event) {
    alert('A name was submitted: ' + this.state.values.join(', '));
    event.preventDefault();
  }*/

  Name=()=>{ console.log(this.state);}
  Next=()=>{ this.props.history.push(`/objectiveQuestion`, this.state)}
  Preview=()=>{
	  this.props.history.push(`/previewCourse`, this.state)}
  AddInstructor=()=>{}
  AddModule=()=>{}
  save=()=>{ console.log('yes') 
			axios
            .post(serverUrl+'/save_unsubmit_course_details', this.state)
            .then(res => {
              //console.log(res);
              //console.log(res.data);
              if (res.data.success === true) {
                // Success
                // alert(res.data.message);
                // this.props.history.push(`/login`);
                //this.props.history.push(`/verify_email`)
				console.log(res.data.data)
              } else {
                alert(res.data.message);
              }
            })
            .catch(function(error) {
              console.log(error);
              alert("Internal server error !");
            });
			}
  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value});
    event.preventDefault();

  }
  
  render() {  
		console.log(this.props);
    return (
      <center >
        <div >
			<Card style={{ width: '90%', height: '100%' }}>
				<Card.Header className="text-center" > Course Details </Card.Header>
				<Card.Body>
					<Form className="text-left">
						<Form.Row>
							<Form.Group as={Col} controlId="exampleForm.ControlSelect1">
								<Form.Label>Check Existing Courses Details</Form.Label>
								<Form.Control as="select" onChange={this.handleChange} name="existing_course_id">
									<option>See the existing courses..</option>
									{this.state.courses.map((course) => <option key={course.course_id}>ID: {course.course_id} Course Title: {course.course_title} Short Name: {course.course_short_name}</option>)}
								</Form.Control>
							</Form.Group>
						</Form.Row>
						<Form.Row>
							<Form.Group as={Col} controlId="formBasicName">
								<Form.Label>Course Title</Form.Label>
								<Form.Control type="text"  onChange={this.handleChange} name="course_title" placeholder="Like Artificial Intelligence" />
								<Form.Text className="text-muted">
									Course title must be uniqe.
								</Form.Text>
							</Form.Group>
							<Form.Group as={Col} controlId="formBasicName">
								<Form.Label>Course Short Name</Form.Label>
								<Form.Control type="text"  onChange={this.handleChange} name="course_short_name" placeholder="Like AI" />
								<Form.Text className="text-muted">
									Course short name must be uniqe.
								</Form.Text>
							</Form.Group>
						</Form.Row>
						
						<Form.Group controlId="formBasicFileUpload">
							<Form.Label>Course Description</Form.Label>
							<Form.File 
								id="custom-course_description"
								label="course_description.txt"
								custom
							/>
						</Form.Group>
						<Form.Group controlId="formBasicFileUpload">
							<Form.Label>Course intro video</Form.Label>	advertisement_image_file	
							<Form.File 
								id="custom-course_intro_video"
								label="course_intro_video.mp4"
								custom
							/>
						</Form.Group>
						<Form.Group controlId="formBasicFileUpload">
							<Form.Label>Course advertisement image</Form.Label>
							<Form.File 
								id="custom-course_advertisement_image"
								label="course_advertisement_image"
								custom
							/>
						</Form.Group>
						<Form.Group controlId="formBasicFileUpload">
							<Form.Label>Course card image</Form.Label>
							<Form.File 
								id="custom-course_card_image"
								label="course_card_image"
								custom
							/>
						</Form.Group>
						<Form.Group controlId="formBasicName">
							<Form.Label>prerequisite preexisting course name</Form.Label>
							<Form.Control type="text"  onChange={this.handleChange} name="prerequisite_preexisting_course_name" placeholder="Like Artificial Intelligence|||Machine Learning" />
							<Form.Text className="text-muted">
								sCourse name must be present in our system.
							</Form.Text>
						</Form.Group>
						<Form.Group controlId="formBasicFileUpload">
							<Form.Label>Prerequisite knowledge file</Form.Label>
							<Form.File 
								id="custom-prerequisite_knowledge_file"
								label="prerequisite_knowledge_file"
								custom
							/>
						</Form.Group>
						<Form.Row>
							<Form.Group as={Col} controlId="formBasicDate">
								<Form.Label>Created on</Form.Label>
								<Form.Control type="text"  onChange={this.handleChange} name="created_on" placeholder="not < 2000-01-01" />
							</Form.Group>
							<Form.Group as={Col} controlId="formBasicLanguage">
								<Form.Label>Communication language</Form.Label>
								<Form.Control type="text" onChange={this.handleChange} name="communication_language" placeholder="Like English" />
							</Form.Group>
						</Form.Row>
						<Form.Group controlId="formBasicFileUpload">
							<Form.Label>Reference material</Form.Label>
							<Form.File 
								id="custom-reference_material_file"
								label="reference_material_file"
								custom
							/>
						</Form.Group>
						<Form.Row>
							<Form.Group as={Col} controlId="formBasicCredit">
								<Form.Label>Course credit</Form.Label>
								<Form.Control type="number" onChange={this.handleChange} name="credit"  placeholder="Like 5" />
							</Form.Group>
							<Form.Group as={Col} controlId="formBasicDuration">
								<Form.Label>Course duration</Form.Label>
								<Form.Control type="time" onChange={this.handleChange} name="duration_in_min"  placeholder="Like 20:12:00" />
							</Form.Group>
							<Form.Group as={Col} controlId="formBasicDateLimit">
								<Form.Label>Course duration</Form.Label>
								<Form.Control type="text" onChange={this.handleChange} name="offering_period_from_to"  placeholder="Like 2019-02-25|||2020-12-31" />
							</Form.Group>
						</Form.Row>
						<Form.Group controlId="formBasicFileUpload">
							<Form.Label>Copyright message</Form.Label>
							<Form.File 
								id="custom-copyright_message_file"
								label="copyright_message_file"
								custom
							/>
						</Form.Group>
						<Form.Group controlId="formBasicSwitch">
							<Form.Check 
								type="switch"
								id="custom-switch"
								name="add_to_carousal"
								value="True"
								onChange={this.handleChange}
								label="add to carousal"
							/>
							<Form.Text className="text-muted">
								If you want to add it.
							</Form.Text>
						</Form.Group>
						{/*<Form.Group controlId="formBasicCheckbox">
							<Form.Check type="checkbox" label="Check me out" />
						</Form.Group>*/}
						<Form.Group>
							{this.createModuleUI()}        
							<input type='button' value='+ Module' onClick={this.addClick.bind(this)}/>
						</Form.Group>
						{/*<button className="btn btn-info" style={{ width: '11%'}} onClick={this.AddModule}>+ Module</button><br/><br/>
						
						<button className="btn btn-info" style={{ width: '11%'}} onClick={this.AddInstructor}>+ Instructor</button>*/}
					</Form>
					<br/>
					<footer>
						<button className="btn btn-info" type="save" style={{ width: '11%'}} onClick={this.save}>Save</button> {'\u00A0'}{'\u00A0'}
						<button className="btn btn-info " style={{ width: '11%'}} onClick={this.Next}>Next >></button>
					</footer>
				</Card.Body>
				
			</Card>
			<br/>
			<Link to="#" style={{ color: "white" }}><button className="btn btn-info"  style={{ width: '11%'}} onClick={this.Preview}>Preview</button></Link> {'\u00A0'}{'\u00A0'}
		    <Link to="#" style={{ color: "white" }}><button className="btn btn-info" style={{ width: '11%'}} onClick={this.Name}>Submit</button></Link> {'\u00A0'}{'\u00A0'}

          <span id="urlspan"></span>
        </div>
        <hr />

      </center>
    )
  }

}




export default UploadCourse;