import React from "react";
//import { Link } from "react-router-dom";
// import Container from "react-bootstrap/Container";
// import Row from "react-bootstrap/Row";
// import Col from "react-bootstrap/Col";
//import { connect } from 'react-redux'
//import Pdf from "react-to-pdf";
//import axios from 'axios'
import ReactPlayer from 'react-player'
import Card from 'react-bootstrap/Card';
import Table from 'react-bootstrap/Table';
//import Form from "../../node_modules/react-bootstrap/Form";
//import Col from "../../node_modules/react-bootstrap/Col";
import jwt from 'jsonwebtoken';
import {serverUrl, JWT_SECRET_KEY} from '../clientMisc'
import { BsFillShiftFill} from "react-icons/bs";
//import { Link } from "react-router-dom";
//import Button from "react-bootstrap/Button";
//export const jwt = localStorage.getItem("my-jwt");
//const ref = React.createRef();
import ScrollToTop from "react-scroll-up";

class PreviewCourse extends React.Component {
  constructor(props) {
    super();

    this.state = {
        courses:[],
        objexercise:[],
        progexercise:[],
        concept:[],
        existing_concept: [],
        userDetails: "", 
        usersdetails: [],
        courseobjectid: "",
        isLoggedIn: false,
        fulluserdata: [],
        profession: "",

    }
  }
  
  async componentDidMount() {
      
      const JwtToken = await localStorage.getItem("my-jwt");
      if(JwtToken!=null){
        var userDetails =await jwt.verify(JwtToken, JWT_SECRET_KEY);
        this.setState({userDetails:userDetails.user});
        this.setState({isLoggedIn:true})
    }
    
      
      await fetch(serverUrl+'/get_savecourses_data')
        .then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ courses: Data });
                })

            })
        .catch(error => {
      console.log(error);
    });
    await fetch(serverUrl+'/get_saveobjexercise_data')
        .then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ objexercise: Data });
                })

            })
        .catch(error => {
      console.log(error);
    });
    await fetch(serverUrl+'/get_saveprogexercise_data')
        .then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ progexercise: Data });
                })

            })
        .catch(error => {
      console.log(error);
    });
    await fetch(serverUrl+'/get_saveconcept_data')
        .then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ concept: Data });
                })

            })
        .catch(error => {
      console.log(error);
    });
    await fetch(serverUrl+'/get_concept')
        .then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ existing_concept: Data });
                })

            })
        .catch(error => {
      console.log(error);
    });
    await fetch(serverUrl+'/get_save_user_data')
        .then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ usersdetails: Data });
                    let user_id = this.state.userDetails["_id"];
                    let usersdetails = this.state.usersdetails;
                    for (let i = 0; i<usersdetails.length; i++){
                        if (usersdetails[i]["user_object_id"] === user_id){
                            this.state.courseobjectid = usersdetails[i]["course_object_id"]
                        }
                        else{
                            this.state.courseobjectid = null
                        }
                    }
                })

            })
        .catch(error => {
      console.log(error);
    });
    await fetch(serverUrl+'/get_user_data_nairp_db')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ fulluserdata: Data });
					let user_id = this.state.userDetails["_id"];
	  				let user_data = this.state.fulluserdata;
					for (let i = 0; i<user_data.length; i++){
						if (user_data[i]._id === user_id){
							let profession = user_data[i].profession
							this.setState({ profession : profession})
						}
					}
                })

            })
		.catch(error => {
      		console.log(error);
    	});
  }

  
  Back=()=>{this.props.history.push(`/uploadCourseMethod`)}
  
  forconcept=(e)=>{
     return this.state.existing_concept.map((concept) => (concept.concept_id === e || concept.concept_id === Number(e)) ?(
                <Card.Body>
                    <Card.Text className=" text-left">
                        Concept ID               :  {concept.concept_id}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Concept Text             :  {concept.concept_text}
                    </Card.Text>
                </Card.Body>
        )
     : (null))
  }
  forobjexercise=(e)=>{
      return this.state.objexercise.map((objexercise) => (objexercise.exercise_id === e || objexercise.exercise_id === Number(e)) ?(
                        <Card.Body>
                            <Card.Text className=" text-left">
                                Exercise ID              :  {objexercise.exercise_id}
                            </Card.Text>
                            <Card.Text className=" text-left">
                                Question             :  {objexercise.question_text}
                            </Card.Text>
                            <Card.Text className=" text-left">
                                Question Type        :  {objexercise.question_type}
                            </Card.Text>
                            <Card.Text className=" text-left">
                                MCQ Type         : {objexercise.mcq_type}
                            </Card.Text>
                            <Card.Subtitle style={{ fontWeight: 'bold' }} className="text-left">Choices : </Card.Subtitle>
                             {objexercise.list_of_choices.map((choice) =>
                                <Card.Body>
                                    <Card.Text className=" text-left">
                                        {choice}
                                    </Card.Text>
                                </Card.Body>
                             )}
                            <Card.Subtitle style={{ fontWeight: 'bold' }} className="text-left">Answer : </Card.Subtitle>
                             {objexercise.list_of_answers.map((answer) =>
                                <Card.Body >
                                    <Card.Text className=" text-left">
                                        {answer}
                                    </Card.Text>
                                </Card.Body>
                             )}
                            <Card.Subtitle style={{ fontWeight: 'bold' }} className="mb-2 text-muted text-left">Concepts : </Card.Subtitle>
                                {objexercise.concepts.map((id) =>
                                    <div>
                                        {this.forconcept(id)}
                                    </div>
                                )}
                            <Card.Text className=" text-left">
                                Mark :  {objexercise.marks}
                            </Card.Text>
                            <hr />
                        </Card.Body>
                        )
            : (null))       
  }
  forprogexercise=(e)=>{
      return this.state.progexercise.map((progexercise) => (progexercise.exercise_id === e || progexercise.exercise_id === Number(e)) ?(
            <Card.Body>
                            <Card.Text className=" text-left">
                                Exercise ID              :  {progexercise.exercise_id}
                            </Card.Text>
                            <Card.Text className=" text-left">
                                Program worksheet            :  {progexercise.worksheet}
                            </Card.Text>
                            <Card.Text className=" text-left">
                                Program Evalution Function       :  {progexercise.evaluation_fn}
                            </Card.Text>
                            <Card.Text className=" text-left">
                                Datasets     :   {progexercise.datasets}
                            </Card.Text>
                            <Card.Subtitle style={{ fontWeight: 'bold' }} className="mb-2 text-muted text-left">Concepts : </Card.Subtitle>
                                {progexercise.concepts.map((id) =>
                                    <div>
                                        {this.forconcept(id)}
                                    </div>
                                )}
                            <Card.Text className=" text-left">
                            Mark :  {progexercise.marks}
                            </Card.Text>
                            <hr />
                        </Card.Body>
        )
            : (null))       
  }
  
  render() {          
    return ((this.state.profession === "Admin" && this.state.isLoggedIn === true) ?(
      <center >
        <div >
            <Card style={{ width: '90%', height: '100%' }}>
                <Card.Header className="text-center" style={{ fontWeight: 'bold' }}> NAIRP Upload Course </Card.Header>
                <Card.Body>
                    {this.state.courses.map((courses) => <div>
                        {(courses._id === this.state.courseobjectid)?(
                    <Card.Body>
                        <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th colSpan="8" style={{ fontWeight: 'bold', width: '25%' }} className="mb-2 text-muted ">Course Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>add to carousal</td>
                                <td colSpan="6" className=" center">{String(courses.add_to_carousal)}</td>
                            </tr>
                            <tr>
                                <td>Course Title </td>
                                <td colSpan="1" className=" center">{courses.course_title}</td>
                                <td>Course Short Name</td>
                                <td colSpan="3" className=" center">{courses.course_short_name}</td>
                            </tr>
                            <tr>
                                <td>Created on</td>
                                <td className=" center">{courses.created_on}</td>
                                <td >From </td>
                                <td colSpan="1" className=" center">{courses.offering_period_from_to[0]}</td>
                                <td >To </td>
                                <td colSpan="1" className=" center">{courses.offering_period_from_to[1]}</td>
                            </tr>
                            <tr>
                                <td>Communication Language</td>
                                <td colSpan="1" className=" center">{courses.communication_language}</td>
                                <td colSpan="1">Credit</td>
                                <td className=" center">{courses.credit}</td>
                                <td colSpan="1">Duration in min </td>
                                <td className=" center">{courses.duration_in_min}</td>
                            </tr>
                            <tr>
                                <td>Card Image File</td>
                                <td style={{ width: '30%' }} className=" center"><Card.Img variant="top" src={courses.card_image_file} style={{ height: '10%', width: '50%' }} /></td>
                                <td style={{ width: '18%' }}>Advertisement Image File</td>
                                <td colSpan="3" className=" center"><Card.Img variant="top" src={courses.advertisement_image_file} style={{ height: '10%', width: '35%' }} /></td>
                            </tr>
                            <tr>
                                <td>Course Intro Video</td>
                                <td colSpan="6" className=" center"><ReactPlayer className="viewer" onReady={()=>console.log("ready")} onError={()=>{console.log("not ready")}} url={courses.course_intro_video} width="30%" height="30%" controls={true} />
                                </td>
                            </tr>
                            <tr>
                                <td>Prerequisite Preexisting Course Titles</td>
                                <td colSpan="6" className=" center">{courses.prerequisite_preexisting_course_title_list}</td>
                            </tr>
                            <tr>
                                <td>Course Description</td>
                                <td colSpan="6" className=" center">{courses.course_description}</td>
                            </tr>
                            <tr>
                                <td>Prerequisite Knowledge File</td>
                                <td colSpan="6" className=" center">{courses.prerequisite_knowledge_file}</td>
                            </tr>
                            
                            <tr>
                                <td>Reference Material File </td>
                                <td colSpan="6" className=" center">{courses.reference_material_file}</td>
                            </tr>
                            
                            <tr>
                                <td>Copyright Message </td>
                                <td colSpan="6" className=" center">{courses.copyright_message}</td>
                            </tr>
                        </tbody>
                    </Table>
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th colSpan="8" style={{ fontWeight: 'bold', width: '25%' }} className="mb-2 text-muted ">Module</th>
                            </tr>
                        </thead>
                        {courses.module.map((modules) =>
                        <tbody>
                            <tr>
                                <td>Module ID</td>
                                <td className=" center"> {modules.module_id}</td>
                                <td>Module Title</td>
                                <td colSpan="4" className=" center">{modules.module_title}</td>
                            </tr>
                            {modules.lecture.map((lectures) =>
                                <tr >
                                    <td>Lecture ID</td>
                                    <td className=" center"> {lectures.lecture_id}</td>
                                    <td>Lecture Title</td>
                                    <td className=" center">{lectures.lecture_title}</td>
                                    <td>Lecture Topic</td>
                                    <td  className=" center">{lectures.topic}</td>
                                </tr>
                                 
                            )}
                        </tbody>
                        )}
                    </Table>
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th colSpan="8" style={{ fontWeight: 'bold', width: '25%' }} className="mb-2 text-muted ">Instructor</th>
                                
                            </tr>
                        </thead>
                        {courses.instructor.map((instructors)=>
                        <tbody>
                            <tr>
                                <td>Instructor ID</td>
                                <td className=" center">{instructors.id}</td>
                                <td>Instructor Name</td>
                                <td colSpan="4" className=" center">{instructors.name}</td>
                            </tr>
                            <tr>
                                <td>Instructor Profile</td>
                                <td colSpan="6" className=" center">{instructors.profile}</td>
                            </tr>
                            <tr>
                                <td>Instructor Designation</td>
                                <td colSpan="6" className=" center">{instructors.designation}</td>
                            </tr>
                        </tbody>
                        )}
                    </Table>
                    {/*
                                        <Card.Subtitle style={{ fontWeight: 'bold' }} className="mb-2 text-muted text-left">Course Details : </Card.Subtitle>
<Card.Text  className="  text-left">
                        add to carousal          :  {String(courses.add_to_carousal)}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Course ID                :  {this.state.courses._id}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Course Title             :  {courses.course_title}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Course Short Name        :  {courses.course_short_name}
                    </Card.Text>
                     {<div><Card.Text className=" text-left">
                        Card Image File          :{'\u00A0'}{'\u00A0'}{'\u00A0'}{'\u00A0'}{'\u00A0'}{'\u00A0'}
                            <Card.Img variant="top" src={courses.card_image_file} style={{ height: '10%', width: '10%' }} />
                        </Card.Text>
                        </div>}<br />
                     {<div><Card.Text className=" text-left">
                        Advertisement Image File :{'\u00A0'}{'\u00A0'}{'\u00A0'}{'\u00A0'}{'\u00A0'}{'\u00A0'}
                            <Card.Img variant="top" src={courses.advertisement_image_file} style={{ height: '10%', width: '10%' }} />
                            </Card.Text>
                    </div>}
                    <Card.Text className=" text-left">
                        Course Description       : {courses.course_description}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Course Intro Video       : {'\u00A0'}{'\u00A0'}{'\u00A0'}
                        <ReactPlayer className="viewer" onReady={()=>console.log("ready")} onError={()=>{console.log("not ready")}} url={courses.course_intro_video} width="30%" height="20%" controls={true} />
                        
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Prerequisite Preexisting Course Titles :    {courses.prerequisite_preexisting_course_title_list}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Prerequisite Knowledge File                : {courses.prerequisite_knowledge_file}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Created on           :  {courses.created_on}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Communication Language           :  {courses.communication_language}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Reference Material File          : {courses.reference_material_file}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Credit           :  {courses.credit}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Duration in min          :  {courses.duration_in_min}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Offering Period From     :  {courses.offering_period_from_to[0]} {'\u00A0'}{'\u00A0'} To : {courses.offering_period_from_to[1]}
                    </Card.Text>
                    <Card.Text className=" text-left">
                        Copyright Message            : {courses.copyright_message}
                    </Card.Text>
                    <hr />*/}
                    {/*<Card.Subtitle style={{ fontWeight: 'bold' }} className="mb-2 text-muted text-left">Module : </Card.Subtitle>
                    
                        {courses.module.map((modules) =>
                            <Card.Body key={modules.module_id}>*/}
                               {/*} <Card.Text className=" text-left">
                                    Module ID                :  {modules.module_id}
                                </Card.Text>
                                <Card.Text className=" text-left">
                                    Module Title                 :  {modules.module_title}
                                </Card.Text>*/}
                                {/*<Card.Subtitle style={{ fontWeight: 'bold' }} className="mb-2 text-muted text-left">Lecture : </Card.Subtitle>
                                    {modules.lecture.map((lectures) =>
                                        <Card.Body key={lectures.lecture_id}>
                                            <Card.Text className=" text-left">
                                                Lecture ID               :  {lectures.lecture_id}
                                            </Card.Text>
                                            <Card.Text className=" text-left">
                                                Lecture Title                :  {lectures.lecture_title}
                                            </Card.Text>
                                            <Card.Text className=" text-left">
                                                Lecture Topic                :  {lectures.topic}
                                            </Card.Text>
                                            <Card.Text className=" text-left">
                                                Lecture Video                :  {<div className="video" style={{ width: '30%', height: '20%' }}>
                                                        <ReactPlayer className="viewer" onReady={()=>console.log("ready")} onError={()=>{console.log("not ready")}} url={lectures.lecture_video} width="100%" height="100%" controls={true} />
                                                    </div>}
                                            </Card.Text>
                                            <Card.Text className=" text-left">
                                                Lecture Note                 :  {lectures.lecture_note}
                                            </Card.Text>
                                            <Card.Text className=" text-left">
                                                Lecture Worksheets                :  
												{lectures.worksheets !== null ? (lectures.worksheets.map((worksheet) =>
													<div>
													<Card.Body>
															<Card.Text className=" text-left">
																Worksheet ID	: {worksheet.worksheet_id}
															</Card.Text>
															<Card.Text className=" text-left">
																Worksheet 		:  {worksheet.worksheet}
															</Card.Text>
                                                            <Card.Text className=" text-left">
                                                                Datasets                :  
												                {worksheet.datasets !== null ? (worksheet.datasets.map((dataset) =>
													            <div>
													                <Card.Body>
															            <Card.Text className=" text-left">
																            {dataset}
															            </Card.Text>
														            </Card.Body>
													            </div>
												                )): null }
                                                            </Card.Text>
														</Card.Body>
													</div>
												)): null }
                                            </Card.Text>
                                            <Card.Subtitle style={{ fontWeight: 'bold' }} className="mb-2 text-muted text-left">Concept : </Card.Subtitle>
                                            {lectures.concepts.map((id) =>
                                                <div>
                                                    {this.forconcept(id)}
                                                </div>
                                            )}
                                            <hr />
                                        </Card.Body>
                                    
                                    )}
                                <Card.Subtitle style={{ fontWeight: 'bold' }} className="mb-2 text-muted text-left">Exercise : </Card.Subtitle>
                                    {(modules.exercise === null)?(null):(
                                        <div>
                                            {modules.exercise.map((exercises)=>
                                                <div>
                                                    {(exercises.exercise_type === "objectiveExercise")?(<div>{this.forobjexercise(exercises.exercise_id)}</div>):(<div>{this.forprogexercise(exercises.exercise_id)}</div>)}
                                                </div>
                                    )}
                                        </div>
                                    )}
                            </Card.Body>
                        )}                      
                    {/*<Card.Subtitle style={{ fontWeight: 'bold' }} className="mb-2 text-muted text-left">Instructor : </Card.Subtitle>
                        {courses.instructor.map((instructors)=>
                            <Card.Body key={instructors.id}>
                                <Card.Text className=" text-left">
                                    Instructor ID                :  {instructors.id}
                                </Card.Text>
                                <Card.Text className=" text-left">
                                    Instructor Name              :  {instructors.name}
                                </Card.Text>
                                <Card.Text className=" text-left">
                                    Instructor Profile               :  {instructors.profile}
                                </Card.Text>
                                <Card.Text className=" text-left">
                                    Instructor Designation               :  {instructors.designation}
                                </Card.Text>
                            </Card.Body>
                        )}*/}
                    
                    </Card.Body>
                        ):(null)}
                    </div>
                    )}
                    
                </Card.Body>
            </Card>
            <ScrollToTop showUnder={160}>
  				<BsFillShiftFill className=" btn-info " style={{fontSize:40}} />
			</ScrollToTop>
            <br/>
            <button className="btn btn-info"  style={{ width: '11%'}} onClick={this.Back}>Back</button> {'\u00A0'}{'\u00A0'}
                {/*<Pdf targetRef={ref} filename="Course_data.pdf"  >
                {({ toPdf }) => <button className="btn btn-info"  style={{ width: '11%'}} onClick={toPdf}>Download</button>}
                </Pdf>*/}
        </div>
        <hr />

      </center>):(
	  	<center >
		  	<div>
	 	 		<Card style={{ width: '90%', height: '100%' }}>
		 		 	<Card.Body>
						<Card.Text>
		  					You are not an Admin user.
		  				</Card.Text>
		 	 		</Card.Body>
				</Card>
			</div>
		</center>
		)
    )
  }
  

}




export default PreviewCourse;
