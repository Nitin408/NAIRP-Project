import React from "react";
//import { Link } from "react-router-dom";
//import { /*Switch, Link*/ Route, withRouter } from "react-router-dom";
// import Container from "react-bootstrap/Container";
// import Row from "react-bootstrap/Row";
// import Col from "react-bootstrap/Col";
//import { connect } from 'react-redux'
import axios from 'axios'
import jwt from 'jsonwebtoken';
import {serverUrl, JWT_SECRET_KEY, AwsConfigForUploadCourseDetails} from '../clientMisc'
import Card from 'react-bootstrap/Card';
import Form from "../../node_modules/react-bootstrap/Form";
import Col from "../../node_modules/react-bootstrap/Col";
//import { green, grey } from '@material-ui/core/colors';
import { BsFillStarFill, BsQuestionCircleFill, BsFillTrashFill , BsFillShiftFill, BsController} from "react-icons/bs";
import Select from 'react-virtualized-select';
import createFilterOptions from 'react-select-fast-filter-options';
import 'react-select/dist/react-select.css';
import 'react-virtualized/styles.css'
import 'react-virtualized-select/styles.css'
//import { Link } from "react-router-dom";
//import Button from "react-bootstrap/Button";
//export const jwt = localStorage.getItem("my-jwt");
// import ObjectiveQuestion from "./components/ObjectiveQuestion.js"
// import ProgramExerciseQuestion from "./components/ProgramExerciseQuestion.js"
import DatePicker from "react-datepicker";
import 'react-datepicker/dist/react-datepicker.css';
import ScrollToTop from "react-scroll-up";
import SimpleDialog from "./components/SimpleDialog.js";
//import FormErrorCheck from "./components/FormErrorCheck.js"
const AWS = require('aws-sdk');

// Enter copied or downloaded access ID and secret key here

const ID = AwsConfigForUploadCourseDetails.accessKeyId;
const SECRET = AwsConfigForUploadCourseDetails.secretAccessKey;

// The name of the bucket that you have created
const BUCKET_NAME = AwsConfigForUploadCourseDetails.s3BucketName;
// here we create a communication with AWS S3
const s3 = new AWS.S3({
    accessKeyId: ID,
    secretAccessKey: SECRET,
	region: 'ap-south-1'
});


class UploadCourse extends React.Component {
  constructor(props) {
    super();

    this.state = {
		common_fields: {
			created_on: null,
			course_advertisement_image: "",
			course_advertisement_image_actual:"",
			course_card_image: "",
			course_card_image_actual: "",
			course_intro_video: "",
			course_intro_video_actual: "",
			course_description: "",
			course_description_actual: "",
			prerequisite_knowledge_file: "",
			prerequisite_knowledge_file_actual: "",
			reference_material_file: "",
			reference_material_file_actual: "",
			copyright_message_file: "",
			copyright_message_file_actual: "",
			offering_period_from: null,
			offering_period_to: null,
			offering_period__from_to: "",
		},
		existing_course: [],
		existing_concept: [],
		concept_data: [],
		existing_objexercise: [],
		existing_progexercise: [],
		user: [],
		user_saved_course:[],
		save_courses : [],
		save_concepts: [],
		save_objexercise: [],
		save_progexercise: [],
		module:[],
		final_course: [],
		final_module:[],
		final_lecture: [],
		final_worked_out_worksheet: [],
		instructor:[],
		prerequisite_preexisting_course: [],
		errors: [],
		mod_errors: [],
		ins_errors: [],
		final_exercise: [],
		final_obj_exercise: [],
		final_prog_exercise: [],
		final_concept: [],
		final_instructor: [],
		fixed_offering_date: false,
		isOpenSave: false,
		isOpen: false,
		isOpenShortName: false,
		isOpenCreatedOn: false,
		isOpenFromDate: false,
		isOpenToDate: false,
		isOpenCredit: false,
		isOpenDuration: false,
		isOpenCourseVideo: false,
		isOpenCourseAdvertiseentImage: false,
		isOpenCourseCardImage: false,
		isOpenCourseDescription: false,
		isOpenCoursePrerequisitePrexistingCourse: false,
		isOpenCoursePrerequisiteKnowledgeFile: false,
		isOpenCourseReferenceMaterialFile: false,
		isOpenCourseCopyRightMessage: false,
		isOpenModuleTitle: false,
		isOpenLectureTitle: false,
		isOpenLectureTopic: false,
		isOpenLectureVideo: false,
		isOpenLectureNote: false,
		isOpenLectureWorksheet: false,
		isOpenConceptText: false,
		isOpenProgMark: false,
		isOpenProgWorksheet: false,
		isOpenProgEvuFun: false,
		isOpenInstructorName: false,
		isOpenInstructorDesignation: false,
		isOpenInstructorProfile: false,
		custom_course_description: false,
		custom_course_prerequisite_knowledge_file: false,
		custom_reference_material_file: false,
		custom_copyright_message_file: false,
		form_submitted: false,
		usersdetails: "",
		saveusersDetails: [],
		courseobjectid: null,
		savecourse: false,
		finalarraysubmission: false,
		formIsValid: true,
		fulluserdata: [],
		profession: "",
		isLoggedIn: false

    }
	
	this.handleChange = this.handleChange.bind(this);

  }
  async componentDidMount() {
	   await fetch(serverUrl+'/api/course/learn')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ existing_course: Data });
                })

            })
		.catch(error => {
      console.log(error);
    });
	 await fetch(serverUrl+'/get_concept')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let concept_data = this.state.concept_data;
					let Data = [];
                    for (let i in result) {
						Data.push(result[i]);
                        concept_data.push({"label" : result[i].concept_text.trim(), "value" : result[i].concept_text.trim().split(' ')[0]});
                    }
					
                    this.setState({ existing_concept: Data });
					this.setState({ concept_data : concept_data})
                })

            })
		.catch(error => {
      console.log(error);
    });
	await fetch(serverUrl+'/get_objectexercise')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ existing_objexercise: Data });
                })

            })
		.catch(error => {
      console.log(error);
    });
	await fetch(serverUrl+'/get_progexercise')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ existing_progexercise: Data });
                })

            })
		.catch(error => {
      console.log(error);
    });
	await fetch(serverUrl+'/get_savecourses_data')
        .then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ save_courses: Data });
                })

            })
        .catch(error => {
      console.log(error);
    });
	if(this.props.history.location.state === "LoadSavedCourse"){
	await fetch(serverUrl+'/get_save_user_data')
        .then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ saveusersDetails: Data });
                })

            })
        .catch(error => {
      console.log(error);
    });
	}
	await fetch(serverUrl+'/get_saveconcept_data')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let concept_data = this.state.concept_data;
                    let Data = [];
                    for (let i in result) {
						Data.push(result[i]);
                        concept_data.push({"label" : result[i].concept_text.trim(), "value" : result[i].concept_text.trim().split(' ')[0]});
                    }
                    this.setState({ save_concepts: Data });
					this.setState({ concept_data: concept_data });
                })

            })
		.catch(error => {
      console.log(error);
    });
	await fetch(serverUrl+'/get_saveobjexercise_data')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ save_objexercise: Data });
                })

            })
		.catch(error => {
      console.log(error);
    });
	await fetch(serverUrl+'/get_saveprogexercise_data')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ save_progexercise: Data });
                })

            })
		.catch(error => {
      console.log(error);
    });
	
	const JwtToken = localStorage.getItem("my-jwt");
	  let usersdetails = this.state.usersdetails;
	  if(JwtToken!=null){
        var user =await jwt.verify(JwtToken, JWT_SECRET_KEY);
        usersdetails = user.user;
		this.setState({usersdetails : usersdetails})
		this.setState({isLoggedIn:true})
    }
    await fetch(serverUrl+'/get_user_data_nairp_db')
		.then( (response) => {
                let jsonStr = response.json();
                jsonStr.then((result) => {
                    let Data = [];
                    for (let i in result) {
                        Data.push(result[i]);
                    }
                    this.setState({ fulluserdata: Data });
					let user_id = this.state.usersdetails["_id"];
	  				let user_data = this.state.fulluserdata;
					for (let i = 0; i<user_data.length; i++){
						if (user_data[i]._id === user_id){
							let profession = user_data[i].profession
							this.setState({ profession : profession})
						}
					}
                })

            })
		.catch(error => {
      		console.log(error);
    	});
	  
	
	if(this.props.history.location.state === "LoadSavedCourse"){
		let user_id = this.state.usersdetails["_id"];
		let usersdetails = this.state.saveusersDetails;
		let courseobjectid = this.state.courseobjectid
		for (let i = 0; i<usersdetails.length; i++){
          if (usersdetails[i]["user_object_id"] === user_id){
            courseobjectid = usersdetails[i]["course_object_id"]
          }
		}
		
		let savecourse = this.state.save_courses;
		let save_concepts = this.state.save_concepts;
		for (let i = 0; i<savecourse.length; i++){
			if (savecourse[i]._id === courseobjectid ){
				let common_fields = this.state.common_fields;
				let prerequisite_preexisting_course = this.state.prerequisite_preexisting_course;
				common_fields.course_title = savecourse[i].course_title
				common_fields.course_short_name = savecourse[i].course_short_name
				common_fields.communication_language = savecourse[i].communication_language
				//common_fields.created_on = savecourse[i].created_on
				common_fields.credit = parseInt(savecourse[i].credit)
				common_fields.duration_in_min = savecourse[i].duration_in_min
				if (savecourse[i].add_to_carousal === 'true'){
					common_fields.add_to_carousal = 'on'
				}
				if (savecourse[i].prerequisite_preexisting_course_title_list.length>0){
					for(let j = 0; j<savecourse[i].prerequisite_preexisting_course_title_list.length; j++){
						let preexisting_course_data;
						preexisting_course_data = {course_title_name: savecourse[i].prerequisite_preexisting_course_title_list[j]}
						prerequisite_preexisting_course.push(preexisting_course_data)
					}
				}
				common_fields.course_intro_video = savecourse[i].course_intro_video.split('/').slice(-1)
				common_fields.course_intro_video_actual = savecourse[i].course_intro_video
				common_fields.course_advertisement_image = savecourse[i].advertisement_image_file.split('/').slice(-1)
				common_fields.course_advertisement_image_actual = savecourse[i].advertisement_image_file
				common_fields.course_card_image = savecourse[i].card_image_file.split('/').slice(-1)
				common_fields.course_card_image_actual = savecourse[i].card_image_file
				common_fields.reference_material_file = savecourse[i].reference_material_file.split('/').slice(-1)
				common_fields.reference_material_file_actual = savecourse[i].reference_material_file
				common_fields.course_description = savecourse[i].course_description.split('/').slice(-1)
				common_fields.course_description_actual = savecourse[i].course_description
				common_fields.copyright_message_file = savecourse[i].copyright_message.split('/').slice(-1)
				common_fields.course_description_actual =  savecourse[i].copyright_message
				common_fields.prerequisite_knowledge_file = savecourse[i].prerequisite_knowledge_file.split('/').slice(-1)
				let module = this.state.module;
				let instructor = this.state.instructor;
				let save_progexercise = this.state.save_progexercise;
				let save_objexercise = this.state.save_objexercise;
				for (let j = 0; j<savecourse[i].module.length; j++){
					let module_data;
					let lecture = [];
					for (let k = 0; k<savecourse[i].module[j].lecture.length; k++){
						let lecture_data;
						let worksheets = [];
						let concepts = [];
						for(let r = 0; r<savecourse[i].module[j].lecture[k].worksheets.length; r++){
							let worksheets_data;
							worksheets_data = {lec_worksheet: savecourse[i].module[j].lecture[k].worksheets[r].worksheet.split('/').slice(-1), lec_worksheet_actual: savecourse[i].module[j].lecture[k].worksheets[r].worksheet}
							worksheets.push(worksheets_data)
						}
						for(let r = 0; r<savecourse[i].module[j].lecture[k].concepts.length; r++){
							let concept_data;
							for(let g = 0; g<save_concepts.length; g++){
								if (save_concepts[g].concept_id === savecourse[i].module[j].lecture[k].concepts[r]){
									concept_data = {concept_text: save_concepts[g].concept_text, exixting_concept: "", concept_text_checkbox: true, concept_id: ""};
									concepts.push(concept_data)
								}
							}
						}
						lecture_data = { lecture_title: savecourse[i].module[j].lecture[k].lecture_title, topic: savecourse[i].module[j].lecture[k].topic, lecture_video: savecourse[i].module[j].lecture[k].lecture_video.split('/').slice(-1), lecture_video_actual: savecourse[i].module[j].lecture[k].lecture_video, lecture_note: savecourse[i].module[j].lecture[k].lecture_note.split('/').slice(-1), lecture_note_actual: savecourse[i].module[j].lecture[k].lecture_note, lecture_worksheet: worksheets, concept: concepts};
						lecture.push(lecture_data)
					}
					let exercise = [];
					for (let k = 0; k<savecourse[i].module[j].exercise.length; k++){
						let exercise_data, prog_exercise_data;
						let prog_exercise = []
						if(savecourse[i].module[j].exercise[k].exercise_type === "progExercise"){
							for (let s = 0; s<save_progexercise.length; s++){
								if (save_progexercise[s].exercise_id === savecourse[i].module[j].exercise[k].exercise_id){
									let dataset = []
									if (save_progexercise[s].datasets !== null){
										let datasets_data;
										for(let h = 0; h<save_progexercise[s].datasets.length; h++){
											datasets_data = {prog_dataset: save_progexercise[s].datasets[0].split('/').slice(-1), prog_dataset_actual: save_progexercise[s].datasets[0]};
											dataset.push(datasets_data)
										}
									}
									let concepts = [];
									for(let r = 0; r<save_progexercise[s].concepts.length; r++){
										let concept_data;
										for(let g = 0; g<save_concepts.length; g++){
											if (save_concepts[g].concept_id === save_progexercise[s].concepts[r]){
												concept_data = {concept_text: save_concepts[g].concept_text, exixting_concept: "", concept_text_checkbox: true, concept_id: ""};
												concepts.push(concept_data)
											}
										}
									}
									prog_exercise_data = {prog_marks: parseInt(save_progexercise[s].marks), prog_worksheet: save_progexercise[s].worksheet.split('/').slice(-1), prog_worksheet_actual: save_progexercise[s].worksheet, prog_evaluation_fn: save_progexercise[s].evaluation_fn.split('/').slice(-1), prog_evaluation_fn_actual: save_progexercise[s].evaluation_fn, prog_datasets: dataset, concept: concepts, concept_id_for_DB: []}
									prog_exercise.push(prog_exercise_data)
									exercise_data = {obj_exercise: [], prog_exercise: prog_exercise, obj_exercise_checkbox: true, prog_exercise_checkbox: true}
									exercise.push(exercise_data)
								}
							}
						}
						else{
							let obj_exercise_data;
							let obj_exercise = []
							for (let s = 0; s<save_objexercise.length; s++){
								if (save_objexercise[s].exercise_id === savecourse[i].module[j].exercise[k].exercise_id){
									let concepts = [];
									for(let r = 0; r<save_objexercise[s].concepts.length; r++){
										let concept_data;
										for(let g = 0; g<save_concepts.length; g++){
											if (save_concepts[g].concept_id === save_objexercise[s].concepts[r]){
												concept_data = {concept_text: save_concepts[g].concept_text, exixting_concept: "", concept_text_checkbox: true, concept_id: ""};
												concepts.push(concept_data)
											}
										}
									}
									let choice_answer = []
									let choice_answer_data;
									for(let r = 0; r<save_objexercise[s].list_of_choices.length; r++){
										for(let w = 0; w<save_objexercise[s].list_of_answers.length; w++){
											if(save_objexercise[s].list_of_answers[w] === save_objexercise[s].list_of_choices[r]){
												choice_answer_data = {choice_text: save_objexercise[s].list_of_choices[r], is_it_an_answer: "on", is_it_an_answer_checkbox: true};
											}else{
												choice_answer_data = {choice_text: save_objexercise[s].list_of_choices[r], is_it_an_answer: "", is_it_an_answer_checkbox: false};
											}
										}
										choice_answer.push(choice_answer_data)
									}
									obj_exercise_data = {question_type: save_objexercise[s].question_type === "mcq" ? ("Multiple Choice Question") : ("Filling the Blanks"), question_has_pdf: "", mcq_type: save_objexercise[s].question_type === "mcq" ? (save_objexercise[s].mcq_type) : (""), question_text: save_objexercise[s].question_text, choice_has_pdf: "",  obj_marks: parseInt(save_objexercise[s].marks), choice_answer: choice_answer, concept: concepts, concept_id_for_DB: [] };
									obj_exercise.push(obj_exercise_data)
									exercise_data = {obj_exercise: obj_exercise, prog_exercise: [], obj_exercise_checkbox: true, prog_exercise_checkbox: true}
									exercise.push(exercise_data)
								}
							}
						}
					}
					module_data = { module_title: savecourse[i].module[j].module_title, lecture: lecture, exercise: exercise }
					module.push(module_data)
				}
				for (let j = 0; j<savecourse[i].instructor.length; j++){
					let instructor_data;
					instructor_data = {instructor_text: "", instructor_profile: savecourse[i].instructor[j].profile.split('/').slice(-1), instructor_profile_actual: savecourse[i].instructor[j].profile, instructor_profile_text: "", instructor_designation: savecourse[i].instructor[j].designation.split('/').slice(-1), instructor_designation_actual: savecourse[i].instructor[j].designation, instructor_designation_text: "", instructor_name: savecourse[i].instructor[j].name, instructor_profile_text_on: false, instructor_designation_text_on: false}
					instructor.push(instructor_data);
				}
				this.setState({ module : module})
				this.setState({ instructor : instructor})
				this.setState({ common_fields : common_fields})
				this.setState({ prerequisite_preexisting_course : prerequisite_preexisting_course})
			}
		}
		this.setState({ courseobjectid : courseobjectid})
	}
  }
  ////////////////////////////////////////////////////////////
  // Define all save functions
  async saveCourse(){ 
	  		let savecourse = this.state.savecourse; 
			await axios
            .post(serverUrl+'/script_save_course_details', this.state)
            .then(res => {
              if (res.data.success === true) {
                // Success
					console.log(res.data.data)
					savecourse = true;
				} else {
					alert(res.data.data);
					savecourse = false;
              }
            })
            .catch(function(error) {
              console.log(error);
              alert("Internal server error !");
            });
			this.setState({ savecourse : savecourse})
	}
	
	////////////////////////// Here we create the final array //////////////////////////////
	uploadInstructorTextFile = async(fileName, coursefoldername, course_id, instructorfoldername, instructor_id) => {
		// Read content from the file
		console.log(fileName)
		// Setting up S3 upload parameters
		const params = {
			Bucket: BUCKET_NAME,
			Key: coursefoldername + "/" + course_id + "/" + instructorfoldername + "/" + instructor_id + "/" + fileName.name, // File name you want to save as in S3
			Body: fileName.data
		};
		// Uploading files to the bucket
		await s3.upload(params, function(err, data) {
			if (err) {
				throw err;
			}
			console.log(`File uploaded successfully. ${data.Location}`);
			return data.Location
		});		
	};
	uploadInstructorFile = async(fileName, coursefoldername, course_id, instructorfoldername, instructor_id) => {
		// Setting up S3 upload parameters
		console.log(fileName)
		const params = {
			Bucket: BUCKET_NAME,
			Key: coursefoldername + "/" + course_id + "/" + instructorfoldername + "/" + instructor_id + "/" + fileName.name, // File name you want to save as in S3
			Body: fileName
		};
		// Uploading files to the bucket
		await s3.upload(params, function(err, data) {
			if (err) {
				throw err;
			}
			console.log(`File uploaded successfully. ${data.Location}`);
			return data.Location
		});		
	};
	uploadExerciseFile = async(fileName, coursefoldername, course_id, modulefoldername, module_id, exercisefoldername, exercis_id)=> {
		// Setting up S3 upload parameters
		console.log(fileName)
		const params = {
			Bucket: BUCKET_NAME,
			Key: coursefoldername + "/" + course_id + "/" + modulefoldername + "/" + module_id + "/" + exercisefoldername + "/" + exercis_id + "/" + fileName.name, // File name you want to save as in S3
			Body: fileName
		};
		// Uploading files to the bucket
		await s3.upload(params, function(err, data) {
			if (err) {
				throw err;
			}
			console.log(`File uploaded successfully. ${data.Location}`);
			return data.Location
		});		
	};

	uploadLectureFile = async(fileName, coursefoldername, course_id, modulefoldername, module_id, lecturefoldername, lecture_id)=> {
		// Setting up S3 upload parameters
		console.log(fileName)
		const params = {
			Bucket: BUCKET_NAME,
			Key: coursefoldername + "/" + course_id + "/" + modulefoldername + "/" + module_id + "/" + lecturefoldername + "/" + lecture_id + "/" + fileName.name, // File name you want to save as in S3
			Body: fileName
		};
		// Uploading files to the bucket
		await s3.upload(params, function(err, data) {
			if (err) {
				throw err;
			}
			console.log(`File uploaded successfully. ${data.Location}`);
			return data.Location
		});		
	};
	
	uploadCourseTextFile = async(fileName, coursefoldername, course_id) => {
		// Read content from the file
		console.log(fileName)
		// Setting up S3 upload parameters
		const params = {
			Bucket: BUCKET_NAME,
			Key: coursefoldername + "/" + course_id + "/" + fileName.name, // File name you want to save as in S3
			Body: fileName.data
		};
		// Uploading files to the bucket
		await s3.upload(params, function(err, data) {
			if (err) {
				throw err;
			}
			console.log(`File uploaded successfully. ${data.Location}`);
			return data.Location
		});		
	};
	uploadCourseFile = async(fileName, coursefoldername, course_id) => {
		// Setting up S3 upload parameters
		console.log(fileName)
		const params = {
			Bucket: BUCKET_NAME,
			Key: coursefoldername + "/" + course_id + "/" + fileName.name, // File name you want to save as in S3
			Body: fileName
		};
		// Uploading files to the bucket
		await s3.upload(params, function(err, data) {
			if (err) {
				throw err;
			}
			console.log(`File uploaded successfully. ${data.Location}`);
			return data.Location
		});		
	};
	
	////// Validation check /////////////////////////////
  
	async handleValidation(){
		let fields = this.state.common_fields;
		let prerequisite = this.state.prerequisite_preexisting_course;
        let errors = {};
        let formIsValid = this.state.formIsValid;

        //course_title
       if(!fields["course_title"]){
            formIsValid = false;
            errors["course_title"] = "Can't be empty!";
        }
      
        if(typeof fields["course_title"] !== "undefined"){
			if(!fields["course_title"].match(/^[a-zA-Z ]+$/)){
                formIsValid = false;
                errors["course_title"] = "Only letters are allowed!";
            }  
			else{
				let existing_course = this.state.existing_course;
				for (let j = 0; j<existing_course.length; j++){
					if(fields["course_title"].match(existing_course[j].course_title)){
						formIsValid = false;
						errors["course_title"] = "This course title's already present in our system!";
					}  
				}
			}
        }
		
		//course_title
        if(!fields["course_short_name"]){
            formIsValid = false;
            errors["course_short_name"] = "Can't be empty!";
        }
      
        if(typeof fields["course_short_name"] !== "undefined"){
			if(!fields["course_short_name"].match(/^[a-zA-Z]+$/)){
                formIsValid = false;
                errors["course_short_name"] = "Only letters are allowed!";
            }
			else if(!fields["course_short_name"].match(/^[A-Z]+$/)){
                formIsValid = false;
                errors["course_short_name"] = "Course Short Name must be capital letter!";
            }
			else if(fields["course_short_name"].length < 2){
                formIsValid = false;
                errors["course_short_name"] = "Course Short Name length must be >=  2!";
            }
			else{
				let existing_course = this.state.existing_course;
				for (let j = 0; j<existing_course.length; j++){
					if(fields["course_short_name"].match(existing_course[j].course_short_name)){
						formIsValid = false;
						errors["course_short_name"] = "This course short name's already present in our system!";
					}  
				}
			}
        }
        
		//communication_language
        if(!fields["communication_language"]){
            formIsValid = false;
            errors["communication_language"] = "Can't be empty!";
        }
      
        if(typeof fields["communication_language"] !== "undefined"){
			if( fields["communication_language"] === "Select.."){
                formIsValid = false;
                errors["communication_language"] = "Please select a valid Communication language!";
            }
        }
		
		
		//created_on
        if(fields["created_on"] === null){
            formIsValid = false;
            errors["created_on"] = "Can't be empty!";
        }
        else if(fields["created_on"] !== null){
			let year = fields["created_on"].toString().split(' ')[3];
			if( year < 2000){
                formIsValid = false;
                errors["created_on"] = "Year is at least 2000!";
            }
			else if( year > 2021){
                formIsValid = false;
                errors["created_on"] = "Year is belongs to future!";
            }
        }
		//offering_period_from
        if(fields["offering_period_from"] === null && this.state.fixed_offering_date === true){
            formIsValid = false;
            errors["offering_period_from"] = "Can't be empty!";
        }
      
        else if(fields["offering_period_from"] !== null  && this.state.fixed_offering_date === true){
			let year = fields["offering_period_from"].toString().split(' ')[3];
			if( year < 2021){
                formIsValid = false;
                errors["offering_period_from"] = "Year can't be < 2021!";
            }
			
        }
		//offering_period_to
        if(fields["offering_period_to"] === null  && this.state.fixed_offering_date === true){
            formIsValid = false;
            errors["offering_period_to"] = "Can't be empty!";
        }
      
        else if(fields["offering_period_to"] !== null && this.state.fixed_offering_date === true){
			let year_to = fields["offering_period_to"].toString().split(' ')[3];
			let year_from = fields["offering_period_from"].toString().split(' ')[3];
			if( year_to <  2021){
                formIsValid = false;
                errors["offering_period_to"] = "Year can't be < 2021!";
            }
			else if( year_to < year_from ){
                formIsValid = false;
                errors["offering_period_to"] = "To date can't be < From date!";
            }
			
        }
		//credit
        if(!fields["credit"]){
            formIsValid = false;
            errors["credit"] = "Can't be empty!";
        }
      
        if(typeof fields["credit"] !== "undefined"){
			
			if( fields["credit"] < 0 || fields["credit"] > 10){
                formIsValid = false;
                errors["credit"] = "Credit can't be > 10 and < 0!";
            }
			
        }
		//duration_in_min
        if(!fields["duration_in_min"]){
            formIsValid = false;
            errors["duration_in_min"] = "Can't be empty!";
        }
      
        if(typeof fields["duration_in_min"] !== "undefined"){
			if( fields["duration_in_min"] < 1){
                formIsValid = false;
                errors["duration_in_min"] = "Duration can't be < 1!";
            }
			
        }
		//course_description
        if(fields.course_description.length === 0 && this.state.custom_course_description === false){
            formIsValid = false;
            errors["course_description"] = "Can't be empty!";
			errors["course_description_text"] = "";
        }
      
        if(fields.course_description.length > 0 && this.state.custom_course_description === false){
			if( typeof fields["course_description"] !== "string"){
                formIsValid = false;
                errors["course_description"] = "It only accept path(string)!";
				errors["course_description_text"] = "";
            }
			let path = fields["course_description"].split('.')[1]
			if( path !== "txt"){
                formIsValid = false;
                errors["course_description"] = "Only .txt file are allowed!";
				errors["course_description_text"] = "";
            }
			
        }
		
		if(!fields["course_description_text"] && this.state.custom_course_description === true){
            formIsValid = false;
            errors["course_description_text"] = "Can't be empty!";
			errors["course_description"] = "";
        }
      
        if(typeof fields["course_description_text"] !== "undefined" && this.state.custom_course_description === true){
			if(!fields["course_description_text"].match(/^[a-zA-Z,.''"" ]+$/)){
                formIsValid = false;
				errors["course_description"] = "";
                errors["course_description_text"] = "Only letters are allowed!";
            }
        }
		
		//prerequisite_knowledge_file
      
        if(fields.prerequisite_knowledge_file.length > 0 && this.state.custom_prerequisite_knowledge_file === false){
			if( typeof fields["prerequisite_knowledge_file"] !== "string"){
                formIsValid = false;
                errors["prerequisite_knowledge_file"] = "It only accept path(string)!";
				errors["course_prerequisite_knowledge_file_text"] = "";
            }
			let path = fields["prerequisite_knowledge_file"].split('.')[1]
			if( path !== "txt"){
                formIsValid = false;
                errors["prerequisite_knowledge_file"] = "Only '.txt' file are allowed!";
				errors["course_prerequisite_knowledge_file_text"] = "";
            }
			
        }
      
        if(typeof fields["course_prerequisite_knowledge_file_text"] !== "undefined" && this.state.custom_prerequisite_knowledge_file === true){
			if(!fields["course_prerequisite_knowledge_file_text"].match(/^[a-zA-Z.,''"" ]+$/)){
                formIsValid = false;
				errors["prerequisite_knowledge_file"] = "";
                errors["course_prerequisite_knowledge_file_text"] = "Only letters are allowed!";
            }
        }
		//reference_material_file
      
        if(fields.reference_material_file.length > 0 && this.state.custom_reference_material_file === false){
			if( typeof fields["reference_material_file"] !== "string"){
                formIsValid = false;
                errors["reference_material_file"] = "It only accept path(string)!";
				errors["course_reference_material_file_text"] = "";
            }
			let path = fields["reference_material_file"].split('.')[1]
			if( path !== "txt"){
                formIsValid = false;
                errors["reference_material_file"] = "Only '.txt' file are allowed!";
				errors["course_reference_material_file_text"] = "";
            }
			
        }
      
        if(typeof fields["course_reference_material_file_text"] !== "undefined" && this.state.custom_reference_material_file === true){
			if(!fields["course_reference_material_file_text"].match(/^[a-zA-Z,.''"" ]+$/)){
                formIsValid = false;
				errors["reference_material_file"] = "";
                errors["course_reference_material_file_text"] = "Only letters are allowed!";
            }
        }
		
		
		//course_intro_video
        if(fields.course_intro_video.length === 0){
            formIsValid = false;
            errors["course_intro_video"] = "Can't be empty!";
        }
      
        if(fields.course_intro_video.length > 0){
			if( typeof fields["course_intro_video"] !== "string"){
                formIsValid = false;
                errors["course_intro_video"] = "It only accept path(string)!";
            }
			let path = fields["course_intro_video"].split('.')[1]
			if( path !== "mp4"){
                formIsValid = false;
                errors["course_intro_video"] = "Only .mp4 file are allowed to upload!";
            }
			
        }
		// course_advertisement_image
		if(fields.course_advertisement_image.length === 0){
            formIsValid = false;
            errors["course_advertisement_image"] = "Can't be empty!";
        }
      
        if(fields.course_advertisement_image > 0){
			if( typeof fields["course_advertisement_image"] !== "string"){
                formIsValid = false;
                errors["course_advertisement_image"] = "It only accept path(string)!";
            }
			let path = fields["course_advertisement_image"].split('.')[1]
			if( path !== "jpg" || path !== "png" || path !== "JPG"){
                formIsValid = false;
                errors["course_advertisement_image"] = "Only .jpg or .png file are allowed to upload!";
            }
			
			
        }
		
		// course_card_image
		if(fields.course_card_image.length === 0){
            formIsValid = false;
            errors["course_card_image"] = "Can't be empty!";
        }
      
        if(fields.course_card_image > 0){
			if( typeof fields["course_card_image"] !== "string"){
                formIsValid = false;
                errors["course_card_image"] = "It only accept path(string)!";
            }
			let path = fields["course_card_image"].split('.')[1]
			if( path !== "jpg" || path !== "png" || path !== "JPG"){
                formIsValid = false;
                errors["course_card_image"] = "Only .jpg or .png file are allowed to upload!";
            }
			
			
        }
		// copyright_message_file
		if(fields.copyright_message_file.length === 0 && this.state.custom_copyright_message_file === false){
            formIsValid = false;
            errors["copyright_message_file"] = "Can't be empty!";
			errors["copyright_message_file_text"] = "";
        }
      
        if(fields.copyright_message_file.length > 0 && this.state.custom_copyright_message_file === false){
			if( typeof fields["copyright_message_file"] !== "string"){
                formIsValid = false;
                errors["copyright_message_file"] = "It only accept path(string)!";
				errors["copyright_message_file_text"] = "";
            }
			let path = fields["copyright_message_file"].split('.')[1]
			if( path !== "txt"){
                formIsValid = false;
                errors["copyright_message_file"] = "Only .txt file are allowed!";
				errors["copyright_message_file_text"] = "";
            }
			
        }
		
		if(!fields["course_copyright_message_file_text"] && this.state.custom_copyright_message_file === true){
            formIsValid = false;
            errors["course_copyright_message_file_text"] = "Can't be empty!";
			errors["copyright_message_file"] = "";
        }
      
        if(typeof fields["course_copyright_message_file_text"] !== "undefined" && this.state.custom_copyright_message_file === true){
			if(!fields["course_copyright_message_file_text"].match(/^[a-zA-Z,.''"" ]+$/)){
                formIsValid = false;
				errors["copyright_message_file"] = "";
                errors["course_copyright_message_file_text"] = "Only letters are allowed!";
            }
        }
				
        // prerequisite_preexisting course

		if(prerequisite.length>0){
			let course_title_name = []
			for (let i = 0; i< prerequisite.length; i++){
				if(prerequisite[i].course_title_name === "" || prerequisite[i].course_title_name === "Select.."){
					prerequisite[i]["eror_in_course_title_name"] = "Please select a valid course name type!"
				}else if(course_title_name.includes(prerequisite[i].course_title_name)){
					prerequisite[i]["eror_in_course_title_name"] = "No duplicate course names are allowed!"
				}else{
					course_title_name.push(prerequisite[i].course_title_name)
					prerequisite[i]["eror_in_course_title_name"] = ""
				}
			}
		}

		// Module 
		
		let module = this.state.module;
        let mod_errors = {};
		if(module.length === 0){
			console.log("module")
            formIsValid = false;
            mod_errors["no_data_on_module"] = "Course should have atleast one Module!";
        }
		
		if (module.length > 0){
			for (let i = 0; i<module.length; i++){
				if(module[i].module_title.length === 0){
					formIsValid = false;
					module[i]["error_in_title"] = "Can't be empty!";
				}
      
				if(module[i].module_title.length > 0){
					if(!module[i].module_title.match(/^[a-zA-Z ]+$/)){
						formIsValid = false;
						module[i]["error_in_title"] = "Only letters are allowed!";
					}else{
						module[i]["error_in_title"] = "";
					}						
				}
				// lecture
				if(module[i].lecture.length === 0){
					console.log("module")
					formIsValid = false;
					module[i]["no_data_on_module_lecture"] = "Module should have Lecture details!";
				}
				if (module[i].lecture.length > 0){
					module[i]["no_data_on_module_lecture"] = "";
					for (let j = 0; j<module[i].lecture.length; j++){
						// title
						if(module[i].lecture[j].lecture_title.length === 0){
							formIsValid = false;
							module[i].lecture[j]["error_in_title"] = "Can't be empty!";
						}
      
						if(module[i].lecture[j].lecture_title.length > 0){
							if(!module[i].lecture[j].lecture_title.match(/^[a-zA-Z ]+$/)){
								formIsValid = false;
								module[i].lecture[j]["error_in_title"] = "Only letters are allowed!";
							}else{
								module[i].lecture[j]["error_in_title"] = "";
							}						
						}
						// topic
						if(module[i].lecture[j].topic.length === 0){
							formIsValid = false;
							module[i].lecture[j]["error_in_topic"] = "Can't be empty!";
						}
      
						if(module[i].lecture[j].topic.length > 0){
							if(!module[i].lecture[j].topic.match(/^[a-zA-Z ]+$/)){
								formIsValid = false;
								module[i].lecture[j]["error_in_topic"] = "Only letters are allowed!";
							}else{
								module[i].lecture[j]["error_in_topic"] = "";
							}						
						}
						// video
						if(module[i].lecture[j].lecture_video.length === 0){
							formIsValid = false;
							module[i].lecture[j]["error_in_video"] = "Can't be empty!";
						}
      
						if(module[i].lecture[j].lecture_video.length > 0){
							let path = module[i].lecture[j].lecture_video.split('.')[1]
							if( path !== "mp4"){
								formIsValid = false;
								module[i].lecture[j]["error_in_video"] = "Only '.mp4 ' file are allowed to upload!";
							}else if(module[i].lecture[j].lecture_video_actual.size < 10240){
									formIsValid = false;
									module[i].lecture[j]["error_in_video"] = "File size <10 KB isn't allowed!";
								}else{
									module[i].lecture[j]["error_in_video"] = "";
								}
													
						}
						if(module[i].lecture[j].lecture_note.length > 0){
							let path = module[i].lecture[j].lecture_note.split('.')[1]
							if( path !== "pdf"){
								formIsValid = false;
								module[i].lecture[j]["error_in_note"] = "Only '.pdf ' file are allowed to upload!";
							}else if(module[i].lecture[j].lecture_note_actual.size < 10240){
									formIsValid = false;
									module[i].lecture[j]["error_in_note"] = "File size <10 KB isn't allowed!";
							}else{
									module[i].lecture[j]["error_in_note"] = "";
							}							
													
						}
      
						if(module[i].lecture[j].lecture_worksheet.length > 0){
							for (let w = 0; w<module[i].lecture[j].lecture_worksheet.length; w++){
								if(module[i].lecture[j].lecture_worksheet[w].lec_worksheet === "" ){
									module[i].lecture[j].lecture_worksheet[w]["error_in_worksheet"] = "Can't be empty!"
								}else{
									let path = module[i].lecture[j].lecture_worksheet[w].lec_worksheet.split('.')[1]
									if( path !== "ipynb"){
										formIsValid = false;
										module[i].lecture[j].lecture_worksheet[w]["error_in_worksheet"] = "Only '.ipynb ' file are allowed to upload!";
									}
									else if(module[i].lecture[j].lecture_worksheet[w].lec_worksheet_actual.size < 1024){
										formIsValid = false;
										module[i].lecture[j].lecture_worksheet[w]["error_in_worksheet"] = "File size <1 KB isn't allowed!";
									}else{
										module[i].lecture[j].lecture_worksheet[w]["error_in_worksheet"] = "";
									}
								}
							}
							console.log(module[i].lecture[j].lecture_worksheet)					
						}
						if(module[i].lecture[j].concept.length === 0){
							console.log("module")
							formIsValid = false;
							module[i].lecture[j]["no_data_on_lecture_concept"] = "Lecture should have concept details!";
						}
						{/*else{
							for (let g = 0; g<module[i].lecture[j].concept.length; g++){
								if(module[i].lecture[j].concept[g].existing_concept === "Select concept from our database" && module[i].lecture[j].concept[g].concept_text_checkbox === false){
									formIsValid = false;
									module[i].lecture[j].concept[g]["error_in_concept_text"] = "";
									module[i].lecture[j].concept[g]["error_in_existing_concept"] = "Can't be empty!";
								}
								if(!module[i].lecture[j].concept[g].concept_text && module[i].lecture[j].concept[g].concept_text_checkbox === true){
									formIsValid = false;
									module[i].lecture[j].concept[g]["error_in_concept_text"] = "Can't be empty!";
									module[i].lecture[j].concept[g]["error_in_existing_concept"] = "";
								}else if (typeof module[i].lecture[j].concept[g].concept_text !== "undefined" && module[i].lecture[j].concept[g].concept_text_checkbox === true ){
									if(!module[i].lecture[j].concept[g].concept_text.match(/^[a-zA-Z ]+$/)){
										formIsValid = false;
										module[i].lecture[j].concept[g]["error_in_existing_concept"] = "";
										module[i].lecture[j].concept[g]["error_in_concept_text"] = "Only letters are allowed!";
									}
								}
							
							}
						}*/}
					}
				}
				if (module[i].exercise.length > 0){
					for (let j = 0; j<module[i].exercise.length; j ++){
						if (module[i].exercise[j].obj_exercise.length > 0){
							if( module[i].exercise[j].obj_exercise[0].question_type === "" || module[i].exercise[j].obj_exercise[0].question_type === "Select.."){
								formIsValid = false;
								module[i].exercise[j].obj_exercise[0]["error_in_question_type"] = "Please select a valid question type!";
							}else{
								module[i].exercise[j].obj_exercise[0]["error_in_question_type"] = "";
							}
							if(module[i].exercise[j].obj_exercise[0].obj_marks === ""){
								formIsValid = false;
								module[i].exercise[j].obj_exercise[0]["error_in_obj_marks"] = "Can't be empty!";
							}
							if(module[i].exercise[j].obj_exercise[0].obj_marks> 0){
								if(module[i].exercise[j].obj_exercise[0].obj_marks < 0 || module[i].exercise[j].obj_exercise[0].obj_marks > 100){
									formIsValid = false;
									module[i].exercise[j].obj_exercise[0]["error_in_obj_marks"] = "Value must be >= 0 and <= 100!";
								}else{
									module[i].exercise[j].obj_exercise[0]["error_in_obj_marks"] = "";
								}
							}
							if(module[i].exercise[j].obj_exercise[0].question_text === ""){
								formIsValid = false;
								module[i].exercise[j].obj_exercise[0]["error_in_question_text"] = "Can't be empty!";
							}
							if(module[i].exercise[j].obj_exercise[0].question_text){
								if(!module[i].exercise[j].obj_exercise[0].question_text.match(/^[a-zA-Z$#? ]+$/)){
									formIsValid = false;
									module[i].exercise[j].obj_exercise[0]["error_in_question_text"] = "Only letters and some special characters are allowed!";
								}else{
									module[i].exercise[j].obj_exercise[0]["error_in_question_text"] = "";
								}
							}
							if(module[i].exercise[j].obj_exercise[0].mcq_type === "" || module[i].exercise[j].obj_exercise[0].mcq_type === "Select.."){
								formIsValid = false;
								module[i].exercise[j].obj_exercise[0]["error_in_mcq_type"] = "Can't be empty!";
							}else{
								module[i].exercise[j].obj_exercise[0]["error_in_mcq_type"] = ""
							}
							let choice = []
							if(module[i].exercise[j].obj_exercise[0].choice_answer.length === 0){
								formIsValid = false;
								module[i].exercise[j].obj_exercise[0]["no_data_on_obj_choice_answer"] = "Objective exercise should have list of choices details!";
							}else{
								let ans = 0
								for (let y = 0; y<module[i].exercise[j].obj_exercise[0].choice_answer.length; y++){
									if(module[i].exercise[j].obj_exercise[0].choice_answer[y].choice_text === ""){
										formIsValid = false;
										module[i].exercise[j].obj_exercise[0].choice_answer[y]["error_in_choice_text"] = "Can't be empty!";
									}else if(!module[i].exercise[j].obj_exercise[0].choice_answer[y].choice_text.match(/^[a-zA-Z ]+$/)){
										formIsValid = false;
										module[i].exercise[j].obj_exercise[0].choice_answer[y]["error_in_choice_text"] = "Only letters are allowed!!";
									}else if(choice.includes(module[i].exercise[j].obj_exercise[0].choice_answer[y].choice_text)){
										module[i].exercise[j].obj_exercise[0].choice_answer[y]["error_in_choice_text"] = "No duplicate values are allowed!"
									}else{
										choice.push(module[i].exercise[j].obj_exercise[0].choice_answer[y].choice_text)
										module[i].exercise[j].obj_exercise[0].choice_answer[y]["error_in_choice_text"] = "";
									}
									if(module[i].exercise[j].obj_exercise[0].choice_answer[y].is_it_an_answer_checkbox === true){
										if (module[i].exercise[j].obj_exercise[0].question_type === "Multiple Choice Question"){
											if(module[i].exercise[j].obj_exercise[0].mcq_type === "singlechoice"){
												if(ans === 0){
													ans = ans + 1
												}else{
													module[i].exercise[j].obj_exercise[0].choice_answer[y]["error_in_is_it_an_answer"] = "Only one answer is allowed for singlechoice MCQ!"
												}
											}
										}
									}else{
										module[i].exercise[j].obj_exercise[0].choice_answer[y]["error_in_is_it_an_answer"] = ""
									}
									
								}
							}

							
							if(module[i].exercise[j].obj_exercise[0].concept.length === 0){
								formIsValid = false;
								module[i].exercise[j].obj_exercise[0]["no_data_on_obj_concept"] = "Objective exercise should have concept details!";
							}
							
							
						}
						if (module[i].exercise[j].prog_exercise.length > 0){
								if( module[i].exercise[j].prog_exercise[0].prog_marks === ""){
									formIsValid = false;
									module[i].exercise[j].prog_exercise[0]["error_in_prog_marks"] = "Can't be empty!";
								}else{
									module[i].exercise[j].prog_exercise[0]["error_in_prog_marks"] = "";
								}
								
								if( module[i].exercise[j].prog_exercise[0].prog_worksheet.length === 0){
									formIsValid = false;
									module[i].exercise[j].prog_exercise[0]["error_in_worksheet"] = "Can't be empty!";
								}else if(module[i].exercise[j].prog_exercise[0].prog_worksheet.length > 0){
									let path = module[i].exercise[j].prog_exercise[0].prog_worksheet.split('.')[1]
									if( path !== "ipynb"){
										formIsValid = false;
										module[i].exercise[j].prog_exercise[0]["error_in_worksheet"] = "Only '.ipynb' file are allowed to upload!";
									}else if(module[i].exercise[j].prog_exercise[0].prog_worksheet_actual.size < 1024){
										formIsValid = false;
										module[i].exercise[j].prog_exercise[0]["error_in_worksheet"] = "File size <1 KB isn't allowed!";
									}else{
										module[i].exercise[j].prog_exercise[0]["error_in_worksheet"] = "";
									}
													
								}
								if( module[i].exercise[j].prog_exercise[0].prog_evaluation_fn.length === 0){
									formIsValid = false;
									module[i].exercise[j].prog_exercise[0]["error_in_evaluation_fn"] = "Can't be empty!";
								}else if(module[i].exercise[j].prog_exercise[0].prog_evaluation_fn.length > 0){
									let path = module[i].exercise[j].prog_exercise[0].prog_evaluation_fn.split('.')[1]
									if( path !== "py"){
										formIsValid = false;
										module[i].exercise[j].prog_exercise[0]["error_in_evaluation_fn"] = "Only '.py' file are allowed to upload!";
									}
									else if(module[i].exercise[j].prog_exercise[0].prog_evaluation_fn_actual.size < 1024){
										formIsValid = false;
										module[i].exercise[j].prog_exercise[0]["error_in_evaluation_fn"] = "File size <1 KB isn't allowed!";
									}else{
										module[i].exercise[j].prog_exercise[0]["error_in_evaluation_fn"] = "";
									}
													
								}

								if(module[i].exercise[j].prog_exercise[0].prog_datasets.length > 0){
									for (let p = 0; p<module[i].exercise[j].prog_exercise[0].prog_datasets.length; p++){
										if( module[i].exercise[j].prog_exercise[0].prog_datasets[p].prog_dataset === ""){
											formIsValid = false;
											module[i].exercise[j].prog_exercise[0].prog_datasets[p]["error_in_datasets"] = "Can't be empty!";
										}else{
											let path = module[i].exercise[j].prog_exercise[0].prog_datasets[p].prog_dataset.split('.')[1]
											if( path !== "csv"){
												formIsValid = false;
												module[i].exercise[j].prog_exercise[0].prog_datasets[p]["error_in_datasets"] = "Only '.csv' file are allowed to upload!";
											}
											else if(module[i].exercise[j].prog_exercise[0].prog_datasets[p].prog_dataset.size < 1024){
												formIsValid = false;
												module[i].exercise[j].prog_exercise[0].prog_datasets[p]["error_in_datasets"]  = "File size <1 KB isn't allowed!";
											}else{
												module[i].exercise[j].prog_exercise[0].prog_datasets[p]["error_in_datasets"]  = "";
											}
										}
									}
													
								}
								if(module[i].exercise[j].prog_exercise[0].concept.length === 0){
									formIsValid = false;
									module[i].exercise[j].prog_exercise[0]["no_data_on_prog_concept"] = "Program exercise should have concept details!";
								}
								
							}
						
					}
				}
			}
			
		}
		
		// Instructor 
		
		let instructor = this.state.instructor;
        let ins_errors = {};
		if(instructor.length === 0){
            formIsValid = false;
            ins_errors["no_data_on_instructor"] = "Course should have atleast one Instructor!";
        }
		if(instructor.length > 0){
			for (let i=0; i<instructor.length; i++){
				if(instructor[i].instructor_name.length === 0){
					formIsValid = false;
					instructor[i]["error_in_name"] = "Can't be empty!";
				}
				else if(instructor[i].instructor_name.length > 0){
					let c = 0
					if (!instructor[i].instructor_name.match(/^[a-zA-Z. ]+$/)){
						formIsValid = false;
						instructor[i]["error_in_name"] = "Only letters and dots are allowed!";
						c ++;
					}
					if (c === 0){
						let name = instructor[i].instructor_name.split(' ')
						for (let i=0; i<name.length; i++){
							if(!name[i][0].match(/^[A-Z]+$/)){
								formIsValid = false;
								instructor[i]["error_in_name"] = "The first letter of each word must be in capital!";
								break
							}	
						}
					}
					
				}
				//// designation
				if( instructor[i].instructor_designation.length === 0 && instructor[i].instructor_designation_text_on === false){
						formIsValid = false;
						instructor[i]["error_in_designation"] = "Can't be empty!";
						instructor[i]["error_in_instructor_designation_text"] = "";
				}	
				else if (instructor[i].instructor_designation.length > 0 && instructor[i].instructor_designation_text_on === false){
					let path = instructor[i].instructor_designation.split('.')[1]
					if( path !== "txt"){
						formIsValid = false;
						instructor[i]["error_in_designation"] = "Only '.txt' file are allowed!";
						instructor[i]["error_in_instructor_designation_text"] = "";
					}
					else if(instructor[i].instructor_designation_actual.size < 1024){
						formIsValid = false;
						instructor[i]["error_in_designation"] = "File size <1 KB isn't allowed!";
						instructor[i]["error_in_instructor_designation_text"] = "";
					}else{
						instructor[i]["error_in_designation"] = "";
						instructor[i]["error_in_instructor_designation_text"] = "";
					}
				}
				
				if( instructor[i].instructor_designation_text.length === 0 && instructor[i].instructor_designation_text_on === true){
						formIsValid = false;
						instructor[i]["error_in_instructor_designation_text"] = "Can't be empty!";
						instructor[i]["error_in_designation"] = "";
				}	
				else if (instructor[i].instructor_designation_text.length > 0 && instructor[i].instructor_designation_text_on === true){
					if (!instructor[i].instructor_designation_text.match(/^[a-zA-Z.,''"" ]+$/)){
						formIsValid = false;
						instructor[i]["error_in_instructor_designation_text"] = "Only letters and dots are allowed!";
						instructor[i]["error_in_designation"] = "";
					}
				}
				
				// Profile
				if (instructor[i].instructor_profile.length > 0 && instructor[i].instructor_profile_text_on === false ){
					let path = instructor[i].instructor_profile.split('.')[1]
					if( path !== "txt"){
						formIsValid = false;
						instructor[i]["error_in_profile"] = "Only '.txt' file are allowed!";
						instructor[i]["error_in_instructor_profile_text"] = "";
					}
					else if(instructor[i].instructor_profile_actual.size < 1024){
						formIsValid = false;
						instructor[i]["error_in_profile"] = "File size <1 KB isn't allowed!";
						instructor[i]["error_in_instructor_profile_text"] = "";
					}else{
						instructor[i]["error_in_profile"] = "";
						instructor[i]["error_in_instructor_profile_text"] = "";
					}
				}
				
				if (instructor[i].instructor_profile_text.length > 0 && instructor[i].instructor_profile_text_on === true ){
					if (!instructor[i].instructor_profile_text.match(/^[a-zA-Z.,''"" ]+$/)){
						formIsValid = false;
						instructor[i]["error_in_instructor_profile_text"] = "Only letters and dots are allowed!";
						instructor[i]["error_in_profile"] = "";
					}
				}
				
				
			}
        }
        this.setState({errors: errors});
		this.setState({ins_errors: ins_errors});
		this.setState({mod_errors: mod_errors});
		this.setState({formIsValid: formIsValid});
    }

	async final_array_for_submission(){
		let course_id = this.state.existing_course.length + this.state.save_courses.length;
		let coursefoldername = "courses"
		let c = this.state.existing_concept.length + this.state.save_concepts.length;
		let exercis_id = this.state.existing_objexercise.length + this.state.save_objexercise.length + this.state.existing_progexercise.length + this.state.save_progexercise.length; 
		let existing_concept = this.state.existing_concept
		let module = this.state.module;
		let final_module = this.state.final_module;
		let final_course = this.state.final_course;
		let final_lecture = this.state.final_lecture;
		let final_worked_out_worksheet = this.state.final_worked_out_worksheet;
		let final_exercise = this.state.final_exercise;
		let instructor = this.state.instructor;
		let course_basic_data = this.state.common_fields;
		let prerequisite_preexisting_course = this.state.prerequisite_preexisting_course;
		let final_concept = this.state.final_concept;
		let final_obj_exercise = this.state.final_obj_exercise;
		let final_prog_exercise = this.state.final_prog_exercise;
		let final_instructor = this.state.final_instructor;
		let finalarraysubmission = this.state.finalarraysubmission;
		let module_id_array, instructor_id_array, course_description, reference_material_file, copyright_message, prerequisite_knowledge_file, add_to_carousal, course_video, course_adv, course_card;
		final_module = [];
		final_course =[];
		final_lecture = [];
		final_worked_out_worksheet = [];
		final_exercise =[];
		final_concept = [];
		final_obj_exercise =[];
		final_prog_exercise = [];
		final_instructor =[];
		
		if (prerequisite_preexisting_course.length > 0){
			let course_name
			for (let j = 0; j<prerequisite_preexisting_course.length; j++){
				course_name = prerequisite_preexisting_course[j]['course_title_name']
				if (j === 0){
					course_basic_data.prerequisite_preexisting_course = course_name;
				}
				else{
					course_basic_data.prerequisite_preexisting_course = course_basic_data.prerequisite_preexisting_course + "|||" + course_name;
				}
			}
		}
		console.log("created_on, offering_period_from  and offering_period_to : ", course_basic_data.created_on, course_basic_data.offering_period_from, course_basic_data.offering_period_to)
		if (course_basic_data.offering_period_from !== ""){
			course_basic_data.offering_period__from_to = course_basic_data.offering_period_from
		}else{
			course_basic_data.offering_period__from_to = "null"
		}
		
		if (course_basic_data.offering_period_to !== ""){
			course_basic_data.offering_period__from_to = course_basic_data.offering_period__from_to + "|||" + course_basic_data.offering_period_to
		}/*else{
			course_basic_data.offering_period__from_to = course_basic_data.offering_period__from_to + "|||" + "null"
		}*/
		/////////////////////
		if(!course_basic_data.course_intro_video_actual.includes("https://")){
			await this.uploadCourseFile(course_basic_data.course_intro_video_actual, coursefoldername, course_id)
			course_video = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + course_basic_data.course_intro_video_actual.name
		}else{
			course_video = course_basic_data.course_intro_video_actual
		}
		if(!course_basic_data.course_advertisement_image_actual.includes("https://")){
			await this.uploadCourseFile(course_basic_data.course_advertisement_image_actual, "courses", course_id)
			course_adv = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + course_basic_data.course_advertisement_image_actual.name
		}else{
			course_adv = course_basic_data.course_advertisement_image_actual
		}
		if(!course_basic_data.course_card_image_actual.includes("https://")){
			await this.uploadCourseFile(course_basic_data.course_card_image_actual, coursefoldername, course_id)
			course_card = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + course_basic_data.course_card_image_actual.name
		}else{
			course_card = course_basic_data.course_card_image_actual
		}
		if(!course_basic_data.course_description_actual.includes("https://")){
			if (this.state.custom_course_description === true){
				let v = {"name": course_basic_data.course_title + "_course_description" + ".txt", "type": "text/plain", "data" : course_basic_data.course_description_text}
				await this.uploadCourseTextFile(v, coursefoldername, course_id)
				course_description = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + v.name
			}
			else{
				if (course_basic_data.course_description_actual !== "" ){
					await this.uploadCourseFile(course_basic_data.course_description_actual, coursefoldername, course_id)
					course_description = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + course_basic_data.course_description_actual.name
				}
			}
		}else{
			course_description = course_basic_data.course_description_actual
		}
		///////////////
		if(!course_basic_data.reference_material_file_actual.includes("https://")){
			if (this.state.custom_reference_material_file === true){ 
				let v = {"name": course_basic_data.course_title + "_reference_material_file" + ".txt", "type": "text/plain", "data" : course_basic_data.course_reference_material_file_text}
				await this.uploadCourseTextFile(v, coursefoldername, course_id)
				reference_material_file = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + v.name;
			}
			else{
				if (course_basic_data.reference_material_file_actual !== "" ){
					await this.uploadCourseFile(course_basic_data.reference_material_file_actual, coursefoldername, course_id)
					reference_material_file = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + course_basic_data.reference_material_file_actual.name
				}else{
					reference_material_file = "None"
				}
			}
		}else{
			reference_material_file = course_basic_data.reference_material_file_actual
		}
		///////////////
		if(!course_basic_data.copyright_message_file_actual.includes("https://")){
			if (this.state.custom_copyright_message_file === true){
				let v = {"name": course_basic_data.course_title + "_copyright_message_file" + ".txt", "type": "text/plain", "data" : course_basic_data.course_copyright_message_file_text}
				await this.uploadCourseTextFile(v, coursefoldername, course_id)
				copyright_message = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + v.name;
			}
			else{
				if (course_basic_data.copyright_message_file_actual !== "" ){
					await this.uploadCourseFile(course_basic_data.copyright_message_file_actual, coursefoldername, course_id)
					copyright_message = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + course_basic_data.copyright_message_file_actual.name
				}
			}
		}
		else{
			copyright_message = course_basic_data.copyright_message_file_actual
		}
		///////////////
		if(!course_basic_data.prerequisite_knowledge_file_actual.includes("https://")){
			if (this.state.custom_course_prerequisite_knowledge_file === true){
				let v = {"name": course_basic_data.course_title + "_prerequisite_knowledge_file" + ".txt", "type": "text/plain", "data" : course_basic_data.course_prerequisite_knowledge_file_text}
				await this.uploadCourseTextFile(v, coursefoldername, course_id)
				prerequisite_knowledge_file = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + v.name;
			}
			else{
				if (course_basic_data.prerequisite_knowledge_file_actual !== "" ){
					await this.uploadCourseFile(course_basic_data.prerequisite_knowledge_file_actual, coursefoldername, course_id)
					prerequisite_knowledge_file = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + course_basic_data.prerequisite_knowledge_file_actual.name
				}
			}
		}else{
			prerequisite_knowledge_file = course_basic_data.prerequisite_knowledge_file_actual
		}
		////////////////////////////
		if (course_basic_data.add_to_carousal === 'on'){
			add_to_carousal = true
		}
		else{
			add_to_carousal = false
		}
		
		let lecture_id = 0; //// for lecture_id
		let lecture_worksheet_id = 0
		let concept = [];
		let modulefoldername = "modules"
		let lecturefoldername = "lectures"
		for (let i = 0; i < module.length; i++){
			console.log(module[i].lecture)
			let module_data;
			let lecture_data, exercise_data, lecture_video,lecture_note;
			let lecture_id_array, exercise_id_array;
			for (let j = 0; j<module[i].lecture.length; j++){
				let con_id, worked_out_worksheet_id;
				lecture_id = lecture_id + 1;
				/////////////////
				if(!module[i].lecture[j].lecture_video_actual.includes("https://")){
					await this.uploadLectureFile(module[i].lecture[j].lecture_video_actual, coursefoldername, course_id, modulefoldername, String(i+1), lecturefoldername, String(lecture_id))
					lecture_video = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + modulefoldername + "/" + String(i+1) + "/" + lecturefoldername + "/" + String(lecture_id) + "/"  + module[i].lecture[j].lecture_video_actual.name
				}else{
					lecture_video = module[i].lecture[j].lecture_video_actual
				}
				////////////////
				if(!module[i].lecture[j].lecture_note_actual.includes("https://")){
					if (module[i].lecture[j].lecture_note_actual !== "" ){
						await this.uploadLectureFile(module[i].lecture[j].lecture_note_actual, coursefoldername, course_id, modulefoldername, String(i+1), lecturefoldername, String(lecture_id))
						lecture_note = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + modulefoldername + "/" + String(i+1) + "/" + lecturefoldername + "/" + String(lecture_id) + "/"  + module[i].lecture[j].lecture_note_actual.name
					}
				}
				else{
					lecture_note = module[i].lecture[j].lecture_note_actual
				}
				if (module[i].lecture[j].lecture_worksheet.length > 0){
					let lec_worksheet;
					for (let lw = 0; lw<module[i].lecture[j].lecture_worksheet.length; lw++){
						lecture_worksheet_id =  lecture_worksheet_id + 1
						///////////
						if(!module[i].lecture[j].lecture_worksheet[lw].lec_worksheet_actual.includes("https://")){
							if (module[i].lecture[j].lecture_worksheet[lw].lec_worksheet_actual !== "" ){
								await this.uploadLectureFile(module[i].lecture[j].lecture_worksheet[lw].lec_worksheet_actual, coursefoldername, course_id, modulefoldername, String(i+1), lecturefoldername, String(lecture_id))
								lec_worksheet = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + modulefoldername + "/" + String(i+1) + "/" + lecturefoldername + "/" + String(lecture_id) + "/"  + module[i].lecture[j].lecture_worksheet[lw].lec_worksheet_actual.name
							}
						}
						else{
							lec_worksheet = module[i].lecture[j].lecture_worksheet[lw].lec_worksheet_actual
						}
						let worked_out_worksheet_format = {"worksheet_id":	lecture_worksheet_id, "worksheet": lec_worksheet}
						final_worked_out_worksheet.push(worked_out_worksheet_format)
						if (lw === 0){
							worked_out_worksheet_id = String(lecture_worksheet_id)
						}
						else{
							worked_out_worksheet_id = worked_out_worksheet_id + "|||" + String(lecture_worksheet_id)
						}
					}
				}
				if (module[i].lecture[j].concept.length > 0){
					let con_format;
					for (let k = 0; k<module[i].lecture[j].concept.length; k++){
						if (module[i].lecture[j].concept[k].concept_text_checkbox === true){
							c = c+1;
							module[i].lecture[j].concept[k].concept_id = c;
							if (k === 0){
								con_id = String(c);
							}
							else{
								con_id = con_id + "|||" + String(c)
							}
							con_format =  {"concept_id": c, "concept_text": module[i].lecture[j].concept[k].concept_text}
							final_concept.push(con_format);
						}
						else{
							for( let id = 0; id<existing_concept.length; id++){
								if(!concept.includes(module[i].lecture[j].concept[k].exixting_concept)){
									if(existing_concept[id].concept_text.trim() === module[i].lecture[j].concept[k].exixting_concept.trim()){
										if (k === 0){
											con_id = String(existing_concept[id].concept_id);
										}
										else{
											con_id = con_id + "|||" + existing_concept[id].concept_id;
										}
										con_format =  {"concept_id": existing_concept[id].concept_id, "concept_text": existing_concept[id].concept_text}
										final_concept.push(con_format);
										concept.push(module[i].lecture[j].concept[k].exixting_concept)
									}
								}
							}
						}
					}
				}
				else{
					con_id = 'None'
				}
				/*if (con_id.length > 0){
					for(let ll = 0; ll<con_id.length; ll++){
						module[i].lecture[j].concept_id_for_DB.push(con_id[ll]);
					}
				}*/
				let lecture = {"lecture_title": module[i].lecture[j].lecture_title, "lecture_id": lecture_id, "topic": module[i].lecture[j].topic, "concepts": con_id, "lecture_video": lecture_video, "lecture_note": lecture_note, "worksheets": worked_out_worksheet_id}
				if(j === 0){
					lecture_id_array = String(lecture_id)
				}
				else{
					lecture_id_array = lecture_id_array + "|||" + String(lecture_id)
				}
				final_lecture.push(lecture)
			}
			lecture_data = lecture_id_array
			let exercisefoldername = "exercises"
			if (module[i].exercise.length > 0){	/////// module level exercise
				let coo = 0;
				for (let j = 0; j<module[i].exercise.length; j++){
					let exercise;
					if (module[i].exercise[j].obj_exercise.length > 0){ //////////// objective exercise
						for (let k = 0; k<module[i].exercise[j].obj_exercise.length; k++){
							exercis_id = exercis_id + 1;
							let obj_exercise_format, question_type;
							let list_of_choices;
							let list_of_answers;
							if(module[i].exercise[j].obj_exercise[k].question_type === "Multiple Choice Question"){
								question_type = "mcq"
							}else{
								question_type = "fillup"
							}
							if (module[i].exercise[j].obj_exercise[k].choice_answer.length > 0){
								if(question_type === "mcq"){
									let cs = 0, as = 0;
									for (let l= 0; l<module[i].exercise[j].obj_exercise[k].choice_answer.length; l++){
										if(cs === 0){
											if (module[i].exercise[j].obj_exercise[k].choice_answer[l].is_it_an_answer === 'on'){
												list_of_choices = module[i].exercise[j].obj_exercise[k].choice_answer[l].choice_text
												list_of_answers = module[i].exercise[j].obj_exercise[k].choice_answer[l].choice_text
												cs = cs + 1
												as = as +1
											}
											else{
												list_of_choices = module[i].exercise[j].obj_exercise[k].choice_answer[l].choice_text
												cs = cs + 1
											}
										}else{
											if (module[i].exercise[j].obj_exercise[k].choice_answer[l].is_it_an_answer === 'on'){
												list_of_choices = list_of_choices + '|||' + module[i].exercise[j].obj_exercise[k].choice_answer[l].choice_text
												if(as === 0){
													list_of_answers = module[i].exercise[j].obj_exercise[k].choice_answer[l].choice_text
												}
												else{
													list_of_answers = list_of_answers + '|||' + module[i].exercise[j].obj_exercise[k].choice_answer[l].choice_text
												}
											}
											else{
												list_of_choices = list_of_choices + '|||' + module[i].exercise[j].obj_exercise[k].choice_answer[l].choice_text
											}
										}	
									}
								}else{
									let cs = 0;
									for (let l= 0; l<module[i].exercise[j].obj_exercise[k].choice_answer.length; l++){
										if(cs === 0){
											list_of_choices = module[i].exercise[j].obj_exercise[k].choice_answer[l].choice_text
											list_of_answers = module[i].exercise[j].obj_exercise[k].choice_answer[l].choice_text
											cs = cs + 1
										}else{
											list_of_choices = list_of_choices + '|||' + module[i].exercise[j].obj_exercise[k].choice_answer[l].choice_text
											list_of_answers = list_of_answers + '|||' + module[i].exercise[j].obj_exercise[k].choice_answer[l].choice_text
										}
									}
								}
							}
							let con_id;
							if (module[i].exercise[j].obj_exercise[k].concept.length > 0){
								let con_format;
								for (let l = 0; l<module[i].exercise[j].obj_exercise[k].concept.length; l++){
									if (module[i].exercise[j].obj_exercise[k].concept[l].concept_text_checkbox === true){
										c = c+1;
										module[i].exercise[j].obj_exercise[k].concept[l].concept_id = c;
										//con_id.push(c);
										if (l === 0){
											con_id = String(c);
										}
										else{
											con_id = con_id + "|||" + String(c)
										}
										con_format =  {"concept_id": c, "concept_text": module[i].exercise[j].obj_exercise[k].concept[l].concept_text}
										final_concept.push(con_format);
									}
									else{
										for( let id = 0; id<existing_concept.length; id++){
											if(existing_concept[id].concept_text.trim() === module[i].exercise[j].obj_exercise[k].concept[l].exixting_concept.trim()){
												if (l === 0){
													con_id = String(existing_concept[id].concept_id);
												}
												else{
													con_id = con_id + "|||" + existing_concept[id].concept_id
												}
												if(!concept.includes(module[i].exercise[j].obj_exercise[k].concept[l].exixting_concept)){
													con_format =  {"concept_id": existing_concept[id].concept_id, "concept_text": existing_concept[id].concept_text}
													final_concept.push(con_format);
													concept.push(module[i].exercise[j].obj_exercise[k].concept[l].exixting_concept)
												}
											}
										}
									}
								}
							}
							else{
								con_id = 'None'
							}
							obj_exercise_format = {"exercise_id": exercis_id, "question_type": question_type, "question_has_pdf": "false", "mcq_type": module[i].exercise[j].obj_exercise[k].mcq_type, "question_text": module[i].exercise[j].obj_exercise[k].question_text, "choice_has_pdf": "false",  "list_of_choices": list_of_choices, "list_of_answers" : list_of_answers, "concepts": con_id, "marks" : module[i].exercise[j].obj_exercise[k].obj_marks};
							console.log(obj_exercise_format)
							final_obj_exercise.push(obj_exercise_format);
							////console.log(obj_exercise_format, "obj_exercise_format")
							/*if (con_id.length > 0){
								for(let ll = 0; ll<con_id.length; ll++){
									module[i].exercise[j].obj_exercise[k].concept_id_for_DB.push(con_id[ll]);
								}
							}*/
							exercise = {"exercise_type": "objectiveExercise", "exercise_id": exercis_id}
							final_exercise.push(exercise)
							if(coo === 0){
								exercise_id_array = String(exercis_id)
								coo = 1
							}
							else{
								exercise_id_array = exercise_id_array + "|||" + String(exercis_id)
							}
						}
					}
					if (module[i].exercise[j].prog_exercise.length > 0){
						let prog_worksheet, prog_evaluation_fn;
						for (let k = 0; k<module[i].exercise[j].prog_exercise.length; k++){
							exercis_id = exercis_id + 1;
							///////////
							if(!module[i].exercise[j].prog_exercise[k].prog_worksheet_actual.includes("https://")){
								if (module[i].exercise[j].prog_exercise[k].prog_worksheet_actual !== "" ){
									await this.uploadExerciseFile(module[i].exercise[j].prog_exercise[k].prog_worksheet_actual, coursefoldername, course_id, modulefoldername, String(i+1), exercisefoldername, String(exercis_id))
									prog_worksheet = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + modulefoldername + "/" + String(i+1) + "/" + exercisefoldername + "/" + String(exercis_id) + "/"  + module[i].exercise[j].prog_exercise[k].prog_worksheet_actual.name
								}
							}
							else{
								prog_worksheet = module[i].exercise[j].prog_exercise[k].prog_worksheet_actual
							}
							///////////
							if(!module[i].exercise[j].prog_exercise[k].prog_evaluation_fn_actual.includes("https://")){
								if (module[i].exercise[j].prog_exercise[k].prog_evaluation_fn_actual !== "" ){
									await this.uploadExerciseFile(module[i].exercise[j].prog_exercise[k].prog_evaluation_fn_actual, coursefoldername, course_id, modulefoldername, String(i+1), exercisefoldername, String(exercis_id))
									prog_evaluation_fn = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + modulefoldername + "/" + String(i+1) + "/" + exercisefoldername + "/" + String(exercis_id) + "/"  + module[i].exercise[j].prog_exercise[k].prog_evaluation_fn_actual.name
								}
							}
							else{
								prog_evaluation_fn = module[i].exercise[j].prog_exercise[k].prog_evaluation_fn_actual
							}
							let prog_exercise_format;
							let datasets = [];
							if(module[i].exercise[j].prog_exercise[k].prog_datasets.length > 0){
								let prog_dataset;
								for (let l= 0; l<module[i].exercise[j].prog_exercise[k].prog_datasets.length; l++){
									///////////
									if(!module[i].exercise[j].prog_exercise[k].prog_datasets[l].prog_dataset_actual.includes("https://")){
										await this.uploadExerciseFile(module[i].exercise[j].prog_exercise[k].prog_datasets[l].prog_dataset_actual, coursefoldername, course_id, modulefoldername, String(i+1), exercisefoldername, String(exercis_id))
										prog_dataset = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + modulefoldername + "/" + String(i+1) + "/" + exercisefoldername + "/" + String(exercis_id) + "/"  + module[i].exercise[j].prog_exercise[k].prog_datasets[l].prog_dataset_actual.name
									}
									else{
										prog_dataset = module[i].exercise[j].prog_exercise[k].prog_datasets[l].prog_dataset_actual
									}
									datasets.push(prog_dataset)
								}
							}							
							let con_id;
							if (module[i].exercise[j].prog_exercise[k].concept.length > 0){
								let con_format;
								for (let l = 0; l<module[i].exercise[j].prog_exercise[k].concept.length; l++){
									if (module[i].exercise[j].prog_exercise[k].concept[l].concept_text_checkbox === true){
										c = c+1;
										module[i].exercise[j].prog_exercise[k].concept[l].concept_id = c;
										//con_id.push(c);
										if (l === 0){
											con_id = String(c);
										}
										else{
											con_id = con_id + "|||" + String(c)
										}
										con_format =  {"concept_id": c, "concept_text": module[i].exercise[j].prog_exercise[k].concept[l].concept_text}
										final_concept.push(con_format);
									}
									else{
										for( let id = 0; id<existing_concept.length; id++){
											if(existing_concept[id].concept_text.trim() === module[i].exercise[j].prog_exercise[k].concept[l].exixting_concept.trim()){
												if (l === 0){
													con_id = String(existing_concept[id].concept_id);
												}
												else{
													con_id = con_id + "|||" + existing_concept[id].concept_id
												}
												if(!concept.includes(module[i].exercise[j].prog_exercise[k].concept[l].exixting_concept)){
													con_format =  {"concept_id": existing_concept[id].concept_id, "concept_text": existing_concept[id].concept_text}
													final_concept.push(con_format);
													concept.push(module[i].exercise[j].prog_exercise[k].concept[l].exixting_concept)
												}
											}
										}
									}
								}
							}
							else{
								con_id = 'None'
							}
							prog_exercise_format = {"exercise_id": exercis_id, "marks": module[i].exercise[j].prog_exercise[k].prog_marks, "worksheet": prog_worksheet, "evaluation_fn": prog_evaluation_fn, "datasets": datasets, "concepts": con_id};
							final_prog_exercise.push(prog_exercise_format);
							/*if (con_id.length > 0){
								for(let ll = 0; ll<con_id.length; ll++){
									module[i].exercise[j].prog_exercise[k].concept_id_for_DB.push(con_id[ll]);
								}
							}*/
							exercise = {"exercise_type": "progExercise", "exercise_id": exercis_id}
							final_exercise.push(exercise)
							if(coo === 1){
								exercise_id_array = exercise_id_array + "|||" + String(exercis_id)
							}
							else{
								exercise_id_array = String(exercis_id)
								coo = 1
							}
							console.log("prog", exercise_id_array)
						}
					}
				}
				exercise_data = exercise_id_array
			}
			else{
				exercise_data = "None"
			}
			if(i === 0){
				module_id_array = String(i+1)
			}
			else{
				module_id_array = module_id_array + "|||" + String(i + 1)
			}
			module_data = { "module_title": module[i].module_title, "module_id": module_id_array, "lecture": lecture_data, "exercise": exercise_data}
			final_module.push(module_data)
		}
		let ins_id = 0
		let instructorfoldername = "instructor"
		for (let i = 0; i<instructor.length; i++){
			ins_id = ins_id + 1;
			let designation, profile, final_array;
			///////////
			if(!instructor[i].instructor_designation_actual.includes("https://")){
				if (instructor[i].instructor_designation_text_on){
					let v = {"name": instructor[i].instructor_name + "_designation" + ".txt", "type": "text/plain", "data" : instructor[i].instructor_designation_text}
					await this.uploadInstructorTextFile(v, coursefoldername, course_id, instructorfoldername, ins_id)
					designation = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + instructorfoldername + "/" + ins_id + "/" + v.name;
				}
				else{
					if (instructor[i].instructor_designation_actual !== "" ){
						await this.uploadInstructorFile(instructor[i].instructor_designation_actual, coursefoldername, course_id, instructorfoldername, ins_id)
						designation = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + instructorfoldername + "/" + ins_id + "/" + instructor[i].instructor_designation_actual.name
					}
				}
			}else{
				designation = instructor[i].instructor_designation_actual
			}
			///////////
			if(!instructor[i].instructor_profile_actual.includes("https://")){
				if (instructor[i].instructor_profile_text_on){
					let v = {"name": instructor[i].instructor_name + "_profile" + ".txt", "type": "text/plain", "data" : instructor[i].instructor_profile_text}
					await this.uploadInstructorTextFile(v, coursefoldername, course_id, instructorfoldername, ins_id)
					profile = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + instructorfoldername + "/" + ins_id + "/" + v.name;
				}
				else{
					if (instructor[i].instructor_profile_actual !== "" ){
						await this.uploadInstructorFile(instructor[i].instructor_profile_actual, coursefoldername, course_id, instructorfoldername, ins_id)
						profile = AwsConfigForUploadCourseDetails.s3BucketAddr + coursefoldername + "/" + course_id + "/" + instructorfoldername + "/" + ins_id + "/" + instructor[i].instructor_profile_actual.name
					}
				}
			}
			else{
				profile = instructor[i].instructor_profile_actual
				console.log(instructor[i].instructor_profile_actual)
			}
			if(i === 0){
				instructor_id_array = String(ins_id+1)
			}
			else{
				instructor_id_array = instructor_id_array + "|||" + String(ins_id + 1)
			}
			final_array = { "id" : instructor_id_array, "name" : instructor[i].instructor_name, "designation": designation, "profile": profile}
			final_instructor.push(final_array);
		}
		
		course_basic_data.module = module_id_array;
		course_basic_data.instructor = instructor_id_array;
		let course_excel_data
		course_excel_data = {'add_to_carousal': add_to_carousal, 'course_title' : course_basic_data.course_title, 'course_short_name': course_basic_data.course_short_name, 'course_description': course_description, 'course_intro_video': course_video, 'advertisement_image_file': course_adv, 'card_image_file': course_card, 'prerequisite_preexisting_course_title_list': course_basic_data.prerequisite_preexisting_course, 'prerequisite_knowledge_file': prerequisite_knowledge_file, 'created_on': course_basic_data.created_on, 'communication_language': course_basic_data.communication_language, 'reference_material_file': reference_material_file, 'credit': course_basic_data.credit, 'duration_in_min': course_basic_data.duration_in_min, 'offering_period_from_to': course_basic_data.offering_period__from_to, 'copyright_message': copyright_message, 'module': course_basic_data.module, 'instructor': course_basic_data.instructor}
		final_course.push(course_excel_data)
		finalarraysubmission = true;
		this.setState({ common_fields : course_basic_data})
		this.setState({ final_course : final_course})
		this.setState({final_concept: final_concept});
		this.setState({final_exercise: final_exercise});
		this.setState({final_obj_exercise: final_obj_exercise});
		this.setState({final_prog_exercise: final_prog_exercise});
		this.setState({final_worked_out_worksheet: final_worked_out_worksheet});
		this.setState({final_instructor: final_instructor});
		this.setState({final_module: final_module});
		this.setState({final_lecture: final_lecture});
		this.setState({module: module});
		this.setState({ finalarraysubmission : finalarraysubmission})
	}
	////////////////////////////////////////////////////////////////////////////////////////

  //// Prerequisite Preexisting course
  createPrerequisitepreexistingcourseUI(){
     return this.state.prerequisite_preexisting_course.map((el, i) => (
       <left key={i}>
		<div>
			<br />
			<Card style={{ width: '60%', height: '100%' }} key={i}>
				<Card.Body>
				<Form className="text-left" onChange={this.handleChangePrerequisitepreexistingcourse.bind(this, i)}>
					<Form.Row>
						<Form.Group as={Col} controlId="formBasicName">
							<Form.Control as="select" name="course_title_name" value={el.course_title_name}>
								<option>select..</option>
								{this.state.existing_course.map((course) => <option key={course.course_id}>{course.course_title}</option>
								)
								}
							</Form.Control>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ el.eror_in_course_title_name}
							</Form.Text>
					</Form.Group>
					<Form.Group as={Col} controlId="formBasicButton">
						<BsFillTrashFill style={{color:"gray", fontSize:20}} onClick={this.deletePrerequisitepreexistingcourse.bind(this, i)} />
						</ Form.Group>
					</ Form.Row>
				</Form>
				</Card.Body>
			</Card>
    	  </div> 
	   </left>
     ))
  }
  addPrerequisitepreexistingcourse=(e)=>{
	  e.preventDefault();
	  this.setState(prevState=>({
		  prerequisite_preexisting_course: [...prevState.prerequisite_preexisting_course, {course_title_name: ""}]
		  
	  }))
  }
  handleChangePrerequisitepreexistingcourse(i, e) {
     const { name, value } = e.target;
     let prerequisite_preexisting_course = [...this.state.prerequisite_preexisting_course];
     prerequisite_preexisting_course[i] = {...prerequisite_preexisting_course[i], [name]: value};
     this.setState({ prerequisite_preexisting_course });
  }
  deletePrerequisitepreexistingcourse=(i)=>{
	 let prerequisite_preexisting_course = [...this.state.prerequisite_preexisting_course];
     prerequisite_preexisting_course.splice(i, 1);
     this.setState({ prerequisite_preexisting_course });
  }
  ///////////////////////////////////  
  //// Create Module
  
  createModuleUI(){
     return this.state.module.map((el, i) => (
       <center key={i}>
		<div>
			<br />
			<Card style={{ width: '100%', height: '100%' }} key={i}>
				<Card.Body>
					<Form className="text-left" onChange={this.handleChangeModule.bind(this, i)}>
						<Form.Group controlId="formBasicID">
							<Form.Label>Module Title</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenModuleTitle: true})} onMouseLeave={(e) => this.setState({isOpenModuleTitle: false})}/>
							<Form.Control type="text"  value={el.module_title}  name='module_title' placeholder="eg. python pandas" />
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ el.error_in_title}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenModuleTitle} target={'module_title'}/>
						</Form.Group>
						{this.createLectureUI(i)}
						<br/>
						<button className="btn btn-info " style={{ width: '15%'}} onClick={this.addLecture.bind(this, i)}> + Lecture </button> {'\u00A0'}{'\u00A0'}
						<br/><Form.Text className="text-muted-red" style={{ color: 'red' }}>{ el.no_data_on_module_lecture }</Form.Text>
						<br/>
						<hr />
						{this.createExerciseUI(i)}
						<br/>
						<button className="btn btn-info " style={{ width: '15%'}} onClick={this.addExercise.bind(this, i)}> + Exercise </button> {'\u00A0'}{'\u00A0'}
					</Form>
					<footer className="text-right">
						<button className="btn btn-info" style={{ width: '15%'}} onClick={this.deleteModule.bind(this, i)}>- Module</button>
					</footer>
				</Card.Body>
			</Card>
    	  </div> 
	   </center>
     ))
  }
  
  addModule=(e)=>{
	  e.preventDefault();
	  this.setState(prevState=>({
		  module: [...prevState.module, { module_title: "", lecture: [], exercise: [] }]
		  
	  }))
  }
  handleChangeModule(i, e) {
     const { name, value } = e.target;
     let module = [...this.state.module];
     module[i] = {...module[i], [name]: value};
     this.setState({ module });
  }
  deleteModule=(i, e)=>{
	 e.preventDefault();
	 let module = [...this.state.module];
     module.splice(i, 1);
     this.setState({ module });
  }
  ////////////////////////////////////////////////////////////
  
  ////////////////////////////////////////////////////////////
  //// Create Lecture
  createLectureUI(j){
     return this.state.module[j].lecture.map((el, i) => (
       <center key={i}>
		<div>
		<br />
			<Card style={{ width: '100%', height: '100%' }} key={i}>
				<Card.Body>
					
					<Form className="text-left" onChange={this.handleChangeLecture.bind(this, i, j)}>
						<Form.Row>
						<Form.Group as={Col} controlId="formBasicID">
							<Form.Label>Lecture Title</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenLectureTitle: true})} onMouseLeave={(e) => this.setState({isOpenLectureTitle: false})}/>
							<Form.Control type="text"  value={el.lecture_title}  name='lecture_title' placeholder="eg. python pandas" />
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ el.error_in_title}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenLectureTitle} target={'lecture_title'}/>
						</Form.Group>
						<Form.Group as={Col} controlId="formBasicID">
							<Form.Label>Lecture Topic</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenLectureTopic: true})} onMouseLeave={(e) => this.setState({isOpenLectureTopic: false})}/>
							<Form.Control type="text"  value={el.topic}  name='topic' placeholder="eg. Dummy topic" />
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ el.error_in_topic}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenLectureTopic} target={'lecture_topic'}/>
						</Form.Group>
						</Form.Row>
						<Form.Row>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<Form.Label>Lecture  Video</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenLectureVideo: true})} onMouseLeave={(e) => this.setState({isOpenLectureVideo: false})}/>
							<Form.File 
								type="file" 
								id="custom-lecture_video"
								label={el.lecture_video !== "" ? el.lecture_video: "lecture video" }
								name="lecture_video"
								custom
							/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ el.error_in_video}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenLectureVideo} target={'lecture_video'}/>
						</Form.Group>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<Form.Label>Lecture Note</Form.Label>{'\u00A0'}{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenLectureNote: true})} onMouseLeave={(e) => this.setState({isOpenLectureNote: false})}/>
							<Form.File 
								type="file" 
								id="custom-lecture_note"
								label={el.lecture_note !== "" ? el.lecture_note: "lecture note" }
								name="lecture_note"
								custom
							/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ el.error_in_note}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenLectureNote} target={'lecture_note'}/>
						</Form.Group>
						</Form.Row>
						<Form.Group controlId="formBasicFileUpload">
							<Form.Label>Worked Out Worksheet</Form.Label>{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenLectureWorksheet: true})} onMouseLeave={(e) => this.setState({isOpenLectureWorksheet: false})}/>
							<SimpleDialog isOpen={this.state.isOpenLectureWorksheet} target={'lecture_worksheet'}/>
						</Form.Group>
						{this.createlecWorksheetSetUI(j, i)}
						<button className="btn btn-info " style={{ width: '15%'}} onClick={this.addlecWorksheetSet.bind(this, i, j)}>+ Worksheet </button> {'\u00A0'}{'\u00A0'}
						<br/>
						<br/>
						{this.createConceptUI(j, i)}
						<br/>
						<br/>
						<button className="btn btn-info " style={{ width: '15%'}} onClick={this.addConcept.bind(this, i, j)}> + Concept </button> {'\u00A0'}{'\u00A0'}
						<br/><Form.Text className="text-muted-red" style={{ color: 'red' }}>{ el.no_data_on_lecture_concept }</Form.Text>
					</Form>
					<footer className="text-right">
						<button className="btn btn-info" style={{ width: '15%'}} onClick={this.deleteLecture.bind(this, i, j)}>- Lecture</button>
					</footer>
				</Card.Body>
			</Card>
    	  </div> 
	   </center>
     ))
  }
  
  addLecture=(i, e)=>{
	  e.preventDefault();
	  let newLecture = { lecture_title: "", topic: "",	lecture_video: "", lecture_video_actual: "", lecture_note: "", lecture_note_actual: "", lecture_worksheet: [], concept: [], concept_id_for_DB: []};
	  let module = this.state.module;
	  module[i].lecture.push(newLecture);
	  this.setState({module:module})//, ()=>{
	  
  }
  handleChangeLecture(i, j, e) {
     const { name, value } = e.target;
     let module = this.state.module;
	 if(e.target.type === "file"){
		 module[j].lecture[i] = {...module[j].lecture[i], [name + "_actual"]: e.target.files[0]};
		 module[j].lecture[i] = {...module[j].lecture[i], [name]: e.target.files[0].name};
	  }else{
		module[j].lecture[i] = {...module[j].lecture[i], [name]: value};        
      }
     this.setState({ module : module});
  }
  deleteLecture=(i, j, e)=>{
	 e.preventDefault();
	 let module = this.state.module;
     module[j].lecture.splice(i, 1);
     this.setState({ module : module});
  }
  ////////////////////////////////////////////////////////////
  handleCectureConceptCheckbox(i, j, k, e){
	  let concept = this.state.module[j].lecture[k].concept
	  concept[i].concept_text_checkbox = e.target.checked;
	  this.setState({concept})
  }
  //// Create lecture Concept
  createConceptUI(j, k){
     return this.state.module[j].lecture[k].concept.map((el, i) => (
       <center key={i}>
		<div>
			<br />
			<Card style={{ width: '100%', height: '100%' }} >
				<Card.Body>
					<Form className="text-left" onChange={this.handleChangeConcept.bind(this, i, j, k)}>
						<Form.Row>
							<Form.Group as={Col}  xs={5} controlId="formBasicName">
								<Form.Label>Concept Text</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenConceptText: true})} onMouseLeave={(e) => this.setState({isOpenConceptText: false})}/>
								{/*<Form.Control as="select" name="exixting_concept" disabled={el.concept_text_checkbox} value = {el.exixting_concept} placeholder="Select concept from our database">
									<option>Select concept from our database</option>
									{this.state.user_saved_course.map((a) => <option >{a.exixting_concept}</option>)}
									<hr />
									{this.state.existing_concept.map((a) => <option key={a.concept_id}>{a.concept_text}</option>)}
									<hr />
									{this.state.save_concepts.map((a) => <option key={a.concept_id}>{a.concept_text}(From save concept)</option>)}
									</Form.Control>*/}
								<Select options={this.state.concept_data} 
									filterOptions={createFilterOptions({
										labelKey: 'label',
										options: this.state.concept_data
	  								})} 
									name = "exixting_concept" disabled={el.concept_text_checkbox} value = {el.exixting_concept + ",Hello"} placeholder="Select concept from our database" 
								/>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
							 		{ el.error_in_existing_concept}
								</Form.Text>
								<SimpleDialog isOpen={this.state.isOpenConceptText} target={'concept_text'}/>
							</Form.Group>
							<Form.Group as={Col} xs="auto" controlId="formBasicFileUpload" >
								<br/>
								<br/>
								{'\u00A0'}{'\u00A0'}{'\u00A0'}<Form.Label>OR</Form.Label>
							</Form.Group>
							<Form.Group as={Col} xs="auto" controlId="formBasicFileUpload">
								<br/>
								<br/>
								<Form.Check type="checkbox" onChange={this.handleCectureConceptCheckbox.bind(this, i, j, k)} checked={el.concept_text_checkbox} label="Add a Concept" name= "exixting_concept_check" id= "exixting_concept_check"/>
							</Form.Group>
							{el.concept_text_checkbox === true ? (
							<Form.Group as={Col} controlId="formBasicIDlec_concept_text">
								<br/>
								<Form.Control type="text" style={{ width: '100%'}} value={el.concept_text}  name='concept_text' placeholder="eg. cover python..." id = "lec_concept_text" disabled={!el.concept_text_checkbox}/>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_concept_text}
								</Form.Text>
							</Form.Group>
						) : null}
						</Form.Row>
					</Form>
					<footer className="text-right">
						<button className="btn btn-info" style={{ width: '15%'}} onClick={this.deleteConcept.bind(this, i, j, k)}>- Concept</button>
					</footer>
				</Card.Body>
			</Card>
    	  </div> 
	   </center>
     ))
  }
    
  addConcept=(i, j, e)=>{
	  e.preventDefault();
	  let newConcept = {concept_text: "", exixting_concept: "", concept_text_checkbox: false, concept_id: ""};
	  let module = this.state.module;
	  module[j].lecture[i].concept.push(newConcept);
	  this.setState({module:module})
  }
  handleChangeConcept(i, j, k, e) {
     const { name, value } = e.target;
	 let user = this.state.user;
	 let concept = this.state.module[j].lecture[k].concept;
	 let user_saved_course = this.state.user_saved_course;
	 concept[i] = {...concept[i], [name]: value};
	 if(name === "exixting_concept"){
	 	if(!user.includes(value)){
			user.push(value)
			user_saved_course.push({[name]: value})
	 	}
	 }
     this.setState({ concept });
	 this.setState({ user });
	 this.setState({ user_saved_course })
  }
  deleteConcept=(i, j, k, e)=>{
	 e.preventDefault();
	 let concept = this.state.module[j].lecture[k].concept;
     concept.splice(i, 1);
     this.setState({ concept });
  }
  /////////////////////////////////////////////
  
   createlecWorksheetSetUI(j, k){
     return this.state.module[j].lecture[k].lecture_worksheet.map((el, i) => (
       <center key={i}>
		<div>
					<Form className="text-left" onChange={this.handleChangelecWorksheetSet.bind(this, i, j, k)}>
						<Form.Row>
							<Form.Group as={Col} controlId="formBasicFileUpload">
								<Form.File 
									id="custom-lec_worksheet"
									type="file"
									label={el.lec_worksheet !== "" ? el.lec_worksheet: "lecture worksheet" } 
									name="lec_worksheet"
									custom
								/>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ el.error_in_worksheet}
							</Form.Text>
							</Form.Group>
							<Form.Group as={Col} controlId="formBasicButton">
								<BsFillTrashFill style={{color:"gray", fontSize:20}} onClick={this.deletelecWorksheetSet.bind(this, i, j, k)} />
							</ Form.Group>
						</ Form.Row>
					</Form>
					<footer className="text-right">
						
					</footer>
    	  </div> 
	   </center>
     ))
  }
    
  addlecWorksheetSet=(i, j, e)=>{
	  e.preventDefault();
	  let newLecWorksheet = {lec_worksheet: "", lec_worksheet_actual: ""};
	  let module = this.state.module;
	  module[j].lecture[i].lecture_worksheet.push(newLecWorksheet);
	  this.setState({module:module})
  }
  handleChangelecWorksheetSet(i, j, k, e) {
     const { name, value } = e.target;
     let lecture_worksheet = this.state.module[j].lecture[k].lecture_worksheet;
	 if(e.target.type === "file"){
		 lecture_worksheet[i] = {...lecture_worksheet[i], [name + "_actual"]: e.target.files[0]};
		 lecture_worksheet[i] = {...lecture_worksheet[i], [name]: e.target.files[0].name};
	  }else{
		lecture_worksheet[i] = {...lecture_worksheet[i], [name]: value};        
      }
     this.setState({ lecture_worksheet : lecture_worksheet });
  }
  deletelecWorksheetSet=(i, j, k, e)=>{
	 e.preventDefault();
	 let lecture_worksheet = this.state.module[j].lecture[k].lecture_worksheet;
     lecture_worksheet.splice(i, 1);
     this.setState({ lecture_worksheet });
  }
  ///////////////////////////////////
  //// exercise
  createExerciseUI(j){
     return this.state.module[j].exercise.map((el, i) => (
       <center key={i}>
		<div>
			<br />
				<Form className="text-left" >
					<Form.Row>
						<Form.Group as={Col} controlId="formBasicCheckbox">
							<Form.Check type="radio" id="checkbox" onClick = {this.addObjExercise.bind(this, i, j)} label="Objective Exercise Question" disabled={el.obj_exercise_checkbox}/>
						</Form.Group>
						<Form.Group as={Col} controlId="formBasicCheckbox">
							<Form.Check type="radio" onClick = {this.addProgExercise.bind(this, i, j)} label="Program Exercise Question" disabled={el.prog_exercise_checkbox}/>
						</Form.Group>
					</Form.Row>
					{this.createObjExerciseUI(j,i)}
					{this.createProgExerciseUI(j,i)}
					<br />
				</Form>
					<footer className="text-right">
						<button className="btn btn-info" style={{ width: '15%'}} onClick={this.deleteExercise.bind(this, i, j)}>- Exercise</button>
					</footer>
    	  </div> 
	   </center>
     ))
  }
  addExercise=(i, e)=>{
	  e.preventDefault();
	  let newExercise = {obj_exercise: [], prog_exercise: [], obj_exercise_checkbox: false, prog_exercise_checkbox: false};
	  let module = this.state.module;
	  module[i].exercise.push(newExercise);
	  this.setState({module:module})
  }
  deleteExercise=(i, j, e)=>{
	 e.preventDefault();
	 let exercise = this.state.module[j].exercise;
     exercise.splice(i, 1);
     this.setState({ exercise });
  }
  ////////////////////////////////////
  //// Object Exercise
  createObjExerciseUI(j,k){
     return this.state.module[j].exercise[k].obj_exercise.map((el, i) => (
       <center key={i}>
		<div>
			<br />
			<Card style={{ width: '100%', height: '100%' }} >
				<Card.Body>
				<Form className="text-left" onChange={this.handleChangeObjExercise.bind(this, i, j, k)} >
						<Form.Row>
							<Form.Group as={Col} controlId="exampleForm.ControlSelect1">
								<Form.Label>Question Type</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenObjQueType: true})} onMouseLeave={(e) => this.setState({isOpenObjQueType: false})}/>
								<Form.Control as="select" name="question_type" defaultValue="Select.." value={el.question_type}>
									<option>Select..</option>
									<option>Multiple Choice Question</option>
									<option>Filling the Blanks</option>
								</Form.Control>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_question_type}
								</Form.Text>
								<SimpleDialog isOpen={this.state.isOpenObjQueType} target={'question_type'}/>
							</Form.Group>
							{el.question_type === "Multiple Choice Question" ? (<Form.Group as={Col} controlId="exampleForm.ControlSelect2">
								<Form.Label>MCQ Type</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenObjMCQType: true})} onMouseLeave={(e) => this.setState({isOpenObjMCQType: false})}/>
								<Form.Control as="select" name="mcq_type" defaultValue="Select.." value={el.mcq_type}>
									<option>Select..</option>
									<option>singlechoice</option>
									<option>multichoice</option>
								</Form.Control>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_mcq_type}
								</Form.Text>
								<SimpleDialog isOpen={this.state.isOpenObjMCQType} target={'mcq_type'}/>
								</Form.Group>
							): null}
							<Form.Group as={Col} controlId="formBasicMarks">
								<Form.Label>Mark</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenObjQueMarks: true})} onMouseLeave={(e) => this.setState({isOpenObjQueMarks: false})}/>
								<Form.Control type="number" name="obj_marks" placeholder="Like 20" value={el.obj_marks}/>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_obj_marks}
								</Form.Text>
								<SimpleDialog isOpen={this.state.isOpenObjQueMarks} target={'obj_marks'}/>
							</Form.Group>
						</Form.Row>
						<Form.Group controlId="formBasicQuestion">
							<Form.Label>Question Text</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenObjQueText: true})} onMouseLeave={(e) => this.setState({isOpenObjQueText: false})}/>
							<Form.Control type="text" name="question_text" placeholder="Question text......." value={el.question_text}/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_question_text}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenObjQueText} target={'question_text'}/>
						</Form.Group>
						{el.question_type === "Multiple Choice Question" || el.question_type === "Filling the Blanks"? (
							<Form.Group as={Col} controlId="formBasicConceptsID">
								<Form.Label>Choices</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenObjQueChoices: true})} onMouseLeave={(e) => this.setState({isOpenObjQueChoices: false})}/>
								<SimpleDialog isOpen={this.state.isOpenObjQueChoices} target={'obj_choices'}/>
							</Form.Group>
						): null}
						{this.createobjChoicesUI(j, k, i)}
						{el.question_type === "Multiple Choice Question" || el.question_type === "Filling the Blanks"? (
						<button className="btn btn-info " style={{ width: '15%'}} onClick={this.addobjChoices.bind(this, i, j, k)} disabled ={this.state.module[j].exercise[k].obj_exercise[i].choice_answer.length <5? false : true }> + Choices </button>) : null} {'\u00A0'}{'\u00A0'}
						<Form.Text className="text-muted-red" style={{ color: 'red' }}>
							{ el.no_data_on_obj_choice_answer}
						</Form.Text>
						<br/>
						{this.createobjConceptUI(j, k, i)}
						<br/>
						<br/>
						<button className="btn btn-info " style={{ width: '15%'}} onClick={this.addobjConcept.bind(this, i, j, k)}> + Concept </button> {'\u00A0'}{'\u00A0'}							
						<Form.Text className="text-muted-red" style={{ color: 'red' }}>
							{ el.no_data_on_obj_concept}
						</Form.Text>
					</Form>
					{/*<footer className="text-right">
						<button className="btn btn-info" style={{ width: '15%'}} onClick={this.deleteObjExercise.bind(this, i, j, k)}>- Objective</button>
						</footer>*/}
					</Card.Body>
			</Card>
    	  </div> 
	   </center>
     ))
  }
  
  addObjExercise=(i, j, e)=>{
	e.preventDefault();
	let newObjExercise = {question_type: "", question_has_pdf: "", mcq_type: "", question_text: "", choice_has_pdf: "",  obj_marks: "", choice_answer: [], concept: [], concept_id_for_DB: [] };
	let module = this.state.module;
	module[j].exercise[i].obj_exercise.push(newObjExercise);
	module[j].exercise[i].obj_exercise_checkbox = true;
	module[j].exercise[i].prog_exercise_checkbox = true;
	this.setState({module:module});
	 
  }
   handleChangeObjExercise(i, j, k, e) {
     const { name, value } = e.target;
	 let obj_exercise = this.state.module[j].exercise[k].obj_exercise;
     obj_exercise[i] = {...obj_exercise[i], [name]: value};
     this.setState({ obj_exercise });
  }
  /*deleteObjExercise=(i, j, k, e)=>{
	 e.preventDefault();
	 let obj_exercise = this.state.module[j].exercise[k].obj_exercise;
	 let module = this.state.module;
     module[j].exercise[k].obj_exercise_checkbox = false;
	 module[j].exercise[k].prog_exercise_checkbox = false;
	 obj_exercise.splice(i, 1);
     this.setState({ obj_exercise });
	 this.setState({module:module});
  }*/
  //////////////////////////////////////////////////
  handObjConceptCheckbox(i, j, k, l, e){
	  let concept = this.state.module[j].exercise[k].obj_exercise[l].concept
	  concept[i].concept_text_checkbox = e.target.checked;
	  this.setState({concept})
  }
  //// Create object Concept
  createobjConceptUI(j, k, l){
     return this.state.module[j].exercise[k].obj_exercise[l].concept.map((el, i) => (
       <center key={i}>
		<div>
			<br />
			<Card style={{ width: '100%', height: '100%' }} >
				<Card.Body>
					<Form className="text-left" onChange={this.handleChangeobjConcept.bind(this, i, j, k, l)}>
						
						<Form.Row>
							<Form.Group as={Col} xs={5} controlId="formBasicName">
								<Form.Label>Concept Text</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}}/>
								{/*<Form.Control as="select" name="exixting_concept" disabled={el.concept_text_checkbox} value = {el.exixting_concept} defaultValue="Select concept from our database">
									<option>Select concept from our database</option>
									{this.state.user_saved_course.map((a) => <option >{a.exixting_concept}</option>)}
									<hr />
									{this.state.existing_concept.map((a) => <option key={a.concept_id}>{a.concept_text}</option>)}
									<hr />
									{this.state.save_concepts.map((a) => <option key={a.concept_id}>{a.concept_text}(From save concept)</option>)}
	 							</Form.Control>*/}
								<Select options={this.state.concept_data} 
									filterOptions={createFilterOptions({
										labelKey: 'label',
										options: this.state.concept_data
	  								})} 
									name="exixting_concept" disabled={el.concept_text_checkbox} value = {el.exixting_concept} placeholder="Select concept from our database" 
								/>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_existing_concept}
								</Form.Text>
						</Form.Group>
						<Form.Group as={Col} xs="auto" controlId="formBasicFileUpload" >
							<br/>
							<br/>
							{'\u00A0'}{'\u00A0'}{'\u00A0'}<Form.Label>OR</Form.Label>
						</Form.Group>
						<Form.Group as={Col} xs="auto" controlId="formBasicFileUpload">
							<br/>
							<br/>
							<Form.Check type="checkbox" onChange={this.handObjConceptCheckbox.bind(this, i, j, k, l)} checked={el.concept_text_checkbox} label="Add a Concept" name= "exixting_concept_check" id= "exixting_concept_check"/>
						</Form.Group>
						{el.concept_text_checkbox === true ? (
							<Form.Group as={Col} controlId="formBasicID">	
								<br/>
								<Form.Control type="text" style={{ width: '100%'}} value={el.concept_text}  name='concept_text' placeholder="eg. cover python..." disabled={!el.concept_text_checkbox} />
							</Form.Group>
						) : null}
						</Form.Row>
					</Form>
					<footer className="text-right">
						<button className="btn btn-info" style={{ width: '15%'}} onClick={this.deleteobjConcept.bind(this, i, j, k, l)}>- Concept</button>
					</footer>
				</Card.Body>
			</Card>
    	  </div> 
	   </center>
     ))
  }
    
  addobjConcept=(i, j, k, e)=>{
	  e.preventDefault();
	  let newConcept = {concept_text: "", existing_concept: "", concept_text_checkbox: false, concept_id: ""};
	  let module = this.state.module;
	  module[j].exercise[k].obj_exercise[i].concept.push(newConcept);
	  this.setState({module:module})
  }
  handleChangeobjConcept(i, j, k, l,e) {
     const { name, value } = e.target;
	 let user = this.state.user;
     let concept = this.state.module[j].exercise[k].obj_exercise[l].concept;
     let user_saved_course = this.state.user_saved_course;
     concept[i] = {...concept[i], [name]: value};
	 if(name === "exixting_concept"){
		if(!user.includes(value)){
		   user.push(value)
		   user_saved_course.push({[name]: value})
		}
	}
     this.setState({ concept });
	 this.setState({ user });
	 this.setState({ user_saved_course })
  }
  deleteobjConcept=(i, j, k, l, e)=>{
	 e.preventDefault();
	 let concept = this.state.module[j].exercise[k].obj_exercise[l].concept;;
     concept.splice(i, 1);
     this.setState({ concept });
  }
  
   //// Create object choices
   handleObjChoiceCheckbox(j, k, l, i, e){
	   let module = this.state.module
	   module[j].exercise[k].obj_exercise[l].choice_answer[i].is_it_an_answer_checkbox = e.target.checked
    	this.setState({module : module})
  }
  createobjChoicesUI(j, k, l){
     return this.state.module[j].exercise[k].obj_exercise[l].choice_answer.map((el, i) => (
       <center key={i}>
		<div>
					<Form className="text-left" onChange={this.handleChangeobjChoices.bind(this, i, j, k, l)}>
						
						<Form.Row>
							<Form.Group as={Col} controlId="formBasicConceptsID">
								<Form.Control type="text" name="choice_text" placeholder="Like Pandas" value = {el.choice_text}/>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_choice_text}
								</Form.Text>
							</Form.Group>
							{this.state.module[j].exercise[k].obj_exercise[l].question_type === "Multiple Choice Question"? (
								<Form.Group as={Col} controlId="formBasicConceptsID">
									<Form.Check type="checkbox" label="Answer" name="is_it_an_answer" id="formHorizontalRadios1" onChange={this.handleObjChoiceCheckbox.bind(this, j, k, l, i)} checked={el.is_it_an_answer_checkbox}/>
									<Form.Text className="text-muted-red" style={{ color: 'red' }}>
										{ el.error_in_is_it_an_answer}
									</Form.Text>
								</Form.Group>
							): null}
							<Form.Group as={Col} controlId="formBasicButton">
								<BsFillTrashFill style={{color:"gray", fontSize:20}} onClick={this.deleteobjChoices.bind(this, i, j, k, l)} />
							</ Form.Group>
						</ Form.Row>
							
					</Form>
    	  </div> 
	   </center>
     ))
  }
    
  addobjChoices=(i, j, k, e)=>{
	  e.preventDefault();
	  let newChoice_answer = {choice_text: "", is_it_an_answer: "", is_it_an_answer_checkbox: false};
	  let module = this.state.module;
	  module[j].exercise[k].obj_exercise[i].choice_answer.push(newChoice_answer);
	  this.setState({module:module})
  }
  handleChangeobjChoices(i, j, k, l,e) {
     const { name, value } = e.target;
     let choice_answer = this.state.module[j].exercise[k].obj_exercise[l].choice_answer;
     choice_answer[i] = {...choice_answer[i], [name]: value};
     this.setState({ choice_answer });
  }
  deleteobjChoices=(i, j, k, l, e)=>{
	 e.preventDefault();
	 let choice_answer = this.state.module[j].exercise[k].obj_exercise[l].choice_answer;
     choice_answer.splice(i, 1);
     this.setState({ choice_answer });
  }
   ////////////////////////////////////
  //// Program Exercise
  createProgExerciseUI(j, k){
     return this.state.module[j].exercise[k].prog_exercise.map((el, i) => (
       <center key={i}>
		<div>
			<br />
			<Card style={{ width: '100%', height: '100%' }} >
				<Card.Body>
				<Form className="text-left" onChange={this.handleChangeProgExercise.bind(this, i, j, k)}>
					<Form.Row>
							<Form.Group as={Col} controlId="formBasicMarks">
								<Form.Label>Mark</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenProgMark: true})} onMouseLeave={(e) => this.setState({isOpenProgMark: false})}/>
								<Form.Control type="number" name="prog_marks" placeholder="Like 20" value={el.prog_marks}/>
								<SimpleDialog isOpen={this.state.isOpenProgMark} target={'prog_marks'}/>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_prog_marks}
								</Form.Text>
							</Form.Group>							
						
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<Form.Label>Program Worksheet</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenProgWorksheet: true})} onMouseLeave={(e) => this.setState({isOpenProgWorksheet: false})}/>
							<Form.File 
								id="custom-worksheet"
								type="file"
								label={el.prog_worksheet !== "" ? el.prog_worksheet: "prog_worksheet" } 
								name="prog_worksheet"
								custom
							/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_worksheet}
								</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenProgWorksheet} target={'prog_worksheet'}/>
						</Form.Group>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<Form.Label>Evaluation Function</Form.Label>	{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenProgEvuFun: true})} onMouseLeave={(e) => this.setState({isOpenProgEvuFun: false})}/>
							<Form.File 
								id="custom-evaluation_fn"
								type="file"
								label={el.prog_evaluation_fn !== "" ? el.prog_evaluation_fn: "prog_evaluation_fn" } 
								name="prog_evaluation_fn"
								custom
							/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_evaluation_fn}
								</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenProgEvuFun} target={'prog_evaluation_fn'}/>
						</Form.Group>
						</Form.Row>
						<Form.Group controlId="formBasicFileUpload">
							<Form.Label>Datasets</Form.Label>{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenProgDatasets: true})} onMouseLeave={(e) => this.setState({isOpenProgDatasets: false})}/>
							<SimpleDialog isOpen={this.state.isOpenProgDatasets} target={'prog_dataset'}/>
						</Form.Group>
						{this.createprogDataSetUI(j, k, i)}
						<button className="btn btn-info " style={{ width: '15%'}} onClick={this.addprogDataSet.bind(this, i, j, k)}> + Dataset </button> {'\u00A0'}{'\u00A0'}
						<br/>
						<br/>
						{this.createprogConceptUI(j, k, i)}
						<br/>
						<br/>
						<button className="btn btn-info " style={{ width: '15%'}} onClick={this.addprogConcept.bind(this, i, j, k)}> + Concept </button> {'\u00A0'}{'\u00A0'}
						<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.no_data_on_prog_concept}
						</Form.Text>
					</Form>
					{/*<footer className="text-right">
						<button className="btn btn-info" style={{ width: '15%'}} onClick={this.deleteProgExercise.bind(this, i, j, k)}>- Program</button>
	 </footer>*/}
					</Card.Body>
			</Card>
    	  </div> 
	   </center>
     ))
  }
  addProgExercise=(i, j, e)=>{
	e.preventDefault();
	let newProgExercise = {prog_marks: "", prog_worksheet: "", prog_worksheet_actual: "", prog_evaluation_fn: "", prog_evaluation_fn_actual: "", prog_datasets: [], concept: [], concept_id_for_DB: []};
	let module = this.state.module;
	module[j].exercise[i].prog_exercise.push(newProgExercise);
	module[j].exercise[i].prog_exercise_checkbox = true;
	module[j].exercise[i].obj_exercise_checkbox = true;
	this.setState({module:module});
	 
  }
   handleChangeProgExercise(i, j, k, e) {
     const { name, value } = e.target;
	 let prog_exercise = this.state.module[j].exercise[k].prog_exercise;
	 if(e.target.type === "file"){
		 prog_exercise[i] = {...prog_exercise[i], [name + "_actual"]: e.target.files[0]};
		 prog_exercise[i] = {...prog_exercise[i], [name]: e.target.files[0].name};
	  }else{
		prog_exercise[i] = {...prog_exercise[i], [name]: value};        
      }
     this.setState({ prog_exercise : prog_exercise });
  }
  /*deleteProgExercise=(i, j, k, e)=>{
	 e.preventDefault();
	 let prog_exercise = this.state.module[j].exercise[k].prog_exercise;
     prog_exercise.splice(i, 1);
     this.setState({ prog_exercise });
  }*/
  //////////////////////////////////////////////////
  handProgConceptCheckbox(i, j, k, l, e){
	  let concept = this.state.module[j].exercise[k].prog_exercise[l].concept
	  concept[i].concept_text_checkbox = e.target.checked;
	  this.setState({concept})
  }
  
  //// Create program Concept
  createprogConceptUI(j, k, l){
     return this.state.module[j].exercise[k].prog_exercise[l].concept.map((el, i) => (
       <center key={i}>
		<div>
		<br />
			<Card style={{ width: '100%', height: '100%' }} >
				<Card.Body>
					<Form className="text-left" onChange={this.handleChangeprogConcept.bind(this, i, j, k, l)}>
						
						<Form.Row>
						<Form.Group as={Col} xs={5} controlId="formBasicName">
							<Form.Label>Concept Text</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}}/>
								{/*<Form.Control as="select" name="exixting_concept" disabled={el.concept_text_checkbox} value = {el.exixting_concept} defaultValue="Select concept from our database">
									<option>Select concept from our database</option>
									{this.state.user_saved_course.map((a) => <option >{a.exixting_concept}</option>)}
									<hr />
									{this.state.existing_concept.map((a) => <option key={a.concept_id}>{a.concept_text}</option>)}
									<hr />
									{this.state.save_concepts.map((a) => <option key={a.concept_id}>{a.concept_text}(From save concept)</option>)}
	 							</Form.Control>*/}
								<Select options={this.state.concept_data} 
									filterOptions={createFilterOptions({
										labelKey: 'label',
										options: this.state.concept_data
	  								})} 
									name="exixting_concept" disabled={el.concept_text_checkbox} value = {el.exixting_concept} placeholder="Select concept from our database" 
								/>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_existing_concept}
								</Form.Text>
						</Form.Group>
						<Form.Group as={Col} xs="auto" controlId="formBasicFileUpload" >
							<br/>
							<br/>
							{'\u00A0'}{'\u00A0'}{'\u00A0'}<Form.Label>OR</Form.Label>
						</Form.Group>
						<Form.Group as={Col} xs="auto" controlId="formBasicFileUpload">
							<br/>
							<br/>
							<Form.Check type="checkbox" onChange={this.handProgConceptCheckbox.bind(this, i, j, k, l)} checked={el.concept_text_checkbox} label="add a Concept" name= "exixting_concept_check" id= "exixting_concept_check"/>
						</Form.Group>
						{el.concept_text_checkbox === true ? (
							<Form.Group as={Col} controlId="formBasicID">
								<br/>
								<Form.Control type="text" style={{ width: '100%'}} value={el.concept_text}  name='concept_text' placeholder="eg. cover python..." disabled={!el.concept_text_checkbox}/>
							</Form.Group>
							
						) : null}
						</Form.Row>
					</Form>
					<footer className="text-right">
						<button className="btn btn-info" style={{ width: '15%'}} onClick={this.deleteprogConcept.bind(this, i, j, k, l)}>- Concept</button>
					</footer>
				</Card.Body>
			</Card>
    	  </div> 
	   </center>
     ))
  }
    
  addprogConcept=(i, j, k, e)=>{
	  e.preventDefault();
	  let newConcept = {concept_text: "", exixting_concept: "", concept_text_checkbox: false, concept_id: ""};
	  let module = this.state.module;
	  module[j].exercise[k].prog_exercise[i].concept.push(newConcept);
	  this.setState({module:module})
  }
  handleChangeprogConcept(i, j, k, l,e) {
     const { name, value } = e.target;
	 let user = this.state.user;
     let concept = this.state.module[j].exercise[k].prog_exercise[l].concept;
     let user_saved_course = this.state.user_saved_course;
     concept[i] = {...concept[i], [name]: value};
	 if(name === "exixting_concept"){
		if(!user.includes(value)){
		   user.push(value)
		   user_saved_course.push({[name]: value})
		}
	}
     this.setState({ concept });
	 this.setState({ user });
	 this.setState({ user_saved_course })
  }
  deleteprogConcept=(i, j, k, l, e)=>{
	 e.preventDefault();
	 let concept = this.state.module[j].exercise[k].prog_exercise[l].concept;;
     concept.splice(i, 1);
     this.setState({ concept });
  }
  /////////////////////////////////////////////
  
   createprogDataSetUI(j, k, l){
     return this.state.module[j].exercise[k].prog_exercise[l].prog_datasets.map((el, i) => (
       <center key={i}>
		<div>
					<Form className="text-left" onChange={this.handleChangeprogDataSet.bind(this, i, j, k, l)}>
						<Form.Row>
							<Form.Group as={Col} controlId="formBasicFileUpload">
								<Form.File 
									id="custom-datasets"
									type="file"
									label={el.prog_dataset !== "" ? el.prog_dataset: "prog_dataset" } 
									name="prog_dataset"
									custom
								/>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_datasets}
								</Form.Text>
							</Form.Group>
							<Form.Group as={Col} controlId="formBasicButton">
								<BsFillTrashFill style={{color:"gray", fontSize:20}} onClick={this.deleteprogDataSet.bind(this, i, j, k, l)} />
							</ Form.Group>
						</ Form.Row>
					</Form>
					<footer className="text-right">
						
					</footer>
    	  </div> 
	   </center>
     ))
  }
    
  addprogDataSet=(i, j, k, e)=>{
	  e.preventDefault();
	  let newDataSet = {prog_dataset: "", prog_dataset_actual: ""};
	  let module = this.state.module;
	  module[j].exercise[k].prog_exercise[i].prog_datasets.push(newDataSet);
	  this.setState({module:module})
  }
  handleChangeprogDataSet(i, j, k, l,e) {
     const { name, value } = e.target;
     let prog_datasets = this.state.module[j].exercise[k].prog_exercise[l].prog_datasets;
	 if(e.target.type === "file"){
		 prog_datasets[i] = {...prog_datasets[i], [name + "_actual"]: e.target.files[0]};
		 prog_datasets[i] = {...prog_datasets[i], [name]: e.target.files[0].name};
	  }else{
		prog_datasets[i] = {...prog_datasets[i], [name]: value};        
      }
     this.setState({ prog_datasets : prog_datasets });
  }
  deleteprogDataSet=(i, j, k, l, e)=>{
	 e.preventDefault();
	 let prog_datasets = this.state.module[j].exercise[k].prog_exercise[l].prog_datasets;;
     prog_datasets.splice(i, 1);
     this.setState({ prog_datasets });
  }
  /////////////////////////////////// 

	handInstructionDesignationCheckbox(i, e){
	  let instructor = this.state.instructor
	  instructor[i].instructor_designation_text_on = e.target.checked;
	  this.setState({instructor})
  }
  handInstructionProfileCheckbox(i, e){
	  let instructor = this.state.instructor
	  instructor[i].instructor_profile_text_on = e.target.checked;
	  this.setState({instructor})
  }
	
  // create instructor 
  createInstructorUI(){
     return this.state.instructor.map((el, i) => (
       <center key={i}>
		<div>
			<br />
			<Card style={{ width: '100%', height: '100%' }} key={i}>
				<Card.Body>
					<Form className="text-left"  onChange={this.handleChangeInstructor.bind(this, i)}>
							<Form.Group controlId="formBasicID">
								<Form.Label>Instructor Name</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenInstructorName: true})} onMouseLeave={(e) => this.setState({isOpenInstructorName: false})}/>
								<Form.Control type="text"  value={el.instructor_name} name='instructor_name' placeholder="eg. Prof. Abcd Ghiyj" />
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ el.error_in_name}
								</Form.Text>
								<SimpleDialog isOpen={this.state.isOpenInstructorName} target={'instructor_name'}/>
							</Form.Group>
							
							<Form.Row>
								<Form.Group as={Col} controlId="formBasicFileUpload">
									<Form.Label>Instructor  Designation</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenInstructorDesignation: true})} onMouseLeave={(e) => this.setState({isOpenInstructorDesignation: false})}/>
									<Form.File 
										type="file" 
										id="custom_instructor_designation"
										label={el.instructor_designation !== "" ? el.instructor_designation: "Enter text file with Instructor Designation" } 
										name="instructor_designation"
										disabled={el.instructor_designation_text_on}
										custom
									/>
									<Form.Text className="text-muted-red" style={{ color: 'red' }}>
										{ el.error_in_designation}
									</Form.Text>
									<SimpleDialog isOpen={this.state.isOpenInstructorDesignation} target={'instructor_designation'}/>
								</Form.Group>
								<Form.Group as={Col} xs={1} controlId="formBasicFileUpload" >
									<br/>
									<br/>
									{'\u00A0'}{'\u00A0'}{'\u00A0'}<Form.Label>OR</Form.Label>
								</Form.Group>
								<Form.Group as={Col} controlId="formBasicFileUpload">
									<br/>
									<br/>
									<Form.Check type="checkbox" onChange={this.handInstructionDesignationCheckbox.bind(this, i)} checked={el.instructor_designation_text_on} label="Instructor Designation Text" name= "instructor_designation_text_checkbox" id= "instructor_designation_text_checkbox"/>
								</Form.Group>
							</Form.Row>
							{el.instructor_designation_text_on === true ? (
								<Form.Group controlId="formBasicFileUpload">
									<textarea style = {{width: "100%"}}    disabled={!el.instructor_designation_text_on} name="instructor_designation_text" placeholder="eg. This is a course to learn the fundamentals of Machine learning. It teaches various aspects of machine learning, its applications, and hands on approaches." 
									value={el.instructor_designation_text} />
									<Form.Text className="text-muted-red" style={{ color: 'red' }}>
										{ el.error_in_instructor_designation_text}
									</Form.Text>
								</Form.Group>
							) : null}
							
							<Form.Row>
								<Form.Group as={Col} controlId="formBasicFileUpload">
									<Form.Label>Instructor Profile</Form.Label>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenInstructorProfile: true})} onMouseLeave={(e) => this.setState({isOpenInstructorProfile: false})}/>
									<Form.File 
										type="file"
										id="custom-instructor_profile"
										label={el.instructor_profile !== "" ? el.instructor_profile: "Enter text file with Instructor Profile" } 
										name="instructor_profile"
										disabled={el.instructor_profile_text_on}
										custom
									/>
									<Form.Text className="text-muted-red" style={{ color: 'red' }}>
										{ el.error_in_profile}
									</Form.Text>
									<SimpleDialog isOpen={this.state.isOpenInstructorProfile} target={'instructor_profile'}/>
								</Form.Group>
								<Form.Group as={Col} xs={1} controlId="formBasicFileUpload" >
									<br/>
									<br/>
									{'\u00A0'}{'\u00A0'}{'\u00A0'}<Form.Label>OR</Form.Label>
								</Form.Group>
								<Form.Group as={Col} controlId="formBasicFileUpload">
									<br/>
									<br/>
									<Form.Check type="checkbox" onChange={this.handInstructionProfileCheckbox.bind(this, i)} checked={el.instructor_profile_text_on} label="Instructor Profile Text" name= "instructor_profile_text_checkbox" id= "instructor_profile_text_checkbox"/>
								</Form.Group>
							</Form.Row>
							{el.instructor_profile_text_on === true ? (
								<Form.Group controlId="formBasicFileUpload">
									<textarea style = {{width: "100%"}}    disabled={!el.instructor_profile_text_on} name="instructor_profile_text" placeholder="eg. This is a course to learn the fundamentals of Machine learning. It teaches various aspects of machine learning, its applications, and hands on approaches." 
									value={el.instructor_profile_text} />
									<Form.Text className="text-muted-red" style={{ color: 'red' }}>
										{ el.error_in_instructor_profile_text}
									</Form.Text>
								</Form.Group>
							) : null}
							
					</Form>
					<footer className="text-right">
						<button className="btn btn-info" style={{ width: '15%'}} onClick={this.deleteInstructor.bind(this, i)}>- Instructor</button>
					</footer>
				</Card.Body>
			</Card>
    	  </div> 
	   </center>
     ))
  }
  
  addInstructor=(e)=>{
	  e.preventDefault();
	  this.setState(prevState=>({
		  instructor: [...prevState.instructor, {instructor_text: "", instructor_profile: "", instructor_profile_actual: "", instructor_profile_text: "", instructor_designation: "", instructor_designation_actual: "", instructor_designation_text: "", instructor_name: "", instructor_profile_text_on: false, instructor_designation_text_on: false}]
		  
	  }))
	  /*this.setState(prevState=>({
		  ins_errors: [...prevState.ins_errors, {instructor_text: "", instructor_profile: "", instructor_designation: "", instructor_name: ""}]
		  
	  }))*/
  }
  handleChangeInstructor(i, e) {
     const { name, value } = e.target;
     let instructor = [...this.state.instructor];
	 if(e.target.type === "file"){
		 instructor[i] = {...instructor[i], [name + "_actual"]: e.target.files[0]};
		 instructor[i] = {...instructor[i], [name]: e.target.files[0].name};
	  }else{
		instructor[i] = {...instructor[i], [name]: value};        
      }
     this.setState({ instructor : instructor });
  }
  deleteInstructor=(i, e)=>{
	 e.preventDefault();
	 let instructor = [...this.state.instructor];
     instructor.splice(i, 1);
     this.setState({ instructor });
  }
  
  ////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////
  handleChange(event) {
	  	event.preventDefault();
	  	const { name, value } = event.target;
	  	let common_fields = this.state.common_fields;
	  	if(event.target.type === "file"){
			common_fields[name + "_actual"] = event.target.files[0]
		 	common_fields[name] = event.target.files[0].name;
	  	}else if(name === "created_on"){
			common_fields[name] = value;
	  	}else{
			common_fields[name] = value;        
      	}
	  	this.setState({common_fields : common_fields });
  	}
  handleChangedate(name, date) {
		let common_fields = this.state.common_fields
		if(name === "created_on"){
			common_fields.created_on = date;
		}else if(name === "offering_period_from"){
			common_fields.offering_period_from = date;
		}else if(name === "offering_period_to"){
			common_fields.offering_period_to = date;
		}
    	this.setState({
			common_fields: common_fields
		})
	}
   /////////////////////////////////////////////////////////////////
  ///// All checkbox functions
  handleCheckbox(e){
    this.setState({custom_course_description: e.target.checked})
  }
  handlePrerequisiteCheckbox(e){
    this.setState({custom_course_prerequisite_knowledge_file: e.target.checked})
  }
  handleReferenceCheckbox(e){
    this.setState({custom_reference_material_file: e.target.checked})
  }
  handleCopyCheckbox(e){
    this.setState({custom_copyright_message_file: e.target.checked})
  }
  async handleOfferingDateCheckbox(e){
	  this.setState({fixed_offering_date: e.target.checked})
  }
  
  //////////////////////////////////////////////////////////////////////////////////
  
  Submit=()=>{ console.log(this.state);
  }
  Preview=()=>{
	  this.props.history.push(`/previewCourse`);
	}
  save=async()=>{ 
	console.log(this.state)
	//await this.handleValidation()
	if(true){//this.state.formIsValid){ 
		await this.final_array_for_submission()
		console.log( "Inside save Function", this.state);
		if (this.state.finalarraysubmission){
			await this.saveCourse()
			if(this.state.savecourse){
				alert("Form has been saved successfully!");
				this.setState({form_submitted: true})
			}
			else{
				console.log(this.state.savecourse)
				alert("Some error occur while uploading the course details to our system. So please contact to the Developer team.")
				this.setState({form_submitted: false})
			}
		}
		else{
			alert("Some Error occur while creating final Submmitimg json file. So please contact to the Developer team.")
			this.setState({form_submitted: false})
		}
		
    }else{
        alert("Form has errors. Please review the errors highlighted in RED.")
		this.setState({form_submitted: false})
    }
	//this.saveCourse();
	}
  ////////////////////////////////////////////////////////////////
  render() {   
	
    return ((this.state.profession === "Admin" && this.state.isLoggedIn === true) ?(
      <center >
        <div >
			<Card style={{ width: '80%', height: '100%' }}>
				<Card.Header className="text-center" style={{ fontWeight: 'bold' }}> Course Details </Card.Header>
				<Card.Body>
					<Form className="text-left" onChange={this.handleChange}>
						<Form.Row>
							<Form.Group as={Col} controlId="formBasicName">
								<Form.Label>Course Title</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpen: true})} onMouseLeave={(e) => this.setState({isOpen: false})}/>
								<Form.Control  type="text" style ={{height: 'auto'}}  name="course_title" placeholder="eg. Artificial Intelligence" value={this.state.common_fields.course_title}/>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.course_title}
								</Form.Text>
								<SimpleDialog isOpen={this.state.isOpen} target={'course_title'}/>
							</Form.Group>
							<Form.Group as={Col} controlId="formBasicName">
								<Form.Label>Course Short Name</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenShortName: true})} onMouseLeave={(e) => this.setState({isOpenShortName: false})}/>
								<Form.Control type="text"   name="course_short_name" placeholder="eg. AI" value={this.state.common_fields.course_short_name} />
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.course_short_name}
								</Form.Text>
								<SimpleDialog isOpen={this.state.isOpenShortName} target={'course_short_name'}/>
							</Form.Group>
							<Form.Group as={Col} controlId="exampleForm.ControlSelect1">
								<Form.Label>List Of Existing Course Names</Form.Label>
								<Form.Control as="select" name="existing_course_title_reference">
									<option>Course Names</option>
									{this.state.existing_course.map((course) => <option key={course.course_id}>{course.course_title}[{course.course_short_name}]</option>)}
								</Form.Control>
							</Form.Group>
							
							{/*<Form.Group as={Col} controlId="formBasicName">
								<Form.Label>Course Short Name For Reference</Form.Label>
								<Form.Control type="text" placeholder={ this.state.existing_course.map((course) => {this.state.common_fields.existing_course_title_reference === course.course_title ? (course.course_short_name): "" }) } />
							</Form.Group>*/}
						</Form.Row>
						<Form.Row>
						<Form.Group as={Col} xs = {3} controlId="exampleForm.ControlSelect2">
								<Form.Label>Communication Language</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>
								<Form.Control as="select" name="communication_language" defaultValue="Select.." value={this.state.common_fields.communication_language}>
									<option>Select..</option>
									<option>English</option>
								</Form.Control>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.communication_language}
								</Form.Text>
							</Form.Group>
							<Form.Group as={Col} xs = {2} controlId="formBasicDate" >
								<Form.Label>Created On</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenCreatedOn: true})} onMouseLeave={(e) => this.setState({isOpenCreatedOn: false})}/>
								<DatePicker
              						selected={ this.state.common_fields.created_on }
              						onChange={ date => this.handleChangedate("created_on", date)}
              						name="created_on"
									dateFormat = "yyyy/MM/dd"
									showYearDropdown
									scrollableMonthYearDropdown
								/>
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.created_on}
								</Form.Text>
								<SimpleDialog isOpen={this.state.isOpenCreatedOn} target={'created_on'}/>
							</Form.Group>
							<Form.Group as={Col} xs = {3} controlId="formBasicFileUpload">
								<br/>
								<br/>
								<Form.Check type="checkbox" onClick={this.handleOfferingDateCheckbox.bind(this)} checked={this.state.fixed_offering_date} label="Is There a Fixed Offering Date?" name= "fixed_offering_date_checkbox" id= "fixed_offering_date_checkbox"/>
							</Form.Group>
							{this.state.fixed_offering_date === true ? (
								<Form.Group as={Col} xs = {2} controlId="formBasicDateLimit">
									<Form.Label>From</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenFromDate: true})} onMouseLeave={(e) => this.setState({isOpenFromDate: false})}/>
									<DatePicker
              							selected={ this.state.common_fields.offering_period_from }
              							onChange={ date => this.handleChangedate("offering_period_from", date)}
              							name="offering_period_from"
										dateFormat = "yyyy/MM/dd"
										minDate= {new Date()}
										showYearDropdown
										scrollableMonthYearDropdown
									/>
									<Form.Text className="text-muted-red" style={{ color: 'red' }}>
										{ this.state.errors.offering_period_from}
									</Form.Text>
									<SimpleDialog isOpen={this.state.isOpenFromDate} target={'offering_period_from'}/>
								</Form.Group>
							) : null}
							{this.state.fixed_offering_date === true ? (
								<Form.Group as={Col} xs = {2} controlId="formBasicDateLimit">
									<Form.Label>To</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenToDate: true})} onMouseLeave={(e) => this.setState({isOpenToDate: false})}/>
									<DatePicker
              							selected={ this.state.common_fields.offering_period_to }
              							onChange={ date => this.handleChangedate("offering_period_to", date)}
              							name="offering_period_to"
										dateFormat = "yyyy/MM/dd"
										minDate= {new Date()}
										showYearDropdown
										scrollableMonthYearDropdown
									/>
									<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ this.state.errors.offering_period_to}
									</Form.Text>
									<SimpleDialog isOpen={this.state.isOpenToDate} target={'offering_period_to'}/>
								</Form.Group>
							) : null}
							</Form.Row>
						<Form.Row>
							<Form.Group as={Col} controlId="formBasicCredit">
								<Form.Label>Course Credit</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenCredit: true})} onMouseLeave={(e) => this.setState({isOpenCredit: false})}/>
								<Form.Control type="number"  name="credit"  placeholder="eg. 5" value={this.state.common_fields.credit} />
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.credit}
								</Form.Text>
								<SimpleDialog isOpen={this.state.isOpenCredit} target={'course_credit'}/>
							</Form.Group>
							<Form.Group as={Col} controlId="formBasicDuration">
								<Form.Label>Course Duration (Min)</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenDuration: true})} onMouseLeave={(e) => this.setState({isOpenDuration: false})}/>
								<Form.Control type="number"  name="duration_in_min"  placeholder="eg. 20" value={this.state.common_fields.duration_in_min} />
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.duration_in_min}
								</Form.Text>
								<SimpleDialog isOpen={this.state.isOpenDuration} target={'course_duration'}/>
							</Form.Group>
							<Form.Group as={Col} controlId="formBasicSwitch">
							<br/>
							<br/>
							<Form.Check 
								type="checkbox"
								id="custom-switch"
								name="add_to_carousal"
								label="Include Course For Advertisement page"
							/>
						</Form.Group>
							
						</Form.Row>
						<Form.Group controlId="formBasicName">
							<Form.Label>Prerequisite Preexisting Course Name</Form.Label> {'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenCoursePrerequisitePrexistingCourse: true})} onMouseLeave={(e) => this.setState({isOpenCoursePrerequisitePrexistingCourse: false})}/>
							{this.createPrerequisitepreexistingcourseUI()}
							<br/>
							<button className="btn btn-info " style={{ width: '15%'}} onClick={this.addPrerequisitepreexistingcourse.bind(this)}> + Add </button> {'\u00A0'}{'\u00A0'}
							<SimpleDialog isOpen={this.state.isOpenCoursePrerequisitePrexistingCourse} target={'prerequisite_preexisting_course'}/>
						</Form.Group>
						<Form.Row>
						<Form.Group  as={Col} controlId="formBasicFileUpload">
							<Form.Label>Course Introduction Video</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenCourseVideo: true})} onMouseLeave={(e) => this.setState({isOpenCourseVideo: false})}/>
							<Form.File 
								id="custom-course_intro_video"
								type="file"
								label={this.state.common_fields.course_intro_video !== "" ? this.state.common_fields.course_intro_video : "course intro video" }
								name="course_intro_video"
								custom
							/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.course_intro_video}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenCourseVideo} target={'course_intro_video'}/>
						</Form.Group>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<Form.Label>Course Advertisement Image</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenCourseAdvertiseentImage: true})} onMouseLeave={(e) => this.setState({isOpenCourseAdvertiseentImage: false})}/>
							<Form.File 
								id="custom-course_advertisement_image"
								type="file"
								label={this.state.common_fields.course_advertisement_image !== "" ? this.state.common_fields.course_advertisement_image : "course advertisement image" }
								name="course_advertisement_image"
								custom
							/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.course_advertisement_image}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenCourseAdvertiseentImage} target={'course_advertisement_image'}/>
						</Form.Group>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<Form.Label>Course Card Image</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenCourseCardImage: true})} onMouseLeave={(e) => this.setState({isOpenCourseCardImage: false})}/>
							<Form.File 
								id="custom-course_card_image"
								type="file"
								label={this.state.common_fields.course_card_image !== "" ? this.state.common_fields.course_card_image : "course card image" }
								name="course_card_image"
								custom
							/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.course_card_image}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenCourseCardImage} target={'course_card_image'}/>
						</Form.Group>
						</Form.Row>
						
						<Form.Row>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<Form.Label>Course Description</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenCourseDescription: true})} onMouseLeave={(e) => this.setState({isOpenCourseDescription: false})}/>
							<Form.File 
								id="custom_course_description"
								type="file"
								label={this.state.common_fields.course_description !== "" ? this.state.common_fields.course_description : "Enter text file with course description" }
								name="course_description"
								disabled={this.state.custom_course_description}
								custom
							/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.course_description}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenCourseDescription} target={'course_description'}/>
						</Form.Group>
						
						<Form.Group as={Col} xs={1} controlId="formBasicFileUpload" >
							<br/>
							<br/>
							{'\u00A0'}{'\u00A0'}{'\u00A0'}<Form.Label>OR</Form.Label>
						</Form.Group>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<br/>
							<br/>
							<Form.Check type="checkbox" onChange={this.handleCheckbox.bind(this)} checked={this.state.custom_course_description} label="Input Text Here" name= "course_description_checkbox" id= "course_description_checkbox"/>
						</Form.Group>
						</Form.Row>
						{this.state.custom_course_description === true ? (
							<Form.Group controlId="formBasicFileUpload">
							<textarea style = {{width: "100%"}}  disabled={!this.state.custom_course_description} name="course_description_text" placeholder="eg. This is a course to learn the fundamentals of Machine learning. It teaches various aspects of machine learning, its applications, and hands on approaches." value={this.state.common_fields.custom_course_description_text} />
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.course_description_text}
							</Form.Text>
						</Form.Group>
						) : null}
						
						<Form.Row>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<Form.Label>Prerequisite Knowledge File</Form.Label>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenCoursePrerequisiteKnowledgeFile: true})} onMouseLeave={(e) => this.setState({isOpenCoursePrerequisiteKnowledgeFile: false})}/>
							<Form.File 
								id="custom_prerequisite_knowledge_file"
								type="file"
								label={this.state.common_fields.prerequisite_knowledge_file !== "" ? this.state.common_fields.prerequisite_knowledge_file : "Enter text file with prerequisite knowledge" }
								name="prerequisite_knowledge_file"
								disabled={this.state.custom_course_prerequisite_knowledge_file}
								custom
							/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.course_prerequisite_knowledge_file}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenCoursePrerequisiteKnowledgeFile} target={'prerequisite_knowledge_file'}/>
						</Form.Group>
						<Form.Group as={Col} xs={1} controlId="formBasicFileUpload" >
							<br/>
							<br/>
							{'\u00A0'}{'\u00A0'}{'\u00A0'}<Form.Label>OR</Form.Label>
						</Form.Group>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<br/>
							<br/>
							<Form.Check type="checkbox" onChange={this.handlePrerequisiteCheckbox.bind(this)} checked={this.state.custom_course_prerequisite_knowledge_file} label="Input Text Here" name= "course_description_checkbox" id= "course_description_checkbox"/>
						</Form.Group>
						</Form.Row>
						{this.state.custom_course_prerequisite_knowledge_file === true ? (
						<Form.Group controlId="formBasicFileUpload">
							<textarea style = {{width: "100%"}}  disabled={!this.state.custom_course_prerequisite_knowledge_file} name="course_prerequisite_knowledge_file_text" placeholder="eg. This is a course to learn the fundamentals of Machine learning. It teaches various aspects of machine learning, its applications, and hands on approaches." value={this.state.common_fields.course_prerequisite_knowledge_file_text} />
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ this.state.errors.course_prerequisite_knowledge_file_text}
								</Form.Text>
							</Form.Group>
						) : null}
						
						
						<Form.Row>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<Form.Label>Reference Material</Form.Label>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenCourseReferenceMaterialFile: true})} onMouseLeave={(e) => this.setState({isOpenCourseReferenceMaterialFile: false})}/>
							<Form.File 
								id="custom_reference_material_file"
								type="file"
								label={this.state.common_fields.reference_material_file !== "" ? this.state.common_fields.reference_material_file : "Enter text file with reference material" }
								name="reference_material_file"
								disabled={this.state.custom_reference_material_file}
								custom
							/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.course_reference_material_file}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenCourseReferenceMaterialFile} target={'reference_material_file'}/>
						</Form.Group>
						<Form.Group as={Col} xs={1} controlId="formBasicFileUpload" >
							<br/>
							<br/>
							{'\u00A0'}{'\u00A0'}{'\u00A0'}<Form.Label>OR</Form.Label>
						</Form.Group>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<br/>
							<br/>
							<Form.Check type="checkbox" onChange={this.handleReferenceCheckbox.bind(this)} checked={this.state.custom_reference_material_file} label="Input Text Here" name= "course_reference_checkbox" id= "course_reference_checkbox"/>
						</Form.Group>
						</Form.Row>
						{this.state.custom_reference_material_file === true ? (
							<Form.Group controlId="formBasicFileUpload">
								<textarea style = {{width: "100%"}}  disabled={!this.state.custom_reference_material_file} name="course_reference_material_file_text" placeholder="eg. This is a course to learn the fundamentals of Machine learning. It teaches various aspects of machine learning, its applications, and hands on approaches." 
								value={this.state.common_fields.course_reference_material_file_text} />
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ this.state.errors.course_reference_material_file_text}
								</Form.Text>
							</Form.Group>
						) : null}
						
						<Form.Row>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<Form.Label>Copyright Message</Form.Label>{'\u00A0'}<BsFillStarFill style={{color:"red", fontSize:10}}/>{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:10}} onMouseEnter={(e) => this.setState({isOpenCourseCopyRightMessage: true})} onMouseLeave={(e) => this.setState({isOpenCourseCopyRightMessage: false})}/>
							<Form.File 
								id="custom_copyright_message_file"
								type="file"
								label={this.state.common_fields.copyright_message_file !== "" ? this.state.common_fields.copyright_message_file : "Enter text file with copyright message" }
								name="copyright_message_file"
								disabled={this.state.custom_copyright_message_file}
								custom
							/>
							<Form.Text className="text-muted-red" style={{ color: 'red' }}>
								{ this.state.errors.copyright_message_file}
							</Form.Text>
							<SimpleDialog isOpen={this.state.isOpenCourseCopyRightMessage} target={'copyright_message_file'}/>
						</Form.Group>
						<Form.Group as={Col} xs={1} controlId="formBasicFileUpload" >
							<br/>
							<br/>
							{'\u00A0'}{'\u00A0'}{'\u00A0'}<Form.Label>OR</Form.Label>
						</Form.Group>
						<Form.Group as={Col} controlId="formBasicFileUpload">
							<br/>
							<br/>
							<Form.Check type="checkbox" onChange={this.handleCopyCheckbox.bind(this)} checked={this.state.custom_copyright_message_file} label="Input Text Here" name= "course_copyright_message_checkbox" id= "course_copyright_message_checkbox"/>
						</Form.Group>
						</Form.Row>
						{this.state.custom_copyright_message_file === true ? (
							<Form.Group controlId="formBasicFileUpload">
								<textarea style = {{width: "100%"}}  disabled={!this.state.custom_copyright_message_file} name="course_copyright_message_file_text" placeholder="eg. This is a course to learn the fundamentals of Machine learning. It teaches various aspects of machine learning, its applications, and hands on approaches." 
								value={this.state.common_fields.course_copyright_message_file_text} />
								<Form.Text className="text-muted-red" style={{ color: 'red' }}>
									{ this.state.errors.course_copyright_message_file_text}
								</Form.Text>
							</Form.Group>
						) : null}
						
						{this.createModuleUI()}
						<br/>
						<button className="btn btn-info " style={{ width: '15%'}} onClick={this.addModule.bind(this)}> + Module </button> {'\u00A0'}{'\u00A0'}
						<br/><Form.Text className="text-muted-red" style={{ color: 'red' }}>{ this.state.mod_errors.no_data_on_module }</Form.Text>
						<br/>
						{this.createInstructorUI()}
						<br/>
						<button className="btn btn-info " style={{ width: '15%'}} onClick={this.addInstructor.bind(this)}> + Instructor </button> {'\u00A0'}{'\u00A0'}
						<br/><Form.Text className="text-muted-red" style={{ color: 'red' }}>{ this.state.ins_errors.no_data_on_instructor }</Form.Text>
						<br/>
						
					</Form>
					<br/>
					<footer>
						<button className="btn btn-info" type="save" style={{ width: '15%'}} onClick={this.save}>Save</button> {'\u00A0'}{'\u00A0'}{'\u00A0'}<BsQuestionCircleFill style={{color:"gray", fontSize:20}} onMouseEnter={(e) => this.setState({isOpenSave: true})} onMouseLeave={(e) => this.setState({isOpenSave: false})}/>
						<SimpleDialog isOpen={this.state.isOpenSave} target={'save'}/>
					</footer>
				</Card.Body>
				
			</Card>
			<ScrollToTop showUnder={160}>
  				<BsFillShiftFill className=" btn-info " style={{fontSize:40}} />
			</ScrollToTop>
			<br/>
			{this.state.form_submitted === true ? (<button className="btn btn-info"  style={{ width: '15%'}} onClick={this.Preview}>Preview</button> ): null }{'\u00A0'}{'\u00A0'}
			{this.state.form_submitted === true ? (<button className="btn btn-info" style={{ width: '15%'}} onClick={this.Submit}>Submit</button> ): null }
        </div>
        <hr />

      </center>):(
	  	<center >
		  	<div>
	 	 		<Card style={{ width: '90%', height: '100%' }}>
		 		 	<Card.Body>
						<Card.Text>
		  					You are not an Admin user.
		  				</Card.Text>
		 	 		</Card.Body>
				</Card>
			</div>
		</center>
		)
    )
  }

}




export default UploadCourse;
