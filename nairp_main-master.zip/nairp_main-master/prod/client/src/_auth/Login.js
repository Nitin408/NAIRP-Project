import React from "../../node_modules/react";
import { Link } from "react-router-dom";
//import PropTypes from '../../node_modules/prop-types';
import Container from "../../node_modules/react-bootstrap/Container";
import Row from "../../node_modules/react-bootstrap/Row";
import Col from "../../node_modules/react-bootstrap/Col";
import Form from "../../node_modules/react-bootstrap/Form";
import Button from "../../node_modules/react-bootstrap/Button";
//import InputGroup from '../../node_modules/react-bootstrap/InputGroup'
// import { ListOfAllCountries, ListOfAllIndianStates, ListOfAllGenders, ListOfAllEducationalLevels, ListOfAllProfessions} from '../clientMisc'
import { Formik } from "../../node_modules/formik";
import * as yup from "../../node_modules/yup";
import Recaptcha from 'react-recaptcha'
import {connect} from 'react-redux'
import {login} from '../store/auth/action'
import {history} from '../clientMisc'

class Login extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      captchaVerified: false,
      captchaVerifyReponse: ""
    };
  }

  captchaOnloadCallback = () => {
    //console.log("Signup page Captcha loaded")
  };

  captchaVerifyCallback = (response) => {
    if (response) {
      //console.log('captchaVerifyResponse:',response)
      this.setState({ captchaVerified: true, captchaVerifyResponse: response })
    }
  }

  checkToken = () => {
    if(this.props.match.params.token){
      localStorage.setItem("my-jwt",this.props.match.params.token)
      history.push('/profile')
    }
  }

  componentDidMount(){
    this.checkToken()
  }

  render() {
    let captchaRef;

    const schema = yup.object({
      email: yup
        .string()
        .trim()
        .required("Email address is required")
        .lowercase()
        .email("Invalid email address")
        .max(50, "Email must be 50 characters at maximum"),

      password: yup.string().required("Password is required")

      ////terms: yup.bool().required(),
    });
    return (
      <Formik
        initialValues={{
          email: "",
          password: ""
        }}
        validationSchema={schema}
        onSubmit={(values, { setSubmitting }) => {
          if (this.state.captchaVerified === false) {
            alert("Please verify that you're not a robot.")
            return;
          }
          const captchaVerifyResponseLocal = this.state.captchaVerifyResponse;

          setSubmitting(false);

          values.email = values.email.trim().toLowerCase();
          values.captchaVerifyResponse = captchaVerifyResponseLocal

          this.props.login(values)

          captchaRef.reset()
          this.setState({ captchaVerified: false, captchaVerifyResponse: "" })
        }}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
          isValid,
          isSubmitting
        }) => (
            <Form noValidate onSubmit={handleSubmit}>
              <Container>

                <Row>
                  {" "}
                  <Col></Col>{" "}
                  <Col xs={4} style={{alignItems: 'center', textAlign: 'center', }}>
                    <a href={"/auth/google"} style={{  border:"1px solid #000", }}>
                      Login with Google
                    </a>
                  </Col>{" "}
                  <Col></Col>{" "}
                </Row>
                <Row>
                  {" "}
                  <Col></Col>{" "}
                  <Col xs={4}>
                    <Form.Group controlId="gEmail">
                      <Form.Label>Email address</Form.Label>
                      <Form.Control
                        type="email"
                        name="email"
                        value={values.email}
                        size="m"
                        placeholder="user@domain.com"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        isValid={touched.email && !errors.email}
                        isInvalid={errors.email && touched.email && errors.email}
                      />
                      <Form.Control.Feedback type="valid">
                        {" "}
                        Looks good !{" "}
                      </Form.Control.Feedback>
                      <Form.Control.Feedback type="invalid">
                        {" "}
                        {errors.email}{" "}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>{" "}
                  <Col></Col>{" "}
                </Row>
                <Row>
                  {" "}
                  <Col></Col>{" "}
                  <Col xs={4}>
                    <Form.Group controlId="gPassword">
                      <Form.Label>Password</Form.Label>
                      <Form.Control
                        type="password"
                        name="password"
                        value={values.password}
                        size="m"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        isValid={touched.password && !errors.password}
                        isInvalid={
                          errors.password && touched.password && errors.password
                        }
                      />
                      {/* <Form.Control.Feedback type="valid"> Looks good ! </Form.Control.Feedback> */}
                      <Form.Control.Feedback type="invalid">
                        {" "}
                        {errors.password}{" "}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>{" "}
                  <Col></Col>{" "}
                </Row>
                <Row>

                  {" "}
                  <Col></Col>{" "}
                  <Col xs={4}>

                    <center>
                      <Link to="/forgot_password">Forgot password?</Link><br></br><br></br>
                    </center>
                  </Col>{" "}
                  <Col></Col>{" "}


                </Row>
                <Row>
                  {" "}
                  <Col></Col>{" "}
                  <Col xs={4}>
                    <center><Recaptcha size="normal" ref={e => captchaRef = e} sitekey="6LdFscIUAAAAAKHF6JSkSwiux70z4V6wGtj1H5H5" render="explicit" onloadCallback={this.captchaOnloadCallback} verifyCallback={this.captchaVerifyCallback} /></center>
                  </Col> <Col></Col> </Row>
                <Row> <Col></Col> <Col> <br></br>

                  <center>
                    <Button variant="info" type="submit" size="m">
                      Login !
                    </Button>
                  </center>
                </Col>{" "}
                  <Col></Col>{" "}
                </Row>
              </Container>
            </Form>
          )
        }
      </Formik>
    );
  }
}

const mapStateToProps = (state) => {
  return {}
}

const mapDispatchToProps = {
  login: login
}

export default connect(mapStateToProps,mapDispatchToProps)(Login)

