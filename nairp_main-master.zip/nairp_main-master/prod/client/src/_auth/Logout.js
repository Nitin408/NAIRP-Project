import React from 'react'
import { connect } from 'react-redux'
import {logout} from '../store/auth/action'

class Logout extends React.Component {

  componentDidMount() {
    this.props.logout()
  }

  render() {
    return (
      <div>
        Logging out....
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  return {}
}

const mapDispatchToProps = {
  logout: logout
}

export default connect(mapStateToProps, mapDispatchToProps)(Logout);