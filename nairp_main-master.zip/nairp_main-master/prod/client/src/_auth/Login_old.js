import React from "../../node_modules/react";
//import PropTypes from '../../node_modules/prop-types';
import Container from "../../node_modules/react-bootstrap/Container";
import Row from "../../node_modules/react-bootstrap/Row";
import Col from "../../node_modules/react-bootstrap/Col";
import Form from "../../node_modules/react-bootstrap/Form";
import Button from "../../node_modules/react-bootstrap/Button";
//import InputGroup from '../../node_modules/react-bootstrap/InputGroup'
// import { ListOfAllCountries, ListOfAllIndianStates, ListOfAllGenders, ListOfAllEducationalLevels, ListOfAllProfessions} from '../clientMisc'
import { Formik } from "../../node_modules/formik";
import * as yup from "../../node_modules/yup";
import axios from "axios";
import {serverUrl} from "../clientMisc"
// import Recaptcha from 'react-recaptcha'

class Login extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      captchaVerified: false,
      captchaVerifyReponse: ""
    };
  }

  captchaOnloadCallback = () => {
    //console.log("Signup page Captcha loaded")
  };

  // captchaVerifyCallback = (response) => {
  //   if(response){
  //     //console.log('captchaVerifyResponse:',response)
  //     this.setState({captchaVerified: true, captchaVerifyResponse: response})
  //   }
  // }

  render() {
    // let captchaRef;

    const schema = yup.object({
      email: yup
        .string()
        .trim()
        .required("Email address is required")
        .lowercase()
        .email("Invalid email address")
        .max(50, "Email must be 50 characters at maximum"),

      password: yup.string().required("Password is required")

      ////terms: yup.bool().required(),
    });
    return (
      <Formik
        initialValues={{
          email: "",
          password: ""
        }}
        validationSchema={schema}
        onSubmit={(values, { setSubmitting }) => {
          // if(this.state.captchaVerified === false){
          //     alert("Please verify that you're not a robot.")
          //     return;
          // }
          // const captchaVerifyResponseLocal = this.state.captchaVerifyResponse;

          setSubmitting(false);

          values.email = values.email.trim().toLowerCase();

          axios
            .post(serverUrl+'/login', {
              email: values.email,
              password: values.password
              // captchaVerifyResponse: captchaVerifyResponseLocal
            })
            .then(res => {
              console.log(res);
              console.log(res.data);
              if (res.data.success === true) {
                // Success
                alert(res.data.message);
                localStorage.setItem("my-jwt", res.data.token);
                this.props.history.push(`/profile`);
              } else {
                alert(res.data.message);
              }
            });
          // .catch(function (error) {
          //   console.log(error);
          //   alert("Internal server error !")
          // });

          //setTimeout(() => {
          //  alert(JSON.stringify(values, null, 2));
          //}, 400);

          // captchaRef.reset()
          // this.setState({captchaVerified : false, captchaVerifyResponse : ""})
        }}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
          isValid,
          isSubmitting
        }) => (
          <Form noValidate onSubmit={handleSubmit}>
            <Container>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col xs={4}>
                  <Form.Group controlId="gEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control
                      type="email"
                      name="email"
                      value={values.email}
                      size="m"
                      placeholder="user@domain.com"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isValid={touched.email && !errors.email}
                      isInvalid={errors.email && touched.email && errors.email}
                    />
                    <Form.Control.Feedback type="valid">
                      {" "}
                      Looks good !{" "}
                    </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                      {" "}
                      {errors.email}{" "}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col xs={4}>
                  <Form.Group controlId="gPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                      type="password"
                      name="password"
                      value={values.password}
                      size="m"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isValid={touched.password && !errors.password}
                      isInvalid={
                        errors.password && touched.password && errors.password
                      }
                    />
                    {/* <Form.Control.Feedback type="valid"> Looks good ! </Form.Control.Feedback> */}
                    <Form.Control.Feedback type="invalid">
                      {" "}
                      {errors.password}{" "}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col xs={4}>
                  {/* <center><Recaptcha size="normal" ref={e => captchaRef = e} sitekey="6LdFscIUAAAAAKHF6JSkSwiux70z4V6wGtj1H5H5" render="explicit" onloadCallback={this.captchaOnloadCallback} verifyCallback={this.captchaVerifyCallback} /></center>
              </Col> <Col></Col> </Row>
              <Row> <Col></Col> <Col> <br></br> */}

                  <center>
                    <Button variant="info" type="submit" size="m">
                      Login !
                    </Button>
                  </center>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
            </Container>
          </Form>
        )}
      </Formik>
    );
  }
}

export default Login;
