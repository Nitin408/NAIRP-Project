import React from "react";
//import PropTypes from 'prop-types';
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
//import InputGroup from 'react-bootstrap/InputGroup'
import {
  ListOfAllCountries,
  ListOfAllIndianStates,
  ListOfAllGenders,
  ListOfAllEducationalLevels,
  ListOfAllProfessions
} from "../clientMisc";
import { Formik } from "formik";
import * as yup from "yup";
import axios from "axios";
import Recaptcha from "react-recaptcha";
import {completeProfile} from '../store/profile/action'
import {connect} from 'react-redux'


class CompleteUserDetails extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      captchaVerified: false,
      captchaVerifyReponse: "",
      proceed: false
    };
  }

  captchaOnloadCallback = () => {
    //console.log("Signup page Captcha loaded")
  };

  captchaVerifyCallback = response => {
    if (response) {
      //console.log('captchaVerifyResponse:',response)
      this.setState({ captchaVerified: true, captchaVerifyResponse: response });
    }
  };

  checkMissingDetails = async () => {
    var email = this.props.match.params.email
    console.log(email)
    var res = await axios.post('/api/profile/check_missing_details', {email: email})
    console.log(res.data)
    if(res.data.success===false){
        this.props.history.push('/profile')
    }else{
        this.setState({proceed: true})
    }
  }

  componentDidMount(){
      this.checkMissingDetails()
  }

  render() {
    let captchaRef;

    const schema = yup.object({
      dob: yup
        .date()
        .required("Date of birth is required")
        .min("1900-01-01", "Date of birth can not be earlier than 1900-01-01") //new Date(1900, 1, 1)
        .max("2018-01-01", "Date of birth can not be later than 2018-01-01"),
      gender: yup
        .string()
        .trim()
        .required("Gender is required")
        .oneOf(ListOfAllGenders)
        .notOneOf(["Please select"]),
      educationalLevel: yup
        .string()
        .trim()
        .required("Educational Level is required")
        .oneOf(ListOfAllEducationalLevels)
        .notOneOf(["Please select"]),
      profession: yup
        .string()
        .trim()
        .required("Profession is required")
        .oneOf(ListOfAllProfessions)
        .notOneOf(["Please select"]),
      country: yup
        .string()
        .trim()
        .required("Country is required")
        .oneOf(ListOfAllCountries),
      state: yup
        .string()
        .trim()
        .required("State is required"),
      password: yup
        .string()
        .required("Password is required")
        .min(8, "Password must be 8 characters at minimum")
        .max(16, "Password must be 16 characters at maximum")
        .matches(
          /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&.*])[a-zA-Z0-9!@#$%^&.*]{8,}$/,
          "Password must contain one uppercase letter, one lowercase letter, one digit and one special character !@#$%^&.*"
        ),
      confirmPassword: yup
        .string()
        .required("Confirm Password is required")
        .min(8, "Password must be 8 characters at minimum")
        .max(16, "Password must be 16 characters at maximum")
        .oneOf([yup.ref("password"), null], "Passwords must match")

      ////terms: yup.bool().required(),
    });

    return (

        (this.state.proceed) ? (
        <div>
          <Container>
            <Row>
              <Col></Col>
              <Col>
              <p>
              Please enter the following details before proceeding
              </p>
              </Col>
              <Col></Col>
            </Row>
          
          </Container>

        <Formik
        initialValues={{
          dob: "",
          gender: "Please select",
          educationalLevel: "Please select",
          profession: "Please select",
          country: "India",
          state: "Andaman and Nicobar Islands",
          password: "",
          confirmPassword: ""
        }}
        validationSchema={schema}
        onSubmit={(values, { setSubmitting }) => {
          if (this.state.captchaVerified === false) {
            alert("Please verify that you're not a robot.");
            return;
          }
          const captchaVerifyResponseLocal = this.state.captchaVerifyResponse;

          setSubmitting(false);

          values.dob = values.dob.trim();
          values.gender = values.gender.trim();
          values.educationalLevel = values.educationalLevel.trim();
          values.profession = values.profession.trim();
          values.country = values.country.trim();
          values.state = values.country !== "India" ? "" : values.state.trim();
          values.captchaVerifyResponse = captchaVerifyResponseLocal
          values.email = this.props.match.params.email

          this.props.completeProfile(values)

          //setTimeout(() => {
          //  alert(JSON.stringify(values, null, 2));
          //}, 400);

          captchaRef.reset();
          this.setState({ captchaVerified: false, captchaVerifyResponse: "" });
        }}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
          isValid,
          isSubmitting
        }) => (
          <Form noValidate onSubmit={handleSubmit}>
            <Container>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col xs={4}>
                  
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col xs={4}>
                  <Form.Group controlId="gPassword">
                    <Form.Label>Password (This does not affect your google password.) </Form.Label>
                    <Form.Control
                      type="password"
                      name="password"
                      value={values.password}
                      size="sm"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isValid={touched.password && !errors.password}
                      isInvalid={
                        errors.password && touched.password && errors.password
                      }
                    />
                    <Form.Control.Feedback type="valid">
                      {" "}
                      Looks good !{" "}
                    </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                      {" "}
                      {errors.password}{" "}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col xs={4}>
                  <Form.Group controlId="gConfirmPassword">
                    <Form.Label>ConfirmPassword</Form.Label>
                    <Form.Control
                      type="password"
                      name="confirmPassword"
                      value={values.confirmPassword}
                      size="sm"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isValid={
                        touched.confirmPassword && !errors.confirmPassword
                      }
                      isInvalid={
                        errors.confirmPassword &&
                        touched.confirmPassword &&
                        errors.confirmPassword
                      }
                    />
                    <Form.Control.Feedback type="valid">
                      {" "}
                      Looks good !{" "}
                    </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                      {" "}
                      {errors.confirmPassword}{" "}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col xs={4}>
                  <Form.Group controlId="gDob">
                    <Form.Label>Date of Birth</Form.Label>
                    <Form.Control
                      as="input"
                      type="date"
                      name="dob"
                      value={values.dob}
                      size="sm"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isValid={touched.dob && !errors.dob}
                      isInvalid={errors.dob && touched.dob && errors.dob}
                    />
                    <Form.Control.Feedback type="valid">
                      {" "}
                      Looks good !{" "}
                    </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                      {" "}
                      {errors.dob}{" "}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col>
                  <Form.Group controlId="gGender">
                    <Form.Label>Gender</Form.Label>
                    <Form.Control
                      as="select"
                      type="select"
                      name="gender"
                      value={values.gender}
                      size="sm"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isValid={touched.gender && !errors.gender}
                      isInvalid={
                        errors.gender && touched.gender && errors.gender
                      }
                    >
                      {ListOfAllGenders.map((value, index) => {
                        if (index === 0) {
                          return (
                            <option key={index} disabled="True">
                              {value}
                            </option>
                          );
                        } else {
                          return <option key={index}>{value}</option>;
                        }
                      })}
                    </Form.Control>
                    <Form.Control.Feedback type="valid">
                      {" "}
                      Looks good !{" "}
                    </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                      {" "}
                      Gender is required{" "}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col>
                  <Form.Group controlId="gEducationalLevel">
                    <Form.Label>Educational Level</Form.Label>
                    <Form.Control
                      as="select"
                      type="select"
                      name="educationalLevel"
                      value={values.educationalLevel}
                      size="sm"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isValid={
                        touched.educationalLevel && !errors.educationalLevel
                      }
                      isInvalid={
                        errors.educationalLevel &&
                        touched.educationalLevel &&
                        errors.educationalLevel
                      }
                    >
                      {ListOfAllEducationalLevels.map((value, index) => {
                        if (index === 0) {
                          return (
                            <option key={index} disabled="True">
                              {value}
                            </option>
                          );
                        } else {
                          return <option key={index}>{value}</option>;
                        }
                      })}
                    </Form.Control>
                    <Form.Control.Feedback type="valid">
                      {" "}
                      Looks good !{" "}
                    </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                      {" "}
                      Educational Level is required{" "}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col>
                  <Form.Group controlId="gProfession">
                    <Form.Label>Profession</Form.Label>
                    <Form.Control
                      as="select"
                      type="select"
                      name="profession"
                      value={values.profession}
                      size="sm"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isValid={touched.profession && !errors.profession}
                      isInvalid={
                        errors.profession &&
                        touched.profession &&
                        errors.profession
                      }
                    >
                      {ListOfAllProfessions.map((value, index) => {
                        if (index === 0) {
                          return (
                            <option key={index} disabled="True">
                              {value}
                            </option>
                          );
                        } else {
                          return <option key={index}>{value}</option>;
                        }
                      })}
                    </Form.Control>
                    <Form.Control.Feedback type="valid">
                      {" "}
                      Looks good !{" "}
                    </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                      {" "}
                      Profession is required{" "}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col>
                  <Form.Group controlId="gCountry">
                    <Form.Label>Country</Form.Label>
                    <Form.Control
                      as="select"
                      type="select"
                      name="country"
                      value={values.country}
                      size="sm"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isValid={touched.country && !errors.country}
                      isInvalid={
                        errors.country && touched.country && errors.country
                      }
                    >
                      {ListOfAllCountries.map((value, index) => {
                        return <option key={index}>{value}</option>;
                      })}
                    </Form.Control>
                    <Form.Control.Feedback type="valid">
                      {" "}
                      Looks good !{" "}
                    </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                      {" "}
                      {errors.country}{" "}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col>
                  <Form.Group controlId="gState">
                    {(() => {
                      if (values.country === "India") {
                        //return <Form.Control required size="sm" as="select" defaultValue="Andaman and Nicobar Islands" onChange={this.handleState}>
                        return (
                          <div>
                            <Form.Label>State</Form.Label>
                            <Form.Control
                              as="select"
                              type="select"
                              name="state"
                              value={values.state}
                              size="sm"
                              onChange={handleChange}
                              onBlur={handleBlur}
                              isValid={touched.state && !errors.state}
                              isInvalid={
                                errors.state && touched.state && errors.state
                              }
                            >
                              {ListOfAllIndianStates.map((value, index) => {
                                return <option key={index}>{value}</option>;
                              })}
                            </Form.Control>
                            <Form.Control.Feedback type="valid">
                              {" "}
                              Looks good !{" "}
                            </Form.Control.Feedback>
                            <Form.Control.Feedback type="invalid">
                              {" "}
                              State is required{" "}
                            </Form.Control.Feedback>
                          </div>
                        );
                      }
                    })()}
                  </Form.Group>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col>
                  <Recaptcha
                    size="normal"
                    ref={e => (captchaRef = e)}
                    sitekey="6LdFscIUAAAAAKHF6JSkSwiux70z4V6wGtj1H5H5"
                    render="explicit"
                    onloadCallback={this.captchaOnloadCallback}
                    verifyCallback={this.captchaVerifyCallback}
                  />
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
              <Row>
                {" "}
                <Col></Col>{" "}
                <Col>
                  <Button variant="info" type="submit" size="sm">
                    Sign me up !
                  </Button>
                </Col>{" "}
                <Col></Col>{" "}
              </Row>
            </Container>
          </Form>
        )}
      </Formik>
      </div>
        ):("") 

      
    );
  }

}

const mapStateToProps = (state) => {
  return {}
}

const mapDispatchToProps = {
  completeProfile: completeProfile
}

export default connect(mapStateToProps,mapDispatchToProps)(CompleteUserDetails)

