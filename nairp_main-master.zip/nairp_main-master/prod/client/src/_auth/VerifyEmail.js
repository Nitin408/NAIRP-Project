import React from '../../node_modules/react'
import Container from '../../node_modules/react-bootstrap/Container'
import Row from '../../node_modules/react-bootstrap/Row'
import Col from '../../node_modules/react-bootstrap/Col'

class VerifyEmail extends React.Component {
  render(){
    return(
      <div>
        <Container className="containerForTbd">
          <Row>
            <Col></Col>
            <Col> Registration Successfull! <br/> Am email has been sent to you with the verification link. Please click on the link to verify your email and then proceed to login. Please note that you will NOT be able to login without verifying your email address. </Col>
            <Col></Col>
          </Row>
        </Container>
      </div>
    )
  }
}

export default VerifyEmail