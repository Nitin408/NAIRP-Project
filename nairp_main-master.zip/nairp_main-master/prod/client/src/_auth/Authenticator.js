import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import axios from "axios";
import {serverUrl} from "..clientMisc/"
class Authenticator extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isVerified: undefined
    };
  }

  componentDidMount() {
    const jwt = localStorage.getItem("my-jwt");
    if (!jwt) {
      this.props.history.push("/Login");
    }

    axios
      .post(serverUrl+'/api/auth/authenticator', {
        token: jwt
      })
      .then(res => {
        if (res.data.result === true) {
          this.setState({
            isVerified: res.data.result

          });
          console.log("Verified");

        } else {
          this.props.history.push(`/login`);
        }
      })
      .catch(err => {
        localStorage.removeItem("my-jwt");
        this.props.history.push("/Login");
      });
  }

  render() {
    if (this.state.isVerified === undefined) {
      return (
        <div>
          <h4>Loading...</h4>
        </div>
      );
    }

    return <div>{this.props.children}</div>;
  }
}

export default withRouter(Authenticator);
