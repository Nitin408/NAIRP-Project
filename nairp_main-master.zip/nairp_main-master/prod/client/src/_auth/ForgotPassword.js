import React, {Component} from '../../node_modules/react'
import Container from '../../node_modules/react-bootstrap/Container'
import Row from '../../node_modules/react-bootstrap/Row'
import Col from '../../node_modules/react-bootstrap/Col'
import Form from '../../node_modules/react-bootstrap/Form'
import Button from '../../node_modules/react-bootstrap/Button'
import * as yup from '../../node_modules/yup'
import { Formik } from '../../node_modules/formik'
import axios from 'axios'

class ForgotPassword extends Component{
    constructor(props) {
        super(props);

        this.state = {}
    }

    render(){
        const schema = yup.object({
            email   :   yup
                        .string()
                        .trim()
                        .required("Email address is required")
                        .lowercase()
                        .email("Invalid email address")
                        .max(50, "Email must be 50 characters at maximum"), 
        })

        return (
            <Formik
            initialValues={{
                email : ""
              }}
            validationSchema={schema}
            onSubmit={(values, { setSubmitting }) => {
                
            setSubmitting(false);

            values.email = values.email.trim().toLowerCase()

            axios.post("/api/auth/forgot_password", {email: values.email})
            .then(res => {
                
                console.log(res.data);
                if(res.data.success === true){ // Success
                  alert(res.data.message)
                }
                else {
                  alert(res.data.message)
                }
              })
              .catch(function (error) {
                console.log(error);
                alert("Internal server error !")
              });

            }}
            >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
        }) => (
          <Form noValidate onSubmit={handleSubmit}>
            <Container>
              <Row> <Col></Col> <Col xs={4}>
                <Form.Group controlId="gEmail">
                  <Form.Label>Email Address</Form.Label>
                  <Form.Control
                    type="email"
                    name="email" 
                    value={values.email} 
                    size="sm" 
                    placeholder="user@domain.com" 
                    onChange={handleChange} 
                    onBlur={handleBlur} 
                    isValid={touched.email && !errors.email}
                    isInvalid={errors.email && touched.email && errors.email} />
                  <Form.Control.Feedback type="valid"> Looks good ! </Form.Control.Feedback>
                  <Form.Control.Feedback type="invalid"> {errors.email} </Form.Control.Feedback>
                </Form.Group>
              </Col> <Col></Col> </Row>

              <Row> <Col></Col> <Col>
                <Button variant="info" type="submit" size="sm">Sign me up !</Button>
              </Col> <Col></Col> </Row>
            </Container>
          </Form>
        )}                
            </Formik>
        )
    }

}


export default ForgotPassword