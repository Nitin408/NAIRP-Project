import React, {Component} from 'react'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import * as yup from 'yup'
import axios from 'axios'
import { Formik } from 'formik'
import {resetPassword} from '../store/auth/action'
import {connect} from 'react-redux'
// import { throws } from 'assert'

class ResetPassword extends Component{
    constructor(props) {
        super(props);
        this.state = {
          response: {}
        }
    }

    checkToken = async () => {
      var email = this.props.match.params.user
      var token = this.props.match.params.token
      var response = await axios.post("/api/auth/check_pass_reset",{email,token})
      // console.log(response)
      return response
    }

    componentDidMount(){
      this.checkToken().then(res => {
        this.setState({
          response: res
        })
      })
    }

    render(){

      const schema = yup.object({
            password   : yup
                        .string()
                        .required("Password is required")
                        .min(8, "Password must be 8 characters at minimum")
                        .max(16, "Password must be 16 characters at maximum")
                        .matches(/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&.*])[a-zA-Z0-9!@#$%^&.*]{8,}$/, "Password must contain one uppercase letter, one lowercase letter, one digit and one special character !@#$%^&.*"),
            confirmPassword:  yup
                        .string()
                        .required('Confirm Password is required')
                        .min(8, "Password must be 8 characters at minimum")
                        .max(16, "Password must be 16 characters at maximum")
                        .oneOf([yup.ref('password'), null], 'Passwords must match')
        })

        if(this.state.response && this.state.response.data){
          if(this.state.response.data.success === true){
            return (
              <Formik
              initialValues={{
                  password          : "",
                  confirmPassword   : ""
                }}
              validationSchema={schema}
              onSubmit={(values, { setSubmitting }) => {

              setSubmitting(false);

              this.props.resetPassword({email: this.props.match.params.user, password: values.password})

              }}
              >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            handleSubmit,
          }) => (
            <Form noValidate onSubmit={handleSubmit}>
              <Container>
              <Row> <Col></Col> <Col xs={4}>
                  <Form.Group controlId="gPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                      type="password"
                      name="password"
                      value={values.password}
                      size="sm"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isValid={touched.password && !errors.password}
                      isInvalid={errors.password && touched.password && errors.password} />
                    <Form.Control.Feedback type="valid"> Looks good ! </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid"> {errors.password} </Form.Control.Feedback>
                  </Form.Group>
                </Col> <Col></Col> </Row>
                <Row> <Col></Col> <Col xs={4}>
                  <Form.Group controlId="gConfirmPassword">
                    <Form.Label>ConfirmPassword</Form.Label>
                    <Form.Control
                      type="password"
                      name="confirmPassword"
                      value={values.confirmPassword}
                      size="sm"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isValid={touched.confirmPassword && !errors.confirmPassword}
                      isInvalid={errors.confirmPassword && touched.confirmPassword && errors.confirmPassword} />
                    <Form.Control.Feedback type="valid"> Looks good ! </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid"> {errors.confirmPassword} </Form.Control.Feedback>
                  </Form.Group>
                </Col> <Col></Col> </Row>

                <Row> <Col></Col> <Col>
                  <Button variant="info" type="submit" size="sm">Reset Password</Button>
                </Col> <Col></Col> </Row>
              </Container>
            </Form>
          )}
              </Formik>
          )
          }
          else return(
            <h2>401 Unauthorized</h2>
          )

        }
        else{
          return ("")
        }




    }

}

const mapStateToProps = (state) => {
  return {}
}

const mapDispatchToProps = {
  resetPassword: resetPassword
}

export default connect(mapStateToProps,mapDispatchToProps)(ResetPassword)