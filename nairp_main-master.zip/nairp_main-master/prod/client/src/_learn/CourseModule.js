import React, { Component } from 'react'
//import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
// import Card from 'react-bootstrap/Card';
import Accordion from 'react-bootstrap/Accordion'
import { connect } from 'react-redux'
import Button from 'react-bootstrap/Button'
import { serverUrl, JWT_SECRET_KEY } from '../clientMisc'
//import Image from 'react-bootstrap/Image'
//import Carousel from 'react-bootstrap/Carousel'
import jwt from 'jsonwebtoken';
import { LinkContainer } from 'react-router-bootstrap'
//import { withRouter } from 'react-router-dom'
//import Nav from 'react-bootstrap/Nav'
import axios from 'axios';
import ReactPlayer from 'react-player'
import ButtonToolbar from 'react-bootstrap/ButtonToolbar'
//import Spinner from 'react-bootstrap/Spinner'
import Modal from 'react-bootstrap/Modal'
import { FaSync } from 'react-icons/fa';
import { CourseModuleSideBoxComponent } from "./components/CourseModuleSideBoxComponent.js"
import socket from 'socket.io-client';
import Tabs from 'react-bootstrap/Tabs'
import Tab from 'react-bootstrap/Tab'

class courseDetails extends Component {

  state = {
    data: [],
    RegisteredCoursesList: '',
    requiredData: null,
    SubscribeColor: '#8f000a',
    isLoggedIn: false,
    subscribeText: 'Subscribe',
    course_id: '',
    isSubscribed: true,
    pageId: '',
    userId: '',
    userDetails: null,
    isCourseAlreadySubscribed: false,
    exercises: [],
    AWSStarted: false,
    nameSplit: '',
    c: {},
    e: {},
    st: {},
    loading: {},
    StartButtonPressedandLoadingTrue: false,
    isExercisePresent: {},
    score: {},
    isModalOpen: [],
    particularExercise: {},
    isInstanceExisting: {},
    isInstanceRunning: {},
    isInstancePending: {},
    isInstanceStopping: {},
    instanceURL: {},
    isvalid: true,
    metadata: {},
    landedOnPage: {},
    clickedRefresh: {},
    fetchingData: true,
    landedOnPageForWW:{},
    isWorksheetInstanceExisting:{},
    isWorksheetInstanceRunning:{},
    isWorksheetInstancePending:{},
    isWorksheetInstanceStopping:{},
    worksheetInstanceURL:{},
  }

  async componentDidMount() {

    let pageId = this.props.match.params._id;
    //console.log(pageId)
    await this.setState({ pageId: pageId });

    ////////fetching details for the required page
    var result = await axios.post(serverUrl + '/api/course/get_course', { courseId: pageId })
    this.setState({ requiredData: result.data.data });
    let isModalOpen = {};
    this.state.requiredData.module.map(arg => {
      return arg.lecture.map((larg) => {
        return isModalOpen[larg.lecture_title] = false;
      })
    })
    this.setState({ isModalOpen });
    //console.log(this.state.isModalOpen)
    ///////fetching user details from jwt token and updating its relevant states
    const JwtToken = localStorage.getItem("my-jwt");
    this.setState({ fetchingData: true })
    if (JwtToken != null) {
      var userDetails = jwt.verify(JwtToken, JWT_SECRET_KEY);
      //console.log(userDetails)
      this.setState({ userDetails: userDetails.user, isLoggedIn: true, userId: userDetails._id });
      var subscribedCourses = await axios.post(serverUrl + '/api/course/subscribed_courses', { userId: this.state.userDetails._id })
      this.setState({ subscribedCourses: subscribedCourses.data });


      let landedOnPage = this.state.landedOnPage;
      let landedOnPageForWW = this.state.landedOnPageForWW;
      for (let i = 0; i < this.state.requiredData.module.length; i++) {
        for (let j = 0; j < this.state.requiredData.module[i].lecture.length; j++){
          landedOnPageForWW[this.state.requiredData.module[i].lecture[j]["lecture_id"]] = {}
          if(this.state.requiredData.module[i].lecture[j].worksheets!==null){
            for(let k = 0; k < this.state.requiredData.module[i].lecture[j].worksheets.length; k++){
              landedOnPageForWW[this.state.requiredData.module[i].lecture[j]["lecture_id"]][this.state.requiredData.module[i].lecture[j].worksheets[k]["worksheet_id"]] = true;
              this.isWorksheetInstanceExisting(this.state.requiredData.aws_course_id, this.state.requiredData.module[i] * 1000000 + this.state.requiredData.module[i].lecture[j]["lecture_id"] * 1000 + this.state.requiredData.module[i].lecture[j].worksheets[k]["worksheet_id"] * 1);
            }
          }
          
        }
        landedOnPage[this.state.requiredData.module[i]["module_id"]] = true

        this.isInstanceExisting(this.state.requiredData.aws_course_id, this.state.requiredData.module[i]["module_id"])
      }
      
      this.setState({ landedOnPage, landedOnPageForWW }, () => {
        console.log(this.state.landedOnPageForWW)
      })





      //////running loop to check wether course is subscribed or not and then makeing ui changes accordingly
      for (let i = 0; i < this.state.subscribedCourses.length; i++) {
        if (this.state.pageId === this.state.subscribedCourses[i]) {
          await this.setState({ isCourseAlreadySubscribed: true })
        }
      }
      if (this.state.isCourseAlreadySubscribed) {
        this.setState({ subscribeText: 'Subscribed', SubscribeColor: '#4d9453', isSubscribed: true, });
      }
    }
    else {
      this.setState({ userDetails: '', isLoggedIn: false });
    }
    this.setState({ fetchingData: false })
    let score_obj = {}
    // for (let i = 0; i < this.state.requiredData.module.length; i++) {

    //   let e = this.state.requiredData.module[i]["module_id"]
    //   const res = await this.getScoreFront(this.state.requiredData.aws_course_id, e)
    //   console.log("XXXXXXXXXXXX", res.data.accuracy, this.state.requiredData.aws_course_id)
    //   if (res.data.accuracy !== "NA") {
    //     console.log("This UID already exists in backend of NAIRP")
    //     score_obj[e] = res.data.accuracy
    //   } else {
    //     score_obj[e] = "No Data"
    //   }
    // }
    this.setState({ score: score_obj })

    console.log("The set state for score is", this.state.score)

  }


  isInstanceExisting = (course_id, exercise_id) => {
    let exercise_id2 = exercise_id * 1000000
    var io = socket.connect('http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/');
    io.on("connect", () => {
      io.emit("get_sage_status", {
        body: {
          course_id: course_id,
          exercise_id: exercise_id2
        },
        token: localStorage.getItem("my-jwt")
      })
      var isInstanceExisting = this.state.isInstanceExisting
      var isInstanceRunning = this.state.isInstanceRunning
      var isInstancePending = this.state.isInstancePending
      var isInstanceStopping = this.state.isInstanceStopping
      var instanceURL = this.state.instanceURL
      // isInstanceRunning[exercise_id]=false
      // isInstanceExisting[exercise_id] = true
      io.on("no_instance_exist", () => {
        isInstanceExisting[exercise_id] = false
      })
      io.on("sage_Inservice", (sagemakerURL) => {
        if ((sagemakerURL !== null) && sagemakerURL.startsWith("https")) {
          // console.log("Check works", sagemakerURL)
          instanceURL[exercise_id] = sagemakerURL
          isInstanceRunning[exercise_id] = true
        }
      })
      io.on("sage_Pending", () => {
        isInstancePending[exercise_id] = true
      })
      io.on("sage_Stopping", () => {
        isInstanceRunning[exercise_id] = false
        isInstanceStopping[exercise_id] = true
        isInstancePending[exercise_id] = false
      })
      io.on("sage_Stopped", () => {
        isInstancePending[exercise_id] = false
        isInstanceStopping[exercise_id] = false
        isInstanceRunning[exercise_id] = false
      })
      this.setState({ isInstanceExisting: isInstanceExisting, isInstanceRunning: isInstanceRunning, isInstancePending: isInstancePending, instanceURL: instanceURL }, () => {
        // console.log(this.state.isInstanceStopping, "is instance stopping");
        // console.log(this.state.isInstancePending, "is instance Pending")
      })
    })

  }

  isWorksheetInstanceExisting = (course_id, exercise_id) => {
    let exercise_id2 = exercise_id;
    var io = socket.connect('http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/');
    io.on("connect", () => {
      io.emit("get_sage_status", {
        body: {
          course_id: course_id,
          exercise_id: exercise_id2
        },
        token: localStorage.getItem("my-jwt")
      })
      var isWorksheetInstanceExisting = this.state.isWorksheetInstanceExisting
      var isWorksheetInstanceRunning = this.state.isWorksheetInstanceRunning
      var isWorksheetInstancePending = this.state.isWorksheetInstancePending
      var isWorksheetInstanceStopping = this.state.isWorksheetInstanceStopping
      var worksheetInstanceURL = this.state.worksheetInstanceURL
      // isInstanceRunning[exercise_id]=false
      // isInstanceExisting[exercise_id] = true
      io.on("no_instance_exist", () => {
        isWorksheetInstanceExisting[exercise_id2] = false
      })
      io.on("sage_Inservice", (sagemakerURL) => {
        if ((sagemakerURL !== null) && sagemakerURL.startsWith("https")) {
          // console.log("Check works", sagemakerURL)
          worksheetInstanceURL[exercise_id2] = sagemakerURL
          isWorksheetInstanceRunning[exercise_id2] = true
        }
      })
      io.on("sage_Pending", () => {
        isWorksheetInstancePending[exercise_id2] = true
      })
      io.on("sage_Stopping", () => {
        isWorksheetInstanceRunning[exercise_id2] = false
        isWorksheetInstanceStopping[exercise_id2] = true
        isWorksheetInstancePending[exercise_id2] = false
      })
      io.on("sage_Stopped", () => {
        isWorksheetInstancePending[exercise_id2] = false
        isWorksheetInstanceStopping[exercise_id2] = false
        isWorksheetInstanceRunning[exercise_id2] = false
      })
      this.setState({ isWorksheetInstanceExisting: isWorksheetInstanceExisting, isWorksheetInstanceRunning: isWorksheetInstanceRunning, isWorksheetInstancePending: isWorksheetInstancePending, worksheetInstanceURL: worksheetInstanceURL }, () => {
        // console.log(this.state.isInstanceStopping, "is instance stopping");
        // console.log(this.state.isInstancePending, "is instance Pending")
      })
    })

  }

  async isvalid(c) {

    var config = {
      method: 'get',
      url: `/validateUser?user_id=${this.state.userDetails._id}&course_id=${c}`,
      headers: {
        'Content-Type': 'application/json',
        'token': localStorage.getItem("my-jwt")
      }
    }
    await axios(config)
      .then((response) => {
        let isvalid = true
        console.log("Validation Check", response)
        if (response.data["valid"] === false) {
          isvalid = false
          console.log("Response arrived and valid is not true")
          console.log(isvalid)
          this.setState({ isvalid: false })
        }
      })
      .catch(function (error) {
        console.log(error)
      })
  }

  async demoStart(c, e) {
    let e1 = e * 1000000
    // Check if the user has exhausted the alloted credits, don't start and pop up message
    // var self = this
    await this.isvalid(c)
    console.log("The result is", this.state.isvalid)
    // console.log("The status is", this.state.isvalid)
    if (this.state.isvalid) {
      console.log("This will work only if check passed")
      var io = socket.connect('http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/');
      io.on("connect", () => {
        // console.log("socket connected");
        io.emit("get_sage_status", {
          body: {
            course_id: c,
            exercise_id: e1
          },
          token: localStorage.getItem("my-jwt")
        })
        io.emit("start-instance", () => {

          console.log("starting instance")
        })
      })
    }
    else {
      alert("Failure! You have exhausted all your alloted AWS Credits")
    }
    this.isInstanceExisting(c, e);
  }

  async demoWorksheetStart(c, e) {
    // Check if the user has exhausted the alloted credits, don't start and pop up message
    // var self = this
    await this.isvalid(c)
    console.log("The result is", this.state.isvalid)
    // console.log("The status is", this.state.isvalid)
    if (this.state.isvalid) {
      console.log("This will work only if check passed")
      var io = socket.connect('http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/');
      io.on("connect", () => {
        // console.log("socket connected");
        io.emit("get_sage_status", {
          body: {
            course_id: c,
            exercise_id: e
          },
          token: localStorage.getItem("my-jwt")
        })
        io.emit("start-instance", () => {

          console.log("starting instance")
        })
      })
    }
    else {
      alert("Failure! You have exhausted all your alloted AWS Credits")
    }
    this.isWorksheetInstanceExisting(c, e);
  }

  async getScoreCompute(c, e) {
    let e1 = e * 1000000
    // Check existing collection for presence of score, if not then fire up request.
    const jwt = localStorage.getItem("my-jwt")
    console.log(jwt, c, e)
    await axios.get("http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/sageview/getscore", {
      params: {
        course_id: c,
        exercise_id: e1,
        token: jwt
      }
    }).then((response) => {

      let score_obj = {}
      let answer_metadata = {}
      score_obj[e] = response.data.score
      let answer_data = []
      if (response.data.response_data != null) {
        answer_data = JSON.parse(response.data.response_data.replace(/'/g, '"'))
        answer_metadata[e] = answer_data

        console.log("Changes to the state are", score_obj, answer_metadata)
        this.setState(prevState => ({
          score: {
            ...prevState.score,
            [e]: response.data.score
          },
          metadata: {
            ...prevState.metadata,
            [e]: answer_data
          }
        }))
        // this.setState({ score: score_obj, metadata: answer_metadata })
        // return (score_obj)
        console.log(this.state.score)
        console.log(this.state.metadata)
      }
      else {
        console.log("The user has not submitted response")
        answer_metadata[e] = answer_data
        this.setState(prevState => ({
          score: prevState.score,
          metadata: prevState.metadata
        }))
        // this.setState({ score: score_obj, metadata: answer_metadata })
      }
    }).catch((err) => {
      console.log(err)
      alert("Error occurred")
    })
  }

  async getWorksheetScoreCompute(c, e) {
   
    // Check existing collection for presence of score, if not then fire up request.
    const jwt = localStorage.getItem("my-jwt")
    console.log(jwt, c, e)
    await axios.get("http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/sageview/getscore", {
      params: {
        course_id: c,
        exercise_id: e,
        token: jwt
      }
    }).then((response) => {

      let score_obj = {}
      let answer_metadata = {}
      score_obj[e] = response.data.score
      let answer_data = []
      if (response.data.response_data != null) {
        answer_data = JSON.parse(response.data.response_data.replace(/'/g, '"'))
        answer_metadata[e] = answer_data

        console.log("Changes to the state are", score_obj, answer_metadata)
        this.setState(prevState => ({
          score: {
            ...prevState.score,
            [e]: response.data.score
          },
          metadata: {
            ...prevState.metadata,
            [e]: answer_data
          }
        }))
        // this.setState({ score: score_obj, metadata: answer_metadata })
        // return (score_obj)
        console.log(this.state.score)
        console.log(this.state.metadata)
      }
      else {
        console.log("The user has not submitted response")
        answer_metadata[e] = answer_data
        this.setState(prevState => ({
          score: prevState.score,
          metadata: prevState.metadata
        }))
        // this.setState({ score: score_obj, metadata: answer_metadata })
      }
    }).catch((err) => {
      console.log(err)
      alert("Error occurred")
    })
  }

  async pushScore(c, e) {
    let e1 = e * 1000000
    let Body = {}
    Body["uid"] = c + "-" + e1 + "-" + this.state.userDetails._id
    Body["user_id"] = this.state.userDetails._id
    Body["course_id"] = c
    Body["module_id"] = e
    Body["question_type"] = "Prog_Ex"
    Body["accuracy"] = this.state.score[e]
    Body["request_data"] = this.state.metadata[e]
    console.log("Final Object is", Body)
    axios.post('/userScoreUpdate', {
      data: Body
    }, {
      headers: {
        'Content-Type': 'application/json',
        'token': localStorage.getItem("my-jwt")
      }
    })
      .then(response => {
        console.log(response)
      }, error => {
        console.log(error)
      })
  }
  async pushWorksheetScore(c, e) {
    let Body = {}
    Body["uid"] = c + "-" + e + "-" + this.state.userDetails._id
    Body["user_id"] = this.state.userDetails._id
    Body["course_id"] = c
    Body["module_id"] = e
    Body["question_type"] = "Prog_Ex"
    Body["accuracy"] = this.state.score[e]
    Body["request_data"] = this.state.metadata[e]
    console.log("Final Object is", Body)
    axios.post('/userScoreUpdate', {
      data: Body
    }, {
      headers: {
        'Content-Type': 'application/json',
        'token': localStorage.getItem("my-jwt")
      }
    })
      .then(response => {
        console.log(response)
      }, error => {
        console.log(error)
      })
  }

  async getScoreFront(c, e) {
    let e1 = e * 1000000
    let uid = c + "-" + e1 + "-" + this.state.userDetails._id
    try {
      const res = await axios.get(`/getScore?uid=${uid}`, {
        headers: {
          'Content-Type': 'application/json',
          'token': localStorage.getItem("my-jwt")
        }
      })
      return res
    } catch (error) {
      console.log(error)
    }
  }
  async demoStop(c, e) {

    // Fetch the scores from NAIRP backend on component mount, if not exists then fetch from the compute service on demoStop.
    // Update the score and metadata state.
    // Write/Update into DB the data, for same

    // const res = await this.getScoreFront(c, e)
    // console.log("XXXXXXXXXXXX", res.data.accuracy)
    // if (res.data.accuracy !== "NA") {
    //   console.log("This UID already exists in backend of NAIRP")
    //   let score_obj = {}
    //   score_obj[e] = res.data.accuracy
    //   this.setState({ score: score_obj })
    // }

    await this.getScoreCompute(c, e)
    let e1 = e * 1000000
    console.log("The state for score is", this.state.score)
    var io = socket.connect('http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/');
    io.on("connect", () => {
      // console.log("socket connected");
      io.emit("get_sage_status", {
        body: {
          course_id: c,
          exercise_id: e1
        },
        token: localStorage.getItem("my-jwt")
      })
      io.emit("stop-instance", () => {
        alert("Inititating termination of Jupyter Notebook instance.")
        let isInstancePending = this.state.isInstancePending;
        isInstancePending[e] = false;
        this.setState({ isInstancePending })
        console.log("stopping-instance");

      })
    })
    await this.pushScore(c, e);
    this.isInstanceExisting(c, e);
  }

  async demoWorksheetStop(c, e) {
    await this.getWorksheetScoreCompute(c, e)
    console.log("The state for score is", this.state.score)
    var io = socket.connect('http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/');
    io.on("connect", () => {
      // console.log("socket connected");
      io.emit("get_sage_status", {
        body: {
          course_id: c,
          exercise_id: e
        },
        token: localStorage.getItem("my-jwt")
      })
      io.emit("stop-instance", () => {
        alert("Inititating termination of Jupyter Notebook instance.")
        let isWorksheetInstancePending = this.state.isWorksheetInstancePending;
        isWorksheetInstancePending[e] = false;
        this.setState({ isWorksheetInstancePending })
        console.log("stopping-instance");

      })
    })
    await this.pushWorksheetScore(c, e);
    this.isWorksheetInstanceExisting(c, e);
  }

  async createInstance(c, e) {
    console.log("called")
    let e1 = e * 1000000
    console.log(e1)
    await this.isvalid(c)
    if (this.state.isvalid) {
      console.log("passed")
      var io = socket.connect('http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/');
      io.on("connect", () => {
        // console.log("socket connected");
        io.emit("get_sage_status", {
          body: {
            course_id: c,
            exercise_id: e1
          },
          token: localStorage.getItem("my-jwt")
        })
        io.emit("create-instance", () => {
          console.log("creating instance")
        })
      })
    }
    else {
      alert("Failure! You have exhausted all your alloted AWS Credits")
    }
    this.isInstanceExisting(c, e);
  }
  async createWorksheetInstance(c, e) {
    await this.isvalid(c)
    if (this.state.isvalid) {
      console.log("passed")
      var io = socket.connect('http://compute-aws-service-staged.eba-jgbgzszy.ap-south-1.elasticbeanstalk.com/');
      io.on("connect", () => {
        // console.log("socket connected");
        io.emit("get_sage_status", {
          body: {
            course_id: c,
            exercise_id: e
          },
          token: localStorage.getItem("my-jwt")
        })
        io.emit("create-instance", () => {
          console.log("creating instance")
        })
      })
    }
    else {
      alert("Failure! You have exhausted all your alloted AWS Credits")
    }
    this.isWorksheetInstanceExisting(c, e);
  }
  // getUrl(c, e) {
  //   const jwt = localStorage.getItem("my-jwt")
  //   axios.get("http://13.234.17.238:9000/sagehandler/", {
  //     params: {
  //       course_id: c,
  //       exercise_id: e,
  //       token: jwt
  //     }
  //   }).then((response) => {
  //     console.log(response)
  //     //document.getElementById('urlspan').innerHTML = `<a href="${response.data.url}" target="_blank">Click here to go to SageMaker</a>`;
  //     if (response.data.url && response.data.url !== "nil") {
  //       window.open(response.data.url, '_blank');
  //     } else {
  //       alert("Error fetching URL");
  //     }
  //   }).catch((err) => {
  //     alert(err)
  //   })
  // }


  callBackforStartButtonPressedandLoadingTrue = (statefromChild) => {
    this.setState({ StartButtonPressedandLoadingTrue: statefromChild })
  }
  render() {

    var { requiredData } = this.state;
    //var {exercises} = this.state;
    //  console.log(requiredData)
    var { userDetails } = this.state;
    return (

      (requiredData != null && !this.state.fetchingData) ? (

        (userDetails != null && this.state.isCourseAlreadySubscribed) ? (<div style={{ width: '98%', height: 'auto' }} >
          <Row>
            {/* Left cards Comes Here */}
            <Col xs={9} style={{ marginLeft: '1%' }}>
              <div style={{ alignItems: 'center', textAlign: 'center' }}>
                <a href={`/courseintro/${this.state.requiredData._id}`} onClick={() => {
                  this.props.history.push(`/courseintro/${this.state.requiredData._id}`);
                }} style={{ textAlign: 'center', color: '#666', fontSize: 30 }}>{requiredData.course_title}</a>
              </div>
              {requiredData.module.map((arg, index) => {

                return (
                  <div key={index} style={{ border: '2px solid #000', padding: 30, marginTop: 10 }}>
                    <div > <p style={{ color: '#888', fontSize: 25 }}>{arg.module_id}. {arg.module_title}</p></div>
                    {arg.lecture.map((larg, index) => {

                      return (
                        <Accordion key={index} style={{ width: '100%', height: 250, marginBottom: 10, border: '2px solid #000' }} >


                          <div id="lecture blocks" style={{ marginBottom: 10, width: '100%', height: 'auto', float: 'right', display: 'flex', flexDirection: 'row' }}>
                            <div style={{ width: '75%', borderTopLeftRadius: 5, borderBottomLeftRadius: 5, backgroundColor: '#f0f0f0', height: '100%', paddingLeft: '2%', display: 'flex', justifyContent: 'space-around', flexDirection: 'column' }}>
                              <p style={{ fontSize: 20, marginTop: 20 }}>{larg.lecture_id}. {larg.lecture_title}</p>


                              {(larg.lecture_note != null) ? (
                                <div style={{ height: '100%', width: '100%' }}>
                                  <Button onClick={() => {
                                    let modalState = this.state.isModalOpen;
                                    modalState[larg.lecture_title] = true;

                                    this.setState({ isModalOpen: modalState })
                                  }} style={{ fontSize: 20, color: 'black', height: 30, width: '100%' }}> Lecture Note </Button>
                                  <Modal show={this.state.isModalOpen[larg.lecture_title]} onHide={() => {
                                    let modalState = this.state.isModalOpen;
                                    modalState[larg.lecture_title] = false;
                                    this.setState({ isModalOpen: modalState })
                                  }} style={{ height: '800px', width: '100%' }} size="xl">
                                    <Modal.Header closeButton>
                                      <Modal.Title>{larg.lecture_title}</Modal.Title>
                                    </Modal.Header>
                                    <Modal.Body style={{ height: '800px' }} >
                                      <iframe style={{ height: '90%', width: '100%' }} src={larg.lecture_note} title="Note" crossorigin />
                                    </Modal.Body>
                                    <Modal.Footer>
                                      <Button variant="secondary" onClick={() => {
                                        let modalState = this.state.isModalOpen;
                                        modalState[larg.lecture_title] = false;
                                        this.setState({ isModalOpen: modalState })
                                      }}>
                                        Close
                                  </Button>

                                    </Modal.Footer>
                                  </Modal>
                                </div>
                              ) : ("")}
                              <div style={{ width: '100%', height: 100 }}>
                                <Tabs defaultActiveKey="profile" id="uncontrolled-tab-example">
                                  {(larg.worksheets != null && larg.worksheets.length > 0) ? (larg.worksheets.map((warg, index) => {
                                    return (
                                      <Tab eventKey={warg.worksheet_id} title={"Access practice worksheet "+warg.worksheet_id}>





                                        { (this.state.landedOnPageForWW[larg.lecture_id][warg.worksheet_id] === true) ? (
                                          <div style={{ marginTop: 10 }}>
                                            <ButtonToolbar style={{ width: '10%', float: 'left' }}  >
                                              <Button onClick={() => {
                                                this.isWorksheetInstanceExisting(this.state.requiredData.aws_course_id,arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1);
                                                
                                                let landedOnPageForWW = this.state.landedOnPageForWW;
                                                landedOnPageForWW[larg.lecture_id][warg.worksheet_id] = false;

                                                this.setState({ landedOnPageForWW })
                                              }} variant="secondary" style={{ backgroundColor: '#fff', marginLeft: 5, marginRight: 5, width: '100%', color: '#000' }}><FaSync /> </Button>

                                            </ButtonToolbar>
                                            <div style={{ width: '90%', float: 'right', justifyContent: 'center', alignItems: 'center', marginTop: 10, }}>Click the refresh button to get running status of Jupyter Notebook instance in AWS SageMaker for Practice worksheet. </div>

                                          </div>
                                        ) : (
                                          <div>
                                            {(this.state.isWorksheetInstanceRunning[arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1] === true) ? (
                                              <div style={{ marginTop: 10 }}>
                                                <ButtonToolbar style={{ width: '10%', float: 'left' }}  >
                                                  <Button onClick={() => { this.isWorksheetInstanceExisting(this.state.requiredData.aws_course_id, arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1) }} variant="secondary" style={{ backgroundColor: '#fff', marginLeft: 5, marginRight: 5, width: '100%', color: '#000' }}><FaSync /> </Button>

                                                </ButtonToolbar>

                                                <div style={{ width: '90%', float: 'right', justifyContent: 'center', alignItems: 'center', marginTop: 10, }}>Jupyter Notebook instance in AWS SageMaker is running. <a role="button" style={{ color: 'blue' }} onClick={() => { this.demoWorksheetStop(requiredData.aws_course_id, arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1); this.isWorksheetInstanceExisting(this.state.requiredData.aws_course_id, arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1) }}>Click Here</a> to stop it.</div>
                                                <ButtonToolbar style={{ width: '100%', float: "right", marginBottom: 10 }}  >
                                                  <Button onClick={() => { window.open(this.state.worksheetInstanceURL[arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1]); }} variant="secondary" style={{ marginTop: 5, width: '100%' }}>Take me to AWS SageMaker for Practice worksheet.</Button>
                                                </ButtonToolbar>
                                              </div>
                                            ) : (
                                              <div style={{ marginTop: 10 }}>
                                                <ButtonToolbar style={{ width: '10%', float: 'left' }}  >
                                                  <Button onClick={() => { this.isWorksheetInstanceExisting(this.state.requiredData.aws_course_id, arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1) }} variant="secondary" style={{ backgroundColor: '#fff', marginLeft: 5, marginRight: 5, width: '100%', color: '#000' }}><FaSync /> </Button>

                                                </ButtonToolbar>
                                                {(this.state.isWorksheetInstancePending[arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1] !== true || this.state.isWorksheetInstancePending[arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1] === false) ? (
                                                  (this.state.isWorksheetInstanceStopping[arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1] === true) ? (
                                                    <div style={{ width: '90%', float: 'right', justifyContent: 'center', alignItems: 'center', marginTop: 10, }}>Jupyter Notebook instance in AWS SageMaker is stopping. Please refresh after 1 minute. </div>
                                                  ) : (<div style={{ width: '90%', float: 'right', justifyContent: 'center', alignItems: 'center', marginTop: 10, }}>Jupyter Notebook instance in AWS SageMaker is not running. <a role="button" style={{ color: 'blue' }} onClick={() => {
                                                    if (this.state.isWorksheetInstanceExisting[arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1] !== false) {
                                                      this.demoWorksheetStart(requiredData.aws_course_id, arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1);
                                                      this.isWorksheetInstanceExisting(this.state.requiredData.aws_course_id, arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1)
                                                    }
                                                    else {
                                                      this.createWorksheetInstance(requiredData.aws_course_id, arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1);
                                                      this.isWorksheetInstanceExisting(this.state.requiredData.aws_course_id, arg.module_id * 1000000 + larg.lecture_id * 1000 + warg.worksheet_id * 1)
                                                    }
                                                  }}>Click Here</a>  to start it. </div>)
                                                ) : (
                                                  <div style={{ width: '90%', float: 'right', justifyContent: 'center', alignItems: 'center', marginTop: 10, }}>Jupyter Notebook instance in AWS SageMaker is starting. Please refresh after 3-5 minutes.</div>
                                                )}
                                              </div>
                                            )}
                                          </div>

                                        )
                                        }






                                      </Tab>
                                    )
                                  })) : ("")}
                                </Tabs>
                              </div>

                            </div>
                            {(larg.lecture_video != null) ? (
                              <div id="video comes here" style={{ width: '25%', height: 190, marginTop: 3 }}>
                                <ReactPlayer url={larg.lecture_video} width="100%" height="100%" controls={true} />
                              </div>) : ("")}

                          </div>
                        </Accordion>
                      )
                    })
                    }







                    <div style={{ height:150,width: '100%', border: '1px solid #000', borderRadius: 5, marginTop: 60, boxShadow: "1px 1px 5px #9E9E9E" }}>
                      <p style={{ marginLeft: "40%", fontSize: 25, }}>Programming Exercise</p>
                      {(this.state.landedOnPage[arg.module_id] === true) ? (
                        <div style={{ marginTop: 5 }}>
                          <ButtonToolbar style={{ width: '10%', float: 'left' }}  >
                            <Button onClick={() => {
                              this.isInstanceExisting(this.state.requiredData.aws_course_id, arg.module_id);

                              let landedOnPage = this.state.landedOnPage;
                              landedOnPage[arg.module_id] = false;

                              this.setState({ landedOnPage })
                            }} variant="secondary" style={{ backgroundColor: '#fff', marginLeft: 5, marginRight: 5, width: '100%', color: '#000' }}><FaSync /> </Button>

                          </ButtonToolbar>
                          <div style={{ width: '90%', float: 'right', justifyContent: 'center', alignItems: 'center',  }}>Click the refresh button to get running status of Jupyter Notebook instance in AWS SageMaker for Programming Exercise. </div>

                        </div>
                      ) : (
                        <div>
                          {(this.state.isInstanceRunning[arg.module_id] === true) ? (
                            <div style={{ marginTop: 5 }}>
                              <ButtonToolbar style={{ width: '10%', float: 'left' }}  >
                                <Button onClick={() => { this.isInstanceExisting(this.state.requiredData.aws_course_id, arg.module_id) }} variant="secondary" style={{ backgroundColor: '#fff', marginLeft: 5, marginRight: 5, width: '100%', color: '#000' }}><FaSync /> </Button>

                              </ButtonToolbar>

                              <div style={{ width: '90%', float: 'right', justifyContent: 'center', alignItems: 'center',}}>Jupyter Notebook instance in AWS SageMaker is running. <a role="button" style={{ color: 'blue' }} onClick={() => { this.demoStop(requiredData.aws_course_id, arg.module_id); this.isInstanceExisting(this.state.requiredData.aws_course_id, arg.module_id) }}>Click Here</a> to stop it. Please select conda_python3 from the list of available kernels.</div>
                              <ButtonToolbar style={{ width: '100%', float: "right", marginBottom: 10 }}  >
                                <Button onClick={() => { window.open(this.state.instanceURL[arg.module_id]); }} variant="secondary" style={{ marginTop: 5, width: '100%' }}>Take me to AWS SageMaker for programming exercise </Button>
                              </ButtonToolbar>
                            </div>
                          ) : (
                            <div style={{ marginTop: 5 }}>
                              <ButtonToolbar style={{ width: '10%', float: 'left' }}  >
                                <Button onClick={() => { this.isInstanceExisting(this.state.requiredData.aws_course_id, arg.module_id) }} variant="secondary" style={{ backgroundColor: '#fff', marginLeft: 5, marginRight: 5, width: '100%', color: '#000' }}><FaSync /> </Button>

                              </ButtonToolbar>
                              {(this.state.isInstancePending[arg.module_id] !== true || this.state.isInstancePending[arg.module_id] === false) ? (
                                (this.state.isInstanceStopping[arg.module_id] === true) ? (
                                  <div style={{ width: '90%', float: 'right', justifyContent: 'center', alignItems: 'center',  }}>Jupyter Notebook instance in AWS SageMaker is stopping. Please refresh after 1 minute. </div>
                                ) : (<div style={{ width: '90%', float: 'right', justifyContent: 'center', alignItems: 'center',  }}>Jupyter Notebook instance in AWS SageMaker is not running. <a role="button" style={{ color: 'blue' }} onClick={() => {
                                  if (this.state.isInstanceExisting[arg.module_id] !== false) {
                                    this.demoStart(requiredData.aws_course_id, arg.module_id);
                                    this.isInstanceExisting(this.state.requiredData.aws_course_id, arg.module_id)
                                  }
                                  else {
                                    this.createInstance(requiredData.aws_course_id, arg.module_id);
                                    this.isInstanceExisting(this.state.requiredData.aws_course_id, arg.module_id)
                                  }
                                }}>Click Here</a>  to start it. </div>)
                              ) : (
                                <div style={{ width: '90%', float: 'right', justifyContent: 'center', alignItems: 'center',  }}>Jupyter Notebook instance in AWS SageMaker is starting. Please refresh after 3-5 minutes.</div>
                              )}
                            </div>
                          )}
                        </div>

                      )



                      }
                      
                    </div>
                    {arg.exercise !== null ? (
                        <ButtonToolbar style={{ width: '100%', flexDirection: 'row', marginBottom: 10, }} >
                          <LinkContainer style={{ width: '100%' }} to={{
                            pathname: '/objective_exercise',
                            data: {
                              "courseId": this.state.pageId,
                              "exercise": arg.exercise
                            },
                          }} ><a href={'/objective_exercise'}> <Button variant="success" style={{ width: '100%' }} >Take me to Objective Exercise</Button></a></LinkContainer>
                        </ButtonToolbar>
                      ) : null}
                  </div>
                )
              })}

            </Col>
            {/*Right Card comes here*/}
            <Col xs={3} style={{ position: 'absolute', right: 0 }}>
              <CourseModuleSideBoxComponent requiredData={requiredData} />

            </Col>
          </Row>
        </div>) : (<div style={{ width: '100%', height: "100%", flex: 1, justifyContent: "center", alignItems: 'center', textAlign: 'center' }}>
          <p style={{}}>OOPS! YOU HAVENT SUBSCRIBED TO THE COURSE PLEASE SUBCRIBE TO THE COURSE TO ACCESS THE CONTENT </p>
        </div>)
      ) : (<div style={{ width: '100%', height: "100%", flex: 1, justifyContent: "center", alignItems: 'center', textAlign: 'center' }}>
        <p style={{}}> Loading...</p>
      </div>)
    )
  }
}

const mapStateToProps = (state) => {
  return {
    profile: state.profile,
    isLogin: state.isLogin
  }
}


export default connect(mapStateToProps)(courseDetails)




