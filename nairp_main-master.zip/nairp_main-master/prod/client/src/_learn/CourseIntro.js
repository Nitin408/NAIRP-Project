import React, { Component } from 'react'
//import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Card from 'react-bootstrap/Card';
//import Accordion from 'react-bootstrap/Accordion'
//import {connect} from 'react-redux'
import Button from 'react-bootstrap/Button'
import ButtonToolbar from 'react-bootstrap/ButtonToolbar'
//import Image from 'react-bootstrap/Image'
//import Carousel from 'react-bootstrap/Carousel'
import jwt from 'jsonwebtoken';
//import { LinkContainer } from 'react-router-bootstrap'
//import { withRouter } from 'react-router-dom'
//import Nav from 'react-bootstrap/Nav'
import axios from 'axios';
//import ReactPlayer from 'react-player'
import {serverUrl, JWT_SECRET_KEY} from '../clientMisc'
import {ReactPlayerComponent} from './components/ReactPlayer'
//import {onSubscribeFunction} from "./functions/Onsubscribe"
import {CourseIntroSideBox} from "./components/CourseIntroSideBox";
class CourseIntro extends Component {
  
  state = {
    data: [],
    RegisteredCoursesList: '',
    requiredData: null,
    SubscribeColor:'#8f000a',
    isLoggedIn:false,
    subscribeText:'Subscribe',
    course_id:'',
    isSubscribed:false,
    pageId:'',
    userId:'',
    userDetails:null,
    isCourseAlreadySubscribed:false,
    exercises:[],
    nameSplit: '',
    c: '',
    e: '',
    st: '',
    course_description:''
    
  }
  // componentDidMount(){
    
  //   const video = document.querySelector('.viewer');
  //   video.addEventListener('contextmenu', event => event.preventDefault());
  // }
 async componentDidMount() {
    let pageId = this.props.match.params._id;
    await this.setState({pageId:pageId});
////////fetching details for the required page   
    var result = await axios.post(serverUrl+'/api/course/get_course', { courseId: pageId })
    this.setState({ requiredData: result.data.data },async ()=>{
		await fetch(this.state.requiredData.course_description)
    .then((r) => r.text())
    .then(text  => {
      this.setState({course_description:text})
    })  
      //console.log(this.state.requiredData)
    });
///////fetching user details from jwt token and updating its relevant states    
    const JwtToken = localStorage.getItem("my-jwt");
    if(JwtToken!=null){
      var userDetails = jwt.verify(JwtToken, JWT_SECRET_KEY);
    this.setState({ userDetails: userDetails.user, isLoggedIn:true });
    var subscribedCourses = await axios.post(serverUrl+'/api/course/subscribed_courses', { userId: this.state.userDetails._id })
    this.setState({ subscribedCourses: subscribedCourses.data });
  
//////running loop to check wether course is subscribed or not and then makeing ui changes accordingly
    for(let i=0; i<this.state.subscribedCourses.length; i++){
        if(this.state.pageId===this.state.subscribedCourses[i]){
         await this.setState({isCourseAlreadySubscribed:true})
        }   
      }
      if(this.state.isCourseAlreadySubscribed){
        this.setState({ subscribeText: 'Subscribed', SubscribeColor: '#4d9453', isSubscribed: true, }) 
      }
    }
    else{
        this.setState({userDetails:'', isLoggedIn: false});
      }
  }
///when subscribed it checks for all conditions and then executes accordingly  
  onSubscribe = async () => {
    const JwtToken =await localStorage.getItem("my-jwt");
     if (!JwtToken) {
      alert("Please login before subscribing.");
 
    }
    else {
      
      if(this.state.isCourseAlreadySubscribed){
        alert('you are already subscribed to this course');
        
      }
      else{
        await axios({
          method: 'PUT',
          url: serverUrl+'/api/course/subscribe_user_to_course',
          data: JSON.stringify({
            email: this.state.userDetails.email,
            courseId: this.state.pageId
          }),
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            "Access-Control-Allow-Credentials": "true"
          }
        })
        
        .then(
          this.setState({ subscribeText: 'Subscribed', SubscribeColor: '#4d9453', isSubscribed: true, }, ()=>{
            alert('You have been successfully subscribed to this course.')
          }));
      }
  
    }
    //then(this.setState({ subscribeText: 'Subscribed', SubscribeColor: '#4d9453', isSubscribed: true, }));
      }
  
////////when take me to course button is pressed
takeTotheCourse = () =>{
    if(this.state.isSubscribed){
        this.props.history.push(`/courseDetails/${this.state.requiredData._id}`);
    }
    else{
        alert('Please subscribe to the course first.')
    }
}

 ///////////////////////
  render() {
    
    var {requiredData} = this.state;
   // console.log(requiredData);
    var {userDetails} = this.state;
    return (    
      (requiredData!=null && userDetails!=null ) ? (
        <div style={{ width: '98%', height: 'auto' }}>
        <Row>
          <Col xs = {1}/>
          <Col xs={7} >
            <div className='Header' xs={3} style={{ width: '100%', height: 100, marginTop: '2%', flexDirection: 'column', justifyContent: 'space-around' }}>
              <div style={{ width: '100%', justifyContent: 'center', alignItems: 'center', marginLeft: '10%', }}><h2 style={{ color: '#333' }}> Introduction to the Course </h2></div>
              
            </div>
{/*React player goes here*/}

              <ReactPlayerComponent requiredData={requiredData} course_description={this.state.course_description}/>
              
          </Col>
          <Col xs={1}/>
          <Col xs={3} >
   {/* right card Comes here.......               */}           
            <div style={{ borderWidth: 2, borderColor: '#000', borderRadius: 10, width: '100%', height: 200,}}>
              <Card text="a1a1a1" style={{ width: '100%', height: 'auto', boxShadow: "1px 1px 5px #9E9E9E", borderRadius: 10 }}>
              <ButtonToolbar >
                    <Button onClick={()=>{
                        this.onSubscribe()
                    }}  style={{backgroundColor: this.state.SubscribeColor, marginLeft: 5, marginRight: 5, marginTop: 5, width:'100%' }}>{this.state.subscribeText}</Button>
            </ButtonToolbar> 
                <CourseIntroSideBox requiredData={requiredData}/>
              </Card>
            <div className="take me to the course button" style={{marginTop:20}}>
            <ButtonToolbar >
                    <Button onClick={()=>{
                        this.takeTotheCourse()
                    }} variant="danger" style={{ marginLeft: 5, marginRight: 5, marginTop: 5, width:'100%' }}>Take me to the Course</Button>
            </ButtonToolbar>          
            </div> 
            </div></Col>
        </Row>
      </div>
        ) : ("")
    )
  }
}

// const mapStateToProps = (state) => {
//   return {
//     profile: state.profile,
//     isLogin: state.isLogin
//   }
// }


export default CourseIntro




