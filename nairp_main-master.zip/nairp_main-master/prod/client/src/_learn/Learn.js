import React, { Component } from 'react'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Card from 'react-bootstrap/Card';
import Accordion from 'react-bootstrap/Accordion'
import jwt from 'jsonwebtoken';
import Button from 'react-bootstrap/Button'
import {serverUrl, JWT_SECRET_KEY} from '../clientMisc'
import axios from 'axios';
import { connect } from 'react-redux';
import {CourseCard} from './components/CourseCard.js';
import {SubscribedCourses} from './components/SubscribedCourses.js';
import {CarouselComponent} from './components/Carousel';
import {fetchCourses, validateCachedCourses} from '../store/course/action'

class Learn extends Component {

    state = {
        RegisteredCoursesList: [],
        courseData: [],
        isLoggedIn:false,
        subscribedCourses:null,
        userDetails:null,
        
    }
   async componentDidMount() {

    if(this.props.courses.cData.length === 0){
        // cache does not exists
        await this.props.fetchCourses()
    }
    else{
        // cache exists
        this.props.validateCachedCourses(this.props.courses.cData)
    }

//////////fetches al subscribed courses and converting the courseId to CourseTitle 
    const JwtToken = localStorage.getItem("my-jwt");
    //console.log(JwtToken)
    if(JwtToken!=null){
        var userDetails =await jwt.verify(JwtToken, JWT_SECRET_KEY);
        this.setState({userDetails:userDetails.user});
        var subscribedCourses = await axios.post(serverUrl+'/api/course/subscribed_courses', {userId:this.state.userDetails._id})
        let subscribedCoursesData = subscribedCourses.data;

        //console.log(subscribedCoursesData)
            for (var i = 0; i < subscribedCoursesData.length; i++) {
                for(var j=0; j < this.props.courses.cData.length;j++){
                    var CourseAndId = {};
                    if(subscribedCoursesData[i]===this.props.courses.cData[j]._id){
                        CourseAndId["_id"]=this.props.courses.cData[j]._id;
                        CourseAndId["course_title"] = this.props.courses.cData[j].course_title;
                        this.state.RegisteredCoursesList.push(CourseAndId);
                        
                    }   
                }
            }
            subscribedCourses=this.state.RegisteredCoursesList;
            console.log(subscribedCourses)
            //console.log(subscribedCourses)
        this.setState({isLoggedIn:true});
    }
    else{
        this.setState({RegisteredCoursesList:['Please login to see all your subscribed courses'], isLoggedIn:false})
    }
}
    
    render() {
        var {RegisteredCoursesList} = this.state;
        var { courseData } = this.state;
      // console.log(RegisteredCoursesList)
        const importAll = require =>
            require.keys().reduce((acc, next) => {
                acc[next.replace("./", "")] = require(next);
                return acc;
            }, {});
/////// creating an image array
        // const images = importAll(
        //     require.context("./course_card_images", false, /\.(png|jpe?g|svg)$/)
        // );
        const banner = importAll(
            require.context("./carousal_images", false, /\.(png|jpe?g|svg)$/)
        );
       // const imageArray = Object.values(images); 
        const bannerArray = Object.values(banner);
        //console.log(bannerArray) 
////////main page
        return (
(this.props.courses.cData!==[]) ? (
            <div style={{ width: '98%' }}>

                <Row >
                <Col className="left_box" style={{ height: '100%', width: '100%' }} xs={2}>
            <Accordion style={{ width: '100%', height: '100%', }}>
              <Card style={{ width: '100%', height: '100%', border: 'none' }}>
              <Accordion.Toggle as={Button} variant="link" eventKey="0" style={{textDecoration:'none', backgroundColor:'#30797e'}} >
                <Card.Header style={{background:'none'}}>
                 
                    <p style={{ fontSize: 20, color:'#fff' }}> My Courses </p>
                
                </Card.Header>
                </Accordion.Toggle>
                 {    (this.state.isLoggedIn)?(
                           RegisteredCoursesList.map((arg, index)=>{
                            return(
                             
                             <SubscribedCourses arg={arg} key={index}/>
                             )
                          })
                          ):(
                            <Accordion.Collapse eventKey="0">
                            
                         <Card.Body>
        
                            {this.state.RegisteredCoursesList}
                         </Card.Body>
                         
                          </Accordion.Collapse>
                         )
                         }   
              </Card>
            </Accordion>
          </Col>
                    <Col className="right_box" xs={10} style={{ float: 'none' }}>
                        <div>
                                <CarouselComponent bannerArray={bannerArray} courseData={courseData}/>
                        
                            <div style={{marginTop:20 }}>
                                <ul style={{ textDecoration: 'none', listStyle: 'none', display: 'flex', flexDirection: 'row', flexWrap: 'wrap' }}>
                               { this.props.courses.cData.map((arg, index) => {
                                    return(

                                                <CourseCard arg={arg} key={index}/>
                                          
                                            )
                                    }
                                )}
                                    {/* {list} */}
                                </ul>


                            </div>
                        </div>
                    </Col>
                </Row>

            </div>
):("")
        )
    }

}
const mapStateToProps = (state) => {
    return {
      profile: state.profile,
      courses: state.courses
    }
  }

const mapDispatchToProps = {
    fetchCourses,
    validateCachedCourses
}

export default connect(mapStateToProps, mapDispatchToProps)(Learn);
