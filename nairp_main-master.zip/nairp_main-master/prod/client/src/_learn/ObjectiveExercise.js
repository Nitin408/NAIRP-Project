import React, { Component } from 'react';
import { serverUrl } from '../clientMisc';
//import quizQuestions from './api/quizQuestions';
import Quiz from './components/Quiz';
import Result from './components/Result';
import './ObjectiveExercise.css'
import Button from 'react-bootstrap/Button'
import { IoIosArrowRoundBack } from "react-icons/io"
import Alert from 'react-bootstrap/Alert'
let MultipleAnswerArray = [];
export default class ObjectiveExercise extends Component {
  constructor(props) {
    super(props);

    this.state = {
      counter: 0,
      questionId: 1,
      question: '',
      answerOptions: [],
      answer: '',
      answersCount: {},
      result: [],
      score: 0,
      quizQuestions: [],
      navigatedData: null,
      questionType: '',
      totalScore: 0,
      InputAnswer: '',
      mcqType: '',
      MultipleAnswerArray: [],
      showResults: false,
      alertDisplay: false,
    };

    this.handleAnswerSelected = this.handleAnswerSelected.bind(this);
  }

  componentDidMount() {
    let navigatedDataVariable = this.props.location.data;
    console.log(this.props.location.data)
    this.setState({ navigatedData: navigatedDataVariable }, async () => {
      if (typeof (this.props.location.data) !== "undefined") {
        await fetch(serverUrl + '/get_objectexercise')
          .then((response) => {
            let jsonStr = response.json();
            jsonStr.then(result => {
				console.log(result)
              let exercises = [];
              let totalScore = 0;
			  for (let k = 0; k<this.props.location.data["exercise"].length; k++){
				  if (this.props.location.data["exercise"][k]["exercise_type"] === "objectiveExercise"){
						for (let i = 0; i < result.length; i++) {
							if (parseInt(result[i]['exercise_id']) === this.props.location.data["exercise"][k]["exercise_id"]) {
								console.log(result[i])
								exercises.push(result[i]);
								totalScore = totalScore + result[i].marks;
							}
						}
					}
				}
              this.setState({ quizQuestions: exercises, totalScore: totalScore }, () => {
                if (this.state.quizQuestions.length > 0 && this.state.quizQuestions !== null) {
                  const shuffledAnswerOptions = this.state.quizQuestions.map(question =>
                    this.shuffleArray(question.list_of_choices)
                  );
                  this.setState({
                    question: this.state.quizQuestions[0].question,
                    answerOptions: shuffledAnswerOptions[0],
                    questionType: this.state.quizQuestions[0].question_type,
                    mcqType: this.state.quizQuestions[0].mcq_type,
                  });
                }
              })
            })
          });
      }
      else {
        this.props.history.goBack();
      }
    });

  }
  shuffleArray(array) {
    var currentIndex = array.length,
      temporaryValue,
      randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {
      // Pick a remaining element...
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;

      // And swap it with the current element.
      temporaryValue = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temporaryValue;
    }

    return array;
  }

  handleAnswerSelected(event) {
    this.setUserAnswer(event.currentTarget.value);

    if (this.state.questionId < this.state.quizQuestions.length) {
      setTimeout(() =>
        this.setNextQuestion(), 400);
    } else {
      this.setState({ showResults: true })
    }
  }
  handleChange = (event) => {
    var input = event.target.value;
    var stripped = input.replace(/[^A-Za-z0-9]/g, '');
    stripped = stripped.toLowerCase();
    console.log(stripped)
    this.setState({ InputAnswer: event.target.value });
  }
  handleSubmit = () => {
    this.setUserAnswer(this.state.InputAnswer);
    if (this.state.questionId < this.state.quizQuestions.length) {
      setTimeout(() =>
        this.setNextQuestion(), 400);
    }
    else {
      this.setState({ showResults: true })
    }
  }
  handleMultipleChoiceSubmit = () => {
    let SelectedAnswers = this.state.MultipleAnswerArray;
    let answerProgress = {
      "question": this.state.question,
      "answerSelected": SelectedAnswers,
      "listOfAnswers": this.state.quizQuestions[this.state.counter].list_of_answers,
      "questionType": this.state.questionType,
      "mcqType": this.state.mcqType
    };
    let result = this.state.result;
    let isAnswerAlreadyPresent = false;
    if (result.length === 0) {
      this.state.result.push(answerProgress);
    }
    else {

      result.forEach(function (val, i) {
        if (val['question'] === answerProgress['question']) {
          isAnswerAlreadyPresent = true;
          let first = result[0];
          result[0] = result[i];
          result[i] = first;
          result.shift();
        }
      });
      if (isAnswerAlreadyPresent) {
        this.setState({ result: result });
        this.state.result.push(answerProgress);
      }
      else {
        this.state.result.push(answerProgress);
      }
    }
    let listOfAnswers = this.state.quizQuestions[this.state.counter].list_of_answers;
    const isAttemptCorrect = listOfAnswers.every(val => SelectedAnswers.includes(val));
    if (isAttemptCorrect) {
      this.setState({ score: this.state.score + this.state.quizQuestions[this.state.counter].marks })
    }
    console.log(this.state.result, "results");
    if (this.state.questionId < this.state.quizQuestions.length) {
      setTimeout(() =>
        this.setNextQuestion(), 400);
    } else {
      this.setState({ showResults: true })
    }
  }
  setUserAnswer(answer) {
    let answerProgress = {
      "question": this.state.question,
      "answerSelected": answer,
      "listOfAnswers": this.state.quizQuestions[this.state.counter].list_of_answers,
      "questionType": this.state.questionType,
      "mcqType": this.state.mcqType
    }

    if (answer === this.state.quizQuestions[this.state.counter].list_of_answers[0]) { this.setState({ score: this.state.score + this.state.quizQuestions[this.state.counter].marks }) }
    this.setState({ answer: answer });
    let result = this.state.result;
    let isAnswerAlreadyPresent = false;
    if (result.length === 0) {
      this.state.result.push(answerProgress);
    }
    else {

      result.forEach(function (val, i) {
        if (val['question'] === answerProgress['question']) {
          isAnswerAlreadyPresent = true;
          let first = result[0];
          result[0] = result[i];
          result[i] = first;
          result.shift();
        }
      });
      if (isAnswerAlreadyPresent) {
        this.setState({ result: result });
        this.state.result.push(answerProgress);
      }
      else {
        this.state.result.push(answerProgress);
      }
    }
    console.log(this.state.result, "results")
  }

  setNextQuestion = () => {
    const counter = this.state.counter + 1;
    const questionId = this.state.questionId + 1;

    this.setState({
      counter: counter,
      questionId: questionId,
      question: this.state.quizQuestions[counter].question,
      answerOptions: this.state.quizQuestions[counter].list_of_choices,
      answer: '',
      questionType: this.state.quizQuestions[counter].question_type,
      mcqType: this.state.quizQuestions[counter].mcq_type
    });
    //console.log(this.state.result, "results") 
  }
  setPreviousQuestion = () => {
    const counter = this.state.counter - 1;
    const questionId = this.state.questionId - 1;

    this.setState({
      counter: counter,
      questionId: questionId,
      question: this.state.quizQuestions[counter].question,
      answerOptions: this.state.quizQuestions[counter].list_of_choices,
      answer: '',
      questionType: this.state.quizQuestions[counter].question_type,
      mcqType: this.state.quizQuestions[counter].mcq_type
    });
    //console.log(this.state.result, "results")
  }
  render() {

    return (
      <div className="App">

        {(this.state.quizQuestions.length > 0 && this.state.quizQuestions !== null) ? (<div>
          {(this.state.showResults !== true) ? (
            <div>
              <Alert show={this.state.alertDisplay} variant="danger">
                <Alert.Heading>Warining!</Alert.Heading>
                <p>
                  Your Answer progress will be lost !
        </p>
                <hr />
                <div className="d-flex justify-content-end">
                  <Button onClick={() => this.setState({ alertDisplay: !this.state.alertDisplay })} variant="outline-danger">
                    Cancel
          </Button>
                  <Button onClick={() => this.props.history.goBack()} variant="outline-danger">
                    Go Back
          </Button>
                </div>
              </Alert>
              <div onClick={() => this.setState({ alertDisplay: !this.state.alertDisplay })} style={{ margin: 0,marginLeft:20, marginRight: 5, padding: 0, backgroundColor: '#fff', }}>
                <Button style={{ width: 100, position: "fixed", backgroundColor: "white", border: "#000 2px solid", color: "black", elevation: 10 }}>
                  <IoIosArrowRoundBack style={{ color: "black", fontSize: 30, }} />Return to Course Module Page</Button>
              </div>
              <Quiz
                answer={this.state.answer}
                answerOptions={this.state.answerOptions}
                questionId={this.state.questionId}
                question={this.state.question}
                questionTotal={this.state.quizQuestions.length}
                onAnswerSelected={this.handleAnswerSelected}
                setPreviousQuestion={this.setPreviousQuestion}
                setNextQuestion={this.setNextQuestion}
                questionType={this.state.questionType}
                handleChange={this.handleChange}
                handleSubmit={this.handleSubmit}
                mcqType={this.state.mcqType}
                sendingMultipleOptionsArray={(key) => {
                  if (MultipleAnswerArray.length === 0) {
                    MultipleAnswerArray.push(key);
                  }
                  else {
                    let isKeyPresent = false;
                    for (let i = 0; i < MultipleAnswerArray.length; i++) {
                      if (key === MultipleAnswerArray[i]) {
                        isKeyPresent = true;
                        let first = MultipleAnswerArray[0];
                        MultipleAnswerArray[0] = MultipleAnswerArray[i];
                        MultipleAnswerArray[i] = first;
                        MultipleAnswerArray.shift();
                      }
                    }
                    if (!isKeyPresent) {
                      MultipleAnswerArray.push(key);
                    }

                  }
                  this.setState({ MultipleAnswerArray: MultipleAnswerArray });
                }}
                handleMultipleChoiceSubmit={this.handleMultipleChoiceSubmit}
                listOfAnswers={this.state.quizQuestions[this.state.counter].list_of_answers}
              />
            </div>) : (<Result GoBack={() => { this.props.history.push(`/courseDetails/${this.state.navigatedData.courseId}`); }} quizResult={this.state.result} score={this.state.score} quizLength={this.state.quizQuestions.length} totalScore={this.state.totalScore} />)}
        </div>) : (<div>
          this module doesnt have exercise
        </div>)}

      </div>
    )
  }
}