import React from 'react';
import Card from 'react-bootstrap/Card';
import { LinkContainer } from 'react-router-bootstrap'

export const CourseCard = ({ arg, index }) => {
    return (
        <LinkContainer to={{
            pathname: `/courseintro/${arg._id}`,
            data: arg,
        }} >
            <a href={`/courseintro/${arg._id}`}>
                <li key={index} >
                    <Card style={{ width: '20rem', height: 'auto', elevation: 10, marginTop: 10, marginRight: 40, borderRadius: 10, boxShadow: "1px 1px 5px #9E9E9E", }} >

                        <div >
                            <Card.Img variant="top" src={arg.card_image_file} style={{ height: 200, width: '100%' }} />

                            <Card.Body style={{ lineHeight: 1, alignItems: 'center', textAlign: 'center' }}>
                                <Card.Title >
                                    {arg.course_title}
                                </Card.Title>

                                <div style={{ color: '#666', display: 'flex', flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around' }}>{arg.instructor.map((instructor, index) => {
                                    return <p key={index}> {instructor.name} </p>
                                })}</div><div style={{ flexDirection: 'row', display: 'flex', justifyContent: 'space-around' }}>
                                    <p style={{ fontSize: 13, marginRight: 10, color: '#2e2e2e' }}>Course Credit: {arg.credit}</p>
                                    <p style={{ fontSize: 13, marginLeft: 10, color: '#2e2e2e' }}>Duration(Minutes): {arg.duration_in_min}</p>
                                </div>
                            </Card.Body>

                        </div>

                    </Card>
                </li>
            </a>
        </LinkContainer>
    )
}