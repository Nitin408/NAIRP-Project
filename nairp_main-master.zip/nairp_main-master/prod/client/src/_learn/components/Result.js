import React from 'react';
import PropTypes from 'prop-types';
import Card from 'react-bootstrap/Card';

import Button from 'react-bootstrap/Button'
import { IoIosArrowRoundBack } from "react-icons/io"
const Result = (props) => {
  return (
    <div style={{ justifyContent: 'center', alignItems: 'center', width: '90%', height: "100%", marginLeft:"5%", marginRight:"5%" }}>
      <div onClick={()=>{props.GoBack()}} style={{ padding:0, backgroundColor:'#fff',position:"fixed",right:10}}>
        <Button style={{ backgroundColor:"white", border:"#000 2px solid",color:"black", elevation:10}}>    
      <IoIosArrowRoundBack style={{color:"black", fontSize:30,}}/>Return to Course Module Page</Button>
    </div>
      <div style={{ fontSize: 40, fontWeight: 30 }} >Score: {props.score}/{props.totalScore}</div>
      <div>
        Your Answer Progress: {props.quizResult.map(arg => {
          let isCorrect=false;
          if(arg['mcqType']==="singlechoice"){
            if(arg['answerSelected']===arg['listOfAnswers'][0]){
              isCorrect=true;
            }
            else{
              isCorrect= false;
            }
          }
          else if(arg['mcqType']==="multichoice"){
            isCorrect= arg["listOfAnswers"].every(val => arg["answerSelected"].includes(val))
          }
          else{
            if(arg['answerSelected']===arg['listOfAnswers'][0]){
              isCorrect=true;
            }
            else{
              isCorrect= false;
            }
          }
        return (<div style={{width: '100%', marginTop:30}}>
          <div style={{width: '100%'}}>
            <Card style={{width: '100%'}}>
              <Card.Header>{((arg['question'].indexOf("$$")=== -1))?
                (arg['question']):(arg['question'].substring(0, arg['question'].indexOf("$$")) + " ______________ "+arg['question'].substring(arg['question'].indexOf("$$") +2))
              }</Card.Header>
              <Card.Body>
                <blockquote className="blockquote mb-0">
                <p >your selected answers are:</p>
                  <p>
                  {(typeof(arg['answerSelected'])==="object")?(arg['answerSelected'].join()):(arg['answerSelected'])}
                  </p>
                  <footer className="blockquote-footer">
                    {(isCorrect)?(<p style={{color:"green"}}>Right</p>):(<p style={{color:"red"}}>Wrong</p>)}
                  </footer>
                </blockquote>
              </Card.Body>
            </Card>
          </div>
        </div>)
      })}

      </div>
    </div>
  )
}

Result.propTypes = {
  quizResult: PropTypes.string.isRequired
};

export default Result;
