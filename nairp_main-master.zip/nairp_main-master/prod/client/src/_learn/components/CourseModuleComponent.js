import React from 'react'
import Card from 'react-bootstrap/Card';
import Accordion from 'react-bootstrap/Accordion'
import Button from 'react-bootstrap/Button'
import ReactPlayer from 'react-player'
import Spinner from 'react-bootstrap/Spinner'
import ButtonToolbar from 'react-bootstrap/ButtonToolbar'
export const CourseModuleComponent=({arg,demoStart,getUrl,demoStop,createInstance, indexM, st, c, e, loading, StartButtonPressedandLoadingTrue, userDetails, score, callBackforStartButtonPressedandLoadingTrue})=>{
return(
<div key={indexM} style={{ border: '2px solid #eee', padding: 30, marginTop: 10 }}>
                    <div > <p style={{ color: '#888', fontSize: 25 }}>{arg.module_id}. {arg.module_title}</p></div>
                    {arg.lecture.map((larg, index) => {
                      return (
                        <Accordion key={index} style={{ width: '100%', height: 100, marginBottom: 10, }}>
                          <div id="lecture blocks" style={{ marginBottom: 10, width: '100%', height: 'auto', float: 'right', display: 'flex', flexDirection: 'row' }}>
                            <div style={{ width: '75%', borderTopLeftRadius: 5, borderBottomLeftRadius: 5, backgroundColor: '#f0f0f0', height: '100%', paddingLeft: '2%', display: 'flex', justifyContent: 'space-around', flexDirection: 'column' }}>
                              <p style={{ fontSize: 20, marginTop: 20 }}>{larg.lecture_id}. {larg.lecture_title}</p>
                              {(larg.lecture_note != null) ? (
                                <div style={{ height: '100%', width: '100%' }}>
                                  <Accordion.Toggle as={Button} variant="link" eventKey="0" style={{ textDecoration: 'none', height: '100%', width: '100%' }} >
                                    <p style={{ fontSize: 20, color: 'blue' }}> Lecture Note </p>
                                  </Accordion.Toggle>

                                  <Accordion.Collapse eventKey="0" key={index}>

                                    <Card.Body>
                                      <div style={{ width: '100%', height: 400 }}><iframe style={{ height: '100%' }} src={"../pdf.pdf"} title="Note" crossorigin /></div>

                                    </Card.Body>

                                  </Accordion.Collapse>

                                </div>
                              ) : ("")}
                            </div>
                            <div id="video comes here" style={{ width: '25%', height: '100%' }}>
                              <ReactPlayer url={larg.lecture_video} width="100%" height="100%" controls={true} />
                            </div>

                          </div>
                        </Accordion>
                      )
                    })
                    }
                    {

                      (st === "ON" || st === "TERM") ? (<ButtonToolbar style={{ width: '100%' }}>
                        <Button onClick={() => { getUrl(c, e) }} variant="secondary" style={{ marginLeft: 5, marginRight: 5, marginTop: 5, width: '48%' }}>Take me to AWS SageMaker for programming exercise </Button>
                        <div style={{ width: '48%', borderRadius: 10, border: '1px #a1a1a1 solid', justifyContent: 'centre', paddingTop: "0.7%", paddingLeft: '4%' }}>Score for programming exercise:  {score} </div>
                        <Button variant="danger" onClick={() => { demoStop(c, e); callBackforStartButtonPressedandLoadingTrue(false) }} style={{ marginLeft: 5, marginRight: 5, marginTop: 5, width: '100%' }}>Stop AWS SageMaker instance</Button>
                      </ButtonToolbar>) : (<ButtonToolbar style={{ width: '100%' }}>
                        <Button onClick={() => {
                          demoStart(c,e);
                          createInstance();
                          if (loading) {
                            callBackforStartButtonPressedandLoadingTrue(true)
                          }
                          else {
                            callBackforStartButtonPressedandLoadingTrue(false)
                          }
                        }} variant="success" style={{ marginLeft: 5, marginRight: 5, marginTop: 5, width: '100%' }}>{
                            (StartButtonPressedandLoadingTrue) ? (<div><Spinner animation="border" /><div>Please wait while AWS SageMaker instance starts (usually it takes 4-5 minutes)</div></div>) : ('Start AWS SageMaker instance')
                          }</Button>
                      </ButtonToolbar>
                        )
                    }
                    

                  </div>)}