import React from 'react';
import Carousel from 'react-bootstrap/Carousel'
export const CarouselComponent = ({ bannerArray, courseData }) => {
    return (
        <div style={{ width: "98%" }}>
        <Carousel interval={1500} style={{ width: "100%",borderRadius: 10, borderColor: '#000', borderWidth: 2 }} >

            {courseData.map((arg, index)=>{
                
                
                return(
                    
                    (arg.add_to_carousal===true)?( <Carousel.Item key={index} style={{ height:300, borderRadius: 10, borderColor: '#000', borderWidth: 2 }}>
                <img
                    className="d-block w-100"
                   src={bannerArray[index]}
                    alt={index + " slide"}
                    style={{width:'100%', height:'100%'}}
                />

                <Carousel.Caption>
                    <h3 style={{ color: "#000" }}  >{arg.course_title}</h3>
                    
                </Carousel.Caption>
            </Carousel.Item>):("")
            )
        
            })
                }
            
        </Carousel>
    </div>
    )
}