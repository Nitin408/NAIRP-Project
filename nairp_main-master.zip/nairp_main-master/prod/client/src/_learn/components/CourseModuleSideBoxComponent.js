import React from 'react'
//import Container from 'react-bootstrap/Container'
// import Row from 'react-bootstrap/Row'
// import Col from 'react-bootstrap/Col'
import Card from 'react-bootstrap/Card'
//import * as requiredData from "./requiredData.json"
export const CourseModuleSideBoxComponent = ({requiredData})=>{
    return(
    <div style={{ borderWidth: 2, borderColor: '#000', borderRadius: 10, width: '100%', height: 200, }}>
                <Card text="a1a1a1" style={{ width: '100%', height: 'auto', boxShadow: "1px 1px 5px #9E9E9E", borderRadius: 10 }}>

                  <Card.Body style={{ width: 'auto', height: 'auto' }}>
                  <Card.Title style={{ alignItems: 'center', textAlign: 'center' }}>Course Info</Card.Title>
                  <Card.Text style={{ lineHeight: 1, marginTop: 20 }}>
                    <h4 style={{ color: '#666', fontSize: 20 }}>Prerequisite Course Title:</h4>
                    <p style={{ color: '#999' }}>{requiredData.prerequisite_preexisting_course_title_list.map((a) => <li key={a}>{a}</li>)}</p>
                    <h4 style={{ color: '#666', fontSize: 20 }}>Reference Material:</h4>
						{/*<p style={{ color: '#999' }}>{requiredData.reference_material_file}</p>*/}
                    <h4 style={{ color: '#666', fontSize: 20 }}>Communication Language:</h4>
                    <p style={{ color: '#999' }}>{requiredData.communication_language}</p>
					<h4 style={{ color: '#666', fontSize: 20 }}>Credits for this course:</h4>
                    <p style={{ color: '#999' }}>{requiredData.credit}</p>
					<h4 style={{ color: '#666', fontSize: 20 }}>Course Created On:</h4>
                    <p style={{ color: '#999' }}>{requiredData.created_on}</p>
					<h4 style={{ color: '#666', fontSize: 20 }}>Offering Period:</h4>
					<li style={{ color: '#666', fontSize: 15 }}>From :	{requiredData.offering_period_from_to[0]}</li>
					<li style={{ color: '#666', fontSize: 15 }}>To :  	  {requiredData.offering_period_from_to[1]}</li>


                    </Card.Text>
                  </Card.Body>
                </Card>
                <div style={{ flexWrap: 'wrap', display: 'flex', float: 'left', marginTop: 20 }}>
                  <div>total score comes here</div>

                </div>
              </div>
)}