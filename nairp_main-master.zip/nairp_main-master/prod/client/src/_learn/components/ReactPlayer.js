import React from 'react';
import ReactPlayer from 'react-player'
import axios from 'axios';
// import MathJax from 'react-mathjax';
// const tex = `f(x) = \\int_{-\\infty}^\\infty
//     \\hat f(\\xi)\\,e^{2 \\pi i \\xi x}
//     \\,d\\xi`

export const ReactPlayerComponent = ({requiredData , course_description}) => {
	let data, data1;

    const apiURL = requiredData.course_description;

    const fetchData = async () => {
        const response = await fetch(apiURL)
		const response1 = await axios.get(apiURL)
        data = response.Headers["Content-Type"];
        data1 = response1;
		
    }
	console.log(data, data1)
    return (
        <div>        <div style={{ height: 400 }}>
            <div className="video" style={{ width: '90%', height: '100%' }}>
      
             <ReactPlayer className="viewer" onReady={()=>console.log("ready")} onError={()=>{console.log("not ready")}} url={requiredData.course_intro_video} width="100%" height="100%" controls={true} /> 
            </div>
        </div>

        <div className="courseDescription" xs={3} style={{ width: '90%', height: 'auto', marginLeft: '3%', justifyContent: 'center', alignItems: 'center', marginTop: '5%' }}>
            <div style={{ justifyContent: 'flex-end' }}>
                <p style={{ fontSize: 30, color: '#555' }}>{requiredData.module[0].module_title} </p>
                {/* <MathJax.Provider>
            <div>
                <MathJax.Node formula={tex} />
            </div>
        </MathJax.Provider> */}
				{course_description}
                <p>{data}</p>
            </div>

        </div>
        </div>

    )
}