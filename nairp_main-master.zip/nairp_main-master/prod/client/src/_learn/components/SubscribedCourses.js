import React from 'react';
import Accordion from 'react-bootstrap/Accordion'
import { LinkContainer } from 'react-router-bootstrap'
import Card from 'react-bootstrap/Card';
export const SubscribedCourses = ({arg,index }) => {
    return(<Accordion.Collapse eventKey="0" key={index}>
        <LinkContainer to={{
            pathname: `/courseintro/${arg._id}`,
            data: arg,
        }}><a href={`/courseintro/${arg._id}`}>
                <Card.Body>
                    {arg["course_title"]}

                </Card.Body>
            </a>
        </LinkContainer>
    </Accordion.Collapse>)
}