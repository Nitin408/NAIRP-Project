import React from 'react';
import PropTypes from 'prop-types';

function AnswerOption(props) {
  return (
    <li className="answerOption">
      {(props.mcqType==="singlechoice")?(<input
        type="radio"
        className="radioCustomButton"
        name="radioGroup"
        onClick={()=>console.log(props.answer)}
        checked={props.answerType === props.answer}
        id={props.answerType}
        value={props.answerType}
        disabled={props.answer}
        onChange={props.onAnswerSelected}
      />):(<input
        type="checkbox"
        className="radioCustomButtonM"
        name="radioGroup"
        style={{borderRadius:0, border:"#fff"}}
        id={props.answerType}
        value={props.answerType}
        //onCheck={()=>console.log(props.answerContent)}
        onClick={()=>{props.sendingMultipleOptions(props.answerContent)}}
      />)}
      <label className="radioCustomLabel" htmlFor={props.answerType}>
        {props.answerContent}
      </label>
    </li>
  );
}

AnswerOption.propTypes = {
  answerType: PropTypes.string.isRequired,
  answerContent: PropTypes.string.isRequired,
  answer: PropTypes.string.isRequired,
  onAnswerSelected: PropTypes.func.isRequired
};

export default AnswerOption;
