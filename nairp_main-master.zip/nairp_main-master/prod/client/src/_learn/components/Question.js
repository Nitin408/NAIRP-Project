import React from 'react';
import PropTypes from 'prop-types';
// import Form from 'react-bootstrap/Form'
import Row from 'react-bootstrap/Row'
// import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'
function Question(props) {
  let questionType = props.questionType;
  let mcqType = props.mcqType;
  let fillupAnswer = props.fillupAnswer;
  if (questionType === "mcq") {
    return (<div><h2 className="question">{(mcqType === "singlechoice")?(props.content):(props.content + "     (Please select all the correct answers)")}</h2> </div>);
  }
  else if (questionType === "fillUp") {
    let question = props.content;
    let InputPlace = question.indexOf("$$");
    let AnswerLength = fillupAnswer[0].length;
    let lengthOfInputBox = 300;
    if(AnswerLength> 20){
      lengthOfInputBox = lengthOfInputBox + (AnswerLength -20)*22
    }
    return (
    <div style={{width: '100%', height:"100%"}}>
    <h2 className="question"><Row> {question.substring(0, InputPlace) + " "} 
    <form style={{width:lengthOfInputBox, marginLeft:10, marginRight:10}}>
      <input onChange={props.handleChange} style={{width: lengthOfInputBox}} />
    </form>
      {" "+question.substring(InputPlace + 2)}</Row>
    </h2>
        <Button onClick={props.handleSubmit} style={{width:100,marginTop:150, marginLeft:"40%", marginRight:"40%"}}>Submit </Button>
       </div>
       )
  }
      
    
  else {
    return (<div>Loading.....</div>)
  }
}

Question.propTypes = {
  content: PropTypes.string.isRequired
};

export default Question;
