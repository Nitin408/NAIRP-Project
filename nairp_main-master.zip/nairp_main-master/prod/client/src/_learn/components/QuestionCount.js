import React from 'react';
import PropTypes from 'prop-types';
import Button from 'react-bootstrap/Button'
import { IoIosArrowRoundForward, IoIosArrowRoundBack } from "react-icons/io";
function QuestionCount(props) {
  return (
    <div className="questionCount">
    { (props.counter!==1)?(<Button onClick={props.setPreviousQuestion} style={{margin:0,marginRight:5, padding:0, backgroundColor:'#fff',}}>
      <IoIosArrowRoundBack style={{color:"blue", fontSize:30}}/>
    </Button>):("")}
      Question 
      <span>{props.counter}</span> of <span>{props.total}</span>
   {(props.counter < props.total)?( <Button onClick={props.setNextQuestion} style={{margin:0, padding:0, backgroundColor:'#fff',marginLeft:5}}>
      <IoIosArrowRoundForward style={{color:"blue", fontSize:30}}/>
    </Button>):("")}

    <p style={{color:"#999"}}>(Old answer that you entered will be deleted if you attempt new submission on question after navigating and previously submitted answers are stored but not shown)</p>
    </div>
  );
}

QuestionCount.propTypes = {
  counter: PropTypes.number.isRequired,
  total: PropTypes.number.isRequired
};

export default QuestionCount;
