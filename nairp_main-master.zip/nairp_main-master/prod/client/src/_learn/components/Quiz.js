import React from 'react';
import PropTypes from 'prop-types';
import { CSSTransition } from 'react-transition-group';
import Question from '../components/Question';
import QuestionCount from '../components/QuestionCount';
import AnswerOption from '../components/AnswerOption';
import Button from 'react-bootstrap/Button'
function Quiz(props) {
  
  function renderAnswerOptions(key) {
    
    return (
      <AnswerOption
        key={key}
        answerContent={key}
        answerType={key}
        answer={props.answer}
        questionId={props.questionId}
        onAnswerSelected={props.onAnswerSelected}
        mcqType={props.mcqType}
        sendingMultipleOptions={()=>{
          props.sendingMultipleOptionsArray(key);
        }}
      />
    );
  }
  return (
    <CSSTransition
      className="container"
      component="div"
      transitionName="fade"
      transitionEnterTimeout={800}
      transitionLeaveTimeout={500}
      transitionAppear
      transitionAppearTimeout={500}
    >
      {(props.questionType==="mcq")?(<div key={props.questionId} >
       {(props.mcqType==="singlechoice")?( <div style={{border:'#000 1px solid', padding:20, borderRadius: 10}}> <QuestionCount setPreviousQuestion={props.setPreviousQuestion} setNextQuestion={props.setNextQuestion} counter={props.questionId} total={props.questionTotal} />
        <Question content={props.question} mcqType={props.mcqType} questionType={props.questionType}/>
        <ul className="answerOptions">
          {props.answerOptions.map(renderAnswerOptions)}
        </ul></div>):(
          <div><div style={{border:'#000 1px solid', padding:20, borderRadius: 10}}> <QuestionCount setPreviousQuestion={props.setPreviousQuestion} setNextQuestion={props.setNextQuestion} counter={props.questionId} total={props.questionTotal} />
        <Question content={props.question} mcqType={props.mcqType} questionType={props.questionType}/>
        <ul className="answerOptions">
          {props.answerOptions.map(renderAnswerOptions)}
        </ul>
        <Button onClick={props.handleMultipleChoiceSubmit} style={{width:100,marginTop:100, marginLeft:"40%", marginRight:"40%"}}>Submit </Button>
        </div>
        </div>
        )}
      </div>):(
        <div key={props.questionId} style={{border:'#000 1px solid', padding:20, borderRadius: 10}}>
        <QuestionCount setPreviousQuestion={props.setPreviousQuestion} setNextQuestion={props.setNextQuestion} counter={props.questionId} total={props.questionTotal} />
        <Question fillupAnswer={props.listOfAnswers} content={props.question} questionType={props.questionType} handleChange={props.handleChange} handleSubmit={props.handleSubmit}/>
        
      </div>
      )}
    </CSSTransition>
  );
}

Quiz.propTypes = {
  answer: PropTypes.string.isRequired,
  answerOptions: PropTypes.array.isRequired,
  question: PropTypes.string.isRequired,
  questionId: PropTypes.number.isRequired,
  questionTotal: PropTypes.number.isRequired,
  onAnswerSelected: PropTypes.func.isRequired
};

export default Quiz;
