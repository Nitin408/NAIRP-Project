import React from 'react';
import Card from 'react-bootstrap/Card';
import Accordion from 'react-bootstrap/Accordion'
import Button from 'react-bootstrap/Button'
export const CourseIntroSideBox = ({requiredData})=>{
    return(
        <Card.Body style={{ width: 'auto', height: 'auto' }}>
                  <Card.Title style={{ alignItems: 'center', textAlign: 'center' }}>Course Info</Card.Title>
                  <Card.Text style={{ lineHeight: 1, marginTop: 20 }}>
                    <h4 style={{ color: '#666', fontSize: 20 }}>Prerequisite Course Title:</h4>
                    <p style={{ color: '#999' }}>{requiredData.prerequisite_preexisting_course_title_list.map((a) => <li key={a}>{a}</li>)}</p>
                    <h4 style={{ color: '#666', fontSize: 20 }}>Reference Material:</h4>
						{/*<p style={{ color: '#999' }}>{requiredData.reference_material_file}</p>*/}
                    <h4 style={{ color: '#666', fontSize: 20 }}>Communication Language:</h4>
                    <p style={{ color: '#999' }}>{requiredData.communication_language}</p>
					<h4 style={{ color: '#666', fontSize: 20 }}>Credits for this course:</h4>
                    <p style={{ color: '#999' }}>{requiredData.credit}</p>
					<h4 style={{ color: '#666', fontSize: 20 }}>Course Created On:</h4>
                    <p style={{ color: '#999' }}>{requiredData.created_on}</p>
					<h4 style={{ color: '#666', fontSize: 20 }}>Offering Period:</h4>
					<li style={{ color: '#666', fontSize: 15 }}>From :	{requiredData.offering_period_from_to[0]}</li>
					<li style={{ color: '#666', fontSize: 15 }}>To :  	  {requiredData.offering_period_from_to[1]}</li>
					

						{/*<p style={{ color: '#999' }}>{requiredData.offering_period.split(' ').slice(0, 4).join(" ")}</p>*/}
                    <div style={{ alignItems: 'center', textAlign: 'center' }}><Accordion style={{ backgroundColor: '#eee', width: '100%', height: 'auto', }}>
                      <Card style={{ width: '100%', height: 'auto', border: 'none' }}>
                       <Accordion.Toggle as={Button} variant="link" eventKey="0" style={{ width: '100%', height: '100%', backgroundColor: 'eee', justifyContent: 'center', alignItems: 'center', textAlign: 'center', textDecoration: 'none', textDecorationLine: 'none' }}><Card.Header style={{ justifyContent: 'center', alignItems: 'center', textAlign: 'center' }}>
                          <p style={{ fontSize: 20, textDecoration: 'none', textDecorationLine: 'none', marginTop: '3%' }}>This Course Includes </p>
                        </Card.Header></Accordion.Toggle>
                        
                        {
                           requiredData.module.map((arg, index)=>{
                            return(
                             
                             <Accordion.Collapse eventKey="0" key={arg.module_id}>
                               
                            <p> <Card.Body>{index +1}. {arg.module_title}</Card.Body></p>
                             
                             </Accordion.Collapse>
                             )
                          })
                         }      

                      </Card>
                    </Accordion></div>

                  </Card.Text>
                </Card.Body>
    )
}