import axios from 'axios'
import {history} from '../../clientMisc'
import {SET_PROFILE, SET_TOKEN} from '../utils/constants'


export const getProfile = (data) => dispatch => {
    const jwt = localStorage.getItem("my-jwt");
    if (!jwt){
        history.push('/login');
        return
    }
    axios.post('/api/profile/get_profile', {
            token: jwt
        })
        .then(res => {
            if(res && res.data && res.data.success === true) {
                
                dispatch({
                    type: SET_PROFILE,
                    payload: {
                        firstName: res.data.firstName,
                        middleName: res.data.middleName,
                        lastName: res.data.lastName,
                        email: res.data.email,
                        educationalLevel: res.data.educationalLevel,
                        dob: res.data.dob,
                        country: res.data.country,
                        state: res.data.state,
                        gender: res.data.gender,
                        profession: res.data.profession,
                    }
                })

            } else {
                history.push(`/login`)
            }
        })
        .catch(err => {
            console.log(err)
            alert("Some error occured! Please try again")
            history.push(`/login`)
            return Promise.reject(err)
        });

}


export const editProfile = (data) => dispatch => {
    const jwt = localStorage.getItem("my-jwt");
    if (!jwt){
        history.push('/login');
        return
    }
    axios.post('/api/profile/edit_profile', {
            firstName: data.firstName,
            middleName: data.middleName,
            lastName: data.lastName,
            email: data.email,
            dob: data.dob,
            gender: data.gender,
            educationalLevel: data.educationalLevel,
            profession: data.profession,
            country: data.country,
            state: data.state,
            captchaVerifyResponse: data.captchaVerifyResponse
    })
        .then(res => {
            if(res && res.data && res.data.success === true) {
                
                dispatch({
                    type: SET_PROFILE,
                    payload: {
                        firstName: data.firstName,
                        middleName: data.middleName,
                        lastName: data.lastName,
                        email: data.email,
                        educationalLevel: data.educationalLevel,
                        dob: data.dob,
                        country: data.country,
                        state: data.state,
                        gender: data.gender,
                        profession: data.profession,
                    }
                })

                history.push('/profile')

            } else {
                history.push(`/login`)
            }
        })
        .catch(err => {
            console.log(err)
            alert("Some error occured! Please try again")
            history.push(`/login`)
            return Promise.reject(err)
        });

}


export const completeProfile = (data) => dispatch => {

    axios.post('/api/profile/complete_user_details', {
            email: data.email,
            dob: data.dob,
            gender: data.gender,
            educationalLevel: data.educationalLevel,
            profession: data.profession,
            country: data.country,
            state: data.state,
            password: data.password,
            captchaVerifyResponse: data.captchaVerifyResponse
    })
        .then(res => {
            if(res && res.data && res.data.success === true) {
                alert(res.data.message);
                localStorage.setItem("my-jwt", res.data.token);
                dispatch({
                    type: SET_TOKEN,
                    payload: {
                        token: res.data.token
                    }
                })
                history.push('/profile')

            } else {
                alert(res.data.message);
                history.push(`/login`)
            }
        })
        .catch(err => {
            console.log(err)
            alert("Some error occured! Please try again")
            history.push(`/login`)
            return Promise.reject(err)
        });

}