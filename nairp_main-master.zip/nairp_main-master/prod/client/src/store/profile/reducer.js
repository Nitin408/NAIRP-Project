import {SET_PROFILE,REMOVE_PROFILE} from '../utils/constants'

let initialState = {
    firstName: "",
    middleName: "",
    lastName: "",
    email: "",
    educationalLevel: "",
    dob: "",
    country: "",
    state: "",
    gender: "",
    profession: ""
}

export default function profileReducer(state = initialState, action){
    switch(action.type){
        case SET_PROFILE:
            return {
                ...state,
                firstName: action.payload.firstName,
                middleName: action.payload.middleName,
                lastName: action.payload.lastName,
                email: action.payload.email,
                educationalLevel: action.payload.educationalLevel,
                dob: action.payload.dob,
                country: action.payload.country,
                state: action.payload.state,
                gender: action.payload.gender,
                profession: action.payload.profession
            }
        case REMOVE_PROFILE:
            return initialState
        default:
            return state
    }
}