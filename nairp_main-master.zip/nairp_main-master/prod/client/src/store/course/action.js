import {history} from '../../clientMisc'
import {SET_COURSES} from '../utils/constants'

export const fetchCourses = () => dispatch => {

    fetch('/api/course/learn')
        .then( (response) => {
            console.log("fetching course data")
            let jsonStr = response.json();
            jsonStr.then((result) => {
                let Data = [];
                for (let i in result) {
                    Data.push(result[i]);
                }
                
                dispatch({
                    type: SET_COURSES,
                    payload: {
                        Data: Data
                    }
                })
            })

        })
        .catch(err => {
            console.log(err)
            alert("Some error occured! Please try again")
            history.push(`/login`)
            return Promise.reject(err)
        });

}


export const validateCachedCourses = (data) => dispatch => {

    fetch('/api/course/learn')
        .then( (response) => {
            console.log("Validating course data")
            let jsonStr = response.json();
            jsonStr.then((result) => {
                let Data = [];
                for (let i in result) {
                    Data.push(result[i]);
                }

                var current = JSON.stringify(data)
                var latest = JSON.stringify(Data)

                if(current.length !== latest.length || current !== latest){
                    dispatch({
                        type: SET_COURSES,
                        payload: {
                            Data: Data
                        }
                    })
                    console.log("Current cache updated")
                }else{
                    console.log("Current cache is latest")
                }
                
                
            })

        })
        .catch(err => {
            console.log(err)
            alert("Some error occured! Please try again")
            history.push(`/login`)
            return Promise.reject(err)
        });

}