import {SET_COURSES} from '../utils/constants'

let initialState = {
    cData: []
}

export default function courseReducer(state = initialState, action){
    switch(action.type){
        case SET_COURSES:
            return {
                ...state,
                cData: action.payload.Data
            }
        default:
            return state
    }
}