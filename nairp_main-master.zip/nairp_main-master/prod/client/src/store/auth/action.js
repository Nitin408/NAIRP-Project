import axios from 'axios'
import {history} from '../../clientMisc'
import {LOGIN, LOGOUT, REMOVE_PROFILE} from '../utils/constants'

export const signup = (data) => dispatch => {

    axios.post('/api/auth/signup', {
            firstName: data.firstName,
            middleName: data.middleName,
            lastName: data.lastName,
            email: data.email,
            dob: data.dob,
            gender: data.gender,
            educationalLevel: data.educationalLevel,
            profession: data.profession,
            country: data.country,
            state: data.state,
            password: data.password,
            captchaVerifyResponse: data.captchaVerifyResponse
        })
        .then(res => {
            //console.log(res.data);
            if (res.data.success === true) {
                history.push(`/verify_email`)
            } else {
                alert(res.data.message);
            }
        })
        .catch(err => {
            console.log(err)
            alert("Some error occured! Please try again")
            return Promise.reject(err)
        });

}


export const login = (data) => dispatch => {

    axios.post('/api/auth/login', {
        email: data.email,
        password: data.password,
        captchaVerifyResponse: data.captchaVerifyResponse
        })
        .then(res => {
            // console.log(res.data);
            if (res.data && res.data.success === true) {
                localStorage.setItem("my-jwt", res.data.token);

                dispatch({
                    type: LOGIN,
                    payload: {
                        email: res.data.email,
                        token: res.data.token
                    }
                })

                history.push(`/profile`);

            } else {
                alert(res.data.message);
            }
        })
        .catch(err => {
            console.log(err)
            alert("Some error occured! Please try again")
            return Promise.reject(err)
        });

}

export const logout = () => dispatch => {
    localStorage.removeItem('my-jwt')
    history.push('/login')
    dispatch({type: REMOVE_PROFILE})
    dispatch({type: LOGOUT})
}

export const resetPassword = (data) => dispatch => {

    axios.post('/api/auth/reset_password', {
        email: data.email,
        password: data.password
        })
        .then(res => {
            if (res.data && res.data.success === true) {
                alert(res.data.message)
                history.push("/login")
            } else {
                alert(res.data.message);
                history.push("/forgot_password")
            }
        })
        .catch(err => {
            console.log(err)
            alert("Some error occured! Please try again")
            return Promise.reject(err)
        });
}