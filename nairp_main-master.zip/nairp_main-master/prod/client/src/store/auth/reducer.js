import {LOGIN, LOGOUT, SET_TOKEN} from '../utils/constants'


let initialState = {
    email: "",
    profile: {},
    token: "",
    loggedIn: false
}

export default function authReducer(state = initialState, action){
    switch(action.type){
        case LOGIN:
            return {
                ...state,
                email: action.payload.email,
                token: action.payload.token,
                loggedIn: true
            }
        case SET_TOKEN:
            return {
                ...state,
                token: action.payload.token
            }
        case LOGOUT:
            return initialState
        default:
            return state
    }
}