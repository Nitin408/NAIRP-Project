import {GET_RESOURCES_S3,REMOVE_RESOURCES} from '../utils/constants'

let initialState = {
    s3data: [],
    home_carousal_page_info_ads: [],
    home_carousal_new_courses: [],
    home_project_info_slideshow: [],
    logo: []
}

export default function resourceReducer(state = initialState, action){
    switch(action.type){
        case GET_RESOURCES_S3:
            return {
                ...state,
                s3data: action.payload.s3data,
                home_carousal_page_info_ads: action.payload.home_carousal_page_info_ads,
                home_carousal_new_courses: action.payload.home_carousal_new_courses,
                home_project_info_slideshow: action.payload.home_project_info_slideshow,
                logo: action.payload.logo
            }
        case REMOVE_RESOURCES:
            return initialState
        default:
            return state
    }
}