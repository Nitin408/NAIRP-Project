import { CDN_domain_name } from '../../clientMisc';
import {GET_RESOURCES_S3,REMOVE_RESOURCES} from '../utils/constants'

export const getResourcesFromS3 = () => dispatch => {

    fetch('/GetMediaContentFromS3Bucket')
        .then((res) => {
            let jsonStr = res.json();
            jsonStr.then((result) => {

                let s3data = [];
                let home_carousal_page_info_ads = [];
                let home_carousal_new_courses = [];
                let home_project_info_slideshow = [];
                let logo = [];
                
                for (let i in result) {
                    if(result[i]['Size']!==0){
                        let FolderName = result[i]['Key'].split('/')[0];
                        if(FolderName==='home-carousal-page-info-ads'){ 
                            home_carousal_page_info_ads.push('https://' + CDN_domain_name + '/' + result[i]['Key']);
                        }
                        else if(FolderName==='home-carousal-new-courses'){ 
                            home_carousal_new_courses.push('https://' + CDN_domain_name + '/'+ result[i]['Key']);
                        }
                        else if(FolderName==='home-project-info-slideshow'){
                            home_project_info_slideshow.push('https://' + CDN_domain_name + '/'+ result[i]['Key']);
                        }
                        else if(FolderName==='logo'){
                            logo.push('https://' + CDN_domain_name + '/'+ result[i]['Key']);
                        }
                        s3data.push(result[i]);
                    }
                }

                console.log(s3data)

                dispatch({
                    type: GET_RESOURCES_S3,
                    payload: {
                        s3data, 
                        home_carousal_page_info_ads,
                        home_carousal_new_courses,
                        home_project_info_slideshow,
                        logo
                    }
                })
            })
        })
        .catch(err => {
            console.log(err)
            alert("Some error occured while fetching resources!")
            return Promise.reject(err)
        });

}


export const removeResources = () => dispatch => {
    dispatch({
        type: REMOVE_RESOURCES
    })
}