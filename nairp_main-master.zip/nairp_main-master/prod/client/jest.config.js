module.exports ={
    verbose: true,
    setupFiles: [
        '<rootDir>/tests/setup.js'
    ],
    
    "reporters": [ "default", [ 'jest-junit', {
        outputDirectory: '../test_reports',
        outputName: 'client.xml',
      } ] ],
    
    transformIgnorePatterns: [`/node_modules/`],
}
