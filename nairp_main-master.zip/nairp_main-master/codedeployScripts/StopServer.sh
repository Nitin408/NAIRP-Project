#!/bin/bash

killall -9 -q node || echo "No node process was running."
rm -rf /home/ubuntu/nairp_main
