#!/bin/bash
export PATH=/home/ubuntu/.nvm/versions/node/v12.19.0/bin:$PATH
cd /home/ubuntu/nairp_main/prod/server
NODE_ENV=production pm2 start server.js --log ./run.log