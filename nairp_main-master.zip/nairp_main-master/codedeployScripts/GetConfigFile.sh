#!/bin/bash

sudo -u ubuntu sh -c "cd /home/ubuntu/nairp_main; aws s3 cp s3://config-env-files/.env ./prod/server/" >> /home/ubuntu/s3.txt

